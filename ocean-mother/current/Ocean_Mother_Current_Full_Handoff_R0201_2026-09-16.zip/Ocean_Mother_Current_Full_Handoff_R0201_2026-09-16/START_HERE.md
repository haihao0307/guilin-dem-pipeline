# Ocean Mother authoritative core — START HERE

This package freezes the current working core selected on 2026-09-16.

## Run first

Open `runtime/Ocean_Mother_R018_V0.3.2_Core_Direct_Open.html` directly in a modern browser.

## Core identity

- Nearshore/island: the user-supplied `Ocean_Mother_R018_V0.3.2_Direct_Open.html` visual system.
- Deep ocean: frozen original Ocean Mother V001, embedded in the same single HTML.
- Runtime assets: no image textures, no external models, no external CDN.
- Development policy: micro-adjust this core only. Do not rebuild the island from another branch and do not substitute a simplified compatibility island.

## Read before editing

1. `docs/CORE_BASELINE.json`
2. `docs/CURRENT_CORE.md`
3. `docs/DEPRECATED_LINES.md`
4. `evidence/STATIC_VERIFICATION.json`

## Approval boundary

This is the authoritative development core. `visualApproved` and `productionApproved` remain false until the user explicitly approves a later review version.
