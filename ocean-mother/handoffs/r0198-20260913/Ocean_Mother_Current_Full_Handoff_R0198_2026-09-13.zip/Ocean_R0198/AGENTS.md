先读 START_HERE.md。执行 knowledge_snapshot 中的两份 Mother 共同规则原件；用户最新指令优先。workspace 内旧档案与冻结源保持原样，实验、学习和真实验收状态分别记录。不得恢复撤销工具。
