from pathlib import Path
import json, hashlib
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
expected={e['path']:e for e in manifest['files']}
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and 'rebuilt' not in p.relative_to(root).parts}
# Nested historical manifests remain part of the verified package.
actual.update(p.relative_to(root).as_posix() for p in root.rglob('MANIFEST.json') if p.parent!=root and 'rebuilt' not in p.relative_to(root).parts)
assert actual==set(expected), ('File set mismatch',sorted(actual-set(expected)),sorted(set(expected)-actual))
for rel,e in expected.items():
    data=(root/rel).read_bytes()
    assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'], rel
print('PASS',len(expected),'files; byte lengths and SHA256 verified')
