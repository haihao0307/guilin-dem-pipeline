from pathlib import Path
import json, hashlib
root=Path(__file__).resolve().parent
src=root/'workspace/R0198_Boot_Experiment/source'
page=(src/'page.template.html').read_bytes()
for block in json.loads((src/'source-map.json').read_text())['blocks']:
    marker=block['marker'].encode()
    assert page.count(marker)==1
    page=page.replace(marker,(src/block['file']).read_bytes())
assert page==(root/'workspace/R0198_Boot_Experiment/index.html').read_bytes()
out=root/'rebuilt/R0198/index.html'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_bytes(page)
print('PASS exact rebuild', hashlib.sha256(page).hexdigest())
