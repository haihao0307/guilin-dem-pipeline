"""Prepare an isolated startup experiment; do not publish or change the handoff."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'Ocean_Mother_Current_Full_Handoff_R0197_2026-09-12'
BASE = PACKAGE / 'frozen_visual_source/restart-v0311'
OUT = ROOT / 'R0198_Boot_Experiment'
sha = lambda b: hashlib.sha256(b).hexdigest()

def build(source):
    page = (source / 'page.template.html').read_bytes()
    for block in json.loads((source / 'source-map.json').read_text())['blocks']:
        marker = block['marker'].encode()
        assert page.count(marker) == 1
        page = page.replace(marker, (source / block['file']).read_bytes())
    return page

assert not OUT.exists(), 'Do not overwrite an existing experiment'
assert build(BASE / 'source') == (BASE / 'index.html').read_bytes()
(OUT / 'source').mkdir(parents=True)
for p in (BASE / 'source').iterdir():
    if p.is_file():
        shutil.copy2(p, OUT / 'source' / p.name)

original = (BASE / 'source/inline-0.js').read_bytes()
old = b"document.getElementById('pause').textContent=paused?'\xe7\xbb\xa7\xe7\xbb\xad\xe8\xbf\x90\xe8\xa1\x8c':'\xe6\x9a\x82\xe5\x81\x9c';initRenderer();"
assert original.count(old) == 1
boot = """// R0198 experiment: allow the bound HTML controls to paint before first GPU submission.
// This does not make a driver's shader compilation preemptible.
notice('正在准备海洋渲染');
document.getElementById('loading').classList.add('done');
const initialBootEpoch=epoch;
requestAnimationFrame(()=>requestAnimationFrame(()=>{
 setTimeout(()=>{
  // Retry or context restoration may already own a newer renderer generation.
  if(epoch===initialBootEpoch&&!contextLost&&!rendererReady&&!runtimeError)initRenderer();
 },0);
}));
""".encode()
candidate = original.replace(old, old[:-len(b'initRenderer();')] + boot)
(OUT / 'source/inline-0.js').write_bytes(candidate)
page = (OUT / 'source/page.template.html').read_text(encoding='utf-8')
page = page.replace('Ocean Mother | R018.11 海岛近岸运行修正版', 'Ocean Mother | R0198 启动实验 · 未验收')
page = page.replace('ISLAND GOLD COAST / R018.11', 'R0198 BOOT EXPERIMENT / UNVERIFIED')
(OUT / 'source/page.template.html').write_text(page, encoding='utf-8', newline='')
html = build(OUT / 'source')
(OUT / 'index.html').write_bytes(html)

def block(name, data):
    pattern = rb'const ' + name.encode() + rb'=`([\s\S]*?)`;'
    return re.search(pattern, data).group(1)

protected = {}
for name in ['VERT', 'FRAG', 'PRESENT_FRAG']:
    a, b = block(name, original), block(name, candidate)
    assert a == b
    protected[name] = sha(a)
deep = re.search(rb'const ORIGINAL_DEEP_HTML=(.*);\r?\n', original).group(1)
assert deep == re.search(rb'const ORIGINAL_DEEP_HTML=(.*);\r?\n', candidate).group(1)
protected['ORIGINAL_DEEP_HTML'] = sha(deep)
assert candidate.replace(boot, b'initRenderer();') == original
for name in ['MOTHER_OBJECT_DEFINITION_RULE_2026-09-09.md', 'MOTHER_PUBLIC_PREVIEW_DELIVERY_RULE_2026-09-08.md']:
    shutil.copy2(Path('G:/小妈') / name, ROOT / name)
report = {
    'version': 'R0198-boot-experiment', 'baselineExactRebuild': True,
    'baselineHtmlSha256': sha((BASE / 'index.html').read_bytes()),
    'candidateHtmlSha256': sha(html), 'protectedSourceHashes': protected,
    'onlyRuntimeChange': 'yield before initial initRenderer; stale generations skipped',
    'visualFunctionsAndParametersUnchanged': True,
    'browserABPassed': False, 'iphoneValidated': False, 'published': False,
    'visualApproved': False, 'productionApproved': False,
    'browserBlocker': 'CUA tab creation timed out; recovery inventory failed to connect',
    'limits': ['Initial paint opportunity only; shader driver can still block after submission',
               'Source equivalence is not visual or performance acceptance',
               'No new assets, tools, physics algorithms, or historical skills activated']
}
(ROOT / 'R0198_SOURCE_CHECK.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
