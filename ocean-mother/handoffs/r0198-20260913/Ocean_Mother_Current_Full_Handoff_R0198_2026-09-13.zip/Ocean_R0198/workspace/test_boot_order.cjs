const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, 'R0198_Boot_Experiment/source/inline-0.js'), 'utf8');

function harness() {
  const raf = [], timers = [], nodes = new Map();
  let gpuStarts = 0;
  const gl = {isContextLost() { gpuStarts++; return true; }};
  const element = id => {
    if (!nodes.has(id)) nodes.set(id, {textContent: '', dataset: {}, style: {setProperty() {}},
      classList: {add() {}, remove() {}, toggle() {}, contains() {return false;}},
      listeners: {}, addEventListener(name, fn) {this.listeners[name] = fn;}, setAttribute() {}, getContext() {return gl;}});
    return nodes.get(id);
  };
  const context = {window: {addEventListener() {}},
    document: {getElementById: element, querySelectorAll: () => [], addEventListener() {},
      documentElement: {style: {setProperty() {}}}},
    devicePixelRatio: 1, innerWidth: 1280, innerHeight: 720, performance: {now: () => 0},
    sessionStorage: {getItem: () => null}, addEventListener() {},
    requestAnimationFrame(fn) {raf.push(fn); return raf.length;},
    setTimeout(fn) {timers.push(fn); return timers.length;}, clearTimeout() {},
    console, Uint8Array, Float32Array};
  vm.runInNewContext(source, context);
  return {raf, timers, nodes, get starts() {return gpuStarts;},
    drain() {while(raf.length) raf.shift()(); while(timers.length) timers.shift()();}};
}

const a = harness();
assert.equal(typeof a.nodes.get('pause').onclick, 'function');
assert.equal(typeof a.nodes.get('panelToggle').onclick, 'function');
assert.equal(a.starts, 0, 'GPU initialization must not run in the initial UI task');
a.raf.shift()();
assert.equal(a.starts, 0, 'First animation callback must still leave GPU untouched');
a.raf.shift()();
assert.equal(a.starts, 0, 'Second animation callback only queues the GPU task');
a.timers.shift()();
assert.equal(a.starts, 1);

const b = harness();
b.nodes.get('ocean').listeners.webglcontextlost({preventDefault() {}});
b.drain();
assert.equal(b.starts, 0, 'A context loss must invalidate deferred initial startup');
const result = {status: 'PASS', runtimeExecuted: 'entire candidate inline-0.js in Node VM',
  cases: ['UI controls bound before GPU start', 'no GPU call in either animation callback',
          'one GPU start in deferred task', 'context loss invalidates deferred startup'],
  scope: 'scheduling only; no browser paint, GLSL execution, visual acceptance, or real GPU validation'};
fs.writeFileSync(path.join(__dirname, 'R0198_BOOT_ORDER_TEST.json'), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
