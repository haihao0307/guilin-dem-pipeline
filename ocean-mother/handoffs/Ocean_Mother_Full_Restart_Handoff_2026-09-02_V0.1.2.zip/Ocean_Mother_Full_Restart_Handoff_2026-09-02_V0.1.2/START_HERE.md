# Ocean Mother 新研发窗口启动入口

这是 Ocean Mother 当前干净全量重启包：`Ocean_Mother_Full_Restart_Handoff_2026-09-02_V0.1.2.zip`。

## 开始步骤

1. 完整解压本包。
2. 先读 `OCEAN_HANDOFF.md`、`HANDOFF.json`、`WORKING_STATE.md`。
3. 运行 `python tools/verify.py`，确认包内文件身份和零图片资产规则。
4. 需要查看时运行 `START_LOCAL.bat`，或执行 `python tools/serve.py`。
5. 继续写 GitHub 前，读取仓库 `haihao0307/guilin-dem-pipeline` 的 `work/ocean-mother-handoff-20260901` 最新 head；本包打包前核验 head 为 `55c454001d2587c8de50c74946deaee89ef1a069`。

## 当前在线入口

`https://haihao0307.github.io/guilin-dem-pipeline/ocean-mother/coast-v012/`

## 当前任务边界

V0.1.2 已解决参数调整后停止、继续按钮无效和必须依赖新种子恢复的问题。下一研发阶段继续三维自由表面液体、体积烟火和参考视觉复刻。

保持 Coast 在 Ocean Mother 内。原深海、冻结天气、其他 Mother、权威真值和共同核心不改。只交在线 HTML 作为视觉成果，图片概念图和截图不作交付。

当前 `visualApproved=false`、`productionApproved=false`、`fullReplication=false`。
