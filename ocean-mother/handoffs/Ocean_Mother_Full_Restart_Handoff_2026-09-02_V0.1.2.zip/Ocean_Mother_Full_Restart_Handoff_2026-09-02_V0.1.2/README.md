# Ocean Mother V0.1.2 干净全量包

包内只有当前可运行 Coast、原深海及其冻结天气依赖、精确测试源码、机器证据、共同政策快照和重启交接文件。

没有图片贴图、概念图、截图、模型、外部 CDN、浏览器缓存、依赖目录、旧 Coast 运行版、构建中间目录或其他 Mother 资产。

本地运行：双击 `START_LOCAL.bat`，或在根目录执行 `python tools/serve.py`。

完整性检查：`python tools/verify.py`。

在线页面仍是主要视觉入口：`https://haihao0307.github.io/guilin-dem-pipeline/ocean-mother/coast-v012/`。
