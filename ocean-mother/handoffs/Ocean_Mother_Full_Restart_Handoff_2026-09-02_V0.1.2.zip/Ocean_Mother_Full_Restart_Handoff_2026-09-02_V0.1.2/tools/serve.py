#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os, threading, webbrowser
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT)
url='http://127.0.0.1:8765/ocean-mother/coast-v012/'
print('Ocean Mother local workbench:',url,flush=True)
threading.Timer(0.8,lambda:webbrowser.open(url)).start()
ThreadingHTTPServer(('127.0.0.1',8765),SimpleHTTPRequestHandler).serve_forever()
