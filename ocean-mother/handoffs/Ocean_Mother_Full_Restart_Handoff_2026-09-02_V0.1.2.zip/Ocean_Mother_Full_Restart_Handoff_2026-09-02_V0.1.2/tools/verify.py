#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'MANIFEST.json').read_text('utf-8'))
errors=[]
for name,e in m['files'].items():
 p=ROOT/name
 if not p.is_file():errors.append({'path':name,'error':'missing'});continue
 b=p.read_bytes()
 if len(b)!=e['bytes'] or hashlib.sha256(b).hexdigest()!=e['sha256']:
  errors.append({'path':name,'error':'identity','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
expected=set(m['files'])
for name in sorted(actual-expected):errors.append({'path':name,'error':'unlisted'})
for p in ROOT.rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.png','.jpg','.jpeg','.gif','.webp','.bmp','.tif','.tiff','.hdr','.exr','.glb','.gltf','.fbx','.obj'}:
  errors.append({'path':p.relative_to(ROOT).as_posix(),'error':'forbidden_asset'})
report={'status':'PACKAGE_INTEGRITY_PASS' if not errors else 'PACKAGE_INTEGRITY_FAIL','packageVersion':m['packageVersion'],'filesChecked':len(expected),'errors':errors,'runtimeImageAssets':0 if not any(e['error']=='forbidden_asset' for e in errors) else None,'visualApproved':False,'productionApproved':False}
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if not errors else 1)
