/** Frozen B candidate material query. No nearest-member search or flat fallback. */
import {resolveMemberHit} from './member-resolver.mjs';
export const FAILURE=Object.freeze({MISSING_HIT:1,NONFINITE_INPUT:2,UNSUPPORTED_MATERIAL:4,INVALID_NORMAL:8,INVALID_EXTENT:16,NONFINITE_GPU:32,DISTANCE_MISMATCH:64});
const IDS=new Set([1,2,3,4,7,8,9,12,13,15,17,18,19]);
export const VERTEX='#version 300 es\nprecision highp float;void main(){vec2 p[3]=vec2[3](vec2(-1,-1),vec2(3,-1),vec2(-1,3));gl_Position=vec4(p[gl_VertexID],0,1);}';
const params=(age,eye,width,height)=>new Float32Array([...eye,age,0,0,-1,.43,1,0,0,1.5,0,1,0,0,width,height,0,0]);
function shader(gl,type,source){const sh=gl.createShader(type);gl.shaderSource(sh,source);gl.compileShader(sh);return sh;}
export async function linkQuery(gl,fragment){
 const start=performance.now(),program=gl.createProgram(),vs=shader(gl,gl.VERTEX_SHADER,VERTEX),fs=shader(gl,gl.FRAGMENT_SHADER,fragment);gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);
 const parallel=gl.getExtension('KHR_parallel_shader_compile');if(parallel)while(!gl.getProgramParameter(program,parallel.COMPLETION_STATUS_KHR)){if(performance.now()-start>240000)throw Error('B query shader compile timeout');await new Promise(r=>setTimeout(r,20));}
 const report={vertexOK:gl.getShaderParameter(vs,gl.COMPILE_STATUS),fragmentOK:gl.getShaderParameter(fs,gl.COMPILE_STATUS),linkOK:gl.getProgramParameter(program,gl.LINK_STATUS),vertexLog:gl.getShaderInfoLog(vs),fragmentLog:gl.getShaderInfoLog(fs),linkLog:gl.getProgramInfoLog(program),durationMs:performance.now()-start};
 gl.deleteShader(vs);gl.deleteShader(fs);if(!report.vertexOK||!report.fragmentOK||!report.linkOK){gl.deleteProgram(program);throw Error('B query compile/link failed: '+JSON.stringify(report));}return{program,report};
}
export function inspectHit(p,n,h,fp){let flags=0;if(!h)return FAILURE.MISSING_HIT;const scalars=[...p,...n,...h.q||[],...h.extent||[],h.id,h.seed,h.baseD,h.sourceSeed,fp];if(h.q?.length!==3||h.extent?.length!==3||!scalars.every(Number.isFinite)||scalars.some(v=>Math.abs(v)>1e12)||fp<0)flags|=FAILURE.NONFINITE_INPUT;if(!IDS.has(h.id))flags|=FAILURE.UNSUPPORTED_MATERIAL;if(Math.abs(Math.hypot(...n)-1)>.002)flags|=FAILURE.INVALID_NORMAL;if(h.extent?.some(v=>v<0))flags|=FAILURE.INVALID_EXTENT;return flags;}
export function hitFromPacked(a,i){const j=i*12;return{q:[a[j],a[j+1],a[j+2]],id:a[j+3],extent:[a[j+4],a[j+5],a[j+6]],seed:a[j+7],baseD:a[j+8],sourceSeed:a[j+9]};}
/** Prefer a separate context: the sampler owns and deletes its GL resources. */
export async function createStationSampler({canvas,fragmentURL=new URL('./generated/material-query-entry-adapted.frag',import.meta.url),fragmentSource,maxBatch=4096}={}){
 canvas??=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(1,1):document.createElement('canvas');const gl=canvas.getContext('webgl2',{antialias:false,alpha:false,depth:false,stencil:false,preserveDrawingBuffer:false});
 if(!gl||!gl.getExtension('EXT_color_buffer_float'))throw Error('Frozen B material sampler needs WebGL2 RGBA32F render/readback');
 if(gl.getParameter(gl.MAX_DRAW_BUFFERS)<4)throw Error('Four float outputs unavailable');
 if(!Number.isInteger(maxBatch)||maxBatch<1)throw Error('Invalid material batch size');
 if(!fragmentSource){const r=await fetch(fragmentURL);if(!r.ok)throw Error('B query load HTTP '+r.status);fragmentSource=await r.text();}
 const {program,report}=await linkQuery(gl,fragmentSource);gl.useProgram(program);
 if(gl.getProgramParameter(program,gl.ACTIVE_UNIFORM_BLOCKS)!==1)throw Error('B query Params block count mismatch');
 const blockSize=gl.getActiveUniformBlockParameter(program,0,gl.UNIFORM_BLOCK_DATA_SIZE);if(blockSize!==80)throw Error('B query Params layout must be 80 bytes; received '+blockSize);
 const uniformBuffer=gl.createBuffer();gl.bindBuffer(gl.UNIFORM_BUFFER,uniformBuffer);gl.bufferData(gl.UNIFORM_BUFFER,80,gl.DYNAMIC_DRAW);gl.uniformBlockBinding(program,0,0);gl.bindBufferBase(gl.UNIFORM_BUFFER,0,uniformBuffer);
 const samplers=[];for(let i=0;i<5;i++){const names=[`stationInput${i}`,`_group_0_binding_${i+1}_fs`];const name=names.find(n=>gl.getUniformLocation(program,n)!==null);if(!name)throw Error('B input binding '+i+' missing');samplers.push(name);gl.uniform1i(gl.getUniformLocation(program,name),i);}
 const inputTextures=Array.from({length:5},()=>gl.createTexture()),outputTextures=Array.from({length:4},()=>gl.createTexture()),fbo=gl.createFramebuffer(),vao=gl.createVertexArray();
 const maximumTextureSize=gl.getParameter(gl.MAX_TEXTURE_SIZE),widthLimit=Math.min(1024,maximumTextureSize),effectiveBatch=Math.min(maxBatch,maximumTextureSize*widthLimit);
 const debug=gl.getExtension('WEBGL_debug_renderer_info'),backend={version:gl.getParameter(gl.VERSION),renderer:gl.getParameter(debug?debug.UNMASKED_RENDERER_WEBGL:gl.RENDERER)};
 let disposed=false,busy=false;
 function texture(tex,unit,width,height,data){gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,width,height,0,gl.RGBA,gl.FLOAT,data);}
 async function sample({positions,normals,hits,packedHits,descriptors,footprintM=.5,age=.58,eye=[96,48,55],onProgress}={}){
  if(disposed)throw Error('B sampler disposed');if(busy)throw Error('B sampler does not permit concurrent calls');
  if(!(positions instanceof Float32Array)||!(normals instanceof Float32Array)||positions.length%3||positions.length!==normals.length)throw Error('positions/normals require equal Float32Array(N*3)');
  const count=positions.length/3;if(packedHits&&(!(packedHits instanceof Float32Array)||packedHits.length!==count*12))throw Error('packedHits requires Float32Array(N*12)');
  if(!Number.isFinite(age)||age<0||age>1||eye.length!==3||!eye.every(Number.isFinite))throw Error('Invalid B material state/eye');
  const colors=new Float32Array(count*3).fill(NaN),roughness=new Float32Array(count).fill(NaN),geometryDistance=new Float32Array(count).fill(NaN),matterDistance=new Float32Array(count).fill(NaN),materialKey=new Uint16Array(count),failureFlags=new Uint16Array(count),detail=new Float32Array(count*4).fill(NaN),state=new Float32Array(count*4).fill(NaN),started=performance.now();let batches=0;
  busy=true;try{for(let start=0;start<count;start+=effectiveBatch){
   if(gl.isContextLost())throw Error('B material WebGL context lost');const n=Math.min(effectiveBatch,count-start),width=Math.min(widthLimit,n),height=Math.ceil(n/width),pixels=width*height;
   const inputs=Array.from({length:5},()=>new Float32Array(pixels*4));
   for(let j=0;j<n;j++){const i=start+j,p=Array.from(positions.subarray(i*3,i*3+3)),normal=Array.from(normals.subarray(i*3,i*3+3)),fp=typeof footprintM==='number'?footprintM:footprintM[i];let h;
    try{h=packedHits?hitFromPacked(packedHits,i):typeof hits==='function'?hits(i,p):hits?.[i];if(!h&&descriptors)h=resolveMemberHit(Array.isArray(descriptors)?descriptors[i]:descriptors,p);}catch{h=null;}
    const flags=inspectHit(p,normal,h,fp),o=j*4;failureFlags[i]=flags;inputs[4][o+2]=flags;if(flags)continue;
    inputs[0].set([...p,fp],o);inputs[1].set([...normal,1],o);inputs[2].set([...h.q,h.id],o);inputs[3].set([...h.extent,h.seed],o);inputs[4].set([h.baseD,h.sourceSeed,0,0],o);
   }
   gl.useProgram(program);gl.bindVertexArray(vao);gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);for(let k=0;k<5;k++)texture(inputTextures[k],k,width,height,inputs[k]);
   for(let k=0;k<4;k++){texture(outputTextures[k],5+k,width,height,null);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0+k,gl.TEXTURE_2D,outputTextures[k],0);}gl.drawBuffers([0,1,2,3].map(i=>gl.COLOR_ATTACHMENT0+i));
   if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('B material float framebuffer incomplete');
   gl.bindBuffer(gl.UNIFORM_BUFFER,uniformBuffer);gl.bindBufferBase(gl.UNIFORM_BUFFER,0,uniformBuffer);gl.bufferSubData(gl.UNIFORM_BUFFER,0,params(age,eye,width,height));gl.viewport(0,0,width,height);gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);gl.disable(gl.SCISSOR_TEST);gl.drawArrays(gl.TRIANGLES,0,3);
   const output=Array.from({length:4},()=>new Float32Array(pixels*4));for(let k=0;k<4;k++){gl.readBuffer(gl.COLOR_ATTACHMENT0+k);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,output[k]);}
   const error=gl.getError();if(error)throw Error('B material WebGL error '+error);
   for(let j=0;j<n;j++){const i=start+j,o=j*4;if(failureFlags[i])continue;const values=output.flatMap(a=>Array.from(a.subarray(o,o+4)));if(!values.every(Number.isFinite)){failureFlags[i]|=FAILURE.NONFINITE_GPU;continue;}if(Math.abs(output[1][o]-output[1][o+1])>1e-7){failureFlags[i]|=FAILURE.DISTANCE_MISMATCH;continue;}colors.set(output[0].subarray(o,o+3),i*3);roughness[i]=output[0][o+3];geometryDistance[i]=output[1][o];matterDistance[i]=output[1][o+1];materialKey[i]=output[1][o+2];detail.set(output[2].subarray(o,o+4),i*4);state.set(output[3].subarray(o,o+4),i*4);}
   batches++;onProgress?.({completed:start+n,total:count,batches});if(start+n<count)await new Promise(r=>setTimeout(r,0));
  }}finally{busy=false;}
  return{colors,roughness,geometryDistance,matterDistance,materialKey,failureFlags,detail,state,count,batches,durationMs:performance.now()-started,colorSpace:'linear',coordinateSpace:'station-local-metres-Y-up',footprintMeaning:'unchanged mother input; not a physical footprint average',sourceCommit:'1f46ba78170752a07086caa3e66c87f2fa4c7fcf'};
 }
 function dispose(){if(busy)throw Error('Cannot dispose during B material sampling');if(disposed)return;disposed=true;for(const t of [...inputTextures,...outputTextures])gl.deleteTexture(t);gl.deleteFramebuffer(fbo);gl.deleteVertexArray(vao);gl.deleteBuffer(uniformBuffer);gl.deleteProgram(program);}
 return{sample,dispose,backend,compile:report,layout:{blockBytes:blockSize,samplers,outputLocations:4,inputFloatsPerVertex:20,packedHitFloatsPerVertex:12},gl};
}
