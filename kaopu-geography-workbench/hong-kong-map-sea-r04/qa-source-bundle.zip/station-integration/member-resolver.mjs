/** CPU construction metadata only. Material values are always evaluated by the frozen B GPU closure. */
import {clockTowerMembers} from './frozen-B/native-clock-tower.mjs';
import {terminalHallMembers,terminalHallMemberSample} from './frozen-B/native-terminal-hall.mjs';
import {shedRoofMembers} from './frozen-B/native-shed-roof.mjs';
import {archTrussMembers} from './frozen-B/native-arch-truss.mjs';
import {STATION_SCORE} from './frozen-B/station-score.mjs';
export const TOWER_PIVOT=Object.freeze([24,0,4]);
export const tower=clockTowerMembers();
export const hall=terminalHallMembers({...STATION_SCORE.hall,deck:.85});
export const shed=shedRoofMembers(STATION_SCORE.shed);
export const trusses=archTrussMembers({...STATION_SCORE.shed,depth:STATION_SCORE.shed.trussDepth});
const sub=(a,b)=>a.map((x,i)=>x-b[i]);
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export function boxDistance(q,b){const d=q.map((x,i)=>Math.abs(x)-b[i]);return Math.hypot(...d.map(x=>Math.max(x,0)))+Math.min(Math.max(...d),0);}
export function beamFrame(p,a,b){const axis=sub(b,a),length=Math.hypot(...axis),w=axis.map(x=>x/length),u=w[1]>-.999999?[1-w[0]*w[0]/(1+w[1]),-w[0],-w[2]*w[0]/(1+w[1])]:[-1,0,0],v=cross(u,w),q=sub(p,a.map((x,i)=>(x+b[i])/2));return {q:[dot(q,u),dot(q,w),dot(q,v)],length,frame:[u,w,v]};}
function beamDistance(p,s){const {q,length}=beamFrame(p,s.a,s.b);return boxDistance(q,[s.width/2,length/2,s.depth/2]);}
function coneDistance(q,r0,r1,h){const p=[Math.hypot(q[0],q[2]),q[1]],a=[r0,-h/2],v=[r1-r0,h],delta=sub(p,a),t=clamp(dot(delta,v)/dot(v,v),0,1),side=Math.hypot(...delta.map((x,i)=>x-v[i]*t)),bottom=Math.hypot(Math.max(p[0]-r0,0),p[1]+h/2),top=Math.hypot(Math.max(p[0]-r1,0),p[1]-h/2),inside=Math.abs(p[1])<=h/2&&p[0]<=r0+(r1-r0)*(p[1]+h/2)/h;return Math.min(side,bottom,top)*(inside?-1:1);}
export function yawCoordinates(p,shape){const q=sub(p,shape.center),c=Math.cos(shape.yaw||0),s=Math.sin(shape.yaw||0);return[c*q[0]-s*q[2],q[1],s*q[0]+c*q[2]];}
/** All four windows on all four sides, identical signed field to native WGSL. */
export function towerWindowCutter(p,win,width=6.2){return boxDistance([Math.min(Math.abs(p[0]),Math.abs(p[2])),p[1]-win.y,Math.max(Math.abs(p[0]),Math.abs(p[2]))-(width/2-.26)],[.745,win.h/2,.66]);}
export function towerPrimitiveDistance(s,p){const q=sub(p,s.center||[0,0,0]);
 if(s.type==='hollow-box')return Math.max(boxDistance(q,s.size.map(x=>x/2)),-boxDistance(sub(p,s.innerCenter),s.innerSize.map(x=>x/2)));
 if(s.type==='box')return boxDistance(q,s.size.map(x=>x/2));
 if(['oriented-box','interior-lining'].includes(s.type))return boxDistance(yawCoordinates(p,s),s.size.map(x=>x/2));
 if(s.type==='beam')return beamDistance(p,s);
 if(s.type==='cylinder')return coneDistance(q,s.radius,s.radiusTop??s.radius,s.height);
 if(s.type==='triangle-prism'){const r=yawCoordinates(p,s),half=s.base/2;return Math.max(-r[1],(s.rise*Math.abs(r[0])+half*r[1]-half*s.rise)/Math.hypot(s.rise,half),Math.abs(r[2])-s.depth/2);}
 if(s.type==='octagon'){const radial=Math.max(Math.abs(q[0]),Math.abs(q[2]),(Math.abs(q[0])+Math.abs(q[2]))*.707106781186548);let d=Math.max(radial-s.radius,Math.abs(q[1])-s.height/2);if(s.inner>0)d=Math.max(d,-(radial-s.inner));return d;}
 if(s.type==='dome'){const k=s.rise/s.radius;return Math.max(Math.abs(Math.hypot(q[0],q[1]/k,q[2])-(s.radius-s.thickness*.5))*k-s.thickness*.5,-q[1]);}
 const plane=s.axis==='x'?[q[2],q[1],q[0]]:q,r=Math.hypot(plane[0],plane[1]);
 if(s.type==='annulus')return Math.max(r-s.radius,s.inner-r,Math.abs(plane[2])-s.depth/2);
 if(s.type==='ring')return Math.hypot(r-s.radius,plane[2])-s.tube;
 if(s.type==='disc')return Math.max(r-s.radius,Math.abs(plane[2])-.006);
 throw Error('Unbound B tower primitive '+s.type);
}
export function clockMemberSample(memberIndex,p){
 const m=tower.parts[memberIndex];if(!m)throw Error('Unknown B clock member '+memberIndex);
 const tq=sub(p,TOWER_PIVOT),s=m.shape,role=m.surface.role;
 if(role==='clock-ink'){const match=/^clock-tick-(\d+)-(\d+)$/.exec(m.id);if(!match)throw Error('Unbound B dial index');const face=Number(match[1]),i=Number(match[2]),a=face*Math.PI/2,n=[Math.sin(a),0,Math.cos(a)],right=[n[2],0,-n[0]],q=[dot(tq,right),tq[1]-25,dot(tq,n)-3.30],theta=i*3.14159265359/30,minor=i%5!==0,r=minor?1.22:1.17,delta=sub(q,[Math.sin(theta)*r,Math.cos(theta)*r,.03]),rotated=[Math.cos(theta)*delta[0]-Math.sin(theta)*delta[1],Math.sin(theta)*delta[0]+Math.cos(theta)*delta[1],delta[2]],baseD=boxDistance(rotated,[minor?.0115:.0325,minor?.035:.10,.013]);return{d:baseD,baseD,id:8,q,seed:0,extent:[1,1,1],sourceSeed:face*60+i,componentId:m.id,role};}
 let baseD=towerPrimitiveDistance(s,tq);
 if(m.id==='clock-shaft'||role==='tower-plaster')for(const win of tower.windows)baseD=Math.max(baseD,-towerWindowCutter(tq,win));
 let id,seed,q=tq,extent=[1,1,1];
 if(role==='masonry-trim'){id=2;seed=171;extent=[4.8,23,4.8];}
 else if(role==='tower-brick'){id=Math.abs(tq[0])>Math.abs(tq[2])?12:1;seed=71;extent=[2.96,13.65,2.96];}
 else if(role==='structural-iron'){id=3;seed=183;}
 else if(role==='tower-concrete'){id=19;seed=173;extent=[2.7,1.3,2.7];}
 else if(role==='clock-face'){id=7;seed=0;}
 else if(role==='window-timber'){id=4;seed=172;const axis=s.size.indexOf(Math.max(...s.size)),perm=axis===1?[1,0,2]:axis===2?[2,0,1]:[0,1,2],local=sub(tq,s.center);q=perm.map(i=>local[i]);extent=perm.map(i=>s.size[i]/2);}
 else if(role==='tower-plaster'||role==='lantern-brick-facet'){id=role==='tower-plaster'?13:1;seed=role==='tower-plaster'?174:175;q=yawCoordinates(tq,s);extent=s.size.map(x=>x/2);}
 else throw Error('Unbound B clock role '+role);
 return {d:baseD,baseD,id,q,seed,extent,sourceSeed:memberIndex,componentId:m.id,role};
}
export function hallMemberSample(memberIndex,p){const m=hall.parts[memberIndex];if(!m)throw Error('Unknown B hall member '+memberIndex);if(m.binding.deferred)throw Error('Deferred B hall optics: '+m.id);return terminalHallMemberSample(m,p,hall.plan);}
const half=STATION_SCORE.shed.length/2,center=STATION_SCORE.shed.front-half;
export function shedMemberSample(kind,memberIndex,p,{barrel=0,bayCenterZ=STATION_SCORE.shed.front}={}){
 if(![-1,0,1].includes(barrel))throw Error('B barrel must be -1, 0, or 1');
 const x=p[0]-barrel*20;let baseD,id=3,seed=52,q=p.slice(),sourceSeed=memberIndex;
 if(kind==='panel'){const m=shed.panels[memberIndex];if(!m)throw Error('Unknown B panel');const slope=(m.y1-m.y0)/(m.x1-m.x0),top=slope*x+m.y0-slope*m.x0,norm=Math.hypot(1,slope);baseD=Math.max((p[1]-top)/norm,(top-m.thickness-p[1])/norm,m.x0-x,x-m.x1,Math.abs(p[2]-center)-half);id=15;seed=55+barrel;q=[x,p[1],p[2]];}
 else if(kind==='purlin'){const m=shed.purlins[memberIndex];if(!m)throw Error('Unknown B purlin');baseD=boxDistance([x-m.x,p[1]-m.y,p[2]-center],[m.widthX/2,m.heightY/2,half]);sourceSeed=100+memberIndex;}
 else if(kind==='truss'){const m=trusses[memberIndex];if(!m)throw Error('Unknown B truss');baseD=beamDistance([x,p[1],p[2]-bayCenterZ],m);}
 else throw Error('Unbound B shed kind '+kind);
 return {d:baseD,baseD,id,q,seed,extent:[1,1,1],sourceSeed};
}
/** Caller supplies actual construction identity, never guessed from nearest position. */
export function resolveMemberHit(descriptor,p){
 if(descriptor.family==='clock')return clockMemberSample(descriptor.member,p);
 if(descriptor.family==='hall')return hallMemberSample(descriptor.member,p);
 if(descriptor.family==='shed')return shedMemberSample(descriptor.kind,descriptor.member,p,descriptor);
 if(descriptor.family==='column')return castColumnMemberSample(descriptor.member,p,descriptor);
 if(descriptor.family==='platform-deck')return platformDeckSample(p,descriptor);
 if(descriptor.family==='platform-edge')return platformEdgeMemberSample(descriptor.member,p);
 if(descriptor.hit){const h=descriptor.hit;if(typeof h==='function')return h(p);return h;}
 throw Error('Unbound station member descriptor; explicit HitField is required');
}

import {castColumnMembers} from './frozen-B/native-cast-column.mjs';
import {platformEdgeMembers,platformEdgeSample} from './frozen-B/native-platform-edge.mjs';
export const columns=castColumnMembers({deck:.85,eave:STATION_SCORE.shed.eave});
export const platformEdges=platformEdgeMembers({deck:.85,eave:STATION_SCORE.shed.eave,back:STATION_SCORE.shed.front-STATION_SCORE.shed.length,front:STATION_SCORE.shed.front,bay:STATION_SCORE.shed.bay});
const extrusion=(a,b)=>Math.min(Math.max(a,b),0)+Math.hypot(Math.max(a,0),Math.max(b,0));
function polygonCone(q,r0,r1,h,sides){if(!sides)return coneDistance(q,r0,r1,h);const ap=Math.cos(3.14159265359/sides),slope=(r1-r0)*ap/h;let d=Math.abs(q[1])-h*.5;for(let k=0;k<sides;k++){const a=(k+.5)*6.28318530718/sides;d=Math.max(d,(q[0]*Math.sin(a)+q[2]*Math.cos(a)-r0*ap-slope*(q[1]+h*.5))/Math.hypot(1,slope));}return d;}
export function castColumnMemberSample(memberIndex,p,{centerX,bayCenterZ}={}){
 if(!Number.isFinite(centerX)||!Number.isFinite(bayCenterZ))throw Error('Explicit column centerX and bayCenterZ required');const m=columns[memberIndex];if(!m)throw Error('Unknown B column');
 const cx=p[0]-centerX,z=p[2]-bayCenterZ,source=[-z,p[1],cx],q=sub(source,m.center||[0,0,0]);let baseD;
 if(m.type==='box')baseD=boxDistance(q,m.size.map(x=>x/2));
 else if(m.type==='cylinder')baseD=extrusion(Math.hypot(q[0],q[2])-m.radius,Math.abs(q[1])-m.height/2);
 else if(m.type==='cone')baseD=polygonCone(q,m.bottomRadius,m.topRadius,m.height,m.sides||0);
 else if(m.type==='flute'){const radius=m.radius-m.depth*(.5+.5*Math.cos(Math.atan2(source[2],source[0])*m.flutes));baseD=extrusion(Math.hypot(q[0],q[2])-radius,Math.abs(q[1])-m.height/2);}
 else if(m.type==='torus')baseD=Math.hypot(Math.hypot(q[0],q[2])-m.radius,source[1]-m.center[1])-m.tube;
 else if(m.type==='hex'){const framed=beamFrame(q,m.direction.map(v=>-.5*v),m.direction.map(v=>.5*v)).q;let side=-1e5;for(let k=0;k<6;k++){const a=(k+.5)*1.0471975512;side=Math.max(side,framed[0]*Math.sin(a)+framed[2]*Math.cos(a)-m.radius*.8660254038);}baseD=extrusion(side,Math.abs(framed[1])-m.depth/2);}
 else if(m.type==='beam')baseD=beamDistance(source,m);else throw Error('Unbound B column primitive');
 return {d:baseD,baseD,id:3,q:[cx,p[1]-5,z],seed:56,extent:[.82,(STATION_SCORE.shed.eave+.62-.85+.03)/2,.49],sourceSeed:memberIndex,componentId:m.id};
}
export function platformDeckSample(p,{centerX}={}){if(!Number.isFinite(centerX))throw Error('Explicit platform centerX required');const q=[p[0]-centerX,p[1]-.275,p[2]-center],baseD=boxDistance(q,[3.4,.575,half+1.3]);return {d:baseD,baseD,id:17,q,seed:77,extent:[1,1,1],sourceSeed:0};}
export function platformEdgeMemberSample(memberIndex,p){const m=platformEdges[memberIndex];if(!m)throw Error('Unknown B platform edge');return platformEdgeSample(m,p);}
