struct Params{eye:vec3<f32>,age:f32,forward:vec3<f32>,fov:f32,right:vec3<f32>,aspect:f32,up:vec3<f32>,debug:f32,resolution:vec2<f32>,pad:vec2<f32>}
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}
struct StationWaterfrontHit{d:f32,baseD:f32,id:u32,q:vec3<f32>,extent:vec3<f32>,member:f32,seed:f32,frame:mat3x3<f32>,owner:f32,waterContact:f32,}
struct ColumnMemberHit{d:f32,member:f32,}
struct StationPlatformEdgeHit{d:f32,baseD:f32,id:u32,q:vec3<f32>,seed:f32,extent:vec3<f32>,sourceSeed:f32,frame:mat3x3<f32>,family:u32,row:u32,segment:u32,side:i32,}
struct StationLetteringHit{valid:u32,d:f32,error:f32,lowerBound:f32,stepDistance:f32,q:vec3<f32>,id:u32,seed:f32,mode:u32,}
struct StationLetteringArc{a:vec2<f32>,b:vec2<f32>,c:vec2<f32>,d:vec2<f32>,lo:vec2<f32>,hi:vec2<f32>,degree:u32,steps:u32,}
struct StationLampMemberHit{d:f32,baseD:f32,member:f32,id:u32,q:vec3<f32>,extent:vec3<f32>,frame:mat3x3<f32>,}
struct FootbridgeMemberHit{d:f32,baseD:f32,member:f32,id:u32,q:vec3<f32>,extent:vec3<f32>,frame:mat3x3<f32>,}
struct HitField { d:f32, id:u32, q:vec3<f32>, seed:f32, baseD:f32, extent:vec3<f32>, sourceSeed:f32, }
struct StationCandidates {count:u32,items:array<HitField,96>,}
struct StationState{age:f32,wet:f32,repair:f32,retained:f32,}
struct StationMatter{d:f32,surface:KpSurface,metal:f32,cavity:f32,specular:f32,microHeight:f32,layer:u32,clearcoat:f32,clearcoatRoughness:f32,parallaxHeight01:f32,}
struct StationGeometry{d:f32,loss:f32,thickness:f32,brickWeight:f32,}
struct StationBrickSample{q:vec3<f32>,seed:f32,}
var<private> stationCandidates:StationCandidates;
var<private> stationCandidateOverflow:bool;
var<private> stationRawCandidateCount:u32;
var<private> stationCandidateUpper:f32;
@group(0)@binding(0)var<uniform>u:Params;
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;
const BENCH_WOOD_SCALE:f32=4.;
const BENCH_WOOD_CONTRAST:f32=0.36;
const RAIL_CROWN:f32=0.086;
fn br_h11(p:f32)->f32 {return fract(sin(p*127.1+311.7)*43758.5453123);}
fn br_hash31(pIn:vec3<f32>)->f32 {var p=fract(pIn*0.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn br_noise3(p:vec3<f32>)->f32 {let i=floor(p);var f=fract(p);f=f*f*(vec3<f32>(3.0)-2.0*f);return mix(mix(mix(br_hash31(i),br_hash31(i+vec3<f32>(1,0,0)),f.x),mix(br_hash31(i+vec3<f32>(0,1,0)),br_hash31(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(br_hash31(i+vec3<f32>(0,0,1)),br_hash31(i+vec3<f32>(1,0,1)),f.x),mix(br_hash31(i+vec3<f32>(0,1,1)),br_hash31(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn br_fbm(pIn:vec3<f32>)->f32 {var p=pIn;var s=0.0;var a=0.5;for(var i=0;i<5;i++){s+=a*br_noise3(p);p=p*2.03+vec3<f32>(7.1,-3.7,11.9);a*=0.5;}return s;}
fn br_roundBox(p:vec3<f32>,b:vec3<f32>,r:f32)->f32 {let q=abs(p)-b+vec3<f32>(r);return length(max(q,vec3<f32>(0.0)))+min(max(q.x,max(q.y,q.z)),0.0)-r;}
fn br_mid_x_m_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01800174*cos(3.0*KP_BRICK_PI*t)+0.00862492*sin(3.0*KP_BRICK_PI*t)-0.00032245*cos(4.0*KP_BRICK_PI*t)-0.00199262*sin(4.0*KP_BRICK_PI*t); }
fn br_high_x_m_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01471101*cos(5.0*KP_BRICK_PI*t)-0.00611511*sin(5.0*KP_BRICK_PI*t)+0.00505069*cos(6.0*KP_BRICK_PI*t)-0.01129023*sin(6.0*KP_BRICK_PI*t)+0.00016204*cos(7.0*KP_BRICK_PI*t)-0.00678541*sin(7.0*KP_BRICK_PI*t)+0.00910669*cos(8.0*KP_BRICK_PI*t)-0.00372102*sin(8.0*KP_BRICK_PI*t)+0.00386620*cos(9.0*KP_BRICK_PI*t)+0.00169141*sin(9.0*KP_BRICK_PI*t)+0.00255569*cos(10.0*KP_BRICK_PI*t)+0.00429621*sin(10.0*KP_BRICK_PI*t)-0.00149008*cos(11.0*KP_BRICK_PI*t)+0.00421699*sin(11.0*KP_BRICK_PI*t)-0.00482651*cos(12.0*KP_BRICK_PI*t)+0.00371242*sin(12.0*KP_BRICK_PI*t)-0.00518212*cos(13.0*KP_BRICK_PI*t)-0.00028101*sin(13.0*KP_BRICK_PI*t)-0.00483069*cos(14.0*KP_BRICK_PI*t)-0.00165143*sin(14.0*KP_BRICK_PI*t)-0.00203463*cos(15.0*KP_BRICK_PI*t)-0.00399068*sin(15.0*KP_BRICK_PI*t)+0.00089974*cos(16.0*KP_BRICK_PI*t)-0.00264073*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_x_m_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01135424*cos(3.0*KP_BRICK_PI*t)-0.00403594*sin(3.0*KP_BRICK_PI*t)+0.01141619*cos(4.0*KP_BRICK_PI*t)-0.00155239*sin(4.0*KP_BRICK_PI*t); }
fn br_high_x_m_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01111828*cos(5.0*KP_BRICK_PI*t)-0.00524976*sin(5.0*KP_BRICK_PI*t)+0.00926048*cos(6.0*KP_BRICK_PI*t)-0.00196252*sin(6.0*KP_BRICK_PI*t)-0.01080133*cos(7.0*KP_BRICK_PI*t)-0.00236667*sin(7.0*KP_BRICK_PI*t)+0.00682428*cos(8.0*KP_BRICK_PI*t)+0.00034784*sin(8.0*KP_BRICK_PI*t)-0.00988528*cos(9.0*KP_BRICK_PI*t)-0.00067851*sin(9.0*KP_BRICK_PI*t)+0.00392564*cos(10.0*KP_BRICK_PI*t)+0.00248324*sin(10.0*KP_BRICK_PI*t)-0.00639717*cos(11.0*KP_BRICK_PI*t)-0.00103361*sin(11.0*KP_BRICK_PI*t)+0.00224399*cos(12.0*KP_BRICK_PI*t)+0.00279355*sin(12.0*KP_BRICK_PI*t)-0.00234379*cos(13.0*KP_BRICK_PI*t)-0.00034023*sin(13.0*KP_BRICK_PI*t)+0.00154531*cos(14.0*KP_BRICK_PI*t)+0.00135488*sin(14.0*KP_BRICK_PI*t)-0.00041372*cos(15.0*KP_BRICK_PI*t)+0.00081121*sin(15.0*KP_BRICK_PI*t)+0.00176690*cos(16.0*KP_BRICK_PI*t)-0.00017177*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_x_p_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01106844*cos(3.0*KP_BRICK_PI*t)+0.00366009*sin(3.0*KP_BRICK_PI*t)+0.00491573*cos(4.0*KP_BRICK_PI*t)-0.00304459*sin(4.0*KP_BRICK_PI*t); }
fn br_high_x_p_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00968863*cos(5.0*KP_BRICK_PI*t)+0.00804842*sin(5.0*KP_BRICK_PI*t)-0.00023933*cos(6.0*KP_BRICK_PI*t)-0.00159630*sin(6.0*KP_BRICK_PI*t)-0.00533428*cos(7.0*KP_BRICK_PI*t)+0.00562751*sin(7.0*KP_BRICK_PI*t)-0.00301718*cos(8.0*KP_BRICK_PI*t)-0.00124667*sin(8.0*KP_BRICK_PI*t)-0.00068517*cos(9.0*KP_BRICK_PI*t)+0.00175252*sin(9.0*KP_BRICK_PI*t)-0.00175606*cos(10.0*KP_BRICK_PI*t)-0.00053161*sin(10.0*KP_BRICK_PI*t)+0.00314901*cos(11.0*KP_BRICK_PI*t)-0.00221809*sin(11.0*KP_BRICK_PI*t)-0.00002768*cos(12.0*KP_BRICK_PI*t)-0.00050747*sin(12.0*KP_BRICK_PI*t)+0.00322590*cos(13.0*KP_BRICK_PI*t)-0.00372527*sin(13.0*KP_BRICK_PI*t)+0.00009642*cos(14.0*KP_BRICK_PI*t)+0.00051161*sin(14.0*KP_BRICK_PI*t)+0.00137602*cos(15.0*KP_BRICK_PI*t)-0.00204386*sin(15.0*KP_BRICK_PI*t)-0.00040926*cos(16.0*KP_BRICK_PI*t)+0.00184796*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_x_p_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01568166*cos(3.0*KP_BRICK_PI*t)-0.00042124*sin(3.0*KP_BRICK_PI*t)+0.00873786*cos(4.0*KP_BRICK_PI*t)+0.00638691*sin(4.0*KP_BRICK_PI*t); }
fn br_high_x_p_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01295239*cos(5.0*KP_BRICK_PI*t)-0.00380655*sin(5.0*KP_BRICK_PI*t)+0.00244597*cos(6.0*KP_BRICK_PI*t)+0.00179228*sin(6.0*KP_BRICK_PI*t)-0.00822504*cos(7.0*KP_BRICK_PI*t)-0.00912719*sin(7.0*KP_BRICK_PI*t)+0.00818194*cos(8.0*KP_BRICK_PI*t)-0.00226580*sin(8.0*KP_BRICK_PI*t)+0.00200288*cos(9.0*KP_BRICK_PI*t)-0.00217961*sin(9.0*KP_BRICK_PI*t)+0.00524195*cos(10.0*KP_BRICK_PI*t)+0.00335884*sin(10.0*KP_BRICK_PI*t)-0.00236021*cos(11.0*KP_BRICK_PI*t)+0.00141195*sin(11.0*KP_BRICK_PI*t)+0.00291234*cos(12.0*KP_BRICK_PI*t)+0.00156187*sin(12.0*KP_BRICK_PI*t)-0.00192814*cos(13.0*KP_BRICK_PI*t)+0.00280991*sin(13.0*KP_BRICK_PI*t)-0.00040794*cos(14.0*KP_BRICK_PI*t)+0.00126868*sin(14.0*KP_BRICK_PI*t)-0.00433065*cos(15.0*KP_BRICK_PI*t)-0.00021126*sin(15.0*KP_BRICK_PI*t)+0.00012984*cos(16.0*KP_BRICK_PI*t)-0.00208270*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_y_m_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00630336*cos(3.0*KP_BRICK_PI*t)+0.00827031*sin(3.0*KP_BRICK_PI*t)+0.00566717*cos(4.0*KP_BRICK_PI*t)+0.00042867*sin(4.0*KP_BRICK_PI*t); }
fn br_high_y_m_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00616945*cos(5.0*KP_BRICK_PI*t)+0.00614401*sin(5.0*KP_BRICK_PI*t)+0.00276823*cos(6.0*KP_BRICK_PI*t)-0.00324009*sin(6.0*KP_BRICK_PI*t)-0.00277462*cos(7.0*KP_BRICK_PI*t)+0.00419118*sin(7.0*KP_BRICK_PI*t)+0.00129222*cos(8.0*KP_BRICK_PI*t)-0.00251670*sin(8.0*KP_BRICK_PI*t)-0.00017492*cos(9.0*KP_BRICK_PI*t)+0.00320414*sin(9.0*KP_BRICK_PI*t)-0.00060079*cos(10.0*KP_BRICK_PI*t)-0.00079424*sin(10.0*KP_BRICK_PI*t)+0.00099889*cos(11.0*KP_BRICK_PI*t)+0.00100195*sin(11.0*KP_BRICK_PI*t)-0.00147204*cos(12.0*KP_BRICK_PI*t)+0.00019719*sin(12.0*KP_BRICK_PI*t)+0.00147029*cos(13.0*KP_BRICK_PI*t)-0.00057325*sin(13.0*KP_BRICK_PI*t)-0.00105959*cos(14.0*KP_BRICK_PI*t)+0.00146526*sin(14.0*KP_BRICK_PI*t)+0.00110262*cos(15.0*KP_BRICK_PI*t)-0.00092602*sin(15.0*KP_BRICK_PI*t)-0.00024836*cos(16.0*KP_BRICK_PI*t)+0.00177536*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_y_m_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00456362*cos(3.0*KP_BRICK_PI*t)+0.00232485*sin(3.0*KP_BRICK_PI*t)+0.00364059*cos(4.0*KP_BRICK_PI*t)-0.00296393*sin(4.0*KP_BRICK_PI*t); }
fn br_high_y_m_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0+0.00058035*cos(5.0*KP_BRICK_PI*t)+0.00351213*sin(5.0*KP_BRICK_PI*t)-0.00311119*cos(6.0*KP_BRICK_PI*t)-0.00082560*sin(6.0*KP_BRICK_PI*t)+0.00447520*cos(7.0*KP_BRICK_PI*t)-0.00080438*sin(7.0*KP_BRICK_PI*t)-0.00625696*cos(8.0*KP_BRICK_PI*t)+0.00100661*sin(8.0*KP_BRICK_PI*t)+0.00468255*cos(9.0*KP_BRICK_PI*t)-0.00231942*sin(9.0*KP_BRICK_PI*t)-0.00397357*cos(10.0*KP_BRICK_PI*t)+0.00223223*sin(10.0*KP_BRICK_PI*t)+0.00344591*cos(11.0*KP_BRICK_PI*t)-0.00145876*sin(11.0*KP_BRICK_PI*t)-0.00081874*cos(12.0*KP_BRICK_PI*t)+0.00036113*sin(12.0*KP_BRICK_PI*t)+0.00095928*cos(13.0*KP_BRICK_PI*t)+0.00022236*sin(13.0*KP_BRICK_PI*t)+0.00016248*cos(14.0*KP_BRICK_PI*t)-0.00163296*sin(14.0*KP_BRICK_PI*t)-0.00041686*cos(15.0*KP_BRICK_PI*t)+0.00173083*sin(15.0*KP_BRICK_PI*t)+0.00042056*cos(16.0*KP_BRICK_PI*t)-0.00171078*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_y_p_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00568083*cos(3.0*KP_BRICK_PI*t)+0.00059518*sin(3.0*KP_BRICK_PI*t)+0.00165756*cos(4.0*KP_BRICK_PI*t)-0.00265243*sin(4.0*KP_BRICK_PI*t); }
fn br_high_y_p_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00237719*cos(5.0*KP_BRICK_PI*t)+0.00155711*sin(5.0*KP_BRICK_PI*t)-0.00174800*cos(6.0*KP_BRICK_PI*t)-0.00034580*sin(6.0*KP_BRICK_PI*t)+0.00109223*cos(7.0*KP_BRICK_PI*t)-0.00076205*sin(7.0*KP_BRICK_PI*t)-0.00183915*cos(8.0*KP_BRICK_PI*t)+0.00169373*sin(8.0*KP_BRICK_PI*t)+0.00166788*cos(9.0*KP_BRICK_PI*t)-0.00197430*sin(9.0*KP_BRICK_PI*t)+0.00023726*cos(10.0*KP_BRICK_PI*t)+0.00209990*sin(10.0*KP_BRICK_PI*t)-0.00013690*cos(11.0*KP_BRICK_PI*t)-0.00204928*sin(11.0*KP_BRICK_PI*t)+0.00149101*cos(12.0*KP_BRICK_PI*t)+0.00080592*sin(12.0*KP_BRICK_PI*t)-0.00168845*cos(13.0*KP_BRICK_PI*t)-0.00052462*sin(13.0*KP_BRICK_PI*t)+0.00199706*cos(14.0*KP_BRICK_PI*t)-0.00016703*sin(14.0*KP_BRICK_PI*t)-0.00114543*cos(15.0*KP_BRICK_PI*t)+0.00067098*sin(15.0*KP_BRICK_PI*t)+0.00132124*cos(16.0*KP_BRICK_PI*t)-0.00060376*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_y_p_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01472244*cos(3.0*KP_BRICK_PI*t)+0.00196068*sin(3.0*KP_BRICK_PI*t)+0.00837774*cos(4.0*KP_BRICK_PI*t)-0.00049031*sin(4.0*KP_BRICK_PI*t); }
fn br_high_y_p_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00814206*cos(5.0*KP_BRICK_PI*t)-0.00053856*sin(5.0*KP_BRICK_PI*t)+0.00257906*cos(6.0*KP_BRICK_PI*t)-0.00127762*sin(6.0*KP_BRICK_PI*t)-0.00086120*cos(7.0*KP_BRICK_PI*t)+0.00165010*sin(7.0*KP_BRICK_PI*t)-0.00324482*cos(8.0*KP_BRICK_PI*t)-0.00230772*sin(8.0*KP_BRICK_PI*t)+0.00531309*cos(9.0*KP_BRICK_PI*t)+0.00285670*sin(9.0*KP_BRICK_PI*t)-0.00601731*cos(10.0*KP_BRICK_PI*t)-0.00308967*sin(10.0*KP_BRICK_PI*t)+0.00756770*cos(11.0*KP_BRICK_PI*t)+0.00401337*sin(11.0*KP_BRICK_PI*t)-0.00704240*cos(12.0*KP_BRICK_PI*t)-0.00363779*sin(12.0*KP_BRICK_PI*t)+0.00672339*cos(13.0*KP_BRICK_PI*t)+0.00366736*sin(13.0*KP_BRICK_PI*t)-0.00539581*cos(14.0*KP_BRICK_PI*t)-0.00292112*sin(14.0*KP_BRICK_PI*t)+0.00379057*cos(15.0*KP_BRICK_PI*t)+0.00280410*sin(15.0*KP_BRICK_PI*t)-0.00302659*cos(16.0*KP_BRICK_PI*t)-0.00189233*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_z_m_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.03445430*cos(3.0*KP_BRICK_PI*t)-0.00282014*sin(3.0*KP_BRICK_PI*t)+0.03501842*cos(4.0*KP_BRICK_PI*t)+0.00267835*sin(4.0*KP_BRICK_PI*t); }
fn br_high_z_m_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.03134970*cos(5.0*KP_BRICK_PI*t)-0.00507503*sin(5.0*KP_BRICK_PI*t)+0.02759835*cos(6.0*KP_BRICK_PI*t)+0.00467492*sin(6.0*KP_BRICK_PI*t)-0.02453092*cos(7.0*KP_BRICK_PI*t)-0.00547356*sin(7.0*KP_BRICK_PI*t)+0.02023931*cos(8.0*KP_BRICK_PI*t)+0.00660731*sin(8.0*KP_BRICK_PI*t)-0.01699690*cos(9.0*KP_BRICK_PI*t)-0.00634397*sin(9.0*KP_BRICK_PI*t)+0.01361088*cos(10.0*KP_BRICK_PI*t)+0.00712487*sin(10.0*KP_BRICK_PI*t)-0.01008559*cos(11.0*KP_BRICK_PI*t)-0.00675053*sin(11.0*KP_BRICK_PI*t)+0.00780155*cos(12.0*KP_BRICK_PI*t)+0.00722028*sin(12.0*KP_BRICK_PI*t)-0.00529194*cos(13.0*KP_BRICK_PI*t)-0.00638835*sin(13.0*KP_BRICK_PI*t)+0.00336004*cos(14.0*KP_BRICK_PI*t)+0.00624403*sin(14.0*KP_BRICK_PI*t)-0.00209103*cos(15.0*KP_BRICK_PI*t)-0.00553015*sin(15.0*KP_BRICK_PI*t)+0.00084286*cos(16.0*KP_BRICK_PI*t)+0.00479951*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_z_m_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01307475*cos(3.0*KP_BRICK_PI*t)+0.00450446*sin(3.0*KP_BRICK_PI*t)+0.00682105*cos(4.0*KP_BRICK_PI*t)+0.00639899*sin(4.0*KP_BRICK_PI*t); }
fn br_high_z_m_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00571077*cos(5.0*KP_BRICK_PI*t)+0.00346485*sin(5.0*KP_BRICK_PI*t)+0.00609629*cos(6.0*KP_BRICK_PI*t)+0.00059963*sin(6.0*KP_BRICK_PI*t)-0.00710636*cos(7.0*KP_BRICK_PI*t)-0.00381479*sin(7.0*KP_BRICK_PI*t)+0.00135812*cos(8.0*KP_BRICK_PI*t)+0.00135282*sin(8.0*KP_BRICK_PI*t)-0.00506045*cos(9.0*KP_BRICK_PI*t)-0.00360239*sin(9.0*KP_BRICK_PI*t)+0.00308686*cos(10.0*KP_BRICK_PI*t)+0.00261325*sin(10.0*KP_BRICK_PI*t)-0.00270687*cos(11.0*KP_BRICK_PI*t)-0.00449361*sin(11.0*KP_BRICK_PI*t)+0.00262569*cos(12.0*KP_BRICK_PI*t)+0.00311502*sin(12.0*KP_BRICK_PI*t)-0.00162438*cos(13.0*KP_BRICK_PI*t)-0.00306571*sin(13.0*KP_BRICK_PI*t)+0.00251715*cos(14.0*KP_BRICK_PI*t)+0.00290793*sin(14.0*KP_BRICK_PI*t)-0.00087650*cos(15.0*KP_BRICK_PI*t)-0.00290014*sin(15.0*KP_BRICK_PI*t)+0.00095675*cos(16.0*KP_BRICK_PI*t)+0.00161494*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_z_p_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00543148*cos(3.0*KP_BRICK_PI*t)-0.01245624*sin(3.0*KP_BRICK_PI*t)+0.01205722*cos(4.0*KP_BRICK_PI*t)+0.00758454*sin(4.0*KP_BRICK_PI*t); }
fn br_high_z_p_m(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.01318042*cos(5.0*KP_BRICK_PI*t)-0.01120445*sin(5.0*KP_BRICK_PI*t)+0.00622728*cos(6.0*KP_BRICK_PI*t)+0.00643460*sin(6.0*KP_BRICK_PI*t)-0.00641567*cos(7.0*KP_BRICK_PI*t)-0.00656035*sin(7.0*KP_BRICK_PI*t)+0.00075536*cos(8.0*KP_BRICK_PI*t)+0.00936163*sin(8.0*KP_BRICK_PI*t)-0.00227068*cos(9.0*KP_BRICK_PI*t)-0.00692473*sin(9.0*KP_BRICK_PI*t)+0.00018661*cos(10.0*KP_BRICK_PI*t)+0.00740915*sin(10.0*KP_BRICK_PI*t)-0.00009489*cos(11.0*KP_BRICK_PI*t)-0.00591066*sin(11.0*KP_BRICK_PI*t)-0.00047542*cos(12.0*KP_BRICK_PI*t)+0.00438750*sin(12.0*KP_BRICK_PI*t)+0.00034270*cos(13.0*KP_BRICK_PI*t)-0.00324690*sin(13.0*KP_BRICK_PI*t)-0.00151968*cos(14.0*KP_BRICK_PI*t)+0.00176894*sin(14.0*KP_BRICK_PI*t)+0.00166849*cos(15.0*KP_BRICK_PI*t)-0.00123680*sin(15.0*KP_BRICK_PI*t)-0.00146369*cos(16.0*KP_BRICK_PI*t)+0.00149355*sin(16.0*KP_BRICK_PI*t); }
fn br_mid_z_p_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00388179*cos(3.0*KP_BRICK_PI*t)+0.00390139*sin(3.0*KP_BRICK_PI*t)+0.00238573*cos(4.0*KP_BRICK_PI*t)-0.00329681*sin(4.0*KP_BRICK_PI*t); }
fn br_high_z_p_p(tIn:f32)->f32 { var t=tIn; t=clamp(t,-0.95,0.95);return 0.0-0.00010459*cos(5.0*KP_BRICK_PI*t)+0.00147038*sin(5.0*KP_BRICK_PI*t)+0.00066299*cos(6.0*KP_BRICK_PI*t)-0.00479755*sin(6.0*KP_BRICK_PI*t)+0.00106469*cos(7.0*KP_BRICK_PI*t)+0.00323743*sin(7.0*KP_BRICK_PI*t)-0.00034190*cos(8.0*KP_BRICK_PI*t)-0.00098051*sin(8.0*KP_BRICK_PI*t)+0.00303712*cos(9.0*KP_BRICK_PI*t)+0.00124931*sin(9.0*KP_BRICK_PI*t)-0.00262919*cos(10.0*KP_BRICK_PI*t)-0.00150538*sin(10.0*KP_BRICK_PI*t)+0.00194169*cos(11.0*KP_BRICK_PI*t)-0.00037848*sin(11.0*KP_BRICK_PI*t)-0.00197504*cos(12.0*KP_BRICK_PI*t)+0.00095933*sin(12.0*KP_BRICK_PI*t)+0.00272261*cos(13.0*KP_BRICK_PI*t)-0.00108356*sin(13.0*KP_BRICK_PI*t)-0.00067581*cos(14.0*KP_BRICK_PI*t)+0.00082625*sin(14.0*KP_BRICK_PI*t)+0.00043735*cos(15.0*KP_BRICK_PI*t)-0.00193681*sin(15.0*KP_BRICK_PI*t)-0.00039229*cos(16.0*KP_BRICK_PI*t)+0.00197941*sin(16.0*KP_BRICK_PI*t); }
fn br_midX(t:f32,sy:f32,sz:f32)->f32 {if(sy<0.0){if(sz<0.0){return br_mid_x_m_m(t);}return br_mid_x_m_p(t);}if(sz<0.0){return br_mid_x_p_m(t);}return br_mid_x_p_p(t);}
fn br_midY(t:f32,sx:f32,sz:f32)->f32 {if(sx<0.0){if(sz<0.0){return br_mid_y_m_m(t);}return br_mid_y_m_p(t);}if(sz<0.0){return br_mid_y_p_m(t);}return br_mid_y_p_p(t);}
fn br_midZ(t:f32,sx:f32,sy:f32)->f32 {if(sx<0.0){if(sy<0.0){return br_mid_z_m_m(t);}return br_mid_z_m_p(t);}if(sy<0.0){return br_mid_z_p_m(t);}return br_mid_z_p_p(t);}
fn br_highX(t:f32,sy:f32,sz:f32)->f32 {if(sy<0.0){if(sz<0.0){return br_high_x_m_m(t);}return br_high_x_m_p(t);}if(sz<0.0){return br_high_x_p_m(t);}return br_high_x_p_p(t);}
fn br_highY(t:f32,sx:f32,sz:f32)->f32 {if(sx<0.0){if(sz<0.0){return br_high_y_m_m(t);}return br_high_y_m_p(t);}if(sz<0.0){return br_high_y_p_m(t);}return br_high_y_p_p(t);}
fn br_highZ(t:f32,sx:f32,sy:f32)->f32 {if(sx<0.0){if(sy<0.0){return br_high_z_m_m(t);}return br_high_z_m_p(t);}if(sy<0.0){return br_high_z_p_m(t);}return br_high_z_p_p(t);}
fn br_nf(c:f32,h:f32,s:f32,band:f32)->f32 {return smoothstep(h-band,h+0.003,s*c);}
fn br_chipWear(vIn:f32)->f32 {let v=max(vIn-0.0018,0.0);return 0.020*tanh(v/0.020)*smoothstep(0.0010,0.0060,v);}
fn br_contour(v:f32)->f32 {return 0.0048*tanh(v/0.030);}
fn br_contourLong(v:f32)->f32 {let s=br_contour(v);if(s>=-0.0022){return s;}return -0.0022+0.00045*tanh((s+0.0022)/0.00045);}
fn br_mx(q:vec3<f32>,b:vec3<f32>,sy:f32,sz:f32)->f32{return br_nf(q.y,b.y,sy,0.042)*br_nf(q.z,b.z,sz,0.054);}
fn br_my(q:vec3<f32>,b:vec3<f32>,sx:f32,sz:f32)->f32{return br_nf(q.x,b.x,sx,0.062)*br_nf(q.z,b.z,sz,0.054);}
fn br_mz(q:vec3<f32>,b:vec3<f32>,sx:f32,sy:f32)->f32{return br_nf(q.x,b.x,sx,0.062)*br_nf(q.y,b.y,sy,0.042);}
fn br_ck(q:vec3<f32>,b:vec3<f32>,sx:f32,sy:f32,sz:f32)->f32{return br_nf(q.x,b.x,sx,0.080)*br_nf(q.y,b.y,sy,0.052)*br_nf(q.z,b.z,sz,0.064);}
fn br_ax(q:vec3<f32>,b:vec3<f32>,sy:f32,sz:f32)->vec3<f32>{let m=br_mx(q,b,sy,sz);let t=q.x/b.x;let md=br_midX(t,sy,sz);return vec3<f32>(br_chipWear(md+br_highX(t,sy,sz))*m,br_contourLong(md)*m,m);}
fn br_ay(q:vec3<f32>,b:vec3<f32>,sx:f32,sz:f32)->vec3<f32>{let m=br_my(q,b,sx,sz);let t=q.y/b.y;let md=br_midY(t,sx,sz);return vec3<f32>(br_chipWear(md+br_highY(t,sx,sz))*m,br_contour(md)*m,m);}
fn br_az(q:vec3<f32>,b:vec3<f32>,sx:f32,sy:f32)->vec3<f32>{let m=br_mz(q,b,sx,sy);let t=q.z/b.z;let md=br_midZ(t,sx,sy);return vec3<f32>(br_chipWear(md+br_highZ(t,sx,sy))*m,br_contour(md)*m,m);}
fn br_surfaceDelta(q:vec3<f32>,b:vec3<f32>)->f32 {
 var sum=vec3<f32>(0.0);
 sum+=br_ax(q,b,-1.0,-1.0);sum+=br_ax(q,b,-1.0,1.0);sum+=br_ax(q,b,1.0,-1.0);sum+=br_ax(q,b,1.0,1.0);
 sum+=br_ay(q,b,-1.0,-1.0);sum+=br_ay(q,b,-1.0,1.0);sum+=br_ay(q,b,1.0,-1.0);sum+=br_ay(q,b,1.0,1.0);
 sum+=br_az(q,b,-1.0,-1.0);sum+=br_az(q,b,-1.0,1.0);sum+=br_az(q,b,1.0,-1.0);sum+=br_az(q,b,1.0,1.0);
 sum.x+=0.0017*br_ck(q,b,-1.0,-1.0,1.0);sum.x+=0.0220*br_ck(q,b,-1.0,1.0,1.0);sum.x+=0.0140*br_ck(q,b,1.0,1.0,-1.0);sum.x+=0.0070*br_ck(q,b,1.0,1.0,1.0);
 return 0.038*tanh(sum.x*1.10/0.038)+sum.y/max(1.0,sum.z);
}
fn br_variant(qIn:vec3<f32>,variant:i32)->vec3<f32>{var q=qIn;if((variant&1)==1){q.x=-q.x;}if((variant&2)==2){q.z=-q.z;}return q;}
fn kpBrickBaseDistance(pLocalM:vec3<f32>,seed:f32,variant:i32,variation:f32)->f32 {
 let q=br_variant(pLocalM/KP_BRICK_SCALE,variant);let b=vec3<f32>(1.04,0.265,0.480);
 let gain=mix(1.0,0.90+0.20*br_h11(seed+7.1),variation);
 return KP_BRICK_SCALE*(br_roundBox(q,b,0.055)+br_surfaceDelta(q,b)*gain);
}
fn kpBrickAnalyticBoundDistance(pLocalM:vec3<f32>)->f32 {return KP_BRICK_SCALE*br_roundBox(pLocalM/KP_BRICK_SCALE,vec3<f32>(1.04,0.265,0.480),0.055);}
fn br_xi(q:vec3<f32>)->vec3<f32>{let rr=max(length(q),1e-4);let cap=0.13*9.5;let radial2=dot(q.xy,q.xy);let angularRadius=sqrt(radial2+cap*cap*exp(-radial2/(cap*cap)));let angle=acos(clamp(q.y/angularRadius,-0.999999,0.999999));return vec3<f32>(log2(rr)-2.0,-q.z/rr-1.0,angle);}
fn br_microscope(q:vec3<f32>,qFootprint:f32)->f32 {
 let xi=br_xi(q);let e=max(qFootprint,1e-7);
 let fp=max(length(br_xi(q+vec3<f32>(e,0,0))-xi),max(length(br_xi(q+vec3<f32>(0,e,0))-xi),length(br_xi(q+vec3<f32>(0,0,e))-xi)));
 var s=0.0;var sc=1.0;for(var j=0;j<17;j++){let gate=1.0-smoothstep(0.48,1.10,fp*sc);let x=xi*sc;s+=gate*(cos(cos(x.z)*cos(x.x)+cos(x.y)*cos(x.y)+cos(x.y)*cos(x.x))-0.6556965)/sc;sc*=2.0;}return s;
}
fn kpBrickOriginalSurface(pLocalM:vec3<f32>,seed:f32,variant:i32,variation:f32,physicalFootprintM:f32)->KpSurface {
 let r0=br_h11(seed+1.2);let r1=br_h11(seed+2.7);let r2=br_h11(seed+4.9);let r3=br_h11(seed+8.3);
 var q=br_variant(pLocalM/KP_BRICK_SCALE,variant);let ang=(r0-0.5)*2.2*variation;let ca=cos(ang);let sa=sin(ang);
 let oldXZ=q.xz;q.x=ca*oldXZ.x+sa*oldXZ.y;q.z=-sa*oldXZ.x+ca*oldXZ.y;
 q+=variation*vec3<f32>((r1-0.5)*18.0,(r2-0.5)*12.0,(r3-0.5)*16.0);
 let body=br_fbm(q*1.15+vec3<f32>(-2.7,4.1,8.3));let fire=br_fbm(q*2.65+vec3<f32>(7.1,-5.2,1.7));let firing=smoothstep(0.27,0.79,0.66*body+0.34*fire);
 let reduction=smoothstep(0.69,0.88,br_fbm(q*0.82+vec3<f32>(12.1,1.4,-9.7)))*smoothstep(0.38,0.82,firing);
 let poreA=br_noise3(q*29.7+vec3<f32>(2.3,9.1,-4.4));let poreB=br_noise3(q*61.3+vec3<f32>(-7.2,3.7,14.6));let pore=smoothstep(0.79,0.92,poreA)*smoothstep(0.64,0.84,poreB);
 let skin=smoothstep(0.36,0.76,br_fbm(q*5.1+vec3<f32>(1.9,-3.2,11.4)));let mm=br_microscope(q*9.5,max(physicalFootprintM,0.0)/KP_BRICK_SCALE*9.5);
 var base=mix(vec3<f32>(0.235,0.043,0.023),vec3<f32>(0.455,0.105,0.048),smoothstep(0.14,0.76,firing));base=mix(base,vec3<f32>(0.625,0.205,0.082),smoothstep(0.58,0.92,firing)*0.34);base=mix(base,vec3<f32>(0.19,0.055,0.038),reduction*0.63);
 let rough=clamp(0.90-0.10*firing+0.055*reduction+0.075*pore,0.68,0.985);
 let h=(body-0.5)*0.010+(skin-0.5)*0.004+mm*0.0034-pore*0.0048;
 base*=0.965+0.07*(skin-0.5);base*=mix(1.0,0.93+0.14*br_h11(seed+19.7),variation);
 return KpSurface(h*KP_BRICK_SCALE,base,rough);
}
fn kpWoodDefaultParams()->KpWoodParams {
  var p:KpWoodParams;
  p.seed=0.7598925376683223;
  p.ringFrequency=22.0;
  p.ringScale=1.1240120360301806;
  p.ringWarp=1.174825141889602;
  p.fiberFrequency=8.73036012029089;
  p.fineFiberFrequency=72.0;
  p.poreFrequency=280.0;
  p.fiberStrength=0.34;
  p.colorBias=-0.015293409994337707;
  p.roughness=0.892843876922503;
  p.angleOffset=0.7194436165372647;
  p.textureScale=1.0;
  p.grainContrast=0.20902697160467504;
  p.detailFineness=1.0188769673019646;
  p.microReliefM=0.00028000000000000003;
  p.parallaxM=0.0010500000000000002;
  p.macroDisplacementM=0.0005600000000000001;
  p.reliefScale=0.7741619322448968;
  p.reliefQuality=3.0;
  p.parallaxSteps=12.0;
  p.clearcoat=0.0;
  p.clearcoatRoughness=1.0;
  p.specularLevel=0.13;
  p.distanceFadeStart=9.0;
  p.distanceFadeEnd=28.0;
  p.toolPhase=0.2499335163798811;
  p.crackPhase=1.1871775190974605;
  p.knotPhase=1.4286763223548267;
  p.pithOffset=vec2<f32>(0.04244730153121054,-0.07805894820950925);
  p.darkGrainColor=vec3<f32>(0.10224173308810132,0.06480326669290577,0.04091519690685319);
  p.lightGrainColor=vec3<f32>(0.31398871337571754,0.1946178304415758,0.11443537382697373);
  p.agedSurfaceColor=vec3<f32>(0.18782077230067787,0.13563332965520566,0.09758734714186246);
  p.weatheredColor=vec3<f32>(0.23455058216100522,0.21586050011389926,0.18782077230067787);
  p.freshCutColor=vec3<f32>(0.39157247774972326,0.26225065752969623,0.162029375639111);
  p.cavityColor=vec3<f32>(0.04091519690685319,0.027320891639074894,0.0202885630566524);
  return p;
}
fn kwSaturate(value:f32, wp:KpWoodParams, fp:f32)->f32 { return clamp(value, 0.0, 1.0); }
fn kwHash31(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  p = fract(p * 0.1031 + wp.seed * vec3<f32>(13.71, 47.13, 91.77));
  p += vec3<f32>(dot(p, p.yzx + vec3<f32>(33.33)));
  return fract((p.x + p.y) * p.z);
}
fn kwValueNoise(p:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var i:vec3<f32> = floor(p);
  var f:vec3<f32> = fract(p);
  f = f * f * (vec3<f32>(3.0) - 2.0 * f);
  return mix(
    mix(mix(kwHash31(i + vec3<f32>(0,0,0), wp, fp), kwHash31(i + vec3<f32>(1,0,0), wp, fp), f.x),
        mix(kwHash31(i + vec3<f32>(0,1,0), wp, fp), kwHash31(i + vec3<f32>(1,1,0), wp, fp), f.x), f.y),
    mix(mix(kwHash31(i + vec3<f32>(0,0,1), wp, fp), kwHash31(i + vec3<f32>(1,0,1), wp, fp), f.x),
        mix(kwHash31(i + vec3<f32>(0,1,1), wp, fp), kwHash31(i + vec3<f32>(1,1,1), wp, fp), f.x), f.y),
    f.z
  );
}
fn kwFbm(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  var result:f32 = 0.0;
  var amplitude:f32 = 0.5;
  var rotation:mat3x3<f32> = mat3x3<f32>(vec3<f32>(0.00,0.80,0.60),vec3<f32>(-0.80,0.36,-0.48),vec3<f32>(-0.60,-0.48,0.64));
  for (var i = 0; i < 5; i++) {
    result += amplitude * kwValueNoise(p, wp, fp);
    p = rotation * p * 2.03 + vec3<f32>(7.1, 3.7, 5.9);
    amplitude *= 0.5;
  }
  return result;
}
fn kwAaSine(coordinate:f32, wp:KpWoodParams, fp:f32)->f32 {
  var footprint:f32 = fp;
  var attenuation:f32 = 1.0 - smoothstep(0.42, 1.15, footprint);
  return 0.5 + 0.5 * sin(KP_WOOD_TAU * coordinate) * attenuation;
}
fn kwAaThinLine(coordinate:f32, width:f32, wp:KpWoodParams, fp:f32)->f32 {
  var distanceToLine:f32 = abs(sin(KP_WOOD_PI * coordinate));
  var footprint:f32 = min(0.22, fp * 0.75);
  return 1.0 - smoothstep(width + footprint, width + 0.085 + footprint, distanceToLine);
}
fn kwFlatAcross(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return select(g.y, g.z, abs(localNormal.y) > abs(localNormal.z));
}
fn kwFlatDepth(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return select(g.z, g.y, abs(localNormal.y) > abs(localNormal.z));
}
fn kwSidePhase(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, multiplier:f32, wp:KpWoodParams, fp:f32)->f32 {
  return kwFlatAcross(g, localNormal, wp, fp) * wp.fiberFrequency * multiplier;
}
fn kwSideAnisotropicNoise(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, axialFrequency:f32, crossFrequency:f32, phase:f32, wp:KpWoodParams, fp:f32)->f32 {
  var planarAcross:f32 = kwFlatAcross(g, localNormal, wp, fp);
  var planarDepth:f32 = kwFlatDepth(g, localNormal, wp, fp);
  var planarCoordinate:vec3<f32> = vec3<f32>(
    g.x * axialFrequency + phase,
    planarAcross * crossFrequency + wp.seed * 4.7,
    planarDepth * 0.72 + wp.seed * 9.1
  );
  return kwFbm(planarCoordinate, wp, fp);
}
fn kwSideValueNoise(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, axialFrequency:f32, crossFrequency:f32, phase:f32, wp:KpWoodParams, fp:f32)->f32 {
  var planarAcross:f32 = kwFlatAcross(g, localNormal, wp, fp);
  var planarDepth:f32 = kwFlatDepth(g, localNormal, wp, fp);
  var planarCoordinate:vec3<f32> = vec3<f32>(
    g.x * axialFrequency + phase,
    planarAcross * crossFrequency + wp.seed * 6.3,
    planarDepth * 0.54 + wp.seed * 3.8
  );
  return kwValueNoise(planarCoordinate, wp, fp);
}
fn kwRidgeFromNoise(value:f32, wp:KpWoodParams, fp:f32)->f32 {
  return 1.0 - abs(value * 2.0 - 1.0);
}
fn kwKnotSignal(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var broad:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    0.34,
    1.35,
    wp.knotPhase + 8.0
  , wp, fp);
  var compact:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    0.72,
    2.25,
    wp.knotPhase * 0.37 + 17.0
  , wp, fp);
  return smoothstep(0.71, 0.91, broad) * smoothstep(0.58, 0.86, compact);
}
fn kwWoodSignals(g:vec3<f32>, localNormal:vec3<f32>, surfaceClass:f32, wp:KpWoodParams, fp:f32)->vec4<f32> {
  var crossSection:f32 = step(0.72, abs(localNormal.x));

  var driftY:f32 = kwFbm(vec3<f32>(g.x * 0.24 + wp.seed * 3.1, 1.17, 7.93), wp, fp) - 0.5;
  var driftZ:f32 = kwFbm(vec3<f32>(g.x * 0.21 - wp.seed * 4.7, 9.31, 2.41), wp, fp) - 0.5;
  var longWarp:vec2<f32> = vec2<f32>(driftY, driftZ) * wp.ringWarp * 0.115;
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset + longWarp;
  var theta:f32 = atan2(crossPosition.y, crossPosition.x);

  var oval:f32 = 0.075 * sin(wp.seed * 31.0 + wp.angleOffset);
  var ringPosition:vec2<f32> = crossPosition * vec2<f32>(1.0 + oval, 1.0 - oval);
  var radial:f32 = length(ringPosition);
  var ringNoise:f32 = kwFbm(vec3<f32>(
    g.x * 0.18 + wp.seed * 2.4,
    ringPosition.x * 2.2,
    ringPosition.y * 2.2
  ), wp, fp);
  var ringCoordinate:f32 = radial * wp.ringFrequency * wp.ringScale;
  ringCoordinate += (ringNoise - 0.5) * wp.ringWarp * 1.18;
  ringCoordinate += sin(theta * 2.0 + wp.seed * 13.0) * 0.12 * wp.ringWarp;
  ringCoordinate += sin(theta * 5.0 - wp.seed * 7.0) * 0.045 * wp.ringWarp;
  var ringLine:f32 = kwAaThinLine(ringCoordinate, 0.060, wp, fp);
  var ringBody:f32 = kwAaSine(ringCoordinate + (ringNoise - 0.5) * 0.16, wp, fp);
  var ring:f32 = kwSaturate(ringBody * 0.62 + ringLine * 0.38, wp, fp);

  var broad:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.18, 1.55, wp.angleOffset, wp, fp);
  var flow:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.42, 3.35, wp.seed * 11.0 + 2.4, wp, fp);
  var medium:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.88, 7.20, wp.seed * 17.0 + 4.7, wp, fp);
  var knot:f32 = kwKnotSignal(g, crossPosition, localNormal, wp, fp);

  var phaseWarp:f32 = (broad - 0.5) * 5.4 + (flow - 0.5) * 2.9;
  phaseWarp += sin(g.x * 0.58 + theta * 1.7 + wp.seed * 19.0) * 0.50;
  phaseWarp += knot * (4.0 + 1.6 * sin(g.x * 1.05 + wp.knotPhase));

  var coarseLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.58, wp, fp) + phaseWarp + wp.angleOffset / KP_WOOD_TAU,
    0.065
  , wp, fp);
  var coarseVein:f32 = kwRidgeFromNoise(flow, wp, fp);
  var coarseFiber:f32 = kwSaturate(
    broad * 0.47 +
    coarseVein * 0.31 +
    coarseLine * 0.22
  , wp, fp);

  var mediumLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 1.85, wp, fp) + phaseWarp * 1.72 + wp.seed * 7.0,
    0.040
  , wp, fp);
  var mediumFiber:f32 = kwSaturate(
    medium * 0.47 +
    kwRidgeFromNoise(flow * 0.62 + medium * 0.38, wp, fp) * 0.37 +
    mediumLine * 0.16
  , wp, fp);

  var crackGate:f32 = smoothstep(
    0.79,
    0.94,
    kwSideValueNoise(g, crossPosition, localNormal, 0.32, 3.1, wp.crackPhase + 13.0, wp, fp)
  );
  var sideCrack:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.17, wp, fp)
      + phaseWarp * 0.16
      + wp.crackPhase / KP_WOOD_TAU,
    0.014
  , wp, fp) * crackGate;
  var radialGate:f32 = smoothstep(
    0.72,
    0.93,
    kwValueNoise(vec3<f32>(radial * 1.9, g.x * 0.27, wp.seed * 9.0), wp, fp)
  );
  var radialCrack:f32 = pow(max(0.0, sin(theta * 7.0 + wp.crackPhase)), 26.0)
    * smoothstep(0.08, 0.27, radial)
    * radialGate;
  var cracks:f32 = mix(sideCrack, max(sideCrack * 0.12, radialCrack), crossSection);

  return vec4<f32>(ring, coarseFiber, mediumFiber, cracks);
}
fn kwSecondarySignals(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->vec4<f32> {
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
  var broadWarp:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    0.46,
    4.4,
    wp.seed * 21.0 + 1.7
  , wp, fp);
  var fineNoise:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    1.55,
    18.0 * max(wp.detailFineness, 0.45),
    wp.seed * 29.0 + 5.3
  , wp, fp);
  var fineLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 4.6 * max(wp.detailFineness, 0.45), wp, fp)
      + (broadWarp - 0.5) * 8.5
      + wp.seed * 19.0,
    0.026
  , wp, fp);
  var fineFiber:f32 = kwSaturate(
    fineNoise * 0.53 +
    kwRidgeFromNoise(fineNoise, wp, fp) * 0.30 +
    fineLine * 0.17
  , wp, fp);

  var poreNoise:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    4.2 * max(wp.detailFineness, 0.45),
    38.0 * max(wp.detailFineness, 0.45),
    wp.seed * 23.0 + 11.0
  , wp, fp);
  var poreGate:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    0.85,
    7.0,
    wp.seed * 31.0 + 2.0
  , wp, fp);
  var pores:f32 = smoothstep(0.865, 0.982, poreNoise)
    * smoothstep(0.52, 0.82, poreGate);

  var toolWave:f32 = kwAaSine(g.x * 1.45 + kwFlatAcross(g, localNormal, wp, fp) * 0.22 + wp.toolPhase / KP_WOOD_TAU, wp, fp);
  var toolMask:f32 = smoothstep(
    0.79,
    0.96,
    kwSideValueNoise(g, crossPosition, localNormal, 0.54, 2.3, wp.toolPhase + 5.0, wp, fp)
  );
  var tool:f32 = toolWave * toolMask;

  var knot:f32 = kwKnotSignal(g, crossPosition, localNormal, wp, fp);
  return vec4<f32>(fineFiber, pores, tool, knot);
}
fn kwMacroSignal(g:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return kwFbm(g * vec3<f32>(0.12, 0.70, 0.70) + vec3<f32>(wp.seed * 5.0), wp, fp);
}
fn kwCoarseRelief(g:vec3<f32>, localNormal:vec3<f32>, surfaceClass:f32, wp:KpWoodParams, fp:f32)->f32 {
  var crossSection:f32 = step(0.72, abs(localNormal.x));
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
  var theta:f32 = atan2(crossPosition.y, crossPosition.x);
  var radial:f32 = length(crossPosition);

  var broadWarp:f32 = kwValueNoise(vec3<f32>(g.x * 0.18, crossPosition * 2.4) + vec3<f32>(wp.seed * 3.1), wp, fp);
  var sideBand:f32 = kwAaSine(
    kwSidePhase(g, crossPosition, localNormal, 0.62, wp, fp)
    + (broadWarp - 0.5) * 3.2
    + wp.angleOffset / KP_WOOD_TAU
  , wp, fp);
  var ringBand:f32 = kwAaSine(
    radial * wp.ringFrequency * wp.ringScale
    + (broadWarp - 0.5) * wp.ringWarp * 0.55
  , wp, fp);
  var sparseGate:f32 = smoothstep(
    0.84,
    0.965,
    kwValueNoise(vec3<f32>(g.x * 0.31 + wp.crackPhase, crossPosition * 4.1), wp, fp)
  );
  var sideCrack:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.20, wp, fp)
    + (broadWarp - 0.5) * 0.22
    + wp.crackPhase / KP_WOOD_TAU,
    0.015
  , wp, fp) * sparseGate;
  var radialCrack:f32 = pow(max(0.0, sin(theta * 7.0 + wp.crackPhase)), 24.0)
    * smoothstep(0.08, 0.28, radial)
    * sparseGate;

  var sideHeight:f32 = (sideBand - 0.5) * 0.36 - sideCrack * 0.60;
  var endHeight:f32 = (ringBand - 0.5) * 0.34 - radialCrack * 0.68;
  return kwSaturate(0.5 + mix(sideHeight, endHeight, crossSection), wp, fp);
}
fn kwVertexHash(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  p = fract(p * 0.1031 + wp.seed * vec3<f32>(17.17, 41.73, 83.11));
  p += vec3<f32>(dot(p, p.yzx + vec3<f32>(31.32)));
  return fract((p.x + p.y) * p.z);
}
fn kwVertexNoise(p:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var i:vec3<f32> = floor(p);
  var f:vec3<f32> = fract(p);
  f = f * f * (vec3<f32>(3.0) - 2.0 * f);
  return mix(
    mix(mix(kwVertexHash(i + vec3<f32>(0,0,0), wp, fp), kwVertexHash(i + vec3<f32>(1,0,0), wp, fp), f.x),
        mix(kwVertexHash(i + vec3<f32>(0,1,0), wp, fp), kwVertexHash(i + vec3<f32>(1,1,0), wp, fp), f.x), f.y),
    mix(mix(kwVertexHash(i + vec3<f32>(0,0,1), wp, fp), kwVertexHash(i + vec3<f32>(1,0,1), wp, fp), f.x),
        mix(kwVertexHash(i + vec3<f32>(0,1,1), wp, fp), kwVertexHash(i + vec3<f32>(1,1,1), wp, fp), f.x), f.y),
    f.z
  );
}
fn kwMacroField(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  var result:f32 = 0.0;
  var amplitude:f32 = 0.58;
  for (var i = 0; i < 3; i++) {
    result += amplitude * kwVertexNoise(p, wp, fp);
    p = p * 2.07 + vec3<f32>(5.2, 9.1, 3.7);
    amplitude *= 0.45;
  }
  return result / 0.94;
}
fn kpWoodMacroDisplacement(pSourceM:vec3<f32>, surfaceClass:f32, wp:KpWoodParams)->f32 {
  let fp=0.0;
  let grain=pSourceM*max(wp.textureScale,0.001);
    var broad:f32 = kwMacroField(grain * vec3<f32>(0.28, 1.15, 1.15) + vec3<f32>(wp.seed * 7.0), wp, fp);
    var longWave:f32 = 0.5 + 0.5 * sin(grain.x * 0.82 + wp.seed * 29.0 + broad * 1.55);
    var macroHeight:f32 = (broad - 0.5) * 0.78 + (longWave - 0.5) * 0.22;
    var classWeight:f32 = 1.0;
    if (surfaceClass > 0.5 && surfaceClass < 2.5) { classWeight = 0.0; }
    else if (surfaceClass > 2.5 && surfaceClass < 3.5) { classWeight = 1.08; }
  return macroHeight * wp.macroDisplacementM * wp.reliefScale * classWeight;
}
fn kpWoodCoordinateFootprint(physicalFootprintM:f32,wp:KpWoodParams)->f32 {
  return max(physicalFootprintM,0.0)*max(wp.textureScale,0.001)*max(wp.ringFrequency*wp.ringScale,wp.fiberFrequency*4.6*max(wp.detailFineness,0.45));
}
fn kpWoodOriginalSample(pSourceM:vec3<f32>,normalIn:vec3<f32>,surfaceClass:f32,wp:KpWoodParams,physicalFootprintM:f32,cameraDistanceM:f32)->KpWoodSample {
  let localNormal=normalize(normalIn);
  let g=pSourceM*max(wp.textureScale,0.001);
  let fp=kpWoodCoordinateFootprint(physicalFootprintM,wp);
  var baseColor=vec3<f32>(0.0);
  var heightMeters=0.0;
  var roughness=wp.roughness;
  var cavity=1.0;
    var signals:vec4<f32> = kwWoodSignals(g, localNormal, surfaceClass, wp, fp);
    var secondary:vec4<f32> = kwSecondarySignals(g, localNormal, wp, fp);
    var ring:f32 = signals.x;
    var coarseFiber:f32 = signals.y;
    var mediumFiber:f32 = signals.z;
    var cracks:f32 = signals.w;
    var fineFiber:f32 = secondary.x;
    var pores:f32 = secondary.y;
    var tool:f32 = secondary.z;
    var knot:f32 = secondary.w;
    var macroTone:f32 = kwMacroSignal(g, wp, fp);

    var crossSection:f32 = step(0.72, abs(localNormal.x));
    var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
    var radial:f32 = length(crossPosition);
    var endRay:f32 = kwAaSine(atan2(crossPosition.y, crossPosition.x) * 3.0 / KP_WOOD_TAU + radial * 2.0 + wp.seed * 7.0, wp, fp);

    var longitudinalTone:f32 =
      (coarseFiber - 0.5) * 1.02 +
      (mediumFiber - 0.5) * 0.43 +
      (macroTone - 0.5) * 0.56 +
      (fineFiber - 0.5) * 0.11 +
      knot * 0.26 -
      cracks * 0.70 -
      pores * 0.08;
    var endTone:f32 =
      (ring - 0.5) * 1.08 +
      (endRay - 0.5) * 0.19 +
      (macroTone - 0.5) * 0.38 -
      cracks * 0.72 -
      pores * 0.05;
    var grainTone:f32 = mix(longitudinalTone, endTone, crossSection) + wp.colorBias;
    var grainMix:f32 = kwSaturate(0.50 + grainTone * wp.grainContrast * 2.72, wp, fp);
    var grainColor:vec3<f32> = mix(wp.lightGrainColor, wp.darkGrainColor, grainMix);
    baseColor = mix(wp.agedSurfaceColor, grainColor, 0.78);

    if (surfaceClass > 0.5 && surfaceClass < 1.5) {
      baseColor = mix(baseColor, wp.freshCutColor, 0.20);
    } else if (surfaceClass > 1.5 && surfaceClass < 2.5) {
      baseColor = mix(baseColor, wp.freshCutColor, 0.27);
    } else if (surfaceClass > 2.5 && surfaceClass < 3.5) {
      baseColor = mix(baseColor, wp.weatheredColor, 0.53);
      roughness = min(0.98, roughness + 0.045);
    }

    baseColor *= 0.905 + macroTone * 0.19;
    baseColor = mix(baseColor, wp.cavityColor, cracks * 0.40 + pores * 0.065 + knot * 0.025);

    var distanceToCamera:f32 = cameraDistanceM;
    var detailFade:f32 = 1.0 - smoothstep(wp.distanceFadeStart, wp.distanceFadeEnd, distanceToCamera);
    var sideMicro:f32 =
      (coarseFiber - 0.5) * 0.32 +
      (mediumFiber - 0.5) * 0.24 +
      (fineFiber - 0.5) * 0.12 -
      pores * 0.30 -
      cracks * 0.94 -
      tool * 0.13 +
      knot * 0.09;
    var endMicro:f32 =
      (ring - 0.5) * 0.34 +
      (fineFiber - 0.5) * 0.05 -
      pores * 0.22 -
      cracks * 1.0;
    var microSignal:f32 = mix(sideMicro, endMicro, crossSection);
    heightMeters = microSignal * wp.microReliefM * wp.reliefScale * detailFade;

    roughness = clamp(
      roughness + pores * 0.045 + cracks * 0.075 + (0.5 - macroTone) * 0.022 - wp.clearcoat * 0.085,
      0.18,
      0.98
    );
    cavity = clamp(1.0 - cracks * 0.34 - pores * 0.06 - ring * crossSection * 0.035, 0.60, 1.0);

  return KpWoodSample(KpSurface(heightMeters,baseColor,roughness),cavity,wp.clearcoat,wp.clearcoatRoughness,wp.specularLevel,kpWoodMacroDisplacement(pSourceM,surfaceClass,wp),kwCoarseRelief(g,localNormal,surfaceClass,wp,fp));
}
fn st_hash33(pIn:vec3<f32>)->vec3<f32> {
 var p=fract(pIn*vec3<f32>(0.1031,0.1030,0.0973));
 p+=vec3<f32>(dot(p,p.yxz+vec3<f32>(33.33)));
 return fract((p.xxy+p.yxx)*p.zyx);
}
fn st_valueNoise3(p:vec3<f32>)->f32 {
 let i=floor(p);var f=fract(p);
 f=f*f*f*(f*(f*6.0-vec3<f32>(15.0))+vec3<f32>(10.0));
 return mix(mix(mix(st_hash33(i).x,st_hash33(i+vec3<f32>(1,0,0)).x,f.x),mix(st_hash33(i+vec3<f32>(0,1,0)).x,st_hash33(i+vec3<f32>(1,1,0)).x,f.x),f.y),mix(mix(st_hash33(i+vec3<f32>(0,0,1)).x,st_hash33(i+vec3<f32>(1,0,1)).x,f.x),mix(st_hash33(i+vec3<f32>(0,1,1)).x,st_hash33(i+vec3<f32>(1,1,1)).x,f.x),f.y),f.z);
}
fn st_seedVector(seed:f32,salt:f32)->vec3<f32> {
 return st_hash33(vec3<f32>(seed*0.001,salt,seed*0.00013))*49.0;
}
fn st_srgbToLinear(c:vec3<f32>)->vec3<f32> {
 return mix(c/12.92,pow((c+vec3<f32>(0.055))/1.055,vec3<f32>(2.4)),step(vec3<f32>(0.04045),c));
}
fn st_sf(p:vec3<f32>)->f32 {
 return st_valueNoise3(p)*0.57+st_valueNoise3(p*2.07+vec3<f32>(13.7))*0.28+st_valueNoise3(p*4.11+vec3<f32>(27.2))*0.15;
}
fn st_warp(p:vec3<f32>,seed:vec3<f32>)->vec3<f32> {
 return p+vec3<f32>(st_sf(p*0.8+seed),st_sf(p*0.8+seed+vec3<f32>(7.0)),st_sf(p*0.8+seed+vec3<f32>(19.0)))*0.25;
}
fn st_line(q:vec3<f32>,seed:vec3<f32>)->f32 {
 return abs(sin((q.x*0.84+q.y*0.37+q.z*0.51+st_sf(q*1.7+seed)*0.44)*12.0));
}
fn st_lineAA(pos:vec3<f32>,seed:vec3<f32>,line:f32,physicalFootprintM:f32)->f32 {
 let e=max(physicalFootprintM,0.0)/KP_STONE_SCALE_M;
 if(e==0.0){return 0.008;}
 let dx=abs(st_line(st_warp(pos+vec3<f32>(e,0,0),seed),seed)-line);
 let dy=abs(st_line(st_warp(pos+vec3<f32>(0,e,0),seed),seed)-line);
 let dz=abs(st_line(st_warp(pos+vec3<f32>(0,0,e),seed),seed)-line);
 return max(dx+dy+dz,0.008);
}
fn kpStoneOriginalSurface(pLocalM:vec3<f32>,sourceWet:f32,roughBias:f32,physicalFootprintM:f32)->KpSurface {
 let pos=pLocalM/KP_STONE_SCALE_M;
 let seed=st_seedVector(KP_STONE_COLOR_SEED,0.071);
 let q=st_warp(pos,seed);
 let broad=st_sf(q*1.35+seed);
 let region=st_sf(q*3.2+seed+vec3<f32>(11.0));
 let weather=st_sf(q*2.2+st_seedVector(KP_STONE_WEATHER_SEED,0.09));
 let line=st_line(q,seed);
 let aa=st_lineAA(pos,seed,line,physicalFootprintM);
 let vein=(1.0-smoothstep(0.028,0.064+aa,line))*smoothstep(0.34,0.63,region);
 let pits=pow(max(0.0,(st_sf(q*19.0+st_seedVector(KP_STONE_PORE_SEED,0.061))-0.57)/0.43),2.0);
 var col=mix(vec3<f32>(0.26,0.31,0.32),vec3<f32>(0.57,0.59,0.55),smoothstep(0.24,0.73,broad));
 col=mix(col,vec3<f32>(0.49,0.40,0.29),smoothstep(0.57,0.76,weather)*0.65);
 let mineral=vein*0.7;
 col=mix(col,vec3<f32>(0.83,0.81,0.70),mineral*0.90);
 let rough=mix(0.79,0.43,mineral);
 let h=(broad-0.5)*0.018+(region-0.5)*0.007+vein*0.004-pits*0.025;
 let geomCavity=0.0;
 let cav=clamp(geomCavity*0.55+pits*1.4,0.0,1.0);
 let wet=clamp(sourceWet*(0.18+0.82*smoothstep(0.32,0.75,weather+cav*0.25)),0.0,1.0);
 let lum=dot(col,vec3<f32>(0.2126,0.7152,0.0722));
 col=mix(vec3<f32>(lum),col,1.0);
 var linear=st_srgbToLinear(clamp(col,vec3<f32>(0.025),vec3<f32>(0.95)));
 linear*=1.0-wet*0.38;
 return KpSurface(h*KP_STONE_SCALE_M,linear,clamp(mix(rough+roughBias,0.17,wet),0.12,0.98));
}
fn kpStoneSurface(pLocalM:vec3<f32>,age:f32,wet:f32,repair:f32,physicalFootprintM:f32)->KpSurface {
 let a=clamp(age,0.0,1.0);let r=clamp(repair,0.0,1.0);let m=clamp(wet,0.0,1.0);
 let retainedAge=a*(1.0-r);
 let sourceWet=clamp(m*(0.45+0.55*retainedAge)*(1.0-0.45*r),0.0,1.0);
 let roughBias=0.07*retainedAge+0.025*0.15-0.06*r;
 return kpStoneOriginalSurface(pLocalM,sourceWet,roughBias,physicalFootprintM);
}
fn mt_kh(pIn:vec3<f32>)->f32{var p=fract(pIn*.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn mt_kn(p:vec3<f32>)->f32{let i=floor(p);var f=fract(p);f=f*f*(vec3<f32>(3.)-2.*f);return mix(mix(mix(mt_kh(i),mt_kh(i+vec3<f32>(1,0,0)),f.x),mix(mt_kh(i+vec3<f32>(0,1,0)),mt_kh(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(mt_kh(i+vec3<f32>(0,0,1)),mt_kh(i+vec3<f32>(1,0,1)),f.x),mix(mt_kh(i+vec3<f32>(0,1,1)),mt_kh(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn mt_kfb(p:vec3<f32>)->f32{return .57*mt_kn(p)+.28*mt_kn(p*2.13)+.15*mt_kn(p*4.17);}
fn kpMetalCorrosion(p:vec3<f32>,age:f32,wet:f32,repair:f32)->f32{let contact=(1.-smoothstep(.02,.07,abs(p.y-1.07)))*.7;let joint=(1.-smoothstep(.06,.18,p.y))+(1.-smoothstep(.01,.08,abs(p.y-.98)))*.28;return clamp(age*(1.-repair)*(wet*.7+joint*.55)*(1.-contact),0.,1.);}
fn kpMetalSurface(p:vec3<f32>,age:f32,wet:f32,repair:f32,footprintM:f32)->KpSurface{
 let kq=p+vec3<f32>(19.);let kp=mt_kfb(kq*3.1);let contact=(1.-smoothstep(.02,.07,abs(p.y-1.07)))*.7;let joint=(1.-smoothstep(.06,.18,p.y))+(1.-smoothstep(.01,.08,abs(p.y-.98)))*.28;let retained=age*(1.-repair);let corrosion=kpMetalCorrosion(p,age,wet,repair);
 var color=vec3<f32>(.17,.235,.20)*(.94+.09*kp);color=mix(color,vec3<f32>(.21,.082,.025),corrosion*.80);color*=1.-wet*.18;
 let rough=clamp(.53+(mt_kn(kq*9.)-.5)*.12+corrosion*.22-contact*.22-wet*.12,.12,.97);
 let originalHeight=(mt_kn(kq*65.)-.5)*.00025*(1.-smoothstep(.4,1.6,footprintM*65.));
 return KpSurface(originalHeight-corrosion*.0008,color,rough);
}
fn kpConcreteStation(p:vec3<f32>,age:f32,wetness:f32,repair:f32,footprint:f32)->KpSurface{
 let q=p+vec3<f32>(19.,19.*.71,19.*.37);let large=mt_kn(q*.63);let meso=mt_kn(q*3.7);var fine=.5;if(footprint<.021){fine=mix(mt_kn(q*127.),.5,smoothstep(.003,.021,footprint));}
 let moisturePatch=smoothstep(.43,.72,large)*smoothstep(.28,.62,meso);let fresh=repair;let damp=clamp(moisturePatch*(.42+large*.58)*(1.-fresh*.85),0.,1.);let wet=wetness*clamp(damp+smoothstep(.60,.81,large)*.38+.22,0.,1.);
 let base=vec3<f32>(.468,.451,.381);let gray=moisturePatch*age*.18*(1.-fresh);var color=mix(base,base*.69+vec3<f32>(.027,.030,.025),gray);let chip=smoothstep(.64,.81,mt_kn(q*23.))*smoothstep(.46,.76,meso)*age;
 color=mix(color,base*vec3<f32>(.59,.56,.49),chip*.42);color=mix(color,base*vec3<f32>(.50,.56,.50),damp*age*.72);color=mix(color,mix(base,vec3<f32>(.80,.78,.69),.17),fresh*.85);color*=1.-wet*.13;
 let height=(fine-.5)*.00042-chip*.0007;let rough=clamp(.87+(fine-.5)*.07-wet*.23,.23,1.);return KpSurface(height,color,rough);
}
fn pl_rotate(v:vec3<f32>,axis:vec3<f32>,a:f32)->vec3<f32>{let c=cos(a);let s=sin(a);return v*c+cross(axis,v)*s+axis*dot(axis,v)*(1.0-c);}
fn pl_warp(p:vec3<f32>,phase:vec3<f32>)->vec3<f32>{let c1=vec3<f32>(0.12,1.42,0.04)+0.035*phase;let a1=normalize(vec3<f32>(0.38,0.82,0.42));let v1=p-c1;let t1=0.65*exp(-dot(v1,v1)/(2.4*2.4))*sin(1.45*dot(a1,v1)+0.7+phase.x);let q=c1+pl_rotate(v1,a1,t1);let c2=vec3<f32>(-0.16,1.63,-0.06)+0.025*phase;let a2=normalize(vec3<f32>(-0.67,0.15,0.73));let v2=q-c2;let t2=0.20*exp(-dot(v2,v2)/(2.1*2.1))*sin(4.1*dot(a2,v2)+2.0+phase.y);return c2+pl_rotate(v2,a2,t2);}
fn pl_xi(p:vec3<f32>,phase:vec3<f32>)->vec3<f32>{let q=pl_warp(p,phase)+vec3<f32>(2.73,0.91,1.37);let r=max(length(q),1e-4);return vec3<f32>(log2(r)-2.0,-q.z/r,atan2(q.x,q.y));}
fn pl_cell(xi:vec3<f32>,sc:f32)->f32{let a=cos(sc*xi.z)*cos(sc*xi.x)+cos(sc*xi.y)*cos(sc*xi.y)+cos(sc*xi.y)*cos(sc*xi.x);return cos(a)-0.6556965458313674;}
fn pl_macroFast(p:vec3<f32>)->f32{let xi=pl_xi(p,vec3<f32>(0.7,-1.3,2.1));let s=pl_cell(xi,1.0)+pl_cell(xi,2.0)*0.5+pl_cell(xi,4.0)*0.25+pl_cell(xi,8.0)*0.125+pl_cell(xi,16.0)*0.0625;return tanh(0.78*s);}
fn pl_microFast(p:vec3<f32>)->f32{let xi=pl_xi(p,vec3<f32>(0.7,-1.3,2.1));let s=pl_cell(xi,16.0)*0.0625+pl_cell(xi,32.0)*0.03125+pl_cell(xi,64.0)*0.015625;return tanh(10.5*s);}
fn pl_q(p:vec3<f32>,a:KpPlasterParams)->vec3<f32>{return vec3<f32>((p.xy-a.centerM)/max(a.halfM,vec2<f32>(0.08)),p.z*2.0);}
fn kpPlasterMacro(p:vec3<f32>,a:KpPlasterParams)->f32{let low=pl_macroFast(pl_q(p,a)+vec3<f32>(-0.17,0.31,0.09));let coarse=sin(p.x*2.7+p.y*0.9)*sin(p.y*3.2-p.x*0.7);return clamp(0.48*low+0.52*coarse,-1.0,1.0);}
fn kpPlasterMicro(p:vec3<f32>,a:KpPlasterParams)->f32{let m=pl_microFast(pl_q(p,a)*vec3<f32>(2.65,2.52,3.55)+vec3<f32>(-0.27,0.44,-0.19));let r=sin(p.x*47.0-p.y*39.0+p.z*58.0)*sin(p.x*31.0+p.y*37.0-p.z*43.0);return clamp(0.78*m+0.22*r,-1.0,1.0);}
fn pl_observed(p:vec3<f32>,a:KpPlasterParams,physicalFootprintM:f32)->f32{
 let q=pl_q(p,a);let phase=vec3<f32>(-1.3,4.7,2.2);let xi=pl_xi(q,phase);
 let e=max(physicalFootprintM,1e-7);let dq=vec3<f32>(e/max(a.halfM.x,0.08),e/max(a.halfM.y,0.08),e*2.0);
 let fp=max(length(pl_xi(q+vec3<f32>(dq.x,0,0),phase)-xi),max(length(pl_xi(q+vec3<f32>(0,dq.y,0),phase)-xi),length(pl_xi(q+vec3<f32>(0,0,dq.z),phase)-xi)));
 var sum=0.0;var sc=1.0;for(var i=0;i<17;i++){let gate=1.0-smoothstep(0.44,1.12,fp*sc);sum+=gate*pl_cell(xi,sc)/sc;sc*=2.0;}return tanh(0.86*sum);
}
fn kpPlasterOriginalField(pLocalM:vec3<f32>,a:KpPlasterParams,physicalFootprintM:f32)->KpPlasterField{
 let pm=kpPlasterMacro(pLocalM,a);let pu=kpPlasterMicro(pLocalM,a);let obs=pl_observed(pLocalM,a,physicalFootprintM);
 
 let wave=max(a.grainWavelengthM,0.0003);let phase=dot(pLocalM,normalize(vec3<f32>(83.0,-61.0,97.0)))*(6.283185307179586/wave);
 let grain=sin(phase)*(1.0-smoothstep(0.35,0.90,physicalFootprintM/wave));
 let microGate=1.0-smoothstep(0.008,0.020,physicalFootprintM);
 let h=microGate*a.microM*(0.26*obs+0.18*pu)+a.grainHeightM*grain;
 let base=mix(a.paletteDark,a.paletteLight,0.58+0.08*obs+0.22*pm)*(0.94+a.grainColor*grain);
 let rough=clamp(0.95+0.032*(-obs),0.86,0.997);
 let thickness=clamp(a.thicknessM+a.reliefM*pm+a.geometryMicroM*pu,a.minThicknessM,a.maxThicknessM);
 return KpPlasterField(pm,pu,thickness,KpSurface(h,base,rough));
}
fn stationPlasterParams(extent:vec3<f32>)->KpPlasterParams{return KpPlasterParams(vec2<f32>(0.),max(extent.xy,vec2<f32>(.08)),.0165,.0012+.0018*u.age,0.,.013,.020,.0001,vec3<f32>(.48,.44,.35),vec3<f32>(.82,.76,.64),.0008,.000008,.018);}
fn stationWaterfrontWaterContact(member:f32)->f32{
if(member>=0.&&member<1.){return 0.35;}
if(member>=1.&&member<2.){return 1.;}
if(member>=2.&&member<73.){return 0.35;}
if(member>=115.&&member<116.){return 0.35;}
if(member>=116.&&member<122.){return 1.;}
if(member>=122.&&member<128.){return 1.;}
return 0.;}
fn heritagePlasterDirection(member:f32,d:vec3<f32>)->vec3<f32>{
if(member==691.){return vec3<f32>(1.*d.x-(0.)*d.z,d.y,0.*d.x+1.*d.z); }
if(member==692.){return vec3<f32>(0.*d.x-(1.)*d.z,d.y,1.*d.x+0.*d.z); }
if(member==693.){return vec3<f32>(-1.*d.x-(0.)*d.z,d.y,0.*d.x+-1.*d.z); }
if(member==694.){return vec3<f32>(0.*d.x-(-1.)*d.z,d.y,-1.*d.x+0.*d.z); }
return d;}
fn heritageTimberDirection(member:f32,d:vec3<f32>)->vec3<f32>{
if(member==381.){return d.yxz;}
if(member==382.){return d.yxz;}
if(member==383.){return d.xyz;}
if(member==384.){return d.xyz;}
if(member==385.){return d.xyz;}
if(member==386.){return d.xyz;}
if(member==387.){return d.xyz;}
if(member==388.){return d.yxz;}
if(member==389.){return d.yxz;}
if(member==397.){return d.yxz;}
if(member==398.){return d.yxz;}
if(member==399.){return d.xyz;}
if(member==400.){return d.xyz;}
if(member==401.){return d.xyz;}
if(member==402.){return d.xyz;}
if(member==403.){return d.xyz;}
if(member==404.){return d.yxz;}
if(member==405.){return d.yxz;}
if(member==413.){return d.yxz;}
if(member==414.){return d.yxz;}
if(member==415.){return d.xyz;}
if(member==416.){return d.xyz;}
if(member==417.){return d.xyz;}
if(member==418.){return d.xyz;}
if(member==419.){return d.xyz;}
if(member==420.){return d.yxz;}
if(member==421.){return d.yxz;}
if(member==429.){return d.yxz;}
if(member==430.){return d.yxz;}
if(member==431.){return d.xyz;}
if(member==432.){return d.xyz;}
if(member==433.){return d.xyz;}
if(member==434.){return d.xyz;}
if(member==435.){return d.xyz;}
if(member==436.){return d.yxz;}
if(member==437.){return d.yxz;}
if(member==445.){return d.yxz;}
if(member==446.){return d.yxz;}
if(member==447.){return d.zxy;}
if(member==448.){return d.zxy;}
if(member==449.){return d.zxy;}
if(member==450.){return d.zxy;}
if(member==451.){return d.zxy;}
if(member==452.){return d.yxz;}
if(member==453.){return d.yxz;}
if(member==461.){return d.yxz;}
if(member==462.){return d.yxz;}
if(member==463.){return d.zxy;}
if(member==464.){return d.zxy;}
if(member==465.){return d.zxy;}
if(member==466.){return d.zxy;}
if(member==467.){return d.zxy;}
if(member==468.){return d.yxz;}
if(member==469.){return d.yxz;}
if(member==477.){return d.yxz;}
if(member==478.){return d.yxz;}
if(member==479.){return d.zxy;}
if(member==480.){return d.zxy;}
if(member==481.){return d.zxy;}
if(member==482.){return d.zxy;}
if(member==483.){return d.zxy;}
if(member==484.){return d.yxz;}
if(member==485.){return d.yxz;}
if(member==493.){return d.yxz;}
if(member==494.){return d.yxz;}
if(member==495.){return d.zxy;}
if(member==496.){return d.zxy;}
if(member==497.){return d.zxy;}
if(member==498.){return d.zxy;}
if(member==499.){return d.zxy;}
if(member==500.){return d.yxz;}
if(member==501.){return d.yxz;}
if(member==509.){return d.yxz;}
if(member==510.){return d.yxz;}
if(member==511.){return d.xyz;}
if(member==512.){return d.xyz;}
if(member==513.){return d.xyz;}
if(member==514.){return d.xyz;}
if(member==515.){return d.xyz;}
if(member==516.){return d.yxz;}
if(member==517.){return d.yxz;}
if(member==525.){return d.yxz;}
if(member==526.){return d.yxz;}
if(member==527.){return d.xyz;}
if(member==528.){return d.xyz;}
if(member==529.){return d.xyz;}
if(member==530.){return d.xyz;}
if(member==531.){return d.xyz;}
if(member==532.){return d.yxz;}
if(member==533.){return d.yxz;}
if(member==541.){return d.yxz;}
if(member==542.){return d.yxz;}
if(member==543.){return d.xyz;}
if(member==544.){return d.xyz;}
if(member==545.){return d.xyz;}
if(member==546.){return d.xyz;}
if(member==547.){return d.xyz;}
if(member==548.){return d.yxz;}
if(member==549.){return d.yxz;}
if(member==557.){return d.yxz;}
if(member==558.){return d.yxz;}
if(member==559.){return d.xyz;}
if(member==560.){return d.xyz;}
if(member==561.){return d.xyz;}
if(member==562.){return d.xyz;}
if(member==563.){return d.xyz;}
if(member==564.){return d.yxz;}
if(member==565.){return d.yxz;}
if(member==573.){return d.yxz;}
if(member==574.){return d.yxz;}
if(member==575.){return d.zxy;}
if(member==576.){return d.zxy;}
if(member==577.){return d.zxy;}
if(member==578.){return d.zxy;}
if(member==579.){return d.zxy;}
if(member==580.){return d.yxz;}
if(member==581.){return d.yxz;}
if(member==589.){return d.yxz;}
if(member==590.){return d.yxz;}
if(member==591.){return d.zxy;}
if(member==592.){return d.zxy;}
if(member==593.){return d.zxy;}
if(member==594.){return d.zxy;}
if(member==595.){return d.zxy;}
if(member==596.){return d.yxz;}
if(member==597.){return d.yxz;}
if(member==605.){return d.yxz;}
if(member==606.){return d.yxz;}
if(member==607.){return d.zxy;}
if(member==608.){return d.zxy;}
if(member==609.){return d.zxy;}
if(member==610.){return d.zxy;}
if(member==611.){return d.zxy;}
if(member==612.){return d.yxz;}
if(member==613.){return d.yxz;}
if(member==621.){return d.yxz;}
if(member==622.){return d.yxz;}
if(member==623.){return d.zxy;}
if(member==624.){return d.zxy;}
if(member==625.){return d.zxy;}
if(member==626.){return d.zxy;}
if(member==627.){return d.zxy;}
if(member==628.){return d.yxz;}
if(member==629.){return d.yxz;}
return d;}
fn rep(x:f32,pitch:f32,lo:f32,hi:f32)->f32{return x-clamp(round(x/pitch),lo,hi)*pitch;}
fn stateWet(p:vec3<f32>)->f32{let drain=1.-smoothstep(.12,.75,abs(rep(p.x,7.5,-4.,4.)));let rain=(1.-smoothstep(7.5,12.,p.y))*smoothstep(.1,.4,p.y);return u.age*.12*(.15+drain*rain)+(1.-smoothstep(.2,1.8,p.y))*.15;}
fn repairAt(p:vec3<f32>)->f32{return .08+.65*(1.-smoothstep(.9,1.4,abs(p.x-15.)))*(1.-smoothstep(1.1,2.2,p.y));}
fn brickQ(p:vec3<f32>,axis:u32,d:f32)->vec3<f32>{let row=floor(p.y/.073);let shift=select(0.,.125,(i32(row)&1)==1);let face=select(p.x,p.z,axis==12u);return vec3<f32>(fract((face+shift)/.25)*.25-.125,fract(p.y/.073)*.073-.0365,.055384615+d);}
fn resolveStationState(p:vec3<f32>)->StationState{let repair=repairAt(p);return StationState(u.age,stateWet(p),repair,u.age*(1.-repair));}
fn stationHeritageMember(h:HitField)->bool{return h.seed==71.||h.seed==171.||h.seed==172.||h.seed==173.||h.seed==174.||h.seed==175.||(h.seed==191.&&h.id!=17u&&h.id!=3u);}
fn stationHeritageExposure(h:HitField,p:vec3<f32>)->vec3<f32>{
 
 if(h.seed==174.){return vec3<f32>(0.,.55,1.-smoothstep(1.2,2.,p.y));}
 let tower=h.seed==71.||h.seed==171.||h.seed==172.||h.seed==173.||h.seed==175.;
 let q=select(p,p-vec3<f32>(24.,0.,4.),tower);
 let belowCornice=select(12.-q.y,min(abs(q.y-28.60+.22),min(abs(q.y-37.55+.20),abs(q.y-8.10+.20))),tower);
 let sheltered=(1.-smoothstep(.08,.40,abs(belowCornice)))*(1.-smoothstep(.4,1.,abs(q.y-12.))*.1);
 let edge=select(abs(rep(p.x,7.5,-4.,4.)),abs(min(abs(q.x),abs(q.z))-.87),tower);
 let rain=(1.-smoothstep(.035,.17,edge))*(.35+.65*smoothstep(1.5,3.,q.y));
 let touch=(1.-smoothstep(1.2,2.0,q.y))*(1.-smoothstep(.15,.65,edge));
 return vec3<f32>(rain,sheltered,touch);
}
fn stationMemberState(h:HitField,p:vec3<f32>,state:StationState)->StationState{var st=state;
 if(stationHeritageMember(h)){let e=stationHeritageExposure(h,p);st.age=min(1.,.32+state.age*.78);st.repair=max(st.repair,.38);st.wet=min(.12,state.wet*.35+e.x*.035);st.retained=st.age*(1.-st.repair*.35);}
if(h.seed==186.){let contact=stationWaterfrontWaterContact(h.sourceSeed);st.wet=max(st.wet,contact*(1.-smoothstep(-.52,.65,p.y)));}return st;}
fn stationWoodParams(h:HitField,st:StationState)->KpWoodParams{var wp=kpWoodDefaultParams();if(h.seed==38.||h.seed==39.||h.seed==138.||h.seed==139.||h.seed==148.||h.seed==149.){wp.textureScale=BENCH_WOOD_SCALE;wp.grainContrast=BENCH_WOOD_CONTRAST;}let stockSeed=select(h.sourceSeed,floor(h.sourceSeed/8.),h.seed==138.||h.seed==139.||h.seed==148.||h.seed==149.);wp.seed=fract(wp.seed+stockSeed*.61803398875);wp.reliefScale*=.35+.85*st.retained;wp.roughness=clamp(wp.roughness+.07*st.retained-.12*st.repair,.2,.98);wp.agedSurfaceColor=mix(wp.freshCutColor,wp.agedSurfaceColor,.4+.6*st.retained);wp.clearcoat=.12*st.repair;return wp;}
fn stationMaterialDirection(h:HitField,p:vec3<f32>,d:vec3<f32>)->vec3<f32>{if(h.seed==172.){return heritageTimberDirection(h.sourceSeed,d);}if(h.seed==174.){return heritagePlasterDirection(h.sourceSeed,d);}if(h.id==4u&&(h.seed==138.||h.seed==139.)){return vec3<f32>(-d.z,d.y,d.x);}if(h.id==4u&&(h.seed==148.||h.seed==149.)){let side=select(-1.,1.,p.z>=0.);return vec3<f32>(d.x*side,d.y,d.z*side);}if(h.id==4u&&h.seed==38.){return d.zxy;}if(h.id==4u&&h.seed==39.){return vec3<f32>(d.x,d.y,d.z*select(-1.,1.,p.z>=0.));}return d;}
fn stationWoodCoordinates(h:HitField)->vec3<f32>{let k=h.sourceSeed-floor(h.sourceSeed/8.)*8.;if(h.seed==138.||h.seed==148.){return h.q+vec3<f32>(0.,0.,k*.115);}if(h.seed==139.||h.seed==149.){return h.q+vec3<f32>(0.,k*.10,0.);}return h.q;}
fn stationWoodClass(h:HitField)->f32{let face=abs(h.q)-h.extent;return select(0.,1.,face.x>=max(face.y,face.z));}
fn stationStoneHeight(qM:vec3<f32>)->f32{let pos=qM/KP_STONE_SCALE_M;let seed=st_seedVector(KP_STONE_COLOR_SEED,.071);let q=st_warp(pos,seed);let broad=st_sf(q*1.35+seed);let region=st_sf(q*3.2+seed+vec3<f32>(11.));let vein=(1.-smoothstep(.028,.072,st_line(q,seed)))*smoothstep(.34,.63,region);let pits=pow(max(0.,(st_sf(q*19.+st_seedVector(KP_STONE_PORE_SEED,.061))-.57)/.43),2.);return ((broad-.5)*.018+(region-.5)*.007+vein*.004-pits*.025)*KP_STONE_SCALE_M;}
fn stationConcreteHeight(p:vec3<f32>,age:f32)->f32{let q=p+vec3<f32>(19.,19.*.71,19.*.37);let meso=mt_kn(q*3.7);let fine=mt_kn(q*127.);let chip=smoothstep(.64,.81,mt_kn(q*23.))*smoothstep(.46,.76,meso)*age;return(fine-.5)*.00042-chip*.0007;}
fn stationCoatingThickness(h:HitField,p:vec3<f32>,st:StationState)->f32{let a=stationPlasterParams(h.extent);let macroSignal=kpPlasterMacro(h.q,a);let sourceThickness=clamp(a.thicknessM+a.reliefM*macroSignal,a.minThicknessM,a.maxThicknessM);let exposure=clamp(st.wet*2.8+(1.-smoothstep(.2,1.8,p.y))*.18,0.,1.);let decay=clamp(st.retained*exposure,0.,1.);let defect=macroSignal*.5+.5;let coverage=smoothstep(decay*.9-.03,decay*.9+.04,defect);return sourceThickness*coverage;}
fn stationMetalCoordinates(h:HitField,p:vec3<f32>)->vec3<f32>{let rail=h.id==3u&&h.seed==55.;return vec3<f32>(h.q.x,select(p.y,p.y+(1.07-RAIL_CROWN),rail),h.q.z);}
fn isStationRoof(h:HitField)->bool{return h.id==15u||(h.id==3u&&(h.seed==8.||h.seed==94.||h.seed==96.));}
fn stationRoofPaintCoverage(h:HitField,p:vec3<f32>,st:StationState)->f32{return 1.-kpMetalCorrosion(stationMetalCoordinates(h,p),st.age,st.wet,st.repair)*.8;}
fn stationLegacyMetal(h:HitField,fp:f32)->KpSurface{let brass=h.seed==182.;let q=h.q+vec3<f32>(19.);let color=select(vec3<f32>(.1946178304415758,.3467040563550296,.2831487404299921),vec3<f32>(.4793201831008268,.3564001441459435,.14412847085805777),brass);let rough=select(.53,.31,brass);let height=(mt_kn(q*65.)-.5)*.00025*(1.-smoothstep(.4,1.6,fp*65.));return KpSurface(height,color*(.94+.09*mt_kfb(q*3.1)),clamp(rough+(mt_kn(q*9.)-.5)*.12,.08,.99));}
fn stationOriginalFinish(q0:vec3<f32>,base:vec3<f32>,rough:f32,fp:f32)->KpSurface{let q=q0+vec3<f32>(19.);return KpSurface((mt_kn(q*65.)-.5)*.00025*(1.-smoothstep(.4,1.6,fp*65.)),base*(.94+.09*mt_kfb(q*3.1)),clamp(rough+(mt_kn(q*9.)-.5)*.12,.08,.99));}
fn stationIronRole(h:HitField)->vec4<f32>{let castRole=h.seed==56.||h.seed==38.||h.seed==39.||h.seed==184.;if(castRole){return vec4<f32>(.0953074666309647,.16826940018969075,.13563332965520566,.58);}if(h.seed==188.){return vec4<f32>(.0295568344378088,.05448027644244237,.04091519690685319,.53);}return vec4<f32>(.22696587351009836,.3049873140698863,.26225065752969623,.43);}
fn stationIronMetalness(h:HitField)->f32{if(h.seed==56.||h.seed==38.||h.seed==39.||h.seed==184.){return .10;}if(h.seed==188.){return .60;}return .40;}
fn stationBrickPoint(h:HitField,p:vec3<f32>)->vec3<f32>{if(h.seed==175.){return vec3<f32>(h.q.x,p.y,h.q.z);}return p;}
fn stationBrickSample(h:HitField,p:vec3<f32>)->StationBrickSample{
 let bp=stationBrickPoint(h,p);
 if(stationHeritageMember(h)){
  let row=floor(bp.y/.073);let shift=select(0.,.125,(i32(row)&1)==1);
  let face=select(bp.x,bp.z,h.id==12u);let phase=(face+shift)/.25;
  let q=vec3<f32>(fract(phase)*.25-.125,fract(bp.y/.073)*.073-.0365,.055384615+h.d);
  return StationBrickSample(q,19.+row*13.+floor(phase));
 }
 return StationBrickSample(brickQ(bp,h.id,h.d),19.+floor(bp.y/.073)*13.+floor((bp.x+bp.z)/.25));
}
fn evaluateStationGeometry(h:HitField,p:vec3<f32>,state:StationState)->StationGeometry{
 let st=stationMemberState(h,p,state);
 var g=StationGeometry(h.d,0.,0.,1.);
 if(h.id==1u||h.id==12u){let sample=stationBrickSample(h,p);let q=sample.q;let seed=sample.seed;let variant=i32(abs(seed))%4;let native=kpBrickBaseDistance(q,seed,variant,.42);let macroSignal=native-kpBrickAnalyticBoundDistance(q);g.loss=clamp(st.retained*st.wet*(.0004+max(0.,macroSignal)*.6),0.,.0016);let mortarDistance=h.d+.006;let brickDistance=native+g.loss;g.brickWeight=select(0.,1.,brickDistance<=mortarDistance);g.d=min(mortarDistance,brickDistance);}
 if(h.id==2u){g.d=h.d-clamp(stationStoneHeight(h.q*.19)*(.25+.75*st.retained),-.004,.004);}
 if((h.id==3u||h.id==15u)&&h.seed!=181.&&h.seed!=182.){g.loss=kpMetalCorrosion(stationMetalCoordinates(h,p),st.age,st.wet,st.repair)*.0008;g.d=h.d+g.loss;if(isStationRoof(h)){g.thickness=.00006*stationRoofPaintCoverage(h,p,st);g.d-=g.thickness;}}
 if(h.id==4u){g.d=h.d-kpWoodMacroDisplacement(stationWoodCoordinates(h),stationWoodClass(h),stationWoodParams(h,st));}
 if(h.id==17u||h.id==19u){g.d=h.d-stationConcreteHeight(h.q,st.retained);}
 if(h.id==13u){g.thickness=stationCoatingThickness(h,p,st);g.d=h.d-clamp(stationStoneHeight(h.q*.19)*.25,-.001,.001)-g.thickness;}
 return g;
}
fn evaluateStationMatter(h:HitField,p:vec3<f32>,normal:vec3<f32>,fp:f32)->StationMatter{
 let state=resolveStationState(p);let st=stationMemberState(h,p,state);let g=evaluateStationGeometry(h,p,state);var m=StationMatter(g.d,KpSurface(0.,vec3<f32>(.34,.33,.28),.85),0.,1.,1.,0.,0u,0.,1.,0.);
 if(h.id==1u||h.id==12u){let sample=stationBrickSample(h,p);let q=sample.q;let seed=sample.seed;let variant=i32(abs(seed))%4;let loss=g.loss;m.surface=kpBrickOriginalSurface(q,seed,variant,.42,fp);if(g.brickWeight==0.){m.surface=KpSurface(0.,vec3<f32>(.28,.26,.21),.94);}m.surface.albedo*=1.-st.wet*.18-loss*60.;m.surface.roughness=clamp(m.surface.roughness+loss*50.,.15,.98);m.microHeight=m.surface.height;m.layer=1u;}
 if(h.id==2u){let relief=.25+.75*st.retained;m.surface=kpStoneSurface(h.q*.19,st.age,st.wet,st.repair,fp*.19);m.surface.height*=relief;m.layer=2u;}
 if(h.id==3u||h.id==15u){let loss=g.loss;m.surface=kpMetalSurface(stationMetalCoordinates(h,p),st.age,st.wet,st.repair,fp);let corrosion=kpMetalCorrosion(stationMetalCoordinates(h,p),st.age,st.wet,st.repair);let role=stationIronRole(h);if(!isStationRoof(h)){m.surface.albedo+=(role.rgb-vec3<f32>(.17,.235,.20))*(.94+.09*mt_kfb((stationMetalCoordinates(h,p)+vec3<f32>(19.))*3.1))*(1.-corrosion*.80)*(1.-st.wet*.18);m.surface.roughness=clamp(m.surface.roughness+role.a-.53,.12,.97);}if(isStationRoof(h)){let mq=stationMetalCoordinates(h,p);let pigmentDelta=vec3<f32>(.066,.073,.078)-vec3<f32>(.17,.235,.20);m.surface.albedo+=pigmentDelta*(.94+.09*mt_kfb((mq+vec3<f32>(19.))*3.1))*stationRoofPaintCoverage(h,p,st)*(1.-st.wet*.18);}m.metal=select(stationIronMetalness(h)*(1.-corrosion),0.,isStationRoof(h));if(h.id==3u&&h.seed==55.){let contact=1.-smoothstep(.01,.035,abs(stationMetalCoordinates(h,p).y-1.07));m.metal=(.40+.48*contact)*(1.-corrosion);}m.microHeight=m.surface.height+loss;m.layer=3u;}
 
 
 if(h.id==3u&&(h.seed==181.||h.seed==182.)){m.surface=stationLegacyMetal(h,fp);m.metal=select(.60,.78,h.seed==182.);m.microHeight=m.surface.height;m.layer=3u;}
 if(h.id==4u){let wp=stationWoodParams(h,st);let cls=stationWoodClass(h);let wn=stationMaterialDirection(h,p,normal);let source=kpWoodOriginalSample(stationWoodCoordinates(h),wn,cls,wp,fp,length(p-u.eye));m.surface=source.surface;m.cavity=source.cavity;m.specular=source.specularLevel;m.microHeight=source.surface.height;m.layer=4u;m.clearcoat=source.clearcoat;m.clearcoatRoughness=source.clearcoatRoughness;m.parallaxHeight01=source.parallaxHeight01;}
 if(h.id==17u||h.id==19u){m.surface=kpConcreteStation(h.q,st.retained,st.wet,st.repair,fp);m.layer=17u;}
 if(h.id==13u){let a=stationPlasterParams(h.extent);let thickness=g.thickness;m.surface=kpPlasterOriginalField(h.q,a,fp).surface;let revealed=1.-smoothstep(.0001,.001,thickness);if(revealed>0.){let exposed=kpStoneSurface(h.q*.19,st.age,st.wet,st.repair,fp*.19);m.surface.albedo=mix(m.surface.albedo,exposed.albedo,revealed);m.surface.roughness=mix(m.surface.roughness,exposed.roughness,revealed);}m.surface.albedo*=1.-st.wet*.18;m.microHeight=m.surface.height*(1.-revealed);m.layer=select(13u,2u,revealed>.5);}
 if(h.id==7u){let lamp=h.seed==184.;var base=select(vec3<f32>(.8148465722161012,.7529422167760779,.5520114015120001),vec3<f32>(1.,.7230551289219693,.3564001441459435),lamp);if(h.seed==187.){base=vec3<f32>(.7835377915261935,.7011018919329731,.5271151257058131);}m.surface=stationOriginalFinish(h.q,base,select(.34,.20,lamp),fp);m.metal=select(0.,.05,lamp);m.microHeight=m.surface.height;m.layer=7u;}
 if(h.id==8u){m.surface=stationOriginalFinish(h.q,vec3<f32>(.0295568344378088,.052860647023180246,.04091519690685319),.34,fp);m.microHeight=m.surface.height;m.layer=8u;}
 if(h.id==18u){m.surface=stationOriginalFinish(h.q,vec3<f32>(.13843161503245183,.16826940018969075,.14412847085805777),.92,fp);m.metal=.05;m.microHeight=m.surface.height;m.layer=18u;}
 if(h.id==9u){m.surface=stationOriginalFinish(h.q,vec3<f32>(.04518620438567554,.10224173308810132,.07227185068231748),.34,fp);m.microHeight=m.surface.height;m.layer=9u;}
 
 
 
 if(stationHeritageMember(h)){
  let e=stationHeritageExposure(h,p);let patina=st.retained*(.018+e.x*.045+e.y*.060);
  if(h.id==2u){let l=dot(m.surface.albedo,vec3<f32>(.2126,.7152,.0722));let grain=clamp(l/.18,.50,1.65);m.surface.albedo=vec3<f32>(.40,.385,.34)*(.84+.16*grain)*(1.-patina);m.surface.roughness=clamp(m.surface.roughness-.035*e.z,.48,.88);}
  if(h.id==13u){let l=dot(m.surface.albedo,vec3<f32>(.2126,.7152,.0722));m.surface.albedo=vec3<f32>(.62,.585,.50)*clamp(l/.72,.84,1.12)*(1.-patina);m.surface.roughness=clamp(m.surface.roughness,.59,.88);}
  if(h.id==1u||h.id==12u){m.surface.albedo*=vec3<f32>(1.04,.97,.91)*(1.-patina*.55);}
  if(h.id==19u){let l=dot(m.surface.albedo,vec3<f32>(.2126,.7152,.0722));m.surface.albedo=vec3<f32>(.67,.655,.60)*clamp(l/.40,.89,1.07)*(1.-patina*.6);m.surface.roughness=clamp(m.surface.roughness,.67,.90);m.metal=0.;m.layer=19u;}
 }
 return m;
}
@fragment fn heritageStateProbe(@builtin(position)pixel:vec4<f32>)->@location(0)vec4<f32>{
 let index=u32(pixel.x);let row=u32(pixel.y);
 var p=vec3<f32>(0.);var normal=vec3<f32>(0.,1.,0.);
 var h=HitField(0.,0u,p,0.,0.,vec3<f32>(1.),0.);
 switch(index){case 0u:{p=vec3<f32>(24.42,10.011,6.962);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(0.42,10.011,2.962),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 1u:{p=vec3<f32>(24.86,9.8,7.24);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,2u,vec3<f32>(0.86,9.8,3.24),171.,0.002,vec3<f32>(4.8,23.,4.8),0.);}
case 2u:{p=vec3<f32>(24.21,3.924,6.941);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,4u,vec3<f32>(0.21,0.024,0.013),172.,0.002,vec3<f32>(0.715,0.022,0.0355),385.);}
case 3u:{p=vec3<f32>(7.5,1.,8.12);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,13u,vec3<f32>(0.13,0.15,0.122),191.,0.002,vec3<f32>(0.2,1.5,0.12),0.);}
case 4u:{p=vec3<f32>(24.17,41.17,4.23);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,19u,vec3<f32>(0.17,41.17,0.23),173.,0.002,vec3<f32>(2.7,1.3,2.7),0.);}
case 5u:{p=vec3<f32>(-20.,1.12,-13.75);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,4u,vec3<f32>(0.21,0.052,0.013),38.,0.002,vec3<f32>(1.7,0.05,0.055),0.);}
case 6u:{p=vec3<f32>(15.,0.852,-20.);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,17u,vec3<f32>(0.31,0.577,0.17),77.,0.002,vec3<f32>(3.4,0.575,67.5),0.);}
case 7u:{p=vec3<f32>(-20.,14.,-25.);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,3u,vec3<f32>(0.31,0.042,0.17),8.,0.002,vec3<f32>(1.,1.,1.),0.);}
case 8u:{p=vec3<f32>(60.177,-0.45,4.2);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,2u,vec3<f32>(0.377,1.2,0.31),186.,0.002,vec3<f32>(0.375,1.25,100.),1.);}
case 9u:{p=vec3<f32>(25.2,15.4,6.314);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,13u,vec3<f32>(1.2,0.45,-0.026),174.,0.002,vec3<f32>(2.33,12.95,0.01),691.);}
case 10u:{p=vec3<f32>(25.66372124094,35.4,5.38087852847);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(0.2,0.4,0.182),175.,0.002,vec3<f32>(0.84,2.23,0.18),695.);}
case 11u:{p=vec3<f32>(22.78975,17.1915,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-1.2102499999999985,17.1915,2.96),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 12u:{p=vec3<f32>(22.79025,17.1915,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-1.2097499999999997,17.1915,2.96),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 13u:{p=vec3<f32>(22.79,17.1915,6.95975);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-1.2100000000000009,17.1915,2.9597499999999997),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 14u:{p=vec3<f32>(22.79,17.1915,6.96025);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-1.2100000000000009,17.1915,2.9602500000000003),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 15u:{p=vec3<f32>(22.87475,17.1915,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-1.1252500000000012,17.1915,2.96),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 16u:{p=vec3<f32>(22.87525,17.1915,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-1.1247499999999988,17.1915,2.96),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 17u:{p=vec3<f32>(26.96,17.1915,2.78975);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,12u,vec3<f32>(2.96,17.1915,-1.21025),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 18u:{p=vec3<f32>(-18.79,10.011,8.12);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(0.2,0.3,0.002),191.,0.002,vec3<f32>(0.8,0.5,0.2),137.);}
case 19u:{p=vec3<f32>(22.49975,17.1,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-1.5002500000000012,17.1,2.96),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 20u:{p=vec3<f32>(22.50025,17.1,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-1.4997499999999988,17.1,2.96),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 21u:{p=vec3<f32>(-0.21,17.1915,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-24.21,17.1915,2.96),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 22u:{p=vec3<f32>(-0.19,17.1915,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(-24.19,17.1915,2.96),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 23u:{p=vec3<f32>(25.6,35.4,5.4);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(0.07,0.4,0.17975),175.,0.002,vec3<f32>(0.84,2.23,0.18),695.);}
case 24u:{p=vec3<f32>(25.6,35.4,5.4);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(0.07,0.4,0.18025),175.,0.002,vec3<f32>(0.84,2.23,0.18),695.);}
case 25u:{p=vec3<f32>(26.96,17.1915,2.78975);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,12u,vec3<f32>(2.960000000000001,17.1915,-1.21025),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 26u:{p=vec3<f32>(26.9605,17.1915,2.78975);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,12u,vec3<f32>(2.9604999999999997,17.1915,-1.21025),71.,0.002,vec3<f32>(2.96,13.65,2.96),0.);}
case 27u:{p=vec3<f32>(-0.21,-0.11,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(0.2,-0.11,0.002),71.,0.002,vec3<f32>(0.8,0.5,0.2),0.);}
case 28u:{p=vec3<f32>(-0.21,-0.04,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(0.2,-0.04,0.002),71.,0.002,vec3<f32>(0.8,0.5,0.2),0.);}
case 29u:{p=vec3<f32>(-1.2,0.15,-3.14);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,12u,vec3<f32>(0.2,0.3,0.002),1.,0.002,vec3<f32>(0.8,0.5,0.2),0.);}
case 30u:{p=vec3<f32>(22.79,17.1915,6.96);normal=vec3<f32>(0.,1.,0.);h=HitField(0.002,1u,vec3<f32>(0.2,0.3,0.002),1.,0.002,vec3<f32>(0.8,0.5,0.2),0.);}
default:{return vec4<f32>(-999.);}}
 let raw=resolveStationState(p);
 let geometry=evaluateStationGeometry(h,p,raw);
 let matter=evaluateStationMatter(h,p,normal,.0005);
 let state=stationMemberState(h,p,raw);
 if(row==0u){return vec4<f32>(geometry.d,matter.d,f32(matter.layer),f32(index+1u));}
 if(row==1u){return vec4<f32>(matter.surface.albedo,matter.surface.roughness);}
 if(row==2u){return vec4<f32>(matter.microHeight,geometry.loss,geometry.thickness,h.baseD);}
 if(row==3u){return vec4<f32>(state.age,state.wet,state.repair,state.retained);}
 if(h.id==1u||h.id==12u){let brick=stationBrickSample(h,p);return vec4<f32>(brick.q,brick.seed);}
 return vec4<f32>(0.);
}
