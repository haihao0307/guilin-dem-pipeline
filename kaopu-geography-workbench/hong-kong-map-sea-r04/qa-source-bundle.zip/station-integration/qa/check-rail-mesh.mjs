/** Validate persisted rail GPU inputs and draw-group coverage without a GPU. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {railMembers,railMemberSample,railProbeFixtures} from '../rail-resolver.mjs';
import {hitFromPacked,inspectHit} from '../material-sampler.mjs';

const root=new URL('../',import.meta.url);
const bytes=name=>fs.readFileSync(new URL(name,root));
const read=(name,Type)=>{const b=bytes(name);return new Type(b.buffer,b.byteOffset,b.byteLength/Type.BYTES_PER_ELEMENT);};
const manifest=JSON.parse(bytes('MESH_MANIFEST.json'));
const positions=read('mesh-positions.f32',Float32Array),normals=read('mesh-normals.f32',Float32Array),hits=read('mesh-hits.f32',Float32Array),indices=read('mesh-indices.u32',Uint32Array);
const near=(a,b,tolerance=2e-5)=>assert.ok(Math.abs(a-b)<=tolerance,`${a} != ${b}`);
assert.equal(positions.length,manifest.vertexCount*3);assert.equal(normals.length,positions.length);assert.equal(hits.length,manifest.vertexCount*12);assert.equal(indices.length,manifest.triangleCount*3);

let vertices=0,indexCount=0,railVertices=0,railTriangles=0,railGroups=0,maxRailPackedResidualM=0,maxFloat32PositionReevaluationResidualM=0,maxPackedCoordinateDifferenceM=0;
for(const group of manifest.groups){
  assert.equal(group.start,vertices);assert.equal(group.indexStart,indexCount);assert.equal(group.indexCount%3,0);
  vertices+=group.vertexCount;indexCount+=group.indexCount;
  if(!group.vertexCount){assert.equal(group.bounds,null);assert.equal(group.indexCount,0);continue;}
  assert.ok(group.bounds?.min.every(Number.isFinite)&&group.bounds.max.every(Number.isFinite));
  for(let j=group.indexStart;j<indexCount;j++)assert.ok(indices[j]>=group.start&&indices[j]<vertices,`${group.label}: cross-group index ${indices[j]}`);
  const rail=group.family==='rail';
  if(rail){railGroups++;railVertices+=group.vertexCount;railTriangles+=group.indexCount/3;assert.equal(group.label,railMembers[group.member].id);}
  for(let j=group.start;j<vertices;j++){
    const p=Array.from(positions.subarray(j*3,j*3+3));
    for(let axis=0;axis<3;axis++)assert.ok(p[axis]>=group.bounds.min[axis]-2e-5&&p[axis]<=group.bounds.max[axis]+2e-5,`${group.label}: bounds omit vertex`);
    if(!rail)continue;
    const h=hitFromPacked(hits,j),expected=railMemberSample(group.member,p),normal=Array.from(normals.subarray(j*3,j*3+3));
    assert.equal(inspectHit(p,normal,h,.5),0);assert.equal(h.id,expected.id);assert.equal(h.seed,expected.seed);assert.equal(h.sourceSeed,expected.sourceSeed);
    for(let axis=0;axis<3;axis++){near(h.q[axis],expected.q[axis]);near(h.extent[axis],expected.extent[axis],1e-7);maxPackedCoordinateDifferenceM=Math.max(maxPackedCoordinateDifferenceM,Math.abs(h.q[axis]-expected.q[axis]));}
    near(h.baseD,expected.baseD);maxRailPackedResidualM=Math.max(maxRailPackedResidualM,Math.abs(h.baseD));maxFloat32PositionReevaluationResidualM=Math.max(maxFloat32PositionReevaluationResidualM,Math.abs(expected.baseD));
  }
}
assert.equal(vertices,manifest.vertexCount);assert.equal(indexCount,indices.length);assert.equal(railGroups,railMembers.length);
// Frozen pre-rail prefix remains the same construction size; rail export appends.
assert.equal(manifest.vertexCount-railVertices,447876);assert.equal(manifest.triangleCount-railTriangles,257452);
const sourceLock=JSON.parse(bytes('SOURCE_LOCK.json'));
for(const file of sourceLock.files){
  const content=bytes('frozen-B/'+file.path);assert.equal(createHash('sha256').update(content).digest('hex'),file.sha256,file.path);
  assert.equal(createHash('sha1').update(Buffer.concat([Buffer.from('blob '+content.length+'\0'),content])).digest('hex'),file.gitBlobSha1,file.path);
}
const inputSha256={};for(const file of['mesh-positions.f32','mesh-normals.f32','mesh-hits.f32','mesh-indices.u32'])inputSha256[file]=createHash('sha256').update(bytes(file)).digest('hex');
const report={status:'passed',sourceCommit:manifest.sourceCommit,scope:'CPU construction/recorder inputs and all draw-group coverage; no GPU/material/visual pass claimed',sourceLockedFiles:sourceLock.files.length,vertexCount:manifest.vertexCount,triangleCount:manifest.triangleCount,groupCount:manifest.groups.length,railGroups,railVertices,railTriangles,railMemberCounts:manifest.stationRails.memberCounts,maxRailPackedResidualM,maxFloat32PositionReevaluationResidualM,maxPackedCoordinateDifferenceM,profileChordErrorLimitM:manifest.stationRails.tessellation.maximumProfileChordErrorM,inputSha256};
fs.writeFileSync(new URL('qa/RAIL-MESH-CHECK.json',root),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(new URL('qa/RAIL-PROBE-FIXTURES.json',root),JSON.stringify({sourceCommit:manifest.sourceCommit,coordinateSpace:'station-local-metres-Y-up',fixtures:railProbeFixtures()},null,2)+'\n');
console.log(JSON.stringify(report,null,2));
