import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {stationRailDistance,stationRailCurves,STATION_RAIL} from '../frozen-B/native-station-rail.mjs';
import {createStationFieldWGSL} from '../frozen-B/station-field.mjs';
import {railMembers,railMemberSample,railProfileDistance,STATION_RAIL_LAYOUT as L,railProbeFixtures} from '../rail-resolver.mjs';
import {railHalfProfile,emitRailMember,appendStationRails,RAIL_TESSELLATION} from '../rail-export.mjs';
import {inspectHit,hitFromPacked} from '../material-sampler.mjs';

const near=(a,b,e=1e-10)=>assert.ok(Math.abs(a-b)<=e,`${a} != ${b}`);
const member=(kind,predicate=()=>true)=>railMembers.find(m=>m.kind===kind&&predicate(m));

test('Six original passenger axes, separate freight siding, and all original rail datums',()=>{
  assert.deepEqual(L.trackAxesX,[-25,-15,-5,5,15,25]);
  assert.deepEqual(L.main.zRange,[-221,-8]);assert.deepEqual(L.main.shedCandidateZRange,[-147,-8]);assert.deepEqual(L.main.runningCandidateZRange,[-221,-145]);
  near(L.gaugeM,1.435);near(2*L.railCenterOffsetM-STATION_RAIL.headWidthM,L.gaugeM);
  near(L.railTopY,.086);near(L.railFootY,-.07275);near(L.sleeper.centerY,-.18275);near(L.bearingPlate.centerY,-.08775);
  near(L.buffers.centerZ,-10.8);assert.deepEqual(L.siding.zRange,[-170,-12]);assert.equal(L.siding.axisX,50);
  near(L.camera.authoredVehicleToPlatformGapM,.1);assert.deepEqual(L.camera.alongTrack.zRange,[-219,-12.98]);
  assert.ok(L.camera.alongTrack.eyeY>L.buffers.topY);assert.ok(L.camera.alongTrack.maximumLateralOffsetM+L.camera.nativeMotherDisplacementEnvelopeM<L.camera.nearestPlatformEdgeFromTrackAxisM);
});

test('Original default WGSL still supplies the rail, timber, bearing, buffer and bed recorders',()=>{
  const field=createStationFieldWGSL();
  assert.match(field,/const RAIL_CENTER_OFFSET:f32=0\.752425/);assert.match(field,/const RAIL_CROWN:f32=0\.086/);
  assert.match(field,/recordPart\(p,max\(completeStationRail\(rail\.xy\),abs\(rail\.z\)-SHED_HALF-2\.\),3u,rail,55\.\)/);
  assert.match(field,/recordTimber\(p,box\(vec3<f32>\(railX,p\.y-SLEEPER_CENTER,rep\(p\.z,\.64/);
  assert.match(field,/round\(p\.z\/\.64\)\+round\(\(p\.x-5\.\)\/10\.\)\*301\./);
  assert.match(field,/3u,bufferLeg,189\./);assert.match(field,/3u,bufferBeam,188\./);assert.match(field,/2u,trackBed,190\./);
  assert.match(field,/30\.,round\(p\.z\/\.64\)\+810\./);
  const source=fs.readFileSync(new URL('../rail-resolver.mjs',import.meta.url),'utf8');
  assert.doesNotMatch(source,/color\s*:|roughness\s*:|evaluateStationMatter\s*=/);
});

test('Cached analytic profile is numerically equivalent to native line/arc field',()=>{
  let count=0;
  for(let i=0;i<=50;i++)for(let j=0;j<=100;j++){
    const q=[-.10+i*.004,.03-j*.0022];near(railProfileDistance(q),stationRailDistance(q),3e-15);count++;
  }
  for(const m of stationRailCurves())for(const p of[m.a,m.b]){near(railProfileDistance(p),0,3e-15);near(railProfileDistance([-p[0],p[1]]),0,3e-15);}
  assert.equal(count,5151);
});

test('All rail construction members are complete, distinct, frozen, and deterministically indexed',()=>{
  const counts={};for(const [i,m] of railMembers.entries()){assert.equal(m.index,i);assert.ok(Object.isFrozen(m));counts[m.kind]=(counts[m.kind]||0)+1;}
  assert.deepEqual(counts,{rail:26,sleeper:2251,bearing:4502,'buffer-leg':12,'buffer-beam':6,'track-bed':1});
  assert.equal(new Set(railMembers.map(m=>m.id)).size,railMembers.length);assert.equal(railMembers.length,6798);
  for(const x of L.trackAxesX){assert.equal(railMembers.filter(m=>m.kind==='sleeper'&&m.trackX===x).length,334);assert.equal(railMembers.filter(m=>m.kind==='bearing'&&m.trackX===x).length,668);}
});

test('Steel q mirrors the original abs(trackX), while recordPart retains unit extent and zero sourceSeed',()=>{
  for(const side of[-1,1]){
    const m=member('rail',m=>m.trackX===5&&m.side===side&&m.segment==='shed');
    const h=railMemberSample(m,[5+side*(L.railCenterOffsetM+.01),L.railTopY-.085,-50]);
    near(h.q[0],.01);near(h.q[1],-.085);near(h.q[2],27.5);near(h.baseD,0);
    assert.equal(h.id,3);assert.equal(h.seed,55);assert.deepEqual(h.extent,[1,1,1]);assert.equal(h.sourceSeed,0);
  }
  const a=member('rail',m=>m.trackX===5&&m.side===1&&m.segment==='shed'),b=member('rail',m=>m.trackX===5&&m.side===1&&m.segment==='running'),p=[5+L.railCenterOffsetM,L.railTopY,-146];
  const A=railMemberSample(a,p),B=railMemberSample(b,p);near(A.baseD,0);near(B.baseD,0);near(A.q[2],-68.5);near(B.q[2],37);
  assert.notEqual(A.q[2],B.q[2]);assert.deepEqual(a.caps,[false,true]);assert.deepEqual(b.caps,[true,false]);
});

test('Every sleeper keeps source stock seeds, local coordinates and metric timber extent',()=>{
  for(const m of railMembers.filter(m=>m.kind==='sleeper')){
    const p=[m.trackX+.23,L.sleeper.centerY+.08,m.cell*.64+.04],h=railMemberSample(m,p);
    near(h.q[0],.23);near(h.q[1],.08);near(h.q[2],.04);near(h.baseD,0);
    assert.equal(h.id,4);assert.equal(h.seed,30);assert.deepEqual(h.extent,[1.165,.08,.115]);
    assert.equal(h.sourceSeed,m.cell+(m.siding?810:Math.round((m.trackX-5)/10)*301));
  }
  // Real 410 mm intervals between 230 mm sleepers are not bridged by geometry.
  const m=member('sleeper',m=>m.trackX===5&&m.cell===-80);
  assert.ok(railMemberSample(m,[5,L.sleeper.centerY,m.center[2]+.32]).baseD>.2);
});

test('Plates, all buffer parts, and track bed preserve the exact original roles and q frames',()=>{
  for(const kind of['bearing','buffer-leg','buffer-beam','track-bed']){
    const m=member(kind),p=[...m.center];p[1]+=m.halfExtent[1];const h=railMemberSample(m,p);
    near(h.baseD,0);assert.deepEqual(h.extent,[1,1,1]);assert.equal(h.sourceSeed,0);
    assert.equal(h.id,kind==='track-bed'?2:3);assert.equal(h.seed,{'bearing':189,'buffer-leg':189,'buffer-beam':188,'track-bed':190}[kind]);
    near(h.q[0],0);near(h.q[1],m.halfExtent[1]);near(h.q[2],0);
  }
});

test('Profile retains every native line/arc join within explicit 0.1 mm chord error',()=>{
  const {points,segments,maximumChordErrorM}=railHalfProfile();
  assert.equal(segments.length,37);assert.equal(points.length,38);assert.ok(maximumChordErrorM<=.0001);
  assert.deepEqual([...new Set(segments.map(s=>s.curveIndex))],Array.from({length:15},(_,i)=>i));
  for(const p of points)near(stationRailDistance(p),0,3e-15);
  for(let i=0;i<segments.length;i++){
    const mid=points[i].map((v,k)=>(v+points[i+1][k])/2);
    assert.ok(Math.abs(stationRailDistance(mid))<=RAIL_TESSELLATION.maximumProfileChordErrorM+1e-12);
  }
  assert.throws(()=>railHalfProfile({maximumProfileChordErrorM:0}),/chord/);
});

test('Tessellation has native profile/ends and no artificial overlap end caps or invalid GPU hits',()=>{
  for(const segment of['shed','running','siding']){
    const m=member('rail',m=>m.segment===segment&&m.side===1);let triangles=0,checked=0;
    emitRailMember(m,(a,b,c)=>{
      triangles++;
      for(const p of[a,b,c]){
        const h=railMemberSample(m,p);assert.ok(Math.abs(h.baseD)<1e-12,`${m.id}: ${h.baseD}`);checked++;
      }
      if(a[2]===b[2]&&b[2]===c[2])assert.ok((m.caps[0]&&a[2]===m.displayZRange[0])||(m.caps[1]&&a[2]===m.displayZRange[1]));
      const ab=b.map((v,k)=>v-a[k]),ac=c.map((v,k)=>v-a[k]),cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]],length=Math.hypot(...cross);
      if(length>1e-12){const mid=a.map((v,k)=>(v+b[k]+c[k])/3),outside=mid.map((v,k)=>v+.001*cross[k]/length),inside=mid.map((v,k)=>v-.001*cross[k]/length);assert.ok(railMemberSample(m,outside).baseD>=railMemberSample(m,inside).baseD,`${m.id}: inward triangle winding`);}
    },{maximumLongitudinalStepM:10});
    assert.ok(triangles>0&&checked===triangles*3);
  }
  for(const probe of railProbeFixtures()){
    const h=probe.hit;assert.equal(inspectHit(probe.position,probe.normal,h,.5),0);
    const a=new Float32Array([...h.q,h.id,...h.extent,h.seed,h.baseD,h.sourceSeed,0,0]),unpacked=hitFromPacked(a,0);
    assert.equal(unpacked.id,h.id);assert.equal(unpacked.seed,h.seed);assert.equal(unpacked.sourceSeed,h.sourceSeed);
  }
});

test('Exporter uses the shared sampler factory for every complete member without color fallback',()=>{
  let calls=0,triangles=0;
  const report=appendStationRails((sample,label,metadata)=>{
    calls++;assert.equal(metadata.family,'rail');assert.equal(label,railMembers[metadata.member].id);
    assert.equal(typeof sample,'function');return()=>triangles++;
  },{maximumLongitudinalStepM:10});
  assert.equal(calls,railMembers.length);assert.equal(report.memberCount,6798);assert.ok(triangles>80000);
  assert.throws(()=>railMemberSample(-1,[0,0,0]),/Unknown/);assert.throws(()=>railMemberSample(0,[NaN,0,0]),/finite/);
});
