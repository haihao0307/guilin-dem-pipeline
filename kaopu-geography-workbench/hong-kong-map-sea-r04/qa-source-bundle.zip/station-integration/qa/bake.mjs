import {createStationSampler} from '../material-sampler.mjs';
const report={status:'running',completed:0,failures:0,batches:0,scope:'Frozen B per-vertex material evaluation; no lighting or whole-domain rendering'};window.__stationBake=report;
async function get(url,json=false){const r=await fetch(url);if(!r.ok)throw Error('Read '+url+': HTTP '+r.status);return json?r.json():new Float32Array(await r.arrayBuffer());}
async function post(name,body,offset){const r=await fetch(`/write/${name}?offset=${offset}`,{method:'POST',body});if(!r.ok)throw Error('Write '+name+': HTTP '+r.status);}
async function progress(){document.querySelector('#status').textContent=JSON.stringify(report,null,2);console.log(`STATION_BAKE_PROGRESS ${report.completed}/${report.total}`);await post('progress.json',JSON.stringify(report),0);}
(async()=>{let sampler;try{
 const manifest=await get('../MESH_MANIFEST.json',true),[positions,normals,packedHits]=await Promise.all(['mesh-positions.f32','mesh-normals.f32','mesh-hits.f32'].map(n=>get('../'+n)));const count=positions.length/3;if(count!==manifest.vertexCount||normals.length!==count*3||packedHits.length!==count*12)throw Error('Mesh binary input shape mismatch');report.total=count;report.sourceCommit=manifest.sourceCommit;
 const params=new URLSearchParams(location.search),naga=params.get('compiled')==='naga';sampler=await createStationSampler({fragmentURL:new URL(naga?'../generated/material-query-naga.frag':'../generated/material-query-entry-adapted.frag',import.meta.url),maxBatch:4096});report.backend=sampler.backend;report.compile=sampler.compile;report.footprintM=.5;report.age=.58;report.eye=[96,48,55];report.footprintMeaning='Unchanged mother footprint input; not a physical average';report.startedAt=new Date().toISOString();const started=performance.now();
 for(let start=0;start<count;start+=8192){const end=Math.min(count,start+8192),output=await sampler.sample({positions:positions.subarray(start*3,end*3),normals:normals.subarray(start*3,end*3),packedHits:packedHits.subarray(start*12,end*12),footprintM:report.footprintM,age:report.age,eye:report.eye});
  for(const f of output.failureFlags)if(f)report.failures++;if(report.failures)throw Error(`${report.failures} material inputs or GPU outputs failed; no fallback colors written for this chunk`);
  await post('colors.f32',output.colors.buffer,start*12);await post('roughness.f32',output.roughness.buffer,start*4);await post('geometry-distance.f32',output.geometryDistance.buffer,start*4);await post('material-key.u16',output.materialKey.buffer,start*2);await post('failure-flags.u16',output.failureFlags.buffer,start*2);
  report.completed=end;report.batches+=output.batches;report.durationMs=performance.now()-started;await progress();
 }
 report.status='passed';report.completedAt=new Date().toISOString();await progress();
 }catch(error){report.status='failed';report.error=error.stack||String(error);await progress().catch(()=>{});}finally{sampler?.dispose();}})();
