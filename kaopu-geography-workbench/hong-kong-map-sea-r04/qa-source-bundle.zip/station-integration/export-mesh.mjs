import fs from 'node:fs';import path from 'node:path';import zlib from 'node:zlib';
import {primitive,gridSolid,add,sub,mul,cross,norm,beamFrame} from './mesh-primitives.mjs';
import {tower,hall,shed,trusses,clockMemberSample,hallMemberSample,shedMemberSample,boxDistance} from './member-resolver.mjs';
import {STATION_SCORE} from './frozen-B/station-score.mjs';
import {castColumnMembers} from './frozen-B/native-cast-column.mjs';
import {appendStationRails} from './rail-export.mjs';
const R=path.dirname(new URL(import.meta.url).pathname),positions=[],normals=[],hits=[],indices=[],groups=[],deferred=[];let maxResidual=0;const vertexMap=new Map();
const pack=x=>Buffer.from(new Float32Array(x).buffer);
function emitFor(sample,label,extra={}){let start=positions.length/3;groups.push({label,start,indexStart:indices.length,...extra});return (a,b,c)=>{let cr=cross(sub(b,a),sub(c,a));if(Math.hypot(...cr)<1e-12)return;let N=norm(cr),mid=mul(add(add(a,b),c),1/3),d0=sample(add(mid,mul(N,.001))).d,d1=sample(add(mid,mul(N,-.001))).d;if(d0<d1)N=mul(N,-1);for(let p of[a,b,c]){let h=sample(p);if(!Number.isFinite(h.d))throw Error(label+' nonfinite');maxResidual=Math.max(maxResidual,Math.abs(h.baseD));let key=label+':'+p.concat(N).map(x=>x.toFixed(6)).join(',');let idx=vertexMap.get(key);if(idx===undefined){idx=positions.length/3;vertexMap.set(key,idx);positions.push(...p);normals.push(...N);hits.push(...h.q,h.id,...h.extent,h.seed,h.baseD,h.sourceSeed,0,0)}indices.push(idx)}}}
const yawFrame=a=>[[Math.cos(a),0,-Math.sin(a)],[0,1,0],[Math.sin(a),0,Math.cos(a)]];
function fromShape(s){let m={kind:s.type,center:s.center||[0,0,0],params:{}};
 if(s.size)m.extent=s.size.map(v=>v/2);
 if(s.type==='oriented-box'){m.kind='box';m.frame=yawFrame(s.yaw||0)}
 if(s.type==='beam'){m.kind='box';m.center=mul(add(s.a,s.b),.5);m.frame=beamFrame(s.a,s.b);m.extent=[s.width/2,Math.hypot(...sub(s.b,s.a))/2,s.depth/2]}
 if(s.type==='cylinder'||s.type==='cone'||s.type==='flute'){m.kind=s.type==='flute'?'flute':'cone';m.params={r0:s.radius??s.bottomRadius,r1:s.radiusTop??s.topRadius??s.radius,height:s.height,sides:s.sides||0,flutes:s.flutes||0,depth:s.depth||0};m.extent=[m.params.r0,s.height/2,m.params.r0]}
 if(s.type==='octagon'){m.params={radius:s.radius,height:s.height,inner:s.inner};m.extent=[s.radius,s.height/2,s.radius]}
 if(s.type==='dome')m.params={radius:s.radius,rise:s.rise,thickness:s.thickness};
 if(['annulus','ring','disc'].includes(s.type)){m.params={radius:s.radius,tube:s.tube,inner:s.inner,outer:s.radius,depth:s.depth??.012};if(s.axis==='x')m.frame=[[0,0,1],[0,1,0],[1,0,0]]}
 if(s.type==='triangle-prism'){m.kind='triangle';m.center=add(s.center,[0,s.rise/2,0]);m.params={width:s.base,rise:s.rise,depth:s.depth};m.frame=yawFrame(s.yaw||0)}
 return m;
}
for(let [i,p]of tower.parts.entries()){
 let sampler=q=>clockMemberSample(i,q),emit=emitFor(sampler,'clock:'+p.id,{family:'clock',member:i}),s=p.shape;
 if(p.surface.role==='clock-ink'){
  let [,face,j]=p.id.match(/clock-tick-(\d+)-(\d+)/).map(Number),a=face*Math.PI/2,t=j*Math.PI/30,n=[Math.sin(a),0,Math.cos(a)],right=[n[2],0,-n[0]],minor=j%5!==0,r=minor?1.22:1.17;
  let center=add([24,25,4],add(mul(right,Math.sin(t)*r),add([0,Math.cos(t)*r,0],mul(n,3.33))));
  primitive({kind:'box',center,extent:[minor?.0115:.0325,minor?.035:.10,.013],frame:[add(mul(right,Math.cos(t)),[0,-Math.sin(t),0]),add(mul(right,Math.sin(t)),[0,Math.cos(t),0]),n]},emit);continue;
 }
 if(s.type==='hollow-box'){
  const axes=[0,1,2].map(k=>{let a=[s.center[k]-s.size[k]/2,s.center[k]+s.size[k]/2,s.innerCenter[k]-s.innerSize[k]/2,s.innerCenter[k]+s.innerSize[k]/2];if(k===1)for(let w of tower.windows)a.push(w.y-w.h/2,w.y+w.h/2);else a.push(-.745,.745,-2.18,2.18);return [...new Set(a)].sort((a,b)=>a-b)});
  gridSolid(...axes,q=>sampler(add(q,[24,0,4])).d<0,(...v)=>emit(...v.map(q=>add(q,[24,0,4]))));continue;
 }
 if(s.type==='interior-lining'){
  let xs=[-s.size[0]/2,-.745,.745,s.size[0]/2],ys=[-s.size[1]/2,s.size[1]/2];for(let w of tower.windows)ys.push(w.y-w.h/2-s.center[1],w.y+w.h/2-s.center[1]);ys.sort((a,b)=>a-b);let zs=[-s.size[2]/2,s.size[2]/2],fr=yawFrame(s.yaw),to=q=>add([24,0,4],s.center.map((v,k)=>v+fr.reduce((sum,a,i)=>sum+a[k]*q[i],0)));
  gridSolid(xs,ys,zs,q=>sampler(to(q)).d<0,(...v)=>emit(...v.map(to)));continue;
 }
 let m=fromShape(s);m.center=add(m.center,[24,0,4]);primitive(m,emit);
}
// Native B field clockMinutes=380 (06:20), including separate hands and spindle caps.
for(let face=0;face<4;face++){
 let a=face*Math.PI/2,n=[Math.sin(a),0,Math.cos(a)],right=[n[2],0,-n[0]],pivot=add([24,25,4],mul(n,3.30));
 let qFor=p=>{let d=sub(p,pivot);return[dotLocal(d,right),d[1],dotLocal(d,n)]};
 for(let minute of[false,true]){let t=380*Math.PI/(minute?30:360),axes=[add(mul(right,Math.cos(t)),[0,-Math.sin(t),0]),add(mul(right,Math.sin(t)),[0,Math.cos(t),0]),n],mid=add(pivot,add(mul(axes[1],minute?.44:.31),mul(n,.09+(minute?.025:0)))),ex=[minute?.0275:.045,minute?.51:.385,.0125];
 let sample=p=>{let q=qFor(p),d=sub(p,mid),baseD=boxDistance(axes.map(axis=>dotLocal(d,axis)),ex);return{d:baseD,baseD,id:8,q,seed:0,extent:[1,1,1],sourceSeed:0}};
 primitive({kind:'box',center:mid,frame:axes,extent:ex},emitFor(sample,'clock-hand:'+face+':'+minute));
 }
 let center=add(pivot,mul(n,.09));primitive({kind:'sphere',center,params:{radius:.095}},emitFor(p=>{let d=Math.hypot(...sub(p,center))-.095;return{d,baseD:d,id:3,q:sub(p,[24,0,4]),seed:182,extent:[1,1,1],sourceSeed:face+500}},'clock-spindle:'+face));
}
function dotLocal(a,b){return a.reduce((s,v,i)=>s+v*b[i],0)}
for(let [i,m]of hall.parts.entries()){
 if(m.binding.deferred){deferred.push({id:m.id,binding:m.binding});continue}
 let shape={kind:m.kind,center:m.center,extent:m.extent,frame:m.frame,params:{...m.params}};
 if(m.kind==='triangle'&&m.params.oculus){let o=m.params.oculus.center;shape.params.hole=[o[0]-m.hallCenter[0],o[1]-m.hallCenter[1],m.params.oculus.radius]}
 primitive(shape,emitFor(p=>hallMemberSample(i,p),'hall:'+m.id,{family:'hall',member:i}));
}
for(let barrel of[-1,0,1]){
 for(let [i,m]of shed.panels.entries()){
  let slope=(m.y1-m.y0)/(m.x1-m.x0),x=(m.x0+m.x1)/2,y=(m.y0+m.y1)/2-m.thickness/2;
  primitive({kind:'roof',center:[barrel*20+x,y,-77.5],extent:[(m.x1-m.x0)/2,1,67.5],params:{slope,thickness:m.thickness}},emitFor(p=>shedMemberSample('panel',i,p,{barrel}),'shed:'+barrel+':panel:'+i));
 }
 for(let [i,m]of shed.purlins.entries())primitive({kind:'box',center:[barrel*20+m.x,m.y,-77.5],extent:[m.widthX/2,m.heightY/2,67.5]},emitFor(p=>shedMemberSample('purlin',i,p,{barrel}),'shed:'+barrel+':purlin:'+i));
 for(let j=0;j<=18;j++)for(let [i,m]of trusses.entries()){let z=-10-j*7.5,shape=fromShape(m);shape.center=add(shape.center,[barrel*20,0,z]);primitive(shape,emitFor(p=>shedMemberSample('truss',i,p,{barrel,bayCenterZ:z}),'truss:'+barrel+':'+j+':'+i))}
}
// Columns and platforms are appended by the same native resolver; no ad hoc material colors.
let ext=await import('./member-resolver.mjs');
if(ext.castColumnMemberSample){for(let x of[-30,-10,10,30])for(let j=0;j<=18;j++)for(let[i,m]of castColumnMembers().entries()){
 let z=-10-j*7.5,shape=fromShape(m);const localToStation=q=>[q[2]+x,q[1],-q[0]+z];
 if(m.type==='torus'){shape={kind:'ring',center:m.center,frame:[[1,0,0],[0,0,1],[0,1,0]],params:{radius:m.radius,tube:m.tube,segments:16,sides:6}}}
 if(m.type==='hex'){shape={kind:'cone',center:m.center,frame:beamFrame([0,0,0],m.direction),extent:[m.radius,m.depth/2,m.radius],params:{r0:m.radius,r1:m.radius,height:m.depth,sides:6}}}
 let emit=emitFor(p=>ext.castColumnMemberSample(i,p,{centerX:x,bayCenterZ:z}),'column:'+x+':'+j+':'+i);primitive(shape,(...v)=>emit(...v.map(localToStation))); 
 }}
for(let x of[-30,-10,10,30])primitive({kind:'box',center:[x,.275,-77.5],extent:[3.4,.575,68.8]},emitFor(p=>ext.platformDeckSample(p,{centerX:x}),'platform:'+x));
for(let [i,m]of ext.platformEdges.entries())primitive({kind:'box',center:m.center,extent:m.extent,frame:m.frame},emitFor(p=>ext.platformEdgeMemberSample(i,p),'platform-edge:'+m.id));
const stationRails=appendStationRails(emitFor);
// Local-space culling metadata; does not alter a vertex, hit, normal or index.
for(let i=0;i<groups.length;i++){
 const group=groups[i],end=groups[i+1]?.start??positions.length/3;
 group.vertexCount=end-group.start;
 group.indexCount=(groups[i+1]?.indexStart??indices.length)-group.indexStart;
 if(!group.vertexCount){group.bounds=null;continue;}
 const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
 for(let vertex=group.start;vertex<end;vertex++)for(let axis=0;axis<3;axis++){
  const value=positions[vertex*3+axis];min[axis]=Math.min(min[axis],value);max[axis]=Math.max(max[axis],value);
 }
 group.bounds={min,max};
}
// Emit binary query buffers before GPU; rendered colors are only produced by sample-batch.
fs.writeFileSync(path.join(R,'mesh-indices.u32'),Buffer.from(new Uint32Array(indices).buffer));fs.writeFileSync(path.join(R,'mesh-positions.f32'),pack(positions));fs.writeFileSync(path.join(R,'mesh-normals.f32'),pack(normals));fs.writeFileSync(path.join(R,'mesh-hits.f32'),pack(hits));
fs.writeFileSync(path.join(R,'MESH_MANIFEST.json'),JSON.stringify({sourceCommit:'1f46ba78170752a07086caa3e66c87f2fa4c7fcf',vertexCount:positions.length/3,triangleCount:indices.length/3,groups,deferred,stationRails,maxConstructionFieldResidualM:maxResidual,sampling:'same native analytical components tessellated for map display; original B mother queried separately on these identical sample positions; no material mean claim'},null,2));
console.log({vertices:positions.length/3,triangles:indices.length/3,maxResidual,groups:groups.length});
