/** Tessellate the retained 56E1 analytic section; never replace it with a box.
 * A finite display mesh approximates curved surfaces. Its material queries keep
 * the exact source component coordinates and seeds, including mirrored rails.
 */
import {stationRailCurves} from './frozen-B/native-station-rail.mjs';
import {primitive} from './mesh-primitives.mjs';
import {railMembers,railMemberSample,STATION_RAIL_LAYOUT} from './rail-resolver.mjs';

export const RAIL_TESSELLATION=Object.freeze({maximumProfileChordErrorM:.0001,maximumLongitudinalStepM:2.56});
/** Right half from crown center to bottom center, retaining every native join. */
export function railHalfProfile({maximumProfileChordErrorM=RAIL_TESSELLATION.maximumProfileChordErrorM}={}){
  if(!Number.isFinite(maximumProfileChordErrorM)||maximumProfileChordErrorM<=0||maximumProfileChordErrorM>.001)throw Error('Rail chord error must be in (0, 0.001] metres');
  const points=[],segments=[];
  for(const [curveIndex,m] of stationRailCurves().entries()){
    const count=m.type==='line'?1:Math.max(1,Math.ceil(Math.abs(m.sweep)/(2*Math.acos(Math.max(-1,1-maximumProfileChordErrorM/m.radius)))));
    if(!points.length)points.push([...m.a]);
    for(let i=1;i<=count;i++){
      const a=m.start+m.sweep*i/count;
      const p=i===count?[...m.b]:[m.center[0]+m.radius*Math.cos(a),m.center[1]+m.radius*Math.sin(a)];
      if(p[1]>points.at(-1)[1]+1e-12)throw Error('Native rail profile is not y-monotone');
      segments.push({curveIndex,type:m.type,chordErrorM:m.type==='arc'?m.radius*(1-Math.cos(Math.abs(m.sweep)/count/2)):0});points.push(p);
    }
  }
  return {points,segments,maximumChordErrorM:Math.max(...segments.map(s=>s.chordErrorM))};
}

export function emitRailMember(m,emit,options={}){
  if(m.kind!=='rail')throw Error('Expected an original rail descriptor');
  const step=options.maximumLongitudinalStepM??RAIL_TESSELLATION.maximumLongitudinalStepM;
  if(!Number.isFinite(step)||step<=0||step>10)throw Error('Rail longitudinal step must be in (0, 10] metres');
  const {points}=railHalfProfile(options),[z0,z1]=m.displayZRange,rows=Math.ceil((z1-z0)/step);
  const world=(p,z,mirror=1)=>[m.center[0]+mirror*p[0],m.center[1]+p[1],z];
  const quad=(a,b,c,d,reverse=false)=>{if(reverse){emit(a,c,b);emit(a,d,c);}else{emit(a,b,c);emit(a,c,d);}};
  for(let row=0;row<rows;row++){
    const a=z0+(z1-z0)*row/rows,b=z0+(z1-z0)*(row+1)/rows;
    for(let i=0;i<points.length-1;i++)for(const side of[-1,1])quad(world(points[i],a,side),world(points[i+1],a,side),world(points[i+1],b,side),world(points[i],b,side),side===1);
  }
  // y-monotone strips fill the concave web correctly; a convex fan would bridge
  // empty space beneath the head. Internal native overlap caps are omitted.
  for(let end=0;end<2;end++)if(m.caps[end]){
    const z=end?z1:z0;
    for(let i=0;i<points.length-1;i++)quad(world(points[i],z,-1),world(points[i],z,1),world(points[i+1],z,1),world(points[i+1],z,-1),end===1);
  }
}

/** emitFor is the existing export-mesh factory, so packing and GPU path match. */
export function appendStationRails(emitFor,options={}){
  if(typeof emitFor!=='function')throw Error('Station rail export requires emitFor');
  const counts={};
  for(const m of railMembers){
    counts[m.kind]=(counts[m.kind]||0)+1;
    const emit=emitFor(p=>railMemberSample(m,p),m.id,{family:'rail',member:m.index,kind:m.kind,trackX:m.trackX??null,segment:m.segment??null,siding:!!m.siding});
    if(m.kind==='rail')emitRailMember(m,emit,options);
    else primitive({kind:'box',center:m.center,extent:m.halfExtent},emit);
  }
  return {layout:STATION_RAIL_LAYOUT,tessellation:{...RAIL_TESSELLATION,...options},memberCounts:counts,memberCount:railMembers.length,profile:railHalfProfile(options).segments};
}
