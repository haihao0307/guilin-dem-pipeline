#version 300 es
precision highp float;
precision highp int;
in float _vs2fs_location6;
in vec3 _vs2fs_location7;
uniform vec4 stationDepth;
uniform vec3 visibilityEye;
uniform vec2 visibilityRadiusCut;
void main(){
 float viewZ=_vs2fs_location6;
 if(viewZ<stationDepth.y||viewZ>stationDepth.z)discard;
 if(visibilityRadiusCut.y>.5&&distance(_vs2fs_location7,visibilityEye)>visibilityRadiusCut.x)discard;
 gl_FragDepth=gl_FragCoord.z;
 if(stationDepth.x>.5)gl_FragDepth=log2(1.+stationDepth.w*max(viewZ,0.))/log2(1.+stationDepth.w*stationDepth.z);
}
