import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {prepareNearMesh} from '../mesh-contract.mjs';
import {splitTowerBrickFaces} from '../split-brick-faces.mjs';
const root=new URL('../../',import.meta.url),read=(name,T)=>{const b=fs.readFileSync(new URL(name,root));return new T(b.buffer,b.byteOffset,b.byteLength/T.BYTES_PER_ELEMENT);},hash=a=>createHash('sha256').update(Buffer.from(a.buffer,a.byteOffset,a.byteLength)).digest('hex');
const positions=read('mesh-positions.f32',Float32Array),normals=read('mesh-normals.f32',Float32Array),packedHits=read('mesh-hits.f32',Float32Array),indices=read('mesh-indices.u32',Uint32Array);
// Identity/area regression does not need material baking. If absent, use zero
// displacement ONLY for this CPU test and say so; runtime never substitutes it.
const baked=new URL('baked/geometry-distance.f32',root),hasBaked=fs.existsSync(baked),geometryDistance=hasBaked?read('baked/geometry-distance.f32',Float32Array):new Float32Array(positions.length/3);
const mesh={positions,normals,packedHits,indices,geometryDistance},before=Object.fromEntries(Object.entries(mesh).map(([k,v])=>[k,hash(v)])),started=performance.now();
const partitioned=splitTowerBrickFaces(mesh),out=prepareNearMesh(partitioned);let tested=0,bad=0;
for(let t=0;t<out.indices.length;t+=3){const vs=Array.from(out.indices.subarray(t,t+3)),h=out.packedHits;if(h[vs[0]*12+7]!==71||![1,12].includes(h[vs[0]*12+3]))continue;tested++;
 for(const weights of [[1/3,1/3,1/3],[.6,.2,.2],[.2,.6,.2],[.2,.2,.6]]){const q=[0,1,2].map(k=>vs.reduce((s,i,j)=>s+h[i*12+k]*weights[j],0));const id=Math.abs(q[0])>Math.abs(q[2])?12:1;
  // A triangle lying exactly on both source boundary planes has measure-zero
  // face orientation ambiguity; no finite-area material transition is lost.
  if(Math.abs(Math.abs(q[0])-Math.abs(q[2]))>1e-6&&id!==h[vs[0]*12+3])bad++;
 }
}
function metrics(m){let area=0,min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];for(let t=0;t<m.indices.length;t+=3){const v=Array.from(m.indices.subarray(t,t+3)).map(i=>Array.from(m.positions.subarray(i*3,i*3+3)));const a=v[1].map((x,k)=>x-v[0][k]),b=v[2].map((x,k)=>x-v[0][k]);area+=Math.hypot(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])*.5;for(const p of v)for(let k=0;k<3;k++){min[k]=Math.min(min[k],p[k]);max[k]=Math.max(max[k],p[k]);}}return{areaM2:area,min,max};}
const original=metrics(mesh),result=metrics(out),sourceUntouched=Object.entries(mesh).every(([k,v])=>hash(v)===before[k]),relativeAreaError=Math.abs(original.areaM2-result.areaM2)/original.areaM2,boundsMatch=JSON.stringify(original.min)===JSON.stringify(result.min)&&JSON.stringify(original.max)===JSON.stringify(result.max);
const report={status:bad===0&&sourceUntouched&&boundsMatch&&relativeAreaError<1e-8?'passed':'failed',...partitioned.brickPartition,allResultTrianglesChecked:out.triangleCount,towerInteriorTrianglesChecked:tested,badInteriorSamples:bad,sourceUntouched,sourceBufferHashes:before,original,result,relativeAreaError,boundsMatch,spatialMaterialGroups:out.groups.length,geometryDisplacementTest:hasBaked?'baked geometry distance':'zero displacement for CPU identity test only; runtime requires real geometryDistance',durationMs:performance.now()-started};
fs.writeFileSync(new URL('./full-mesh-report.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));if(report.status!=='passed')process.exitCode=1;
