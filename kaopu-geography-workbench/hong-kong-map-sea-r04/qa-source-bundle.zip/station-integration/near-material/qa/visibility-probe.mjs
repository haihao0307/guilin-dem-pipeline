import {createNearStationRenderer,linkNearProgram} from '../renderer.mjs';
import {createStationSampler} from '../../material-sampler.mjs';
import {COLOR_TOLERANCE,DEPTH_TOLERANCE,CLEAR,DEBUG_MODES,buildFixtureSuite,perspectiveCamera,compareReadbacks,assertNoGLError,waitForGPU,decodeGzipArray} from './visibility-test-helpers.mjs';

/** Explicitly invoked, bounded correctness/software-backend experiment. Never
 * starts a host scene, animation loop, resolution sweep or hardware FPS test.
 * ?naga=1 selects both Naga material fragments. ?scene=1 replaces the fixtures
 * with ONE actual station-data camera at 256x144, and is never run by default.
 * Before importing/running, an embedding harness may set
 * window.VISIBILITY_PROBE_SCENE_CAMERA = {eye,target,up,verticalFovDegrees,
 *   nearM,farM,clipFromStation,nearRadiusM}; eye/target are station-local metres.
 * Otherwise camera-data.json's station-hall preset is used. Dimensions, age,
 * light and debug modes stay bounded and fixed for both arms.
 */
const FIXED={age:.58,sun:[-.45,.78,.38],sunColor:[1,.92,.82],day:1,light:[4.6,1,1,1],exposure:1,nearM:.05,farM:60000,logDepth:true,logCoefficient:1,fragmentRadiusCut:true,visibilityExtraDepthMargin:0};
const SCOPE='Small raster correctness and completed wall-clock software test only. No hardware FPS, realtime acceptance, whole-domain proof or automatic high-resolution/long-scene run.';
async function json(url){const response=await fetch(url);if(!response.ok)throw Error(`HTTP ${response.status}: ${url}`);return response.json();}
function target(gl,width,height,withDepth){
 const framebuffer=gl.createFramebuffer(),color=gl.createTexture(),depth=withDepth?gl.createTexture():null;
 gl.bindFramebuffer(gl.FRAMEBUFFER,framebuffer);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,color);
 for(const [p,v] of [[gl.TEXTURE_MIN_FILTER,gl.NEAREST],[gl.TEXTURE_MAG_FILTER,gl.NEAREST],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,p,v);
 gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,width,height,0,gl.RGBA,gl.FLOAT,null);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);
 if(depth){gl.bindTexture(gl.TEXTURE_2D,depth);for(const [p,v] of [[gl.TEXTURE_MIN_FILTER,gl.NEAREST],[gl.TEXTURE_MAG_FILTER,gl.NEAREST],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE],[gl.TEXTURE_COMPARE_MODE,gl.NONE]])gl.texParameteri(gl.TEXTURE_2D,p,v);gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,width,height,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,depth,0);}
 gl.drawBuffers([gl.COLOR_ATTACHMENT0]);gl.readBuffer(gl.COLOR_ATTACHMENT0);
 if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Visibility probe framebuffer incomplete');assertNoGLError(gl,'target allocation');
 return{framebuffer,color,depth,dispose(){gl.deleteFramebuffer(framebuffer);gl.deleteTexture(color);if(depth)gl.deleteTexture(depth);}};
}
async function depthReader(gl,width,height){
 const vertex='#version 300 es\nprecision highp float;void main(){vec2 p[3]=vec2[3](vec2(-1,-1),vec2(3,-1),vec2(-1,3));gl_Position=vec4(p[gl_VertexID],0.,1.);}';
 const fragment='#version 300 es\nprecision highp float;precision highp int;uniform highp sampler2D inputDepth;out vec4 value;void main(){float d=texelFetch(inputDepth,ivec2(gl_FragCoord.xy),0).r;value=vec4(d,d,d,1.);}';
 const {program,report}=await linkNearProgram(gl,vertex,fragment),out=target(gl,width,height,false),vao=gl.createVertexArray(),location=gl.getUniformLocation(program,'inputDepth');
 return{compile:report,read(texture){
  gl.bindFramebuffer(gl.FRAMEBUFFER,out.framebuffer);gl.drawBuffers([gl.COLOR_ATTACHMENT0]);gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.viewport(0,0,width,height);gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);gl.disable(gl.SCISSOR_TEST);gl.disable(gl.CULL_FACE);gl.colorMask(true,true,true,true);gl.useProgram(program);gl.bindVertexArray(vao);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);gl.bindSampler(0,null);gl.uniform1i(location,0);gl.drawArrays(gl.TRIANGLES,0,3);
  const rgba=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,rgba);assertNoGLError(gl,'depth helper pass/readback');return Float32Array.from({length:width*height},(_,i)=>rgba[i*4]);
 },dispose(){out.dispose();gl.deleteVertexArray(vao);gl.deleteProgram(program);}};
}
function prepareHost(gl,output,width,height){
 gl.bindFramebuffer(gl.FRAMEBUFFER,output.framebuffer);gl.drawBuffers([gl.COLOR_ATTACHMENT0]);gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.viewport(0,0,width,height);
 for(const capability of [gl.BLEND,gl.CULL_FACE,gl.SCISSOR_TEST,gl.STENCIL_TEST,gl.POLYGON_OFFSET_FILL,gl.SAMPLE_ALPHA_TO_COVERAGE,gl.SAMPLE_COVERAGE,gl.RASTERIZER_DISCARD,gl.DITHER])gl.disable(capability);
 gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LESS);gl.depthMask(true);gl.depthRange(0,1);gl.colorMask(true,true,true,true);gl.clearColor(CLEAR,CLEAR,CLEAR,CLEAR);gl.clearDepth(1);gl.pixelStorei(gl.PACK_ALIGNMENT,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);assertNoGLError(gl,'prepare host state');
}
function hostState(gl){
 const state={};
 for(const name of ['DRAW_FRAMEBUFFER_BINDING','READ_FRAMEBUFFER_BINDING','READ_BUFFER','DRAW_BUFFER0','VIEWPORT','DEPTH_FUNC','DEPTH_WRITEMASK','DEPTH_CLEAR_VALUE','DEPTH_RANGE','COLOR_WRITEMASK','CULL_FACE_MODE','FRONT_FACE','SCISSOR_BOX','BLEND_SRC_RGB','BLEND_DST_RGB','BLEND_SRC_ALPHA','BLEND_DST_ALPHA','BLEND_EQUATION_RGB','BLEND_EQUATION_ALPHA','BLEND_COLOR','ACTIVE_TEXTURE','CURRENT_PROGRAM','VERTEX_ARRAY_BINDING','UNIFORM_BUFFER_BINDING']){const value=gl.getParameter(gl[name]);state[name]=ArrayBuffer.isView(value)?Array.from(value):value;}
 for(const name of ['DEPTH_TEST','CULL_FACE','BLEND','SCISSOR_TEST','STENCIL_TEST','POLYGON_OFFSET_FILL','RASTERIZER_DISCARD'])state[name]=gl.isEnabled(gl[name]);
 for(const binding of [6,7,8])for(const name of ['UNIFORM_BUFFER_BINDING','UNIFORM_BUFFER_START','UNIFORM_BUFFER_SIZE'])state[`ubo${binding}.${name}`]=gl.getIndexedParameter(gl[name],binding);
 try{for(const unit of [0,1,2,3,4,5,6,7,15]){gl.activeTexture(gl.TEXTURE0+unit);for(const name of ['TEXTURE_BINDING_2D','TEXTURE_BINDING_CUBE_MAP','TEXTURE_BINDING_3D','TEXTURE_BINDING_2D_ARRAY','SAMPLER_BINDING'])state[`unit${unit}.${name}`]=gl.getParameter(gl[name]);}}
 finally{gl.activeTexture(state.ACTIVE_TEXTURE);}
 return state;
}
function compareHostState(before,after){
 const same=(a,b)=>Array.isArray(a)?Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>v===b[i]):a===b;
 const differences=Object.keys(before).filter(key=>!same(before[key],after[key]));
 return{passed:differences.length===0,differences,textureUnitsChecked:[0,1,2,3,4,5,6,7,15],uboBindingsAndRangesChecked:[6,7,8]};
}
function hostSentinels(gl){
 const textures=[],samplers=[],vao=gl.createVertexArray(),buffer=gl.createBuffer(),alignment=gl.getParameter(gl.UNIFORM_BUFFER_OFFSET_ALIGNMENT),stride=Math.max(alignment,Math.ceil(80/alignment)*alignment);
 gl.bindBuffer(gl.UNIFORM_BUFFER,buffer);gl.bufferData(gl.UNIFORM_BUFFER,stride*4+80,gl.STATIC_DRAW);
 for(const unit of [0,1,2,3,4,5,6,7,15]){const texture=gl.createTexture(),sampler=gl.createSampler();textures.push(texture);samplers.push(sampler);gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([unit,37,91,255]));for(const setting of [gl.TEXTURE_MIN_FILTER,gl.TEXTURE_MAG_FILTER])gl.samplerParameteri(sampler,setting,gl.NEAREST);}
 return{bind(){for(const [i,unit] of [0,1,2,3,4,5,6,7,15].entries()){gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,textures[i]);gl.bindSampler(unit,samplers[i]);}for(const [i,binding] of [6,7,8].entries())gl.bindBufferRange(gl.UNIFORM_BUFFER,binding,buffer,stride*(i+1),binding===8?16:80);gl.bindBuffer(gl.UNIFORM_BUFFER,buffer);gl.useProgram(null);gl.bindVertexArray(vao);gl.activeTexture(gl.TEXTURE3);},dispose(){for(const texture of textures)gl.deleteTexture(texture);for(const sampler of samplers)gl.deleteSampler(sampler);gl.deleteVertexArray(vao);gl.deleteBuffer(buffer);}};
}
async function capture(gl,near,output,reader,sentinels,frame){
 prepareHost(gl,output,frame.width,frame.height);sentinels.bind();const beforeState=hostState(gl);assertNoGLError(gl,'host state snapshot');
 // Settle the clear before timing. We record completion, never present CPU
 // submission time as frame time. Poll/scheduling overhead remains included.
 await waitForGPU(gl);assertNoGLError(gl,'before material draw');
 const started=performance.now(),receipt=near.draw(frame),submitted=performance.now(),stateRestoration=compareHostState(beforeState,hostState(gl));
 const fence=await waitForGPU(gl),completed=performance.now();assertNoGLError(gl,'material draw completion');
 if(gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING)!==output.framebuffer||gl.getParameter(gl.READ_FRAMEBUFFER_BINDING)!==output.framebuffer)throw Error('Renderer failed to restore host draw/read framebuffer');
 gl.readBuffer(gl.COLOR_ATTACHMENT0);const color=new Float32Array(frame.width*frame.height*4);gl.readPixels(0,0,frame.width,frame.height,gl.RGBA,gl.FLOAT,color);const colorRead=performance.now();assertNoGLError(gl,'color readback');
 const depth=reader.read(output.depth),depthRead=performance.now();
 return{color,depth,receipt,stateRestoration,timing:{submitOnlyMs:submitted-started,drawCompletedWallMs:completed-started,colorReadbackWallMs:colorRead-completed,depthHelperAndReadbackWallMs:depthRead-colorRead,totalWallMs:depthRead-started,fencePolls:fence.polls}};
}
function validateReceipt(a,b,microNormal){
 const errors=[];
 if(!a?.visibility||!b?.visibility)errors.push('Missing visibility receipt');
 if(!a?.drawCalls||!b?.drawCalls)errors.push('No submitted material draw calls');
 if(a?.drawCalls!==b?.drawCalls||a?.triangles!==b?.triangles)errors.push('A/B material geometry selection differs');
 if((a?.visibility?.prepassDrawCalls??-1)!==0)errors.push('Baseline unexpectedly ran a prepass');
 if(microNormal){if(b?.visibility?.mode!=='bypass-micro-normal')errors.push('microNormal did not explicitly bypass');if(b?.visibility?.prepassDrawCalls!==0)errors.push('microNormal bypass still ran a prepass');}
 else{if(b?.visibility?.mode!=='conservative-depth-prepass')errors.push('Candidate did not activate conservative-depth-prepass');if(!(b?.visibility?.prepassDrawCalls>0&&b?.visibility?.prepassTriangles>0))errors.push('Candidate prepass did not draw');if(!Number.isFinite(b?.visibility?.depthEpsilon)||b.visibility.depthEpsilon<0)errors.push('Invalid depth epsilon');}
 return errors;
}
async function fixtureInput(naga,width,height,onProgress){
 const manifest=await json(new URL('../../qa/reference/manifest.json',import.meta.url)),suite=buildFixtureSuite(manifest.fixtures);
 onProgress?.({stage:'baking small fixture geometry with original B',vertices:suite.mesh.positions.length/3});
 const sampler=await createStationSampler({fragmentURL:new URL(naga?'../../generated/material-query-naga.frag':'../../generated/material-query-entry-adapted.frag',import.meta.url),maxBatch:4096});
 let bake,exactCoplanar;try{const sampled=await sampler.sample({...suite.mesh,age:FIXED.age,eye:[24,12,7],footprintM:.0005});if(sampled.failureFlags.some(Boolean))throw Error('Original B fixture geometry query failed');suite.mesh.geometryDistance.set(sampled.geometryDistance);
 const {firstVertices,secondVertices}=suite.exactCoplanar,equalGeometryDistance=firstVertices.every((v,i)=>Object.is(sampled.geometryDistance[v],sampled.geometryDistance[secondVertices[i]]));
 if(!equalGeometryDistance)throw Error('Exact-coplanar real B geometryDistance differs; the depth-tie fixture is invalid');
 const range=vertices=>{const values=vertices.map(i=>suite.mesh.packedHits[i*12]);return[Math.min(...values),Math.max(...values)];};
 exactCoplanar={equalGeometryDistance,firstGeometryDistance:firstVertices.map(i=>sampled.geometryDistance[i]),secondGeometryDistance:secondVertices.map(i=>sampled.geometryDistance[i]),firstQXRange:range(firstVertices),secondQXRange:range(secondVertices),expectedWinner:'first submitted duplicate under LESS; q.x distinguishes original B diagnostic output only'};
 assertNoGLError(sampler.gl,'original B fixture bake');bake={compile:sampler.compile,vertices:sampled.count,batches:sampled.batches,completedReadbackWallMs:sampled.durationMs,backend:sampler.backend,footprintM:.0005,source:'original frozen B material query geometryDistance; synthetic occlusion mesh using unchanged fixture HitFields'};}finally{sampler.dispose();}
 const cases=suite.cases.map(spec=>({name:spec.name,fixture:spec.fixture,layers:spec.layers,debugModes:spec.debugModes||(spec.layers?DEBUG_MODES:[0,1,2,5,7]),frame:suite.caseFrame(spec,width,height)}));
 // One small shaded/normal pair additionally proves that enabling visibility
 // with micro-normal derivatives follows the exact original shader path.
 const micro=cases.find(x=>x.name==='heritage-brick-4-layers');cases.push({...micro,name:'micro-normal-forced-bypass',microNormal:true,debugModes:[0,7]});
 return{mesh:suite.mesh,cases,bake,fixtureNames:suite.fixtureNames,exactCoplanar,splitBrickFaces:false};
}
async function sceneInput(width,height,override){
 const [data,cameras]=await Promise.all([json(new URL('../../../station-data.json',import.meta.url)),json(new URL('../../../camera-data.json',import.meta.url))]);
 const preset=cameras.presets.find(x=>x.id==='station-hall');if(!preset)throw Error('station-hall camera preset missing');
 const mesh={};for(const [key,Type] of [['positions',Float32Array],['normals',Float32Array],['packedHits',Float32Array],['geometryDistance',Float32Array],['indices',Uint32Array]])mesh[key]=await decodeGzipArray(data[key],Type);
 const supplied=override||{},cameraSpec={eye:preset.eye,target:preset.target,up:[0,1,0],verticalFovDegrees:preset.verticalFovDegrees||cameras.defaultFovDegrees||52,nearM:preset.nearPlaneM||.05,farM:preset.farPlaneM||60000,...supplied};
 const camera=perspectiveCamera(cameraSpec,width,height);
 if(supplied.clipFromStation!==undefined){if(supplied.clipFromStation.length!==16||!Array.from(supplied.clipFromStation).every(Number.isFinite))throw Error('Custom clipFromStation must be a finite column-major mat4');camera.clipFromStation=new Float32Array(supplied.clipFromStation);}
 const nearRadiusM=supplied.nearRadiusM===undefined?95:supplied.nearRadiusM;if(!(nearRadiusM>0&&(Number.isFinite(nearRadiusM)||nearRadiusM===Infinity)))throw Error('Invalid scene nearRadiusM');
 return{mesh,cases:[{name:'station-hall-single-camera',frame:{...camera,nearRadiusM}}],splitBrickFaces:true,source:{url:new URL('../../../station-data.json',import.meta.url).href,sourceCommit:data.metadata?.sourceCommit,vertexCount:mesh.positions.length/3,triangleCount:mesh.indices.length/3,cameraPreset:preset.id,customCamera:!!override,geometryDistance:'actual original B baked station-data field'}};
}
export async function run(canvas,{search=globalThis.location?.search||'',sceneCamera=globalThis.VISIBILITY_PROBE_SCENE_CAMERA,onProgress}={}){
 const started=performance.now(),params=new URLSearchParams(search),naga=params.get('naga')==='1',scene=params.get('scene')==='1',width=scene?256:128,height=scene?144:72;
 canvas.width=width;canvas.height=height;
 const gl=canvas.getContext('webgl2',{antialias:false,alpha:false,depth:true,stencil:false,preserveDrawingBuffer:false});if(!gl||!gl.getExtension('EXT_color_buffer_float'))throw Error('WebGL2 RGBA32F color and DEPTH_COMPONENT24 required');
 const debugInfo=gl.getExtension('WEBGL_debug_renderer_info'),rendererName=gl.getParameter(debugInfo?debugInfo.UNMASKED_RENDERER_WEBGL:gl.RENDERER),backend={version:gl.getParameter(gl.VERSION),renderer:rendererName,softwareBackendRecognized:/SwiftShader|llvmpipe|softpipe|Software/i.test(rendererName)};
 const input=scene?await sceneInput(width,height,sceneCamera):await fixtureInput(naga,width,height,onProgress);
 let near,output,reader,sentinels;const reports=[];
 try{
  onProgress?.({stage:'compiling baseline, candidate and depth-copy programs',scene,naga});const createStarted=performance.now();
  near=await createNearStationRenderer({gl,mesh:input.mesh,splitBrickFaces:input.splitBrickFaces,enableVisibilityCandidate:true,fragmentURL:new URL(naga?'../generated/near-material-naga.frag':'../generated/near-material-entry-adapted.frag',import.meta.url),visibilityFragmentURL:new URL(naga?'../generated/near-material-visible-naga.frag':'../generated/near-material-visible-entry-adapted.frag',import.meta.url)});
  const rendererCreateWallMs=performance.now()-createStarted;output=target(gl,width,height,true);reader=await depthReader(gl,width,height);sentinels=hostSentinels(gl);assertNoGLError(gl,'all programs ready');
  for(const test of input.cases)for(const debug of test.debugModes||DEBUG_MODES){
   onProgress?.({stage:'small A/B draw',case:test.name,debug,completed:reports.length});
   const frame={...FIXED,...test.frame,width,height,debug,microNormal:!!test.microNormal};
   // The same renderer, typed matrix, geometry, camera, age, light, radius and
   // host target are used in both arms. Only visibilityPrepass changes.
   const baseline=await capture(gl,near,output,reader,sentinels,{...frame,visibilityPrepass:false}),candidate=await capture(gl,near,output,reader,sentinels,{...frame,visibilityPrepass:true});
   const comparison=compareReadbacks(baseline,candidate),receiptErrors=validateReceipt(baseline.receipt,candidate.receipt,frame.microNormal);
   if(test.name==='near-plane-crossing'&&!test.frame.geometryDiagnostics?.nearPlaneCrossed)receiptErrors.push('Fixture does not actually cross the near plane after original B displacement');
   // Bypass is the same shader/program, so demand bit-for-bit float/depth
   // equality as well as the standard material tolerance.
   let exactDepthTieWinner;
   if(test.name==='exact-coplanar-LESS-first-winner'&&debug===6){
    let pixel=-1,best=Infinity;for(let i=0;i<width*height;i++){if(baseline.color[i*4]===CLEAR)continue;const d=((i%width)+.5-width/2)**2+(Math.floor(i/width)+.5-height/2)**2;if(d<best){best=d;pixel=i;}}
    const first=input.exactCoplanar.firstQXRange,second=input.exactCoplanar.secondQXRange,inFirst=q=>Number.isFinite(q)&&q>=first[0]-COLOR_TOLERANCE&&q<=first[1]+COLOR_TOLERANCE;
    const baselineQX=pixel<0?null:baseline.color[pixel*4],candidateQX=pixel<0?null:candidate.color[pixel*4];
    exactDepthTieWinner={passed:pixel>=0&&inFirst(baselineQX)&&inFirst(candidateQX),pixel,x:pixel%width,y:Math.floor(pixel/width),baselineQX,candidateQX,firstQXRange:first,secondQXRange:second,expected:'first submitted exact-depth duplicate under LESS'};
    if(!exactDepthTieWinner.passed)receiptErrors.push('Exact-depth LESS winner is not the first submitted fixture');
   }
   const bypassExact=frame.microNormal?baseline.color.every((v,i)=>Object.is(v,candidate.color[i]))&&baseline.depth.every((v,i)=>Object.is(v,candidate.depth[i])):undefined;
   reports.push({case:test.name,fixture:test.fixture,layers:test.layers,geometryDiagnostics:test.frame.geometryDiagnostics,debug,microNormal:frame.microNormal,nearRadiusM:frame.nearRadiusM===Infinity?'Infinity':frame.nearRadiusM,comparison,receiptErrors,bypassExact,exactDepthTieWinner,passed:comparison.passed&&!receiptErrors.length&&bypassExact!==false&&baseline.stateRestoration.passed&&candidate.stateRestoration.passed,baseline:{receipt:baseline.receipt,stateRestoration:baseline.stateRestoration,timing:baseline.timing},candidate:{receipt:candidate.receipt,stateRestoration:candidate.stateRestoration,timing:candidate.timing}});
  }
  const bounded=reports.find(x=>x.case==='radius-95m-boundary'&&x.debug===0),unbounded=reports.find(x=>x.case==='radius-Infinity-control'&&x.debug===0),radiusBoundaryCheck=scene?null:{passed:!!bounded&&!!unbounded&&bounded.comparison.baselineCovered>0&&bounded.comparison.baselineCovered<unbounded.comparison.baselineCovered,at95m:bounded?.comparison.baselineCovered,atInfinity:unbounded?.comparison.baselineCovered};
  assertNoGLError(gl,'probe complete');
  return{status:reports.every(r=>r.passed)&&radiusBoundaryCheck?.passed!==false?'passed':'failed',scope:SCOPE,mode:scene?'explicit-single-camera-scene':'bounded-fixture-stacks-and-edge-cases',naga,width,height,backend,fixtureNames:input.fixtureNames,fixtureBake:input.bake,exactCoplanarFixture:input.exactCoplanar,sceneSource:input.source,caseCount:input.cases.length,pairCount:reports.length,debugModes:DEBUG_MODES,colorTolerance:COLOR_TOLERANCE,depthTolerance:DEPTH_TOLERANCE,depthFormat:'DEPTH_COMPONENT24 copied with texelFetch to RGBA32F for actual depth comparison',coverageRule:'Zero missing OR extra covered pixels; nonempty baseline; color and stored depth masks agree',radiusBoundaryCheck,compile:{rendererCreateWallMs,near:near.compile,visibility:near.visibilityCompile,depthCopy:reader.compile},timingMeaning:'drawCompletedWallMs uses fenceSync/clientWaitSync completion, includes host-state checks/poll/scheduling overhead and may include lazy first-use driver work. Compilation/setup is reported separately. Color/depth readback times are separate. No FPS is calculated.',glErrors:[],reports,totalWallMs:performance.now()-started};
 }finally{sentinels?.dispose();reader?.dispose();output?.dispose();near?.dispose();}
}
