import {createNearStationRenderer} from '../renderer.mjs';
import {createStationSampler} from '../../material-sampler.mjs';

/** Small regression only. Diagnostic atlas, not a scene/visual/performance test. */
export async function run(canvas){
 const manifest=await fetch(new URL('../../qa/reference/manifest.json',import.meta.url)).then(r=>r.json()),fixtures=manifest.fixtures;
 const gl=canvas.getContext('webgl2',{antialias:false,alpha:false,depth:false});
 if(!gl||!gl.getExtension('EXT_color_buffer_float'))throw Error('RGBA32F WebGL2 required');
 const naga=new URLSearchParams(location.search).get('naga')==='1';
 const W=fixtures.length*8,H=8;canvas.width=W;canvas.height=H;
 const positions=[],normals=[],hits=[],indices=[],distance=[],corners=[[-1,-1],[1,-1],[-1,1],[-1,1],[1,-1],[1,1]];
 for(const f of fixtures)for(const [x,z] of corners){
  positions.push(f.p[0]+x*.0016,f.p[1],f.p[2]+z*.0016);normals.push(...f.normal);hits.push(f.q[0]+x*.0016,f.q[1],f.q[2]+z*.0016,f.id,...f.extent,f.seed,f.baseD,f.sourceSeed,0,0);indices.push(indices.length);distance.push(0);
 }
 const vertex=`#version 300 es
 precision highp float;precision highp int;
 layout(location=0)in vec3 p;layout(location=1)in vec3 n;layout(location=2)in vec4 q;layout(location=3)in vec4 e;layout(location=4)in vec4 b;
 uniform mat4 stationClipFromLocal;uniform vec4 stationDepth;
 out vec3 _vs2fs_location0;out vec3 _vs2fs_location1;out vec3 _vs2fs_location2;flat out vec4 _vs2fs_location3;flat out vec2 _vs2fs_location4;out float _vs2fs_location5;out float _vs2fs_location6;out vec3 _vs2fs_location7;
 void main(){vec2 uv[6]=vec2[6](vec2(-1,-1),vec2(1,-1),vec2(-1,1),vec2(-1,1),vec2(1,-1),vec2(1,1));int f=gl_VertexID/6;vec2 a=uv[gl_VertexID%6];float x=(float(f)+(a.x+1.)*.5)/float(${fixtures.length})*2.-1.;gl_Position=stationClipFromLocal*vec4(x,a.y,0.,1.);_vs2fs_location0=p;_vs2fs_location1=n;_vs2fs_location2=q.xyz;_vs2fs_location3=e;_vs2fs_location4=vec2(q.w,b.y);_vs2fs_location5=b.x;_vs2fs_location6=2.+stationDepth.y*0.00000001;_vs2fs_location7=p;}`;
 const fragmentURL=new URL(naga?'../generated/near-material-naga.frag':'../generated/near-material-entry-adapted.frag',import.meta.url);
 const near=await createNearStationRenderer({gl,vertexSource:vertex,fragmentURL,splitBrickFaces:false,mesh:{positions:new Float32Array(positions),normals:new Float32Array(normals),packedHits:new Float32Array(hits),indices:new Uint32Array(indices),geometryDistance:new Float32Array(distance)}});
 const sampler=await createStationSampler({fragmentURL:new URL(naga?'../../generated/material-query-naga.frag':'../../generated/material-query-entry-adapted.frag',import.meta.url),maxBatch:4096});
 const fbo=gl.createFramebuffer(),texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,W,H,0,gl.RGBA,gl.FLOAT,null);gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Probe framebuffer incomplete');
 const frame={clipFromStation:new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),width:W,height:H,sun:[-.45,.78,.38],sunColor:[1,.92,.82],day:1,light:[4.6,1,1,1],exposure:1,nearRadiusM:10000,fragmentRadiusCut:true};
 const reports=[];let maximumError=0;
 try{
 for(const eye of [[96,48,55],[24,1.6,8]])for(const age of [0,.58,1]){
  Object.assign(frame,{eye,age});const output={};
  for(const debug of[1,2,3,4,5,6]){gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.viewport(0,0,W,H);gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);gl.disable(gl.CULL_FACE);gl.disable(gl.SCISSOR_TEST);gl.clearColor(-999,-999,-999,-999);gl.clear(gl.COLOR_BUFFER_BIT);near.draw({...frame,debug});const a=new Float32Array(W*H*4);gl.readPixels(0,0,W,H,gl.RGBA,gl.FLOAT,a);output[debug]=a;}
  const pp=[],nn=[],hh=[],ff=[],pixels=[];
  // Four interior pixels/fixture; avoids primitive edges/helper-pixel ambiguity.
  for(let f=0;f<fixtures.length;f++)for(const [x,y] of[[2,2],[5,2],[2,5],[5,5]]){const k=(y*W+f*8+x)*4,v=fixtures[f];pp.push(...output[5].slice(k,k+3));ff.push(output[5][k+3]);nn.push(...v.normal);hh.push(...output[6].slice(k,k+3),v.id,...v.extent,v.seed,output[6][k+3],v.sourceSeed,0,0);pixels.push(k);}
  const exact=await sampler.sample({positions:new Float32Array(pp),normals:new Float32Array(nn),packedHits:new Float32Array(hh),footprintM:new Float32Array(ff),eye,age});let max=0,bad=0;
  for(let i=0;i<pixels.length;i++){
   if(exact.failureFlags[i])throw Error('Reference query failed '+exact.failureFlags[i]);const k=pixels[i];
   const actual=[...output[1].slice(k,k+4),...output[2].slice(k,k+3),...output[3].slice(k,k+4),...output[4].slice(k,k+4)];
   const expected=[...exact.colors.slice(i*3,i*3+3),exact.roughness[i],exact.geometryDistance[i],exact.matterDistance[i],exact.materialKey[i],...exact.detail.slice(i*4,i*4+4),...exact.state.slice(i*4,i*4+4)];
   actual.forEach((v,j)=>{const error=Math.abs(v-expected[j]);if(!Number.isFinite(error)||error>0.0005)bad++;max=Math.max(max,error);});
  }
  reports.push({eye,age,samples:pixels.length,maxAbsError:max,bad});maximumError=Math.max(maximumError,max);
 }
 return{status:reports.every(x=>x.bad===0)?'passed':'failed',naga,fixtureCount:fixtures.length,totalSamples:reports.reduce((n,x)=>n+x.samples,0),maxAbsError:maximumError,reports,nearCompile:near.compile,referenceCompile:sampler.compile,scope:'Raster-interpolated p/q/baseD and derivative footprint versus original query. Small atlas, not normal-perspective scene acceptance or realtime performance.'};
 }finally{near.dispose();sampler.dispose();gl.deleteFramebuffer(fbo);gl.deleteTexture(texture);}
}
