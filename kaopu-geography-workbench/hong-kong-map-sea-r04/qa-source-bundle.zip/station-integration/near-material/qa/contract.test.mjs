import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {WGSL} from '../../frozen-B/receiver.mjs';
import {extraction} from '../../shader-closure.mjs';
import {prepareNearMesh,mapPointToStation,stationPointToMap,mapDirectionToStation,stationDirectionToMap,stationClipFromMap,logDepth,makeStationParams,makeNearParams,groupDistanceM} from '../mesh-contract.mjs';
import {splitTowerBrickFaces} from '../split-brick-faces.mjs';
const read=p=>fs.readFileSync(new URL(p,import.meta.url),'utf8');
const sha=x=>createHash('sha256').update(x).digest('hex');
function mesh(){return{positions:new Float32Array([0,0,0,1,0,0,0,0,1]),normals:new Float32Array([0,1,0,0,1,0,0,1,0]),packedHits:new Float32Array([0,0,0,17,1,1,1,77,0,0,0,0,1,0,0,17,1,1,1,77,0,0,0,0,0,0,1,17,1,1,1,77,0,0,0,0]),indices:new Uint32Array([0,1,2]),geometryDistance:new Float32Array([.002,-.003,.004])};}
test('Each frozen source byte remains locked to B',()=>{const lock=JSON.parse(read('../../SOURCE_LOCK.json'));for(const f of lock.files){assert.equal(sha(fs.readFileSync(new URL('../../frozen-B/'+f.path,import.meta.url))),f.sha256,f.path);}});
test('Near closure and compiled mother prefix are unchanged',()=>{
 const manifest=JSON.parse(read('../generated/manifest.json')),s=extraction(WGSL),r=extraction(read('../../qa/reference/probe.wgsl'));
 assert.equal(s.header,r.header);assert.equal(s.closure(manifest.roots),r.closure(manifest.roots));assert.equal(sha(s.closure(manifest.roots)),manifest.closureSha256);
 const old=read('../../qa/reference/probe.frag'),prefix=old.slice(0,old.lastIndexOf('void main() {'));
 assert.ok(read('../generated/near-material-entry-adapted.frag').startsWith(prefix));assert.equal(sha(prefix),manifest.frozenGlslPrefixSha256);
 assert.equal(sha(read('../generated/near-material.wgsl')),manifest.fragmentWgslSha256);
 assert.equal(sha(read('../generated/near-material-entry-adapted.frag')),manifest.fragmentGlslSha256);
 assert.doesNotMatch(read('../generated/near-material.wgsl'),/fn (stationDomain|march|shade)\(/);
});
test('Near entry calls original geometry/matter and uses pixel footprint derivatives',()=>{
 for(const file of ['../near-entry.wgsl','../near-entry.glsl']){let s=read(file);assert.match(s,/evaluateStationGeometry\(/);assert.match(s,/evaluateStationMatter\(/);assert.match(s,/max\(length\(dx\),length\(dy\)\)/);}
 assert.match(read('../near-entry.wgsl'),/@location\(3\)@interpolate\(flat\)/);assert.match(read('../near-entry.wgsl'),/@location\(4\)@interpolate\(flat\)/);
 assert.match(read('../near.vert'),/stationClipFromLocal\*vec4\(projected,1\.\)/);
});
test('Mesh validation covers all flat fields, and preserves inputs',()=>{
 const input=mesh(),before=new Float32Array(input.packedHits),out=prepareNearMesh(input);assert.equal(out.triangleCount,1);assert.deepEqual(input.packedHits,before);
 assert.ok(out.groups[0].min[1]<-.0039);assert.ok(out.groups[0].max[1]>.0029);
 for(const field of[3,4,5,6,7,9]){const bad=mesh();bad.packedHits[12+field]+=(field===3?1:.1);assert.throws(()=>prepareNearMesh(bad),/flat HitField ownership/);}
 const bad=mesh();bad.normals[1]=0;assert.throws(()=>prepareNearMesh(bad),/Invalid near-mesh vertex/);
 const outOfRange=mesh();outOfRange.indices[0]=100;assert.throws(()=>prepareNearMesh(outOfRange),/valid triangles/);
});
test('Camera and sun transform use exact existing tower anchoring, no bake camera',()=>{
 for(const p of [[24,1.6,4],[-30,.85,-70],[24,25,4]]){const q=mapPointToStation(stationPointToMap(p));q.forEach((v,i)=>assert.ok(Math.abs(v-p[i])<1e-9));}
 assert.deepEqual(mapDirectionToStation(stationDirectionToMap([1,2,3])),[1,2,3]);
 const eye=mapPointToStation([1477.171,5.5,9824.015]),p=makeStationParams({eye,width:800,height:600});assert.ok(Math.abs(p[1]-1.6)<1e-6);assert.equal(p.byteLength,80);
 const identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],matrix=stationClipFromMap(identity);assert.equal(matrix[2],1);assert.equal(matrix[8],-1);
});
test('Host depth convention and near-normal defaults are explicit',()=>{
 const p=makeNearParams({sun:[0,1,0],sunColor:[1,.9,.8],day:1,light:[4.6,1,1,1]});assert.equal(p.byteLength,80);assert.equal(p[12],1);assert.ok(Math.abs(p[13]-.05)<1e-8);assert.equal(p[14],60000);assert.equal(p[15],1);assert.equal(p[16],0);
 assert.equal(logDepth(0),0);assert.equal(logDepth(60000),1);assert.ok(logDepth(.05)>0);assert.ok(logDepth(2)>logDepth(1));
 assert.throws(()=>makeNearParams({sun:[0,0,0],sunColor:[1,1,1],day:1,light:[1,1,1,1]}),/Host sun/);
 assert.equal(groupDistanceM({min:[0,0,0],max:[1,1,1]},[.5,.5,.5]),0);assert.equal(groupDistanceM({min:[0,0,0],max:[1,1,1]},[3,.5,.5]),2);
});
test('Near/far radius cut uses final display position and can be explicitly disabled',()=>{
 const host={sun:[0,1,0],sunColor:[1,1,1],day:1,light:[1,1,1,1]};
 const normal=makeNearParams(host);assert.equal(normal[17],80);assert.equal(normal[18],1);
 const unbounded=makeNearParams({...host,nearRadiusM:Infinity});assert.ok(unbounded.every(Number.isFinite));assert.equal(unbounded[18],0);assert.ok(unbounded[17]>1e30);
 const groupOnly=makeNearParams({...host,nearRadiusM:20,fragmentRadiusCut:false});assert.equal(groupOnly[17],20);assert.equal(groupOnly[18],0);
 assert.match(read('../near.vert'),/_vs2fs_location7=projected/);
 assert.match(read('../near-entry.glsl'),/distance\(_vs2fs_location7,_group_0_binding_0_fs.eye\)>nearSettings.render.y/);
 assert.match(read('../near-entry.wgsl'),/distance\(input.displayP,u.eye\)>nearSettings.render.y/);
});
function brick(points,ids){const m=mesh();m.positions=new Float32Array(points.flat());m.packedHits=new Float32Array(points.flatMap((p,i)=>[...p,ids[i],2.96,13.65,2.96,71,0,1,0,0]));return m;}
test('Clock corner tie duplicates one-sided flat identity without moving geometry',()=>{
 const m=brick([[2,0,2],[1,0,2],[1,1,2]],[12,1,1]),before=new Float32Array(m.packedHits),out=splitTowerBrickFaces(m);
 assert.equal(out.brickPartition.changedTriangles,1);assert.equal(out.brickPartition.faceOnlyReassignments,1);assert.equal(out.indices.length,3);assert.deepEqual(m.packedHits,before);prepareNearMesh(out);
 for(const i of out.indices)assert.equal(out.packedHits[i*12+3],1);
 assert.ok(out.brickPartition.areaErrorM2<1e-12);
});
test('Octagonal face crosses true material boundary and must split',()=>{
 const m=brick([[2,0,1],[1,0,2],[1,1,2]],[12,1,1]),out=splitTowerBrickFaces(m);
 assert.equal(out.brickPartition.splitTriangles,1);assert.equal(out.indices.length,9);assert.ok(out.brickPartition.areaErrorM2<1e-12);prepareNearMesh(out);
 for(let t=0;t<out.indices.length;t+=3){const vs=Array.from(out.indices.subarray(t,t+3));const q=[0,1,2].map(k=>vs.reduce((s,i)=>s+out.packedHits[i*12+k],0)/3);assert.equal(out.packedHits[vs[0]*12+3],Math.abs(q[0])>Math.abs(q[2])?12:1);}
});
test('Equal vertex IDs do not prove constant triangle-interior identity',()=>{
 const m=brick([[-2,0,-2],[2,0,-2],[2,0,2]],[1,1,1]),out=splitTowerBrickFaces(m);
 assert.equal(out.brickPartition.sourceMixedIdTriangles,0);assert.equal(out.brickPartition.interiorOnlyChanges,1);assert.equal(out.brickPartition.splitTriangles,1);assert.ok(out.brickPartition.areaErrorM2<1e-12);prepareNearMesh(out);
});
test('Other member/material ownership errors still fail instead of being flattened',()=>{
 const m=brick([[2,0,1],[1,0,2],[1,1,2]],[12,1,1]);for(let i=0;i<3;i++)m.packedHits[i*12+7]=171;
 const out=splitTowerBrickFaces(m);assert.equal(out.brickPartition.changedTriangles,0);assert.throws(()=>prepareNearMesh(out),/flat HitField ownership/);
});
