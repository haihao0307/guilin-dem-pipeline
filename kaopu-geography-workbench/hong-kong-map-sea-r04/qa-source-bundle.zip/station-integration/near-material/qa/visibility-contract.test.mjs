import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {WGSL} from '../../frozen-B/receiver.mjs';
import {extraction} from '../../shader-closure.mjs';
import {makeVisibilityWGSL,makeVisibilityGLSL,visibilityTolerance,visibilityEpsilon} from '../visibility-entry.mjs';
import {createVisibilityDepthTarget,captureNearHostState,restoreNearHostState} from '../visibility-depth-target.mjs';
const read=p=>fs.readFileSync(new URL(p,import.meta.url),'utf8');
test('Unchanged mother closure has no derivative/texture/discard dependency',()=>{
 const c=extraction(WGSL).closure(['evaluateStationGeometry','evaluateStationMatter','stationMemberState','stationBrickSample']);
 assert.doesNotMatch(c,/\b(?:dpdx\w*|dpdy\w*|fwidth\w*|textureSample\w*|textureGather\w*|textureLoad|discard)\b/);
});
test('Visibility WGSL entry preserves footprint helpers before rejection and removes micro derivatives',()=>{
 const entry=makeVisibilityWGSL(read('../near-entry.wgsl'));
 assert.match(entry,/fn stationNearVisibleFragment/);assert.equal((entry.match(/dpdx\(/g)||[]).length,1);assert.equal((entry.match(/dpdy\(/g)||[]).length,1);
 assert.ok(entry.indexOf('dpdy(input.p)')<entry.indexOf('discard;'));
 assert.ok(entry.indexOf('if(depth>stored+tolerance)')<entry.indexOf('let m=evaluateStationMatter'));
 assert.doesNotMatch(entry,/dpdx\(m\.microHeight\)|dpdy\(m\.microHeight\)/);
 assert.match(entry,/textureLoad\(stationVisibilityDepth,vec2<i32>\(input.pixel.xy\),0\)/);
});
test('Visibility GLSL keeps exact B prefix and mirrors the separate WGSL entry',()=>{
 const entry=makeVisibilityGLSL(read('../near-entry.glsl')),old=read('../../qa/reference/probe.frag'),prefix=old.slice(0,old.lastIndexOf('void main() {'));
 assert.ok(read('../generated/near-material-visible-entry-adapted.frag').startsWith(prefix));
 assert.equal((entry.match(/dFdx\(/g)||[]).length,1);assert.equal((entry.match(/dFdy\(/g)||[]).length,1);assert.ok(entry.indexOf('dFdy(p)')<entry.indexOf('discard;'));
 assert.ok(entry.indexOf('if(depth>stored+tolerance)')<entry.indexOf('StationMatter m='));assert.match(read('../near.vert'),/invariant gl_Position/);
});
test('Numerical tolerance retains equal and uncertain depth, rejects only distinctly farther values',()=>{
 const e=visibilityEpsilon(.45,.45);assert.ok(e>=2/(2**24-1)+8*2**-23);assert.ok(e<.000002);
 const reject=(a,b)=>a>b+visibilityEpsilon(a,b);
 assert.equal(reject(.45,.45),false);assert.equal(reject(.44,.45),false);assert.equal(reject(.45+e*.5,.45),false);assert.equal(reject(.45+e*2,.45),true);
 assert.ok(visibilityEpsilon(.45,.45,.00001)>e);assert.throws(()=>visibilityTolerance(-.1));assert.throws(()=>visibilityTolerance(NaN));
});
test('Renderer keeps visibility explicit and bypasses it for micro-normal derivatives',()=>{
 const code=read('../renderer.mjs');assert.match(code,/enableVisibilityCandidate=false/);assert.match(code,/useVisibility=requested&&!near\[16\]/);assert.match(code,/'bypass-micro-normal'/);
 assert.match(code,/const groups=prepared.groups.filter/);assert.match(code,/depthTarget.render\(\{frame:frozen,params,near,groups,vao\}\)/);
});
function mockGL(){
 const names=['MAX_TEXTURE_IMAGE_UNITS','MAX_TEXTURE_SIZE','ACTIVE_TEXTURE','TEXTURE_BINDING_2D','DRAW_FRAMEBUFFER_BINDING','READ_FRAMEBUFFER_BINDING','VIEWPORT','DEPTH_RANGE','SAMPLES','STENCIL_TEST','POLYGON_OFFSET_FILL','RASTERIZER_DISCARD','COLOR_WRITEMASK','DEPTH_WRITEMASK','DEPTH_FUNC','DEPTH_CLEAR_VALUE','DEPTH_TEST','SCISSOR_TEST','CURRENT_PROGRAM','VERTEX_ARRAY_BINDING','SAMPLER_BINDING','BLEND','DRAW_FRAMEBUFFER','READ_FRAMEBUFFER','FRAMEBUFFER','TEXTURE_2D','TEXTURE_MIN_FILTER','TEXTURE_MAG_FILTER','TEXTURE_WRAP_S','TEXTURE_WRAP_T','TEXTURE_COMPARE_MODE','NONE','NEAREST','CLAMP_TO_EDGE','DEPTH_COMPONENT24','DEPTH_COMPONENT','UNSIGNED_INT','DEPTH_ATTACHMENT','FRAMEBUFFER_COMPLETE','LESS','DEPTH_BUFFER_BIT','TRIANGLES'];
 names.push('CULL_FACE','UNIFORM_BUFFER','UNIFORM_BUFFER_BINDING','UNIFORM_BUFFER_START','UNIFORM_BUFFER_SIZE');
 const g=Object.fromEntries(names.map(n=>[n,n]));g.TEXTURE0=1000;
 const host={kind:'host'},other={kind:'read'},oldProgram={kind:'program'},oldVAO={kind:'vao'},originalTexture={kind:'texture'},originalSampler={kind:'sampler'};
 const p=new Map([[g.MAX_TEXTURE_IMAGE_UNITS,16],[g.MAX_TEXTURE_SIZE,4096],[g.ACTIVE_TEXTURE,1003],[g.DRAW_FRAMEBUFFER_BINDING,host],[g.READ_FRAMEBUFFER_BINDING,other],[g.VIEWPORT,[0,0,128,72]],[g.DEPTH_RANGE,[0,1]],[g.SAMPLES,0],[g.COLOR_WRITEMASK,[true,false,true,false]],[g.DEPTH_WRITEMASK,true],[g.DEPTH_FUNC,g.LESS],[g.DEPTH_CLEAR_VALUE,.9],[g.CURRENT_PROGRAM,oldProgram],[g.VERTEX_ARRAY_BINDING,oldVAO]]),enabled=new Set([g.DEPTH_TEST,g.SCISSOR_TEST]),textures=new Map([[1003,originalTexture],[1015,originalTexture]]),samplers=new Map([[1015,originalSampler]]),events=[];let serial=0;
 g.getParameter=k=>k===g.TEXTURE_BINDING_2D?textures.get(p.get(g.ACTIVE_TEXTURE))??null:k===g.SAMPLER_BINDING?samplers.get(p.get(g.ACTIVE_TEXTURE))??null:p.get(k);
 g.isEnabled=k=>enabled.has(k);g.enable=k=>enabled.add(k);g.disable=k=>enabled.delete(k);
 g.getUniformLocation=(_,n)=>n;g.createTexture=()=>({kind:'owned-texture',serial:++serial});g.createFramebuffer=()=>({kind:'owned-framebuffer',serial:++serial});
 g.deleteTexture=x=>events.push(['deleteTexture',x]);g.deleteFramebuffer=x=>events.push(['deleteFramebuffer',x]);
 g.activeTexture=x=>p.set(g.ACTIVE_TEXTURE,x);g.bindTexture=(_,x)=>textures.set(p.get(g.ACTIVE_TEXTURE),x);g.bindSampler=(u,x)=>samplers.set(1000+u,x);
 g.bindFramebuffer=(target,x)=>{if(target!==g.READ_FRAMEBUFFER)p.set(g.DRAW_FRAMEBUFFER_BINDING,x);if(target!==g.DRAW_FRAMEBUFFER)p.set(g.READ_FRAMEBUFFER_BINDING,x);};
 for(const name of ['texParameteri','texImage2D','framebufferTexture2D','drawBuffers','readBuffer','uniformMatrix4fv','uniform4fv','uniform3fv','uniform2f'])g[name]=(...args)=>events.push([name,...args]);
 g.checkFramebufferStatus=()=>g.FRAMEBUFFER_COMPLETE;g.viewport=(...x)=>p.set(g.VIEWPORT,x);g.colorMask=(...x)=>p.set(g.COLOR_WRITEMASK,x);g.depthMask=x=>p.set(g.DEPTH_WRITEMASK,x);g.depthFunc=x=>p.set(g.DEPTH_FUNC,x);g.clearDepth=x=>p.set(g.DEPTH_CLEAR_VALUE,x);g.useProgram=x=>p.set(g.CURRENT_PROGRAM,x);g.bindVertexArray=x=>p.set(g.VERTEX_ARRAY_BINDING,x);
 g.clear=x=>events.push(['clear',x,p.get(g.DRAW_FRAMEBUFFER_BINDING),enabled.has(g.SCISSOR_TEST)]);
 g.drawElements=(...x)=>events.push(['draw',...x,p.get(g.DRAW_FRAMEBUFFER_BINDING)]);
 const bases=new Map();g.getIndexedParameter=(param,i)=>{const b=bases.get(i);return param===g.UNIFORM_BUFFER_BINDING?b?.buffer??null:param===g.UNIFORM_BUFFER_START?b?.start??0:b?.size??0;};
 g.bindBuffer=(_,b)=>p.set(g.UNIFORM_BUFFER_BINDING,b);g.bindBufferRange=(_,i,buffer,start,size)=>{bases.set(i,{buffer,start,size});p.set(g.UNIFORM_BUFFER_BINDING,buffer);};g.bindBufferBase=(_,i,buffer)=>{bases.set(i,{buffer,start:0,size:0});p.set(g.UNIFORM_BUFFER_BINDING,buffer);};
 return{g,p,enabled,events,host,other,oldProgram,oldVAO,originalTexture,originalSampler};
}
test('Same-frame depth target clears each call, restores host state and samples off-target only',()=>{
 const {g,p,events,host,other,oldProgram,oldVAO,originalTexture,originalSampler}=mockGL(),t=createVisibilityDepthTarget(g,{program:{kind:'depth-program'},textureUnit:15});
 const frame={width:128,height:72,clipFromStation:new Float32Array(16)},params=new Float32Array(20),near=new Float32Array(20);near.set([1,.05,60000,1],12);near[17]=95;near[18]=1;
 const input={frame,params,near,groups:[{indexCount:6,indexStart:0},{indexCount:9,indexStart:6}],vao:{kind:'near-vao'}};
 for(let i=0;i<2;i++)t.render(input);
 assert.equal(events.filter(x=>x[0]==='clear').length,2);assert.equal(events.filter(x=>x[0]==='draw').length,4);
 for(const e of events.filter(x=>x[0]==='clear')){assert.equal(e[2].kind,'owned-framebuffer');assert.equal(e[3],false);}
 assert.equal(p.get(g.DRAW_FRAMEBUFFER_BINDING),host);assert.equal(p.get(g.READ_FRAMEBUFFER_BINDING),other);assert.equal(p.get(g.CURRENT_PROGRAM),oldProgram);assert.equal(p.get(g.VERTEX_ARRAY_BINDING),oldVAO);assert.deepEqual(p.get(g.COLOR_WRITEMASK),[true,false,true,false]);assert.equal(p.get(g.DEPTH_CLEAR_VALUE),.9);
 t.withTexture(()=>{assert.equal(p.get(g.DRAW_FRAMEBUFFER_BINDING),host);assert.equal(g.getParameter(g.TEXTURE_BINDING_2D).kind,'owned-texture');assert.equal(g.getParameter(g.SAMPLER_BINDING),null);});
 assert.equal(p.get(g.ACTIVE_TEXTURE),1003);g.activeTexture(1015);assert.equal(g.getParameter(g.TEXTURE_BINDING_2D),originalTexture);assert.equal(g.getParameter(g.SAMPLER_BINDING),originalSampler);g.activeTexture(1003);
 t.dispose();assert.throws(()=>t.render(input),/disposed/);
});
test('Unsupported viewport and non-opaque/depth semantics fail instead of using wrong visibility',()=>{
 const {g,p}=mockGL(),t=createVisibilityDepthTarget(g,{program:{},textureUnit:15});const args={frame:{width:128,height:72},params:new Float32Array(20),near:new Float32Array(20),groups:[],vao:{}};
 p.set(g.VIEWPORT,[1,0,128,72]);assert.throws(()=>t.render(args),/origin-zero/);p.set(g.VIEWPORT,[0,0,128,72]);g.disable(g.DEPTH_TEST);assert.throws(()=>t.render(args),/opaque depth-tested/);t.dispose();
 assert.throws(()=>createVisibilityDepthTarget(g,{program:{},textureUnit:7}),/outside host units 0\.\.7/);
});
test('Outer draw snapshot restores all requested host states and exact UBO ranges',()=>{
 const {g,p,enabled}=mockGL(),oldBuffer={kind:'old-ubo'},generic={kind:'generic-ubo'};
 g.bindBufferRange(g.UNIFORM_BUFFER,6,oldBuffer,256,80);g.bindBuffer(g.UNIFORM_BUFFER,generic);g.enable(g.CULL_FACE);
 const s=captureNearHostState(g,[6,7,8]);g.bindFramebuffer(g.FRAMEBUFFER,{kind:'different-target'});g.viewport(0,0,1,1);g.depthMask(false);g.depthFunc('ALWAYS');g.clearDepth(0);g.colorMask(false,false,false,false);g.disable(g.CULL_FACE);g.enable(g.BLEND);g.disable(g.SCISSOR_TEST);g.activeTexture(1015);g.useProgram({});g.bindVertexArray({});g.bindBufferRange(g.UNIFORM_BUFFER,6,{kind:'new-ubo'},0,16);
 restoreNearHostState(g,s);
 assert.equal(p.get(g.DRAW_FRAMEBUFFER_BINDING),s.draw);assert.equal(p.get(g.READ_FRAMEBUFFER_BINDING),s.read);assert.deepEqual(p.get(g.VIEWPORT),s.viewport);assert.equal(p.get(g.DEPTH_FUNC),s.depthFunc);assert.equal(p.get(g.DEPTH_WRITEMASK),s.depthMask);assert.deepEqual(p.get(g.COLOR_WRITEMASK),s.colorMask);assert.equal(p.get(g.DEPTH_CLEAR_VALUE),s.clearDepth);assert.equal(p.get(g.ACTIVE_TEXTURE),s.active);assert.equal(p.get(g.CURRENT_PROGRAM),s.program);assert.equal(p.get(g.VERTEX_ARRAY_BINDING),s.vao);
 assert.equal(enabled.has(g.CULL_FACE),true);assert.equal(enabled.has(g.BLEND),false);assert.equal(enabled.has(g.SCISSOR_TEST),true);assert.equal(g.getIndexedParameter(g.UNIFORM_BUFFER_BINDING,6),oldBuffer);assert.equal(g.getIndexedParameter(g.UNIFORM_BUFFER_START,6),256);assert.equal(g.getIndexedParameter(g.UNIFORM_BUFFER_SIZE,6),80);assert.equal(p.get(g.UNIFORM_BUFFER_BINDING),generic);
});
