/** Utilities for the bounded visibility A/B probe. No material implementation. */
export const COLOR_TOLERANCE=0.0005;
export const DEPTH_TOLERANCE=2/0xffffff;
export const CLEAR=-999;
export const DEBUG_MODES=Object.freeze([0,1,2,3,4,5,6,7]);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const unit=a=>{const l=Math.hypot(...a);if(!Number.isFinite(l)||l<1e-12)throw Error('Degenerate camera axis');return a.map(x=>x/l);};
export function perspectiveCamera({eye,target,up=[0,1,0],verticalFovDegrees=52,nearM=.05,farM=60000},width,height){
 if(![eye,target,up].every(a=>a?.length===3&&Array.from(a).every(Number.isFinite)))throw Error('Camera needs finite station-metre eye, target and up');
 if(!(nearM>0&&farM>nearM&&verticalFovDegrees>0&&verticalFovDegrees<179&&width>0&&height>0))throw Error('Invalid camera projection');
 const forward=unit(target.map((v,i)=>v-eye[i])),right=unit(cross(forward,up)),cameraUp=unit(cross(right,forward));
 const t=Math.tan(verticalFovDegrees*Math.PI/360),a=width/height,A=(farM+nearM)/(farM-nearM),B=-2*farM*nearM/(farM-nearM);
 const row0=[...right.map(x=>x/(t*a)),-dot(right,eye)/(t*a)],row1=[...cameraUp.map(x=>x/t),-dot(cameraUp,eye)/t],row2=[...forward.map(x=>x*A),-dot(forward,eye)*A+B],row3=[...forward,-dot(forward,eye)];
 const rows=[row0,row1,row2,row3],clipFromStation=new Float32Array(16);
 for(let c=0;c<4;c++)for(let r=0;r<4;r++)clipFromStation[c*4+r]=rows[r][c];
 return{eye:Array.from(eye),target:Array.from(target),up:Array.from(up),verticalFovDegrees,nearM,farM,clipFromStation};
}

/** Synthetic occlusion geometry, with original fixture HitFields. Every vertex
 * is baked with the original B query before drawing. No fabricated colors or
 * substitute material functions. One mesh/program pair serves all small cases. */
export function buildFixtureSuite(fixtures){
 const names=['heritage-brick','heritage-timber','heritage-hall-plaster'];
 const chosen=names.map(name=>{const f=fixtures.find(x=>x.name===name);if(!f)throw Error('Missing real B fixture '+name);return f;});
 const p=[],n=[],h=[],indices=[],tags=[],cases=[],patches=new Map();
 function patch(f,tag,{offset=[0,0,0],halfX=.025,halfZ=.018,slope=0,layer=0,qOffset=[0,0,0]}={}){
  const anchor=[];
  // Far layers are inserted first. Hidden material work is not accidentally
  // avoided solely by a convenient front-to-back submission order.
  for(const [x,z] of [[-1,-1],[1,-1],[-1,1],[-1,1],[1,-1],[1,1]]){
   const dx=x*halfX,dz=z*halfZ,dy=x*slope;
   const i=p.length/3;p.push(f.p[0]+offset[0]+dx,f.p[1]+offset[1]+dy,f.p[2]+offset[2]+dz);n.push(...f.normal);
   h.push(f.q[0]+dx+qOffset[0],f.q[1]+dy+qOffset[1],f.q[2]+dz+qOffset[2],f.id,...f.extent,f.seed,f.baseD,f.sourceSeed,0,0);indices.push(i);tags.push({tag,layer});anchor.push(i);
  }
  if(!patches.has(tag)||layer===0)patches.set(tag,anchor);return anchor;
 }
 for(const f of chosen){
  const tag=f.name;
  for(let layer=15;layer>=0;layer--)patch(f,tag,{offset:[0,-layer*.0125,0],layer});
  for(const layers of [1,4,16])cases.push({name:`${tag}-${layers}-layers`,tag,layers,fixture:f.name,eyeHeight:.11,nearRadiusM:95});
 }
 const f=chosen[0];
 patch(f,'near-plane-crossing',{offset:[1,0,0],slope:.04});
 cases.push({name:'near-plane-crossing',tag:'near-plane-crossing',eyeHeight:.07,nearRadiusM:95});
 patch(f,'thin-rod',{offset:[2,0,0],halfX:.0012,halfZ:.022});
 cases.push({name:'thin-rod',tag:'thin-rod',eyeHeight:.11,nearRadiusM:95});
 patch(f,'subpixel-edge',{offset:[3,-.0125,0],halfX:.029,halfZ:.022,layer:1});
 patch(f,'subpixel-edge',{offset:[3.00037,0,0],halfX:.02483,halfZ:.01777});
 cases.push({name:'subpixel-edge',tag:'subpixel-edge',eyeHeight:.11,nearRadiusM:95});
 patch(f,'near-coplanar',{offset:[4,-.000002,0],layer:1});
 patch(f,'near-coplanar',{offset:[4,0,0]});
 cases.push({name:'near-coplanar',tag:'near-coplanar',eyeHeight:.11,nearRadiusM:95});
 patch(f,'radius-boundary',{offset:[5,0,0],halfX:.22,halfZ:.2,slope:.12});
 cases.push({name:'radius-95m-boundary',tag:'radius-boundary',eyeHeight:95,verticalFovDegrees:.5,nearRadiusM:95});
 cases.push({name:'radius-Infinity-control',tag:'radius-boundary',eyeHeight:95,verticalFovDegrees:.5,nearRadiusM:Infinity});
 // Exact raster/depth duplicates retain their original submission order.
 // Only q.x differs for debug 6. Seed-71 tower brick uses stationBrickSample(p)
 // for geometry/material; the real B bake below must prove equal distances.
 const firstVertices=patch(f,'exact-coplanar',{offset:[6,0,0]}),secondVertices=patch(f,'exact-coplanar',{offset:[6,0,0],qOffset:[.125,0,0]});
 cases.push({name:'exact-coplanar-LESS-first-winner',tag:'exact-coplanar',eyeHeight:.11,nearRadiusM:95,debugModes:[1,2,6]});
 const exactCoplanar={firstVertices,secondVertices};
 const mesh={positions:new Float32Array(p),normals:new Float32Array(n),packedHits:new Float32Array(h),indices:new Uint32Array(indices),geometryDistance:new Float32Array(p.length/3),cellM:.000125};
 // Match prepareNearMesh's spatial/material grouping exactly. Fail on any
 // collision that could silently select another case/layer.
 const groupOwners=new Map();
 for(let t=0;t<indices.length;t+=3){
  const vs=indices.slice(t,t+3),center=[0,1,2].map(k=>vs.reduce((s,v)=>s+mesh.positions[v*3+k],0)/3);
  const key=mesh.packedHits[vs[0]*12+3]+':'+center.map(x=>Math.floor(x/mesh.cellM)).join(','),owner=tags[vs[0]],previous=groupOwners.get(key);
  if(previous&&(previous.tag!==owner.tag||previous.layer!==owner.layer)&&!(owner.tag==='near-coplanar'&&previous.tag===owner.tag))throw Error('Fixture group collision '+key);
  groupOwners.set(key,owner);
 }
 function caseFrame(spec,width,height){
  const anchor=patches.get(spec.tag),center=[0,1,2].map(k=>anchor.reduce((s,i)=>s+mesh.positions[i*3+k]-mesh.normals[i*3+k]*mesh.geometryDistance[i],0)/anchor.length);
  const camera=perspectiveCamera({eye:[center[0],center[1]+spec.eyeHeight,center[2]],target:center,up:[0,0,-1],verticalFovDegrees:spec.verticalFovDegrees||52},width,height);
  const selected=tags.map((tag,i)=>({tag,i})).filter(({tag})=>tag.tag===spec.tag&&(spec.layers===undefined||tag.layer<spec.layers)),depths=selected.map(({i})=>camera.eye[1]-(mesh.positions[i*3+1]-mesh.normals[i*3+1]*mesh.geometryDistance[i]));
  const geometryDiagnostics={vertexCount:selected.length,viewDepthMinM:Math.min(...depths),viewDepthMaxM:Math.max(...depths),nearPlaneCrossed:Math.min(...depths)<camera.nearM&&Math.max(...depths)>camera.nearM};
  return{...camera,geometryDiagnostics,nearRadiusM:spec.nearRadiusM,includeGroup:g=>{const owner=groupOwners.get(g.key);if(!owner)throw Error('Unknown probe group '+g.key);return owner.tag===spec.tag&&(spec.layers===undefined||owner.layer<spec.layers);}};
 }
 return{mesh,cases,groupOwners,caseFrame,fixtureNames:names,exactCoplanar};
}

export function compareReadbacks(baseline,candidate,{colorTolerance=COLOR_TOLERANCE,depthTolerance=DEPTH_TOLERANCE}={}){
 if(baseline.color.length!==candidate.color.length||baseline.depth.length!==candidate.depth.length||baseline.color.length!==baseline.depth.length*4)throw Error('Mismatched A/B buffers');
 const r={passed:true,pixels:baseline.depth.length,baselineCovered:0,candidateCovered:0,missingCoverage:0,extraCoverage:0,colorDepthCoverageDisagreements:0,nonFinite:0,badColorComponents:0,badDepthPixels:0,maxColorAbsError:0,maxDepthAbsError:0,firstFailures:[]};
 const fail=(kind,pixel,details)=>{if(r.firstFailures.length<8)r.firstFailures.push({kind,pixel,...details});};
 for(let pixel=0;pixel<r.pixels;pixel++){
  const k=pixel*4,am=[0,1,2,3].some(c=>baseline.color[k+c]!==CLEAR),bm=[0,1,2,3].some(c=>candidate.color[k+c]!==CLEAR);
  r.baselineCovered+=+am;r.candidateCovered+=+bm;
  if(am&&!bm){r.missingCoverage++;fail('missing-coverage',pixel,{});}if(!am&&bm){r.extraCoverage++;fail('extra-coverage',pixel,{});}
  if(am!==(baseline.depth[pixel]<1)||bm!==(candidate.depth[pixel]<1)){r.colorDepthCoverageDisagreements++;fail('color-depth-coverage',pixel,{});}
  for(let c=0;c<4;c++){
   const av=baseline.color[k+c],bv=candidate.color[k+c];
   if(!Number.isFinite(av)||!Number.isFinite(bv)){r.nonFinite++;fail('non-finite-color',pixel,{channel:c});continue;}
   if(am&&bm){const e=Math.abs(av-bv);r.maxColorAbsError=Math.max(r.maxColorAbsError,e);if(e>colorTolerance){r.badColorComponents++;fail('color',pixel,{channel:c,baseline:av,candidate:bv,error:e});}}
  }
  const ad=baseline.depth[pixel],bd=candidate.depth[pixel],e=Math.abs(ad-bd);
  if(!Number.isFinite(ad)||!Number.isFinite(bd)){r.nonFinite++;fail('non-finite-depth',pixel,{});}else{r.maxDepthAbsError=Math.max(r.maxDepthAbsError,e);if(e>depthTolerance){r.badDepthPixels++;fail('depth',pixel,{baseline:ad,candidate:bd,error:e});}}
 }
 r.passed=r.baselineCovered>0&&![r.missingCoverage,r.extraCoverage,r.colorDepthCoverageDisagreements,r.nonFinite,r.badColorComponents,r.badDepthPixels].some(Boolean);
 if(!r.baselineCovered)fail('empty-baseline',0,{});
 return r;
}
export function assertNoGLError(gl,stage){
 const errors=[];for(let i=0;i<32;i++){const e=gl.getError();if(e===gl.NO_ERROR)break;errors.push('0x'+e.toString(16));}
 if(errors.length)throw Error(`${stage}: WebGL errors ${errors.join(', ')}`);
 if(gl.isContextLost())throw Error(stage+': WebGL context lost');
}
export async function waitForGPU(gl,timeoutMs=120000){
 const sync=gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE,0);if(!sync)throw Error('Unable to create completion fence');gl.flush();const started=performance.now();let polls=0;
 try{while(true){polls++;const state=gl.clientWaitSync(sync,0,0);if(state===gl.ALREADY_SIGNALED||state===gl.CONDITION_SATISFIED)return{polls};if(state===gl.WAIT_FAILED)throw Error('Completion fence WAIT_FAILED');if(gl.isContextLost())throw Error('Context lost while waiting for GPU completion');if(performance.now()-started>timeoutMs)throw Error('Draw completion fence timeout');await new Promise(resolve=>setTimeout(resolve,1));}}finally{gl.deleteSync(sync);}
}
export async function decodeGzipArray(encoded,Type){
 if(typeof encoded!=='string'||!encoded.length)throw Error('Missing gzip/base64 mesh field');
 const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0)),buffer=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
 if(buffer.byteLength%Type.BYTES_PER_ELEMENT)throw Error('Misaligned mesh field');return new Type(buffer);
}
