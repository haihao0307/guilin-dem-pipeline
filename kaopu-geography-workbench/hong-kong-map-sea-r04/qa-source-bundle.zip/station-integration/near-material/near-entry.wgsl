// This is host raster/shading glue; all mother functions precede it unchanged.
struct NearParams{sunExposure:vec4<f32>,sunColorDay:vec4<f32>,light:vec4<f32>,depth:vec4<f32>,render:vec4<f32>}
@group(0)@binding(1)var<uniform>nearSettings:NearParams;
struct NearInput{
 @builtin(position)pixel:vec4<f32>,
 @location(0)p:vec3<f32>,@location(1)normal:vec3<f32>,@location(2)q:vec3<f32>,
 @location(3)@interpolate(flat)extentSeed:vec4<f32>,
 @location(4)@interpolate(flat)idSource:vec2<f32>,
 @location(5)baseD:f32,@location(6)viewZ:f32,
 @location(7)displayP:vec3<f32>,
}
struct NearOutput{@location(0)color:vec4<f32>,@builtin(frag_depth)depth:f32}
fn nearSurfaceNormal(n:vec3<f32>,dx:vec3<f32>,dy:vec3<f32>,hx:f32,hy:f32)->vec3<f32>{
 let r1=cross(dy,n);let r2=cross(n,dx);let det=dot(dx,r1);
 if(abs(det)<1e-12){return n;}
 return normalize(abs(det)*n-sign(det)*(hx*r1+hy*r2));
}
fn nearLighting(m:StationMatter,n:vec3<f32>,p:vec3<f32>)->vec3<f32>{
 let l=normalize(nearSettings.sunExposure.xyz);let v=normalize(u.eye-p);let h=normalize(l+v);
 let nl=max(dot(n,l),0.);let nv=max(dot(n,v),.001);let nh=max(dot(n,h),0.);let vh=max(dot(v,h),0.);
 let rough=clamp(m.surface.roughness,.065,.98);let alpha=rough*rough;let a2=alpha*alpha;let den=nh*nh*(a2-1.)+1.;
 let distribution=a2/(3.14159265*den*den);let k=(rough+1.)*(rough+1.)*.125;
 let masking=(nl/(nl*(1.-k)+k))*(nv/(nv*(1.-k)+k));
 let f0=mix(vec3<f32>(.04),m.surface.albedo,m.metal);let f=f0+(vec3<f32>(1.)-f0)*pow(1.-vh,5.);
 let spec=distribution*masking*f/max(.004,4.*nl*nv)*m.specular;
 let diffuse=(vec3<f32>(1.)-f)*(1.-m.metal)*m.surface.albedo/3.14159265;
 let sky=mix(vec3<f32>(.012,.018,.04),vec3<f32>(.83,.92,1.08),clamp(nearSettings.sunColorDay.w,0.,1.));
 let ambient=m.surface.albedo*sky*(.22+.30*max(n.y,0.))*nearSettings.light.y;
 return ((diffuse+spec)*nearSettings.sunColorDay.xyz*clamp(nearSettings.sunColorDay.w,0.,1.)*nearSettings.light.x*nl+ambient)*m.cavity;
}
@fragment fn stationNearFragment(input:NearInput)->NearOutput{
 // Derivatives must be evaluated before data-dependent discard/branch.
 let dx=dpdx(input.p);let dy=dpdy(input.p);
 let fp=max(.00001,max(length(dx),length(dy)));
 let normal=normalize(input.normal);
 let h=HitField(input.baseD,u32(input.idSource.x),input.q,input.extentSeed.w,input.baseD,input.extentSeed.xyz,input.idSource.y);
 let raw=resolveStationState(input.p);
 let g=evaluateStationGeometry(h,input.p,raw);
 let m=evaluateStationMatter(h,input.p,normal,fp);
 let hx=dpdx(m.microHeight);let hy=dpdy(m.microHeight);
 var n=normal;
 if(nearSettings.render.x>.5){n=nearSurfaceNormal(normal,dx,dy,hx,hy);}
 if(input.viewZ<nearSettings.depth.y||input.viewZ>nearSettings.depth.z){discard;}
 if(nearSettings.render.z>.5&&distance(input.displayP,u.eye)>nearSettings.render.y){discard;}
 var depth=input.pixel.z;
 if(nearSettings.depth.x>.5){depth=log2(1.+nearSettings.depth.w*max(input.viewZ,0.))/log2(1.+nearSettings.depth.w*nearSettings.depth.z);}
 var out=NearOutput(vec4<f32>(0.),depth);
 // Diagnostic outputs are linear, before lighting/tonemapping/gamma.
 if(u.debug==1.){out.color=vec4<f32>(m.surface.albedo,m.surface.roughness);return out;}
 if(u.debug==2.){out.color=vec4<f32>(g.d,m.d,f32(m.layer),fp);return out;}
 if(u.debug==3.){out.color=vec4<f32>(m.microHeight,g.loss,g.thickness,h.baseD);return out;}
 if(u.debug==4.){let st=stationMemberState(h,input.p,raw);out.color=vec4<f32>(st.age,st.wet,st.repair,st.retained);return out;}
 if(u.debug==5.){out.color=vec4<f32>(input.p,fp);return out;}
 if(u.debug==6.){out.color=vec4<f32>(input.q,h.baseD);return out;}
 if(u.debug==7.){out.color=vec4<f32>(n,1.);return out;}
 var color=nearLighting(m,n,input.p)*nearSettings.sunExposure.w;
 // Same ACES-fit + gamma output convention as the Weather host.
 color=clamp((color*(2.51*color+vec3<f32>(.03)))/(color*(2.43*color+vec3<f32>(.59))+vec3<f32>(.14)),vec3<f32>(0.),vec3<f32>(1.));
 out.color=vec4<f32>(pow(max(color,vec3<f32>(0.)),vec3<f32>(1./2.2)),1.);return out;
}
