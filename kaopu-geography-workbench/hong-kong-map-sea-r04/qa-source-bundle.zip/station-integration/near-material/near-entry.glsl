// Interface/lighting-only GLSL adapter. Pinned Naga mother prefix is unchanged.
struct NearParams{vec4 sunExposure;vec4 sunColorDay;vec4 light;vec4 depth;vec4 render;};
layout(std140) uniform NearParams_block_1Fragment{NearParams nearSettings;};
in vec3 _vs2fs_location0;
in vec3 _vs2fs_location1;
in vec3 _vs2fs_location2;
flat in vec4 _vs2fs_location3;
flat in vec2 _vs2fs_location4;
in float _vs2fs_location5;
in float _vs2fs_location6;
in vec3 _vs2fs_location7;
vec3 nearSurfaceNormal(vec3 n,vec3 dx,vec3 dy,float hx,float hy){
 vec3 r1=cross(dy,n),r2=cross(n,dx);float det=dot(dx,r1);
 if(abs(det)<1e-12)return n;
 return normalize(abs(det)*n-sign(det)*(hx*r1+hy*r2));
}
vec3 nearLighting(StationMatter m,vec3 n,vec3 p){
 vec3 l=normalize(nearSettings.sunExposure.xyz),v=normalize(_group_0_binding_0_fs.eye-p),h=normalize(l+v);
 float nl=max(dot(n,l),0.),nv=max(dot(n,v),.001),nh=max(dot(n,h),0.),vh=max(dot(v,h),0.);
 float rough=clamp(m.surface.roughness,.065,.98),alpha=rough*rough,a2=alpha*alpha,den=nh*nh*(a2-1.)+1.;
 float distribution=a2/(3.14159265*den*den),k=(rough+1.)*(rough+1.)*.125;
 float masking=(nl/(nl*(1.-k)+k))*(nv/(nv*(1.-k)+k));
 vec3 f0=mix(vec3(.04),m.surface.albedo,m.metal),f=f0+(vec3(1.)-f0)*pow(1.-vh,5.);
 vec3 spec=distribution*masking*f/max(.004,4.*nl*nv)*m.specular;
 vec3 diffuse=(vec3(1.)-f)*(1.-m.metal)*m.surface.albedo/3.14159265;
 vec3 sky=mix(vec3(.012,.018,.04),vec3(.83,.92,1.08),clamp(nearSettings.sunColorDay.w,0.,1.));
 vec3 ambient=m.surface.albedo*sky*(.22+.30*max(n.y,0.))*nearSettings.light.y;
 return ((diffuse+spec)*nearSettings.sunColorDay.xyz*clamp(nearSettings.sunColorDay.w,0.,1.)*nearSettings.light.x*nl+ambient)*m.cavity;
}
void main(){
 vec3 p=_vs2fs_location0,dx=dFdx(p),dy=dFdy(p);
 float fp=max(.00001,max(length(dx),length(dy)));
 vec3 normal=normalize(_vs2fs_location1);
 HitField h=HitField(_vs2fs_location5,uint(_vs2fs_location4.x),_vs2fs_location2,_vs2fs_location3.w,_vs2fs_location5,_vs2fs_location3.xyz,_vs2fs_location4.y);
 StationState raw=resolveStationState(p);
 StationGeometry g=evaluateStationGeometry(h,p,raw);
 StationMatter m=evaluateStationMatter(h,p,normal,fp);
 float hx=dFdx(m.microHeight),hy=dFdy(m.microHeight);
 vec3 n=normal;
 if(nearSettings.render.x>.5)n=nearSurfaceNormal(normal,dx,dy,hx,hy);
 float viewZ=_vs2fs_location6;
 if(viewZ<nearSettings.depth.y||viewZ>nearSettings.depth.z)discard;
 if(nearSettings.render.z>.5&&distance(_vs2fs_location7,_group_0_binding_0_fs.eye)>nearSettings.render.y)discard;
 gl_FragDepth=gl_FragCoord.z;
 if(nearSettings.depth.x>.5)gl_FragDepth=log2(1.+nearSettings.depth.w*max(viewZ,0.))/log2(1.+nearSettings.depth.w*nearSettings.depth.z);
 float debug=_group_0_binding_0_fs.debug;
 if(debug==1.){_fs2p_location0=vec4(m.surface.albedo,m.surface.roughness);return;}
 if(debug==2.){_fs2p_location0=vec4(g.d,m.d,float(m.layer),fp);return;}
 if(debug==3.){_fs2p_location0=vec4(m.microHeight,g.loss,g.thickness,h.baseD);return;}
 if(debug==4.){StationState st=stationMemberState(h,p,raw);_fs2p_location0=vec4(st.age,st.wet,st.repair,st.retained);return;}
 if(debug==5.){_fs2p_location0=vec4(p,fp);return;}
 if(debug==6.){_fs2p_location0=vec4(h.q,h.baseD);return;}
 if(debug==7.){_fs2p_location0=vec4(n,1.);return;}
 vec3 color=nearLighting(m,n,p)*nearSettings.sunExposure.w;
 color=clamp((color*(2.51*color+vec3(.03)))/(color*(2.43*color+vec3(.59))+vec3(.14)),vec3(0.),vec3(1.));
 _fs2p_location0=vec4(pow(max(color,vec3(0.)),vec3(1./2.2)),1.);
}
