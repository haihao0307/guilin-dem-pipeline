import {prepareNearMesh,makeStationParams,makeNearParams,groupDistanceM} from './mesh-contract.mjs';
import {splitTowerBrickFaces} from './split-brick-faces.mjs';
import {createVisibilityDepthTarget,captureNearHostState,restoreNearHostState} from './visibility-depth-target.mjs';
import {visibilityTolerance,visibilityEpsilon,VISIBILITY_EPSILON} from './visibility-entry.mjs';

async function source(url){const r=await fetch(url);if(!r.ok)throw Error(`Near material shader HTTP ${r.status}: ${url}`);return r.text();}
export async function linkNearProgram(gl,vertex,fragment,{timeoutMs=240000}={}){
 const started=performance.now(),program=gl.createProgram(),shaders=[];
 try{
  for(const [type,code] of [[gl.VERTEX_SHADER,vertex],[gl.FRAGMENT_SHADER,fragment]]){const s=gl.createShader(type);shaders.push(s);gl.shaderSource(s,code);gl.compileShader(s);gl.attachShader(program,s);}
  gl.linkProgram(program);const parallel=gl.getExtension('KHR_parallel_shader_compile');
  if(parallel)while(!gl.getProgramParameter(program,parallel.COMPLETION_STATUS_KHR)){if(performance.now()-started>timeoutMs)throw Error('Near material shader compile timeout');await new Promise(r=>setTimeout(r,20));}
  const report={vertexOK:gl.getShaderParameter(shaders[0],gl.COMPILE_STATUS),fragmentOK:gl.getShaderParameter(shaders[1],gl.COMPILE_STATUS),linkOK:gl.getProgramParameter(program,gl.LINK_STATUS),vertexLog:gl.getShaderInfoLog(shaders[0]),fragmentLog:gl.getShaderInfoLog(shaders[1]),linkLog:gl.getProgramInfoLog(program),durationMs:performance.now()-started};
  if(!report.vertexOK||!report.fragmentOK||!report.linkOK)throw Error('Near material shader failed: '+JSON.stringify(report));
  return{program,report};
 }catch(e){gl.deleteProgram(program);throw e;}finally{for(const s of shaders)gl.deleteShader(s);}
}

/** Host owns context, framebuffer, viewport, depth/blend/cull state and scheduling.
 * This renderer owns only its program, VAO, VBOs and two UBOs. No hidden overlay,
 * camera movement, distance-based color fallback or requestAnimationFrame. */
export async function createNearStationRenderer({gl,mesh,vertexSource,fragmentSource,fragmentURL=new URL('./generated/near-material-entry-adapted.frag',import.meta.url),uniformBindings=[6,7],splitBrickFaces=true,enableVisibilityCandidate=false,visibilityFragmentSource,visibilityFragmentURL,visibilityUniformBinding=8,visibilityTextureUnit=15}){
 if(!gl||typeof gl.bindVertexArray!=='function')throw Error('WebGL2 context required');
 if(uniformBindings.length!==2||new Set(uniformBindings).size!==2||uniformBindings.some(i=>!Number.isInteger(i)||i<0||i>=gl.getParameter(gl.MAX_UNIFORM_BUFFER_BINDINGS)))throw Error('Two distinct available host UBO bindings required');
 if(enableVisibilityCandidate&&(!Number.isInteger(visibilityUniformBinding)||visibilityUniformBinding<0||visibilityUniformBinding>=gl.getParameter(gl.MAX_UNIFORM_BUFFER_BINDINGS)||uniformBindings.includes(visibilityUniformBinding)))throw Error('Visibility UBO binding must be available and distinct');
 const partitioned=splitBrickFaces?splitTowerBrickFaces(mesh):mesh,prepared=prepareNearMesh(partitioned);
 vertexSource??=await source(new URL('./near.vert',import.meta.url));fragmentSource??=await source(fragmentURL);
 const {program,report}=await linkNearProgram(gl,vertexSource,fragmentSource),buffers=[],programs=[program];
 let vao,disposed=false,visibleProgram=null,depthTarget=null,toleranceBuffer=null,visibilityCompile=null;
 try{
  vao=gl.createVertexArray();gl.bindVertexArray(vao);
  const buffer=(target,data)=>{const b=gl.createBuffer();buffers.push(b);gl.bindBuffer(target,b);gl.bufferData(target,data,gl.STATIC_DRAW);return b;};
  const attrib=(location,size,stride=0,offset=0)=>{gl.enableVertexAttribArray(location);gl.vertexAttribPointer(location,size,gl.FLOAT,false,stride,offset);};
  buffer(gl.ARRAY_BUFFER,prepared.positions);attrib(0,3);buffer(gl.ARRAY_BUFFER,prepared.normals);attrib(1,3);
  buffer(gl.ARRAY_BUFFER,prepared.packedHits);attrib(2,4,48,0);attrib(3,4,48,16);attrib(4,4,48,32);
  buffer(gl.ARRAY_BUFFER,prepared.geometryDistance);attrib(5,1);buffer(gl.ELEMENT_ARRAY_BUFFER,prepared.indices);
  const uniformBuffers=[];
  for(const [j,prefix] of ['Params_block_','NearParams_block_'].entries()){
   const candidates=Array.from({length:gl.getProgramParameter(program,gl.ACTIVE_UNIFORM_BLOCKS)},(_,i)=>({i,name:gl.getActiveUniformBlockName(program,i)})).filter(x=>x.name.startsWith(prefix));
   if(candidates.length!==1)throw Error('Missing or ambiguous '+prefix+' uniform block');
   const block=candidates[0].i,size=gl.getActiveUniformBlockParameter(program,block,gl.UNIFORM_BLOCK_DATA_SIZE);
   if(size!==80)throw Error(prefix+' must have 80 bytes, received '+size);
   const b=gl.createBuffer();buffers.push(b);uniformBuffers.push(b);gl.bindBuffer(gl.UNIFORM_BUFFER,b);gl.bufferData(gl.UNIFORM_BUFFER,80,gl.DYNAMIC_DRAW);gl.uniformBlockBinding(program,block,uniformBindings[j]);
  }
  const clipLocation=gl.getUniformLocation(program,'stationClipFromLocal'),depthLocation=gl.getUniformLocation(program,'stationDepth');
  if(clipLocation===null||depthLocation===null)throw Error('Near material vertex projection interface missing');
  const locations=new Map([[program,{clip:clipLocation,depth:depthLocation}]]);
  if(enableVisibilityCandidate){
   visibilityFragmentURL??=new URL(String(fragmentURL).includes('-naga.frag')?'./generated/near-material-visible-naga.frag':'./generated/near-material-visible-entry-adapted.frag',import.meta.url);
   visibilityFragmentSource??=await source(visibilityFragmentURL);
   const visible=await linkNearProgram(gl,vertexSource,visibilityFragmentSource);visibleProgram=visible.program;programs.push(visibleProgram);
   const depth=await linkNearProgram(gl,vertexSource,await source(new URL('./visibility-depth.frag',import.meta.url)));programs.push(depth.program);
   visibilityCompile={material:visible.report,depth:depth.report};
   locations.set(visibleProgram,{clip:gl.getUniformLocation(visibleProgram,'stationClipFromLocal'),depth:gl.getUniformLocation(visibleProgram,'stationDepth')});
   if(Object.values(locations.get(visibleProgram)).some(x=>x===null))throw Error('Visible material vertex interface missing');
   for(const [prefix,bytes,binding] of [['Params_block_',80,uniformBindings[0]],['NearParams_block_',80,uniformBindings[1]],['VisibilityParams_block_',16,visibilityUniformBinding]]){
    const blocks=Array.from({length:gl.getProgramParameter(visibleProgram,gl.ACTIVE_UNIFORM_BLOCKS)},(_,i)=>({i,name:gl.getActiveUniformBlockName(visibleProgram,i)})).filter(x=>x.name.startsWith(prefix));
    if(blocks.length!==1||gl.getActiveUniformBlockParameter(visibleProgram,blocks[0].i,gl.UNIFORM_BLOCK_DATA_SIZE)!==bytes)throw Error('Visible material UBO mismatch: '+prefix);
    gl.uniformBlockBinding(visibleProgram,blocks[0].i,binding);
   }
   const sampler=['stationVisibilityDepth','_group_0_binding_2_fs'].map(n=>gl.getUniformLocation(visibleProgram,n)).find(x=>x!==null);
   if(sampler===undefined)throw Error('Visibility depth texture binding missing');
   gl.useProgram(visibleProgram);gl.uniform1i(sampler,visibilityTextureUnit);
   toleranceBuffer=gl.createBuffer();buffers.push(toleranceBuffer);gl.bindBuffer(gl.UNIFORM_BUFFER,toleranceBuffer);gl.bufferData(gl.UNIFORM_BUFFER,16,gl.DYNAMIC_DRAW);
   depthTarget=createVisibilityDepthTarget(gl,{program:depth.program,textureUnit:visibilityTextureUnit});
  }
  function draw(frame){
   if(disposed)throw Error('Near station renderer disposed');if(gl.isContextLost())throw Error('Near station context lost');
   if(frame.clipFromStation?.length!==16||!Array.from(frame.clipFromStation).every(Number.isFinite))throw Error('Host clipFromStation column-major mat4 required');
   const hostState=captureNearHostState(gl,enableVisibilityCandidate?[...uniformBindings,visibilityUniformBinding]:uniformBindings);
   try{
   const params=makeStationParams(frame),near=makeNearParams(frame),frozen={...frame,clipFromStation:new Float32Array(frame.clipFromStation),eye:Array.from(frame.eye)};
   const groups=prepared.groups.filter(g=>groupDistanceM(g,frozen.eye)<=near[17]&&(!frame.includeGroup||frame.includeGroup(g)));
   const requested=!!frame.visibilityPrepass,useVisibility=requested&&!near[16];
   if(useVisibility&&!depthTarget)throw Error('Visibility candidate was not compiled; create renderer with enableVisibilityCandidate:true');
   const extra=frame.visibilityExtraDepthMargin??0,tolerance=visibilityTolerance(extra);
   for(let j=0;j<2;j++){gl.bindBuffer(gl.UNIFORM_BUFFER,uniformBuffers[j]);gl.bindBufferBase(gl.UNIFORM_BUFFER,uniformBindings[j],uniformBuffers[j]);gl.bufferSubData(gl.UNIFORM_BUFFER,0,j?near:params);}
   let prepass=null;
   if(useVisibility){frame.onPhase?.('prepass-begin');prepass=depthTarget.render({frame:frozen,params,near,groups,vao});frame.onPhase?.('prepass-end');gl.bindBuffer(gl.UNIFORM_BUFFER,toleranceBuffer);gl.bindBufferBase(gl.UNIFORM_BUFFER,visibilityUniformBinding,toleranceBuffer);gl.bufferSubData(gl.UNIFORM_BUFFER,0,tolerance);}
   let drawCalls=0,triangles=0;
   const materialDraw=()=>{const selected=useVisibility?visibleProgram:program,l=locations.get(selected);gl.useProgram(selected);gl.bindVertexArray(vao);gl.uniformMatrix4fv(l.clip,false,frozen.clipFromStation);gl.uniform4fv(l.depth,near.subarray(12,16));for(const g of groups){gl.drawElements(gl.TRIANGLES,g.indexCount,gl.UNSIGNED_INT,g.indexStart*4);drawCalls++;triangles+=g.indexCount/3;}};
   frame.onPhase?.('material-begin');if(useVisibility)depthTarget.withTexture(materialDraw);else materialDraw();frame.onPhase?.('material-end');
   return{drawCalls,triangles,eye:[...frozen.eye],nearRadiusM:frame.nearRadiusM===Infinity?Infinity:near[17],fragmentRadiusCut:!!near[18],microNormal:!!near[16],visibility:{mode:useVisibility?'conservative-depth-prepass':requested&&near[16]?'bypass-micro-normal':'disabled',prepassDrawCalls:prepass?.drawCalls??0,prepassTriangles:prepass?.triangles??0,depthEpsilon:useVisibility?visibilityEpsilon(1,1,extra):0,epsilonPolicy:useVisibility?{...VISIBILITY_EPSILON,extraDepthMargin:extra}:null,target:prepass,limitation:'Conservative numerical candidate, not exact visibility proof; external terrain not included; equal/uncertain depths remain.'},geometryMode:'fixed finite sampled mesh; non-unit-field normal projection approximation',materialMode:'original B each fragment',performanceStatus:'not a realtime acceptance measurement'};
   }finally{restoreNearHostState(gl,hostState);}
  }
  function dispose(){if(disposed)return;disposed=true;depthTarget?.dispose();for(const b of buffers)gl.deleteBuffer(b);gl.deleteVertexArray(vao);for(const p of programs)gl.deleteProgram(p);}
  return{draw,dispose,compile:report,visibilityCompile,groups:prepared.groups,brickPartition:partitioned.brickPartition,program,uniformBindings:[...uniformBindings],sourceCommit:'1f46ba78170752a07086caa3e66c87f2fa4c7fcf'};
 }catch(e){depthTarget?.dispose();for(const b of buffers)gl.deleteBuffer(b);if(vao)gl.deleteVertexArray(vao);for(const p of programs)gl.deleteProgram(p);throw e;}
}
