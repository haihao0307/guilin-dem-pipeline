/** Interface generation only; never edits an original mother function. */
export const VISIBILITY_EPSILON=Object.freeze({depthQuantizationSteps:2,floatRoundoffFactor:8,extraDepthMargin:0,depthBits:24,unitFloatEpsilon:2**-23,mathProof:false});
export function visibilityTolerance(extraDepthMargin=0){
 if(!Number.isFinite(extraDepthMargin)||extraDepthMargin<0||extraDepthMargin>1)throw Error('visibilityExtraDepthMargin must be finite in [0,1]');
 return new Float32Array([2/(2**24-1),8*2**-23,extraDepthMargin,0]);
}
export function visibilityEpsilon(candidateDepth,storedDepth,extraDepthMargin=0){const t=visibilityTolerance(extraDepthMargin);return t[0]+t[1]*Math.max(1,Math.abs(candidateDepth),Math.abs(storedDepth))+t[2];}
export function makeVisibilityWGSL(base){
 const cut=base.indexOf('@fragment fn stationNearFragment('),tail=base.indexOf(' // Diagnostic outputs');
 if(cut<0||tail<cut)throw Error('Near WGSL interface markers changed');
 return base.slice(0,cut)+`
// Dedicated microNormal=false entry. No derivatives after any discard.
@group(0)@binding(2)var stationVisibilityDepth:texture_depth_2d;
struct VisibilityParams{tolerance:vec4<f32>}
@group(0)@binding(3)var<uniform>visibilitySettings:VisibilityParams;
@fragment fn stationNearVisibleFragment(input:NearInput)->NearOutput{
 let dx=dpdx(input.p);let dy=dpdy(input.p);
 let fp=max(.00001,max(length(dx),length(dy)));
 if(input.viewZ<nearSettings.depth.y||input.viewZ>nearSettings.depth.z){discard;}
 if(nearSettings.render.z>.5&&distance(input.displayP,u.eye)>nearSettings.render.y){discard;}
 var depth=input.pixel.z;
 if(nearSettings.depth.x>.5){depth=log2(1.+nearSettings.depth.w*max(input.viewZ,0.))/log2(1.+nearSettings.depth.w*nearSettings.depth.z);}
 let stored=textureLoad(stationVisibilityDepth,vec2<i32>(input.pixel.xy),0);
 let tolerance=visibilitySettings.tolerance.x+visibilitySettings.tolerance.y*max(1.,max(abs(depth),abs(stored)))+visibilitySettings.tolerance.z;
 if(depth>stored+tolerance){discard;}
 let normal=normalize(input.normal);let n=normal;
 let h=HitField(input.baseD,u32(input.idSource.x),input.q,input.extentSeed.w,input.baseD,input.extentSeed.xyz,input.idSource.y);
 let raw=resolveStationState(input.p);
 let g=evaluateStationGeometry(h,input.p,raw);
 let m=evaluateStationMatter(h,input.p,normal,fp);
 var out=NearOutput(vec4<f32>(0.),depth);
`+base.slice(tail);
}
export function makeVisibilityGLSL(base){
 const cut=base.indexOf('void main(){'),tail=base.indexOf(' float debug=');
 if(cut<0||tail<cut)throw Error('Near GLSL interface markers changed');
 return base.slice(0,cut)+`
uniform highp sampler2D stationVisibilityDepth;
struct VisibilityParams{vec4 tolerance;};
layout(std140) uniform VisibilityParams_block_2Fragment{VisibilityParams visibilitySettings;};
// Dedicated microNormal=false entry. No derivatives after any discard.
void main(){
 vec3 p=_vs2fs_location0,dx=dFdx(p),dy=dFdy(p);
 float fp=max(.00001,max(length(dx),length(dy)));
 float viewZ=_vs2fs_location6;
 if(viewZ<nearSettings.depth.y||viewZ>nearSettings.depth.z)discard;
 if(nearSettings.render.z>.5&&distance(_vs2fs_location7,_group_0_binding_0_fs.eye)>nearSettings.render.y)discard;
 float depth=gl_FragCoord.z;
 if(nearSettings.depth.x>.5)depth=log2(1.+nearSettings.depth.w*max(viewZ,0.))/log2(1.+nearSettings.depth.w*nearSettings.depth.z);
 float stored=texelFetch(stationVisibilityDepth,ivec2(gl_FragCoord.xy),0).r;
 float tolerance=visibilitySettings.tolerance.x+visibilitySettings.tolerance.y*max(1.,max(abs(depth),abs(stored)))+visibilitySettings.tolerance.z;
 if(depth>stored+tolerance)discard;
 gl_FragDepth=depth;
 vec3 normal=normalize(_vs2fs_location1),n=normal;
 HitField h=HitField(_vs2fs_location5,uint(_vs2fs_location4.x),_vs2fs_location2,_vs2fs_location3.w,_vs2fs_location5,_vs2fs_location3.xyz,_vs2fs_location4.y);
 StationState raw=resolveStationState(p);
 StationGeometry g=evaluateStationGeometry(h,p,raw);
 StationMatter m=evaluateStationMatter(h,p,normal,fp);
`+base.slice(tail);
}
