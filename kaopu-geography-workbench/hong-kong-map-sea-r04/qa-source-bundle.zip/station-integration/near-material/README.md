# Frozen B near-fragment adapter

This is a bounded station-material adapter. It does not replace the map engine,
change the frozen B functions, invent a palette, or add a texture skin.

## What it evaluates

The fragment entry directly calls `evaluateStationGeometry` and
`evaluateStationMatter` from frozen commit
`1f46ba78170752a07086caa3e66c87f2fa4c7fcf`.

- `p`, `q`, the source geometric normal and `baseD` use perspective interpolation.
- `id`, `extent`, `seed` and `sourceSeed` are flat. The CPU rejects incompatible
  triangles rather than interpolating member/material identity.
- `Params.eye` is the live eye in original station-local metres. The old bake eye
  is never used as a runtime substitute.
- Footprint is `max(length(dpdx(p)), length(dpdy(p)), 0.00001)` in source metres.
  This is a pixel-scale input to the unchanged mother. Their existing partial
  filtering is **not** a strict low-pass, area integral, or alias-free guarantee.
- The mesh still renders `p - normal * sampledGeometryDistance`. This is the
  existing finite-mesh normal projection of a non-unit distance field, not an
  exact SDF projection. The new per-fragment distance is diagnostic, not a second
  displacement/depth layer.

The default normal is the existing mesh normal. Optional `microNormal: true`
uses a screen-space surface-gradient estimate of the **same original**
`m.microHeight`. This is not equivalent to original B's four-tap full-station
material-normal reevaluation. It remains off by default and needs same-camera
visual A/B evaluation before enabling.

The original B legacy green-iron material named copper is preserved with its
known chemistry gap. This adapter does not quietly replace it with a different
mother or claim that B already contained a validated copper model.

## Files and build

Run from `station-integration/`:

```sh
node near-material/emit-shaders.mjs
node --test near-material/qa/contract.test.mjs
node near-material/qa/check-full-mesh.mjs
compiler/target/release/kaopu-station-shader-bridge \
  near-material/generated/near-material.wgsl \
  near-material/generated/near-material-naga.frag stationNearFragment
```

The compiler must be the existing locked Naga **27.0.3**. The generated
entry-adapted GLSL retains every byte of the existing pinned Naga reference's
mother prefix. It is provided so the source functions do not need translation
or rewriting. The equivalent WGSL is independently compiled in the host CI;
GPU output comparison is still required.

## Host interface

```js
import {createNearStationRenderer} from './station-integration/near-material/renderer.mjs';
import {stationClipFromMap,mapPointToStation,mapDirectionToStation}
  from './station-integration/near-material/mesh-contract.mjs';

const near = await createNearStationRenderer({
  gl,
  mesh: {positions, normals, packedHits, indices, geometryDistance},
  // Optional: choose the independently Naga-compiled fragment URL after QA.
  // fragmentURL: new URL('./generated/near-material-naga.frag', import.meta.url),
  uniformBindings: [6, 7]
});

near.draw({
  clipFromStation: stationClipFromMap(hostClipFromMap),
  eye: mapPointToStation(hostEye),
  sun: mapDirectionToStation(uSun),
  sunColor: uSunColor,
  day: uDay,
  light: uLight, // [sunlight, skylight, scatter, haze]
  exposure,
  age: 0.58,
  width: gl.drawingBufferWidth,
  height: gl.drawingBufferHeight,
  nearM: 0.05,
  farM: 60000,
  logDepth: true,
  logCoefficient: 1,
  microNormal: false,
  nearRadiusM: 80,
  fragmentRadiusCut: true,
  debug: 0
});
```

The matrix is column-major and must have conventional positive forward `clip.w`
as view depth. The adapter does not choose, move or replace the host camera.
The rigid station/map registration is exactly the existing map adapter, including
its authored datum/orientation limitations. If the host already works in station
coordinates, pass its matrix/eye/directions directly and do not transform twice.

The host owns framebuffer, viewport, depth/blend/cull state and draw scheduling.
The adapter does not start an animation loop. Each draw restores the host's
framebuffer, viewport, depth function/write mask, color mask, clear depth,
depth/cull/blend/scissor enables, active texture, program, VAO, and previous
UBO/range bindings in a `finally` block. The optional private prepass temporarily
uses `LESS` and depth writes, restoring those states before the material pass.

All surface passes sharing depth must use the same host near/far and log mapping:

`log2(1 + C * viewZ) / log2(1 + C * farM)`.

With `C = 1`, `farM = 60000`, this is the requested host mapping. Both the
vertex clip depth and fragment depth use it. The fragment clips below the
host near plane or above its far plane. With `logDepth:false`, original matrix
depth is retained. Do not mix this log-depth pass with a linear-depth map pass.

The host chooses how to retain far-distance display. `nearRadiusM` is both a CPU
group-AABB culling threshold and, by default, a per-fragment spherical cut.
The new smooth location-7 `displayP` varying contains exactly the final vertex
position `p - normal * sampledGeometryDistance`, in station coordinates. Near
fragments survive when `distance(displayP, liveEye) <= nearRadiusM`; the source
material sampling p is not used to decide the cut. Since station/map registration
is rigid, the host far pass uses the equivalent final displayed world position
and retains `distance(displayWorld, worldEye) >= nearRadiusM`. Each pass can use
depth `LESS`; no same-surface `LEQUAL` overlay is required. Use the same radius,
eye and final finite-mesh projection on both sides of that partition.

`fragmentRadiusCut:false` explicitly disables only the fragment cut, retaining
CPU group filtering. `nearRadiusM:Infinity` disables both radius restrictions;
the implementation transmits a finite Float32 maximum radius and a disabled-cut
flag, never an Infinity uniform. There is no automatic color blend/fade.

Groups are binned by original material ID and 16 m triangle-centroid cell;
their actual AABBs cover both source and projected positions. Large triangles
may cross many metres and remain in the pass when their bounds overlap the
near region, with individual far fragments then discarded by the spherical cut.
No vertex-color fallback is hidden inside this adapter.

The shader consumes host sun direction, sun color, daylight, sunlight/skylight
and exposure; then uses GGX and approximate hemispheric ambient with ACES-fit
and gamma output. This is host-layer illumination, not a material rewrite.
The `scatter`/`haze` values are accepted for a stable host interface but **not
applied** in this near station pass. There is no all-station shadow/AO/GI query.
Do not treat lighting as equivalent to the original complete B renderer.

## Brick ownership at corners and octagonal faces

`splitTowerBrickFaces` only considers B tower brick (`seed == 71`, IDs 1/12).
Its authority is the exact B field predicate:

`abs(tq.x) > abs(tq.z) ? 12 : 1`.

It partitions only when needed using the two linear planes `q.x-q.z=0` and
`q.x+q.z=0`, retaining a flat one-sided identity on each resulting triangle.
Checking only three vertex IDs is insufficient: a triangle's interior can
cross a source material partition while all endpoints have the same ID.

On the current 508,240-triangle export:

- 348 triangles had mixed endpoint IDs.
- 16 further triangles had constant endpoint IDs and interior crossings.
- 248 triangles only required one-sided edge identity.
- 116 required actual partitioning.
- Result: 508,420 triangles and 1,632 added vertices; no zero-area output.
- Original source/batch buffers are not mutated.

Added attributes interpolate the **existing finite mesh**. Interpolating
`geometryDistance` at a new intersection is not a new mother evaluation or an
exact full-domain displacement solve. The full CPU check verifies all output
flat metadata, interior identity samples, surface area, and unchanged bounds.
Other material/member ownership mismatches still fail explicitly.

## Verification and limits

`qa/contract.test.mjs`: source hashes, exact closure/prefix, vertex/fragment
interface, flat metadata negative tests, 1.6 m live-eye transform, log depth,
single-sided corner ties, true octagonal crossings, and constant-endpoint
interior crossings.

`qa/check-full-mesh.mjs`: final exported mesh identity/area/bounds regression.
The CPU identity test can use an explicitly labelled zero displacement if a
bake output is absent. **Runtime never substitutes zero displacement** and
requires the real `geometryDistance` array.

`qa/probe.html?naga=1`: small RGBA32F diagnostic atlas. It renders interpolated
p/q/baseD and derivative footprint, reads these actual inputs back, and compares
the near fragment outputs with the original material query at the same inputs,
two live eyes and three ages. Four interior pixels are checked per fixture.
Wait for `window.DONE`, then read `window.RESULT`. The original
`generated/material-query-naga.frag` must also exist. Without `?naga=1`, both
entry-adapted paths are tested instead. This atlas is **not** normal-perspective
scene acceptance or a frame-time measurement.

Debug modes:

1. Linear albedo RGB, roughness
2. Geometry distance, matter distance, layer, footprint
3. Microheight, loss, coating thickness, baseD
4. Age, wetness, repair, retained
5. Source p XYZ, footprint
6. Source q XYZ, baseD
7. Used normal XYZ, one

Host CI must still compile/link, run the numeric GPU regression and inspect
normal-perspective near views at the requested 1.6 m eye height. No local shader
compiler/GPU scene acceptance or realtime/final-art result is claimed here.

## Optional same-frame conservative visibility candidate

This candidate is **off by default**. It is an optimization of which fragments
evaluate the original material, not a replacement renderer, color fallback,
material approximation, or geometry reduction. It has not received local GPU
acceptance; use the A/B tests below before enabling it for a delivery.

```js
const near = await createNearStationRenderer({
  gl, mesh,
  fragmentURL: new URL('./generated/near-material-naga.frag', import.meta.url),
  enableVisibilityCandidate: true,
  visibilityFragmentURL: new URL('./generated/near-material-visible-naga.frag', import.meta.url),
  visibilityUniformBinding: 8,
  visibilityTextureUnit: 15
});
near.draw({...frame, microNormal:false, visibilityPrepass:true});
// Exact same frame inputs and renderer, baseline:
near.draw({...frame, microNormal:false, visibilityPrepass:false});
```

Compile the additional material entry with the existing pinned compiler:

```sh
compiler/target/release/kaopu-station-shader-bridge \
  near-material/generated/near-material-visible.wgsl \
  near-material/generated/near-material-visible-naga.frag stationNearVisibleFragment
node --test near-material/qa/*.test.mjs
```

The prepass renders the same selected group list, same vertex source (including
`invariant gl_Position`), same finite displaced geometry, and a frozen copy of
that frame's camera matrix. It uses the same near/far/radius rules and logarithmic
depth expression. Only a private `DEPTH_COMPONENT24` target is written; it is
cleared every call. No previous-frame or historical visibility is reused.

The host framebuffer is rebound before the material pass samples the finished
prepass texture. Normal GL command ordering orders those operations; no
`gl.finish` stall is inserted. Reading a depth texture while it is attached to
the active draw framebuffer is explicitly rejected. External terrain is not
included in this depth target, which can cause extra work rather than remove a
visible station surface.

In the dedicated `stationNearVisibleFragment` entry, `dpdx(p)` and `dpdy(p)` are
computed unconditionally **before any discard**, preserving the primitive's
footprint/helper context. Cheap near/radius/depth checks then run before the
unchanged mothers. The source-locked mother closure contains no derivative,
texture-sampling or discard operation. The candidate therefore introduces no
derivative into non-uniform control flow. `microNormal:true` always uses the
original full derivative path and reports `bypass-micro-normal`; its material
microheight derivatives are never evaluated after visibility rejection.

A fragment is rejected only when candidate depth is greater than the stored
nearest depth plus:

`2 / (2^24 - 1) + 8 * 2^-23 * max(1, abs(candidate), abs(stored)) + extraMargin`.

The default is approximately `1.073e-6` normalized depth. The first term allows
D24 storage quantization; the second is a conservative unit-range Float32
roundoff allowance. `visibilityExtraDepthMargin` can add a finite value in
`[0,1]`; it cannot decrease these allowances. This is a **numerical policy, not
a mathematical proof** bounding every driver's log/transform implementation.
GPU A/B coverage tests must confirm no false rejection on the tested backend.
Equal, nearly coplanar, and uncertain-depth fragments remain and may evaluate
the mother more than once. Do not describe this as a unique-visible-pixel or
perfect occlusion solution.

The candidate currently requires an origin-zero full viewport, single-sample
rendering, depth range `[0,1]`, opaque `LESS` rendering with depth writes enabled,
and no stencil, polygon offset, or rasterizer discard. Unsupported states fail
explicitly. The depth texture uses `NEAREST`, `COMPARE_MODE=NONE`, and integer
pixel `texelFetch`, with no filtering across silhouettes. Its reserved unit must
be `>=8` and below `MAX_TEXTURE_IMAGE_UNITS`; host texture/sampler units 0–7 are
never changed. The reserved unit's previous texture and sampler are restored.
One D24 target costs approximately four bytes per pixel, backend-dependent.

The return value's `visibility` record includes mode, actual prepass group and
triangle counts, dimensions, format, epsilon and limitations. `onPhase` may be a
read-only timing callback receiving `prepass-begin`, `prepass-end`,
`material-begin`, and `material-end`. It must not mutate GL state or input data.
CPU dispatch duration is not GPU time. GPU timer queries are valid only when
supported and non-disjoint; otherwise label fence/readback completion elapsed
time as wall-clock time, never hardware FPS.

The small test entry is `qa/visibility-probe.html?naga=1` (128×72 synthetic
occlusion cases using the real original materials). The optional
`?naga=1&scene=1` interface uses a 256×144 real-station single-camera comparison.
It is intentionally separate from the full map suite and never automatically
expands to a large screenshot render. Both publish `window.DONE/RESULT`.
