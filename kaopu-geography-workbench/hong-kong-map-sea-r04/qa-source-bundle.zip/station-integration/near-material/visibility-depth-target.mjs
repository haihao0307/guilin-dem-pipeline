/** Private same-frame depth target. No textures are sampled while attached to
 * the active draw framebuffer. GL command ordering supplies write/read ordering;
 * this helper does not gl.finish(), cache visibility, or infer hidden geometry. */
export function createVisibilityDepthTarget(gl,{program,textureUnit}){
 let texture=null,framebuffer=null,width=0,height=0,disposed=false;
 const locations=Object.fromEntries(['stationClipFromLocal','stationDepth','visibilityEye','visibilityRadiusCut'].map(n=>[n,gl.getUniformLocation(program,n)]));
 if(Object.values(locations).some(x=>x===null))throw Error('Visibility depth shader interface incomplete');
 if(!Number.isInteger(textureUnit)||textureUnit<8||textureUnit>=gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS))throw Error('Visibility texture unit must be available and outside host units 0..7');
 function ensure(w,h){
  if(texture&&width===w&&height===h)return;
  const max=gl.getParameter(gl.MAX_TEXTURE_SIZE);
  if(!Number.isInteger(w)||!Number.isInteger(h)||w<=0||h<=0||w>max||h>max)throw Error('Visibility depth target dimensions invalid');
  const active=gl.getParameter(gl.ACTIVE_TEXTURE),draw=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING);gl.activeTexture(gl.TEXTURE0+textureUnit);const bound=gl.getParameter(gl.TEXTURE_BINDING_2D);
  try{
   if(texture)gl.deleteTexture(texture);if(framebuffer)gl.deleteFramebuffer(framebuffer);
   texture=gl.createTexture();framebuffer=gl.createFramebuffer();width=w;height=h;
   gl.bindTexture(gl.TEXTURE_2D,texture);
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_COMPARE_MODE,gl.NONE);
   gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,w,h,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);
   gl.bindFramebuffer(gl.FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,texture,0);
   gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);
   if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Visibility depth-only framebuffer incomplete');
  }finally{gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,read);gl.bindTexture(gl.TEXTURE_2D,bound);gl.activeTexture(active);}
 }
 function render({frame,params,near,groups,vao}){
  if(disposed)throw Error('Visibility depth target disposed');
  const viewport=gl.getParameter(gl.VIEWPORT),range=gl.getParameter(gl.DEPTH_RANGE);
  if(viewport[0]!==0||viewport[1]!==0||viewport[2]!==frame.width||viewport[3]!==frame.height)throw Error('Visibility candidate requires a full origin-zero viewport matching frame dimensions');
  if(range[0]!==0||range[1]!==1||gl.getParameter(gl.SAMPLES)!==0||gl.isEnabled(gl.STENCIL_TEST)||gl.isEnabled(gl.POLYGON_OFFSET_FILL)||gl.isEnabled(gl.RASTERIZER_DISCARD))throw Error('Visibility candidate supports single-sample, depth range [0,1], no stencil/polygon-offset/rasterizer-discard');
  if(!gl.isEnabled(gl.DEPTH_TEST)||gl.getParameter(gl.DEPTH_FUNC)!==gl.LESS||!gl.getParameter(gl.DEPTH_WRITEMASK)||gl.isEnabled(gl.BLEND))throw Error('Visibility candidate requires opaque depth-tested LESS rendering with depth writes enabled');
  ensure(frame.width,frame.height);
  const old={draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),color:gl.getParameter(gl.COLOR_WRITEMASK),depthMask:gl.getParameter(gl.DEPTH_WRITEMASK),depthFunc:gl.getParameter(gl.DEPTH_FUNC),clear:gl.getParameter(gl.DEPTH_CLEAR_VALUE),test:gl.isEnabled(gl.DEPTH_TEST),scissor:gl.isEnabled(gl.SCISSOR_TEST),program:gl.getParameter(gl.CURRENT_PROGRAM),vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING)};
  if(old.draw===framebuffer)throw Error('Visibility depth framebuffer must not be the host target');
  try{
   gl.bindFramebuffer(gl.FRAMEBUFFER,framebuffer);gl.viewport(0,0,width,height);gl.colorMask(false,false,false,false);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.depthFunc(gl.LESS);
   gl.disable(gl.SCISSOR_TEST);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);if(old.scissor)gl.enable(gl.SCISSOR_TEST);
   gl.useProgram(program);gl.bindVertexArray(vao);gl.uniformMatrix4fv(locations.stationClipFromLocal,false,frame.clipFromStation);gl.uniform4fv(locations.stationDepth,near.subarray(12,16));gl.uniform3fv(locations.visibilityEye,params.subarray(0,3));gl.uniform2f(locations.visibilityRadiusCut,near[17],near[18]);
   for(const g of groups)gl.drawElements(gl.TRIANGLES,g.indexCount,gl.UNSIGNED_INT,g.indexStart*4);
  }finally{
   gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,old.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,old.read);gl.viewport(...viewport);gl.colorMask(...old.color);gl.depthMask(old.depthMask);gl.depthFunc(old.depthFunc);gl.clearDepth(old.clear);
   if(old.test)gl.enable(gl.DEPTH_TEST);else gl.disable(gl.DEPTH_TEST);if(old.scissor)gl.enable(gl.SCISSOR_TEST);else gl.disable(gl.SCISSOR_TEST);gl.useProgram(old.program);gl.bindVertexArray(old.vao);
  }
  return{width,height,depthFormat:'DEPTH_COMPONENT24',drawCalls:groups.length,triangles:groups.reduce((n,g)=>n+g.indexCount/3,0),externalOccludersIncluded:false,sameFrame:true};
 }
 function withTexture(fn){
  if(!texture||disposed)throw Error('Visibility depth must be rendered in this frame before sampling');
  if(gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING)===framebuffer)throw Error('Visibility texture feedback denied');
  const active=gl.getParameter(gl.ACTIVE_TEXTURE);gl.activeTexture(gl.TEXTURE0+textureUnit);
  const bound=gl.getParameter(gl.TEXTURE_BINDING_2D),sampler=gl.getParameter(gl.SAMPLER_BINDING);
  try{gl.bindTexture(gl.TEXTURE_2D,texture);gl.bindSampler(textureUnit,null);return fn();}
  finally{gl.bindTexture(gl.TEXTURE_2D,bound);gl.bindSampler(textureUnit,sampler);gl.activeTexture(active);}
 }
 function dispose(){if(disposed)return;disposed=true;if(texture)gl.deleteTexture(texture);if(framebuffer)gl.deleteFramebuffer(framebuffer);texture=null;framebuffer=null;}
 return{render,withTexture,dispose};
}

/** A draw is a guest in the map context, including on a thrown error. */
export function captureNearHostState(gl,bindings){
 const enabled=[gl.DEPTH_TEST,gl.CULL_FACE,gl.BLEND,gl.SCISSOR_TEST].map(cap=>[cap,gl.isEnabled(cap)]);
 return{draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),viewport:gl.getParameter(gl.VIEWPORT),depthFunc:gl.getParameter(gl.DEPTH_FUNC),depthMask:gl.getParameter(gl.DEPTH_WRITEMASK),colorMask:gl.getParameter(gl.COLOR_WRITEMASK),clearDepth:gl.getParameter(gl.DEPTH_CLEAR_VALUE),active:gl.getParameter(gl.ACTIVE_TEXTURE),program:gl.getParameter(gl.CURRENT_PROGRAM),vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING),ubo:gl.getParameter(gl.UNIFORM_BUFFER_BINDING),enabled,bases:bindings.map(i=>({i,buffer:gl.getIndexedParameter(gl.UNIFORM_BUFFER_BINDING,i),start:gl.getIndexedParameter(gl.UNIFORM_BUFFER_START,i),size:gl.getIndexedParameter(gl.UNIFORM_BUFFER_SIZE,i)}))};
}
export function restoreNearHostState(gl,s){
 gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,s.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,s.read);gl.viewport(...s.viewport);gl.depthFunc(s.depthFunc);gl.depthMask(s.depthMask);gl.colorMask(...s.colorMask);gl.clearDepth(s.clearDepth);
 for(const [cap,enabled] of s.enabled){if(enabled)gl.enable(cap);else gl.disable(cap);}
 gl.activeTexture(s.active);gl.useProgram(s.program);gl.bindVertexArray(s.vao);
 for(const b of s.bases){if(b.buffer&&b.size>0)gl.bindBufferRange(gl.UNIFORM_BUFFER,b.i,b.buffer,b.start,b.size);else gl.bindBufferBase(gl.UNIFORM_BUFFER,b.i,b.buffer);}
 gl.bindBuffer(gl.UNIFORM_BUFFER,s.ubo);
}
