import {inspectHit,hitFromPacked} from '../material-sampler.mjs';

export const STATION_ANCHOR=Object.freeze({map:[1477.171,3.90,9824.015],station:[24,0,4]});
export function mapPointToStation([x,y,z]){return[z-9824.015+24,y-3.90,4-(x-1477.171)];}
export function stationPointToMap([x,y,z]){return[1477.171-(z-4),3.90+y,9824.015+(x-24)];}
export function mapDirectionToStation([x,y,z]){return[z,y,-x];}
export function stationDirectionToMap([x,y,z]){return[-z,y,x];}
// Column-major rigid transform: station local -> map world. No new registration.
export const STATION_TO_MAP_MATRIX=Object.freeze([0,0,1,0,0,1,0,0,-1,0,0,0,1481.171,3.90,9800.015,1]);
export function multiplyMat4(a,b){
 if(a.length!==16||b.length!==16)throw Error('Two column-major mat4 values required');
 const o=new Float32Array(16);
 for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)o[c*4+r]+=a[k*4+r]*b[c*4+k];
 return o;
}
export function stationClipFromMap(clipFromMap){return multiplyMat4(clipFromMap,STATION_TO_MAP_MATRIX);}
const FLAT_FIELDS=[3,4,5,6,7,9];
const finite=(x,n,name)=>{if(!(x instanceof Float32Array)||x.length!==n||!x.every(Number.isFinite))throw Error(`${name} requires ${n} finite Float32 values`);};

/** Fail closed: no material averaged across an ownership boundary. */
export function prepareNearMesh({positions,normals,packedHits,indices,geometryDistance,cellM=16}){
 if(!(positions instanceof Float32Array)||positions.length%3)throw Error('positions requires Float32Array(N*3)');
 const count=positions.length/3;
 finite(positions,count*3,'positions');finite(normals,count*3,'normals');finite(packedHits,count*12,'packedHits');finite(geometryDistance,count,'geometryDistance');
 if(!(indices instanceof Uint32Array)||indices.length%3||indices.some(i=>i>=count))throw Error('indices requires Uint32Array valid triangles');
 if(!Number.isFinite(cellM)||cellM<=0)throw Error('cellM must be positive');
 for(let i=0;i<count;i++){
  const flags=inspectHit(positions.subarray(i*3,i*3+3),normals.subarray(i*3,i*3+3),hitFromPacked(packedHits,i),0);
  if(flags)throw Error(`Invalid near-mesh vertex ${i}, flags ${flags}`);
 }
 const grouped=new Map();
 for(let t=0;t<indices.length;t+=3){
  const a=indices[t],b=indices[t+1],c=indices[t+2];
  for(const field of FLAT_FIELDS){
   if(packedHits[a*12+field]!==packedHits[b*12+field]||packedHits[a*12+field]!==packedHits[c*12+field]){
    throw Error(`Near material triangle ${t/3} crosses flat HitField ownership at field ${field}; split/re-resolve this source member before rasterization`);
   }
  }
  const center=[0,1,2].map(k=>(positions[a*3+k]+positions[b*3+k]+positions[c*3+k])/3);
  const id=packedHits[a*12+3],key=id+':'+center.map(x=>Math.floor(x/cellM)).join(',');
  let g=grouped.get(key);
  if(!g){g={key,materialId:id,indexList:[],min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]};grouped.set(key,g);}
  g.indexList.push(a,b,c);
  for(const v of[a,b,c])for(let k=0;k<3;k++){
   // Bounds cover source and displaced geometry; no fixed displacement bound.
   const p=positions[v*3+k],shift=p-normals[v*3+k]*geometryDistance[v];
   g.min[k]=Math.min(g.min[k],p,shift);g.max[k]=Math.max(g.max[k],p,shift);
  }
 }
 const sortedIndices=new Uint32Array(indices.length),groups=[];let offset=0;
 for(const g of grouped.values()){
  sortedIndices.set(g.indexList,offset);groups.push({key:g.key,materialId:g.materialId,indexStart:offset,indexCount:g.indexList.length,min:g.min,max:g.max});offset+=g.indexList.length;
 }
 return{positions,normals,packedHits,indices:sortedIndices,geometryDistance,groups,vertexCount:count,triangleCount:indices.length/3,cellM};
}
export function groupDistanceM(group,eye){return Math.hypot(...eye.map((v,k)=>Math.max(group.min[k]-v,0,v-group.max[k])));}
export function logDepth(viewZ,farM=60000,coefficient=1){return Math.log2(1+coefficient*Math.max(viewZ,0))/Math.log2(1+coefficient*farM);}

export function makeStationParams({eye,age=.58,width,height,debug=0}){
 if(eye?.length!==3||!eye.every(Number.isFinite)||age<0||age>1||!Number.isFinite(age)||!Number.isFinite(debug)||!Number.isFinite(width)||!Number.isFinite(height)||width<=0||height<=0)throw Error('Invalid live station Params');
 return new Float32Array([...eye,age,0,0,-1,.43,1,0,0,width/height,0,1,0,debug,width,height,0,0]);
}
export function makeNearParams({sun,exposure=1,sunColor,day,light,logDepth:useLog=true,nearM=.05,farM=60000,logCoefficient=1,microNormal=false,nearRadiusM=80,fragmentRadiusCut=true}){
 if(sun?.length!==3||sunColor?.length!==3||light?.length!==4||![...sun,...sunColor,...light,exposure,day,nearM,farM,logCoefficient].every(Number.isFinite)||!(Number.isFinite(nearRadiusM)||nearRadiusM===Infinity)||Math.hypot(...sun)<1e-8||nearM<=0||farM<=nearM||logCoefficient<=0||nearRadiusM<=0)throw Error('Host sun/color/day/light and valid depth settings required');
 // Infinity explicitly disables both practical CPU radius culling and the
 // fragment cut; do not transmit Infinity as a uniform value.
 const unbounded=nearRadiusM===Infinity;
 return new Float32Array([...sun,exposure,...sunColor,day,...light,useLog?1:0,nearM,farM,logCoefficient,microNormal?1:0,Math.min(nearRadiusM,3.4028234663852886e38),!unbounded&&fragmentRadiusCut?1:0,0]);
}
