/** Interface-only adaptation. Frozen B functions are never edited. */
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {WGSL} from '../frozen-B/receiver.mjs';
import {extraction} from '../shader-closure.mjs';
import {makeVisibilityWGSL,makeVisibilityGLSL,VISIBILITY_EPSILON} from './visibility-entry.mjs';

const read=p=>fs.readFileSync(new URL(p,import.meta.url),'utf8');
const write=(p,s)=>fs.writeFileSync(new URL(p,import.meta.url),s);
const sha=s=>createHash('sha256').update(s).digest('hex');
const roots=['evaluateStationGeometry','evaluateStationMatter','stationMemberState','stationBrickSample'];
const source=extraction(WGSL),reference=extraction(read('../qa/reference/probe.wgsl'));
const closure=source.closure(roots);
if(source.header!==reference.header||closure!==reference.closure(roots))throw Error('Frozen B closure mismatch');
const referenceGLSL=read('../qa/reference/probe.frag');
const prefix=referenceGLSL.slice(0,referenceGLSL.lastIndexOf('void main() {'));
if(!prefix)throw Error('Pinned reference fragment entry missing');
const fragmentWGSL=source.header+closure+'\n'+read('./near-entry.wgsl');
const fragmentGLSL=prefix+'\n'+read('./near-entry.glsl');
fs.mkdirSync(new URL('./generated/',import.meta.url),{recursive:true});
write('./generated/near-material.wgsl',fragmentWGSL);
write('./generated/near-material-entry-adapted.frag',fragmentGLSL);
const visibilityWGSL=source.header+closure+'\n'+makeVisibilityWGSL(read('./near-entry.wgsl'));
const visibilityGLSL=prefix+'\n'+makeVisibilityGLSL(read('./near-entry.glsl'));
write('./generated/near-material-visible.wgsl',visibilityWGSL);
write('./generated/near-material-visible-entry-adapted.frag',visibilityGLSL);
const manifest={
 schema:'kaopu.station-near-fragment/1',sourceCommit:'1f46ba78170752a07086caa3e66c87f2fa4c7fcf',
 roots,closureSha256:sha(closure),frozenGlslPrefixSha256:sha(prefix),frozenGlslPrefixBytes:Buffer.byteLength(prefix),
 fragmentWgslSha256:sha(fragmentWGSL),fragmentGlslSha256:sha(fragmentGLSL),
 visibilityCandidate:{defaultEnabled:false,entry:'stationNearVisibleFragment',wgslSha256:sha(visibilityWGSL),glslSha256:sha(visibilityGLSL),microNormalAllowed:false,epsilon:VISIBILITY_EPSILON,proof:'Conservative numerical policy, not a mathematical exact-visibility proof; GPU A/B acceptance required',depth:'Same-frame own DEPTH_COMPONENT24 texture; no read/write feedback; external occluders omitted conservatively',derivativeContract:'p derivatives computed before any discard; mother closure contains no derivative, texture or discard operations'},
 interface:{entry:'stationNearFragment',vertex:'near.vert',attributes:['source p.xyz','source normal.xyz','q.xyz, id','extent.xyz, seed','baseD, sourceSeed, reserved, reserved','sampled geometryDistance'],smooth:['p','normal','q','baseD','clip w','displayP = p - normal * sampledGeometryDistance'],flat:['id','seed','sourceSeed','extent'],uniformBlocks:{Params:80,NearParams:80}},
 validation:{cpu:'Run qa/contract.test.mjs',naga:'Pending host CI: Naga 27.0.3, exact Cargo.lock',gpu:'Pending host CI: near-material/qa/probe.html; no realtime claim'},
 semantics:{eye:'Live camera converted to original station-local metres; never the bake camera',footprint:'max(length(dpdx(source p)),length(dpdy(source p)),1e-5 metres). Original mother input; not a strict low-pass or physical pixel integral.',geometry:'Finite mesh displaced by sampled B geometry distance along mesh normal. Approximate projection of a non-unit distance field; per-fragment geometry is evaluated but not applied a second time.',normal:'Default original mesh normal. Optional microHeight screen-space surface gradient is an approximation, not original B four-tap full-station normal.',shading:'Host-controlled sun direction/color, daylight, sunlight/skylight and exposure. GGX + approximate hemispheric ambient, ACES + gamma; no all-scene shadows/AO/GI. Near haze/scatter not applied.',depth:'Host clip-from-station matrix. Optional log2(1+C*viewZ)/log2(1+C*farM), default C=1; explicit host near/far fragment clipping.',identity:'No replacement material colors, textures or material kernels. Nine-mother identity remains as source-locked; B legacy green-iron/copper gap remains.'}
};
write('./generated/manifest.json',JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({status:'emitted',wgslBytes:Buffer.byteLength(fragmentWGSL),glslBytes:Buffer.byteLength(fragmentGLSL),motherPrefixBytes:Buffer.byteLength(prefix)}));
