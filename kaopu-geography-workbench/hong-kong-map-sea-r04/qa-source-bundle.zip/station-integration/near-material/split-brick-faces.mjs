/** Raster-only ownership partition of frozen B tower brick.
 * Frozen station-field.mjs: select(1u,12u,abs(tq.x)>abs(tq.z)).
 * Original export/batch buffers are not mutated. Added vertices linearly
 * interpolate the finite mesh, including its sampled geometry displacement.
 * This is not a new evaluation or exact projection of the original field. */
const side=(v,plane)=>v.h[0]+(plane===0?-v.h[2]:v.h[2]);
const idAt=q=>Math.abs(q[0])>Math.abs(q[2])?12:1;
const mix=(a,b,t)=>a.map((v,k)=>v+(b[k]-v)*t);
const interpolate=(a,b,t)=>({p:mix(a.p,b.p,t),n:mix(a.n,b.n,t),h:mix(a.h,b.h,t),d:a.d+(b.d-a.d)*t});
const area=(a,b,c)=>{const x=b.p.map((v,k)=>v-a.p[k]),y=c.p.map((v,k)=>v-a.p[k]);return Math.hypot(x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0])*.5;};
const centroid=poly=>[0,1,2].map(k=>poly.reduce((s,v)=>s+v.h[k],0)/poly.length);
function clip(poly,plane,sign){
 const out=[];
 for(let i=0;i<poly.length;i++){
  const a=poly[i],b=poly[(i+1)%poly.length],da=side(a,plane)*sign,db=side(b,plane)*sign;
  if(da>=0)out.push(a);
  if((da<0&&db>0)||(da>0&&db<0))out.push(interpolate(a,b,da/(da-db)));
 }
 return out;
}
function regions(triangle){
 let polygons=[triangle];
 for(let plane=0;plane<2;plane++){
  const next=[];
  for(const poly of polygons){const s=poly.map(v=>side(v,plane));if(s.some(x=>x<0)&&s.some(x=>x>0)){next.push(clip(poly,plane,1),clip(poly,plane,-1));}else next.push(poly);}
  polygons=next;
 }
 return polygons;
}
const extend=(original,extra)=>{const out=new Float32Array(original.length+extra.length);out.set(original);out.set(extra,original.length);return out;};
export function splitTowerBrickFaces(mesh){
 const {positions:p,normals:n,packedHits:h,geometryDistance:d,indices}=mesh;
 if(!(p instanceof Float32Array)||!(n instanceof Float32Array)||!(h instanceof Float32Array)||!(d instanceof Float32Array)||!(indices instanceof Uint32Array)||p.length%3||n.length!==p.length||h.length!==p.length*4||d.length!==p.length/3||indices.length%3)throw Error('Invalid source mesh for brick-face partition');
 const addedP=[],addedN=[],addedH=[],addedD=[],outI=[],count=p.length/3;
 const report={sourceTriangles:indices.length/3,towerBrickTriangles:0,sourceMixedIdTriangles:0,changedTriangles:0,interiorOnlyChanges:0,splitTriangles:0,faceOnlyReassignments:0,discardedZeroAreaTriangles:0,addedVertices:0,sourceChangedAreaM2:0,resultChangedAreaM2:0,sourceBuffersMutated:false,rule:'B seed71 tower-brick id = abs(q.x)>abs(q.z) ? 12 : 1',interpolation:'p/q/baseD/normal and sampled geometryDistance linearly interpolated on finite mesh; no new analytic field solve'};
 for(let t=0;t<indices.length;t+=3){
  const vi=[indices[t],indices[t+1],indices[t+2]];
  if(!vi.every(i=>h[i*12+7]===71&&(h[i*12+3]===1||h[i*12+3]===12))){outI.push(...vi);continue;}
  report.towerBrickTriangles++;
  const triangle=vi.map(i=>({p:Array.from(p.subarray(i*3,i*3+3)),n:Array.from(n.subarray(i*3,i*3+3)),h:Array.from(h.subarray(i*12,i*12+12)),d:d[i]}));
  const originalIds=triangle.map(v=>v.h[3]),mixed=!originalIds.every(id=>id===originalIds[0]);if(mixed)report.sourceMixedIdTriangles++;
  const polygons=regions(triangle),ids=polygons.map(poly=>idAt(centroid(poly))),oneId=ids.every(id=>id===ids[0]);
  if(oneId&&!mixed&&originalIds[0]===ids[0]){outI.push(...vi);continue;}
  report.changedTriangles++;if(!mixed)report.interiorOnlyChanges++;
  report.sourceChangedAreaM2+=area(...triangle);
  const pieces=oneId?[triangle]:polygons;if(oneId)report.faceOnlyReassignments++;else report.splitTriangles++;
  for(let k=0;k<pieces.length;k++){
   const poly=pieces[k],id=oneId?ids[0]:ids[k];
   for(let j=1;j<poly.length-1;j++){
    const tri=[poly[0],poly[j],poly[j+1]],a=area(...tri);if(a<1e-14){report.discardedZeroAreaTriangles++;continue;}report.resultChangedAreaM2+=a;
    for(const v of tri){outI.push(count+addedD.length);addedP.push(...v.p);addedN.push(...v.n);const hit=[...v.h];hit[3]=id;addedH.push(...hit);addedD.push(v.d);}
   }
  }
 }
 report.addedVertices=addedD.length;report.resultTriangles=outI.length/3;report.areaErrorM2=Math.abs(report.sourceChangedAreaM2-report.resultChangedAreaM2);
 return{...mesh,positions:extend(p,addedP),normals:extend(n,addedN),packedHits:extend(h,addedH),geometryDistance:extend(d,addedD),indices:new Uint32Array(outI),brickPartition:report};
}
