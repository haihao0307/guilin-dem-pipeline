#version 300 es
precision highp float;
precision highp int;
invariant gl_Position;
layout(location=0) in vec3 stationPosition;
layout(location=1) in vec3 stationNormal;
layout(location=2) in vec4 stationQId;
layout(location=3) in vec4 stationExtentSeed;
layout(location=4) in vec4 stationBaseSource;
layout(location=5) in float stationGeometryDistance;
uniform mat4 stationClipFromLocal;
// [logEnabled, nearM, farM, C]. Must equal host terrain/sea depth settings.
uniform vec4 stationDepth;
out vec3 _vs2fs_location0;
out vec3 _vs2fs_location1;
out vec3 _vs2fs_location2;
flat out vec4 _vs2fs_location3;
flat out vec2 _vs2fs_location4;
out float _vs2fs_location5;
out float _vs2fs_location6;
out vec3 _vs2fs_location7;
void main(){
 _vs2fs_location0=stationPosition;
 _vs2fs_location1=stationNormal;
 _vs2fs_location2=stationQId.xyz;
 _vs2fs_location3=stationExtentSeed;
 _vs2fs_location4=vec2(stationQId.w,stationBaseSource.y);
 _vs2fs_location5=stationBaseSource.x;
 // Same finite mesh projection as the map baker. Not an exact SDF solve.
 vec3 projected=stationPosition-stationNormal*stationGeometryDistance;
 _vs2fs_location7=projected;
 gl_Position=stationClipFromLocal*vec4(projected,1.);
 _vs2fs_location6=gl_Position.w;
 if(stationDepth.x>.5){
  float d=log2(1.+stationDepth.w*max(gl_Position.w,0.))/log2(1.+stationDepth.w*stationDepth.z);
  gl_Position.z=(2.*d-1.)*gl_Position.w;
 }
}
