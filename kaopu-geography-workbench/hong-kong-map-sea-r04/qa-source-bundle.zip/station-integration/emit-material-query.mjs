import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {WGSL} from './frozen-B/receiver.mjs';
import {extraction} from './shader-closure.mjs';
const read=p=>fs.readFileSync(new URL(p,import.meta.url),'utf8'),write=(p,s)=>fs.writeFileSync(new URL(p,import.meta.url),s),sha=s=>createHash('sha256').update(s).digest('hex');
const originalWGSL=read('./qa/reference/probe.wgsl'),originalGLSL=read('./qa/reference/probe.frag');
const roots=['evaluateStationGeometry','evaluateStationMatter','stationMemberState','stationBrickSample'];
const b=extraction(WGSL),ref=extraction(originalWGSL),closure=b.closure(roots);
if(b.header!==ref.header||closure!==ref.closure(roots))throw Error('Frozen B material/geometry closure does not match the pinned-Naga B reference');
const bindings=Array.from({length:5},(_,i)=>`@group(0)@binding(${i+1})var stationInput${i}:texture_2d<f32>;`).join('\n');
const entry=`
struct StationMapResult{@location(0) surface:vec4<f32>,@location(1) geometry:vec4<f32>,@location(2) detail:vec4<f32>,@location(3) state:vec4<f32>}
@fragment fn stationMapMaterialQuery(@builtin(position)pixel:vec4<f32>)->StationMapResult{
 let index=vec2<i32>(pixel.xy);let a=textureLoad(stationInput0,index,0);let b=textureLoad(stationInput1,index,0);let c=textureLoad(stationInput2,index,0);let d=textureLoad(stationInput3,index,0);let e=textureLoad(stationInput4,index,0);
 if(b.w==0.){return StationMapResult(vec4<f32>(0.),vec4<f32>(0.,0.,0.,e.z),vec4<f32>(0.),vec4<f32>(0.));}
 let p=a.xyz;let normal=b.xyz;let h=HitField(e.x,u32(c.w),c.xyz,d.w,e.x,d.xyz,e.y);
 let raw=resolveStationState(p);let g=evaluateStationGeometry(h,p,raw);let m=evaluateStationMatter(h,p,normal,a.w);let st=stationMemberState(h,p,raw);
 return StationMapResult(vec4<f32>(m.surface.albedo,m.surface.roughness),vec4<f32>(g.d,m.d,f32(m.layer),0.),vec4<f32>(m.microHeight,g.loss,g.thickness,h.baseD),vec4<f32>(st.age,st.wet,st.repair,st.retained));
}
`;
const newWGSL=b.header+bindings+'\n'+closure+entry;write('./generated/material-query.wgsl',newWGSL);
const offset=originalGLSL.lastIndexOf('void main() {');if(offset<0)throw Error('Missing B GLSL entry');
const prefix=originalGLSL.slice(0,offset);
const glEntry=Array.from({length:5},(_,i)=>`uniform highp sampler2D stationInput${i};`).join('\n')+`
layout(location=1) out vec4 stationGeometry;
layout(location=2) out vec4 stationDetail;
layout(location=3) out vec4 stationState;
void main() {
 ivec2 index=ivec2(gl_FragCoord.xy);vec4 a=texelFetch(stationInput0,index,0),b=texelFetch(stationInput1,index,0),c=texelFetch(stationInput2,index,0),d=texelFetch(stationInput3,index,0),e=texelFetch(stationInput4,index,0);
 if(b.w==0.0){_fs2p_location0=vec4(0.0);stationGeometry=vec4(0.0,0.0,0.0,e.z);stationDetail=vec4(0.0);stationState=vec4(0.0);return;}
 vec3 p=a.xyz,normal=b.xyz;HitField h=HitField(e.x,uint(c.w),c.xyz,d.w,e.x,d.xyz,e.y);
 StationState raw=resolveStationState(p);StationGeometry g=evaluateStationGeometry(h,p,raw);StationMatter m=evaluateStationMatter(h,p,normal,a.w);StationState st=stationMemberState(h,p,raw);
 _fs2p_location0=vec4(m.surface.albedo,m.surface.roughness);stationGeometry=vec4(g.d,m.d,float(m.layer),0.0);stationDetail=vec4(m.microHeight,g.loss,g.thickness,h.baseD);stationState=vec4(st.age,st.wet,st.repair,st.retained);
}
`;
const newGLSL=prefix+glEntry;write('./generated/material-query-entry-adapted.frag',newGLSL);
write('./generated/manifest.json',JSON.stringify({schema:'kaopu.station-map-material-query/1',frozenCommit:'1f46ba78170752a07086caa3e66c87f2fa4c7fcf',receiverSha256:sha(WGSL),exactMaterialClosureSha256:sha(closure),frozenReferenceWgslSha256:sha(originalWGSL),frozenReferenceGlslSha256:sha(originalGLSL),unchangedGlslPrefixSha256:sha(prefix),unchangedGlslPrefixBytes:Buffer.byteLength(prefix),dynamicWgslSha256:sha(newWGSL),entryAdaptedGlslSha256:sha(newGLSL),compiler:{name:'naga',version:'27.0.3',checksum:'066cf25f0e8b11ee0df221219010f213ad429855f57c494f995590c861a9a7d8',reference:'B pinned CI artifact; dynamic GLSL changes only entry/interface. Equivalent dynamic WGSL requires separate pinned CI compile.'},coordinates:'station-local metres, Y-up; tower pivot [24,0,4]',input:['p.xyz, footprintM','normal.xyz, valid','q.xyz, materialId','extent.xyz, seed','baseD, sourceSeed, failureBits, reserved'],output:['linear albedo.rgb, roughness','geometryD, matterD, resolved material layer, failureBits','microHeight, geometry loss, coating thickness, baseD','state age, wet, repair, retained'],minimumFootprintM:0,defaultFootprintM:.5,footprintMeaning:'Passed to the unchanged original mothers. Partial analytic filtering only; not a footprint integral or physical area average.',missingCandidateBehavior:'explicit failure; no flat-color fallback',limits:'Candidate geometry/material evaluation only; no all-station nearest-member search, no light/tonemap/gamma, no geometry displacement application, no scene or visual acceptance.'},null,2)+'\n');
console.log(JSON.stringify({closureExact:true,wgslBytes:Buffer.byteLength(newWGSL),glslBytes:Buffer.byteLength(newGLSL),motherPrefixBytes:Buffer.byteLength(prefix)}));
