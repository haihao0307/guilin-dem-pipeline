// Far/mid-view tessellation of the authoritative analytic construction parameters.
// No white proxy, imported architectural model, or raster facade is used.
export const add=(a,b)=>a.map((v,i)=>v+b[i]),sub=(a,b)=>a.map((v,i)=>v-b[i]),mul=(a,s)=>a.map(v=>v*s),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm=a=>mul(a,1/(Math.hypot(...a)||1));
export function beamFrame(a,b){let w=norm(sub(b,a)),u=w[1]>-.999999?[1-w[0]*w[0]/(1+w[1]),-w[0],-w[2]*w[0]/(1+w[1])]:[-1,0,0];return [u,w,cross(u,w)]}
export function primitive({kind,center=[0,0,0],extent,frame=[[1,0,0],[0,1,0],[0,0,1]],params={}},emit){
 const world=q=>center.map((v,k)=>v+frame.reduce((s,a,i)=>s+a[k]*q[i],0));
 const tri=(a,b,c)=>emit(...[a,b,c].map(world));
 const quad=(a,b,c,d)=>{tri(a,b,c);tri(a,c,d)};
 const box=(lo,hi)=>{let [a,b,c]=lo,[x,y,z]=hi;quad([a,b,c],[a,y,c],[x,y,c],[x,b,c]);quad([a,b,z],[x,b,z],[x,y,z],[a,y,z]);quad([a,b,c],[x,b,c],[x,b,z],[a,b,z]);quad([a,y,c],[a,y,z],[x,y,z],[x,y,c]);quad([a,b,c],[a,b,z],[a,y,z],[a,y,c]);quad([x,b,c],[x,y,c],[x,y,z],[x,b,z])};
 if(kind==='box'){box(extent.map(v=>-v),extent);return}
 if(kind==='roof'){let [x,y,z]=extent,s=params.slope,t=params.thickness/2;const p=[[-x,-s*x-t,-z],[x,s*x-t,-z],[x,s*x-t,z],[-x,-s*x-t,z],[-x,-s*x+t,-z],[x,s*x+t,-z],[x,s*x+t,z],[-x,-s*x+t,z]];for(let f of[[0,3,2,1],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]])quad(...f.map(i=>p[i]));return}
 if(['cone','flute','octagon'].includes(kind)){
  let h=params.height??extent[1]*2,r0=params.r0??params.radius,r1=params.r1??r0,seg=params.sides||Math.max(24,(params.flutes||0)*4),inner=params.inner||0;
  // An octagon field radius is its apothem, not circumradius.
  if(kind==='octagon'){seg=8;r0/=Math.cos(Math.PI/8);r1=r0;inner/=Math.cos(Math.PI/8)}
  const rad=(r,a)=>r-(params.flutes?params.depth*(.5+.5*Math.cos(a*params.flutes)):0),pt=(a,y,r)=>[Math.cos(a)*rad(r,a),y,Math.sin(a)*rad(r,a)];
  for(let i=0;i<seg;i++){let a=2*Math.PI*i/seg+(kind==='octagon'?Math.PI/8:0),b=2*Math.PI*(i+1)/seg+(kind==='octagon'?Math.PI/8:0),p=pt(a,-h/2,r0),q=pt(b,-h/2,r0),r=pt(b,h/2,r1),s=pt(a,h/2,r1);quad(p,q,r,s);if(inner){let P=pt(a,-h/2,inner),Q=pt(b,-h/2,inner),R=pt(b,h/2,inner),S=pt(a,h/2,inner);quad(P,S,R,Q);quad(p,P,Q,q);quad(s,r,R,S)}else{tri([0,-h/2,0],q,p);tri([0,h/2,0],s,r)}}return
 }
 if(['arch','annulus','disc'].includes(kind)){
  let inner=kind==='disc'?0:(params.inner??params.radius),outer=params.outer??params.radius+(params.width||0),depth=params.depth??params.thickness??.012,segments=kind==='arch'?32:64,span=kind==='arch'?Math.PI:Math.PI*2;
  for(let i=0;i<segments;i++){let a=span*i/segments,b=span*(i+1)/segments;const p=(r,a,z)=>[Math.cos(a)*r,Math.sin(a)*r,z],A=p(inner,a,-depth/2),B=p(outer,a,-depth/2),C=p(outer,b,-depth/2),D=p(inner,b,-depth/2),E=p(inner,a,depth/2),F=p(outer,a,depth/2),G=p(outer,b,depth/2),H=p(inner,b,depth/2);quad(A,D,C,B);quad(E,F,G,H);quad(B,C,G,F);if(inner)quad(A,E,H,D);if(kind==='arch'&&i===0)quad(A,B,F,E);if(kind==='arch'&&i===segments-1)quad(D,H,G,C)}return
 }
 if(kind==='ring'){let R=params.radius,r=params.tube,ns=params.segments||48,nt=params.sides||8;const pt=(a,b)=>[(R+r*Math.cos(b))*Math.cos(a),(R+r*Math.cos(b))*Math.sin(a),r*Math.sin(b)];for(let i=0;i<ns;i++)for(let j=0;j<nt;j++)quad(pt(i*2*Math.PI/ns,j*2*Math.PI/nt),pt((i+1)*2*Math.PI/ns,j*2*Math.PI/nt),pt((i+1)*2*Math.PI/ns,(j+1)*2*Math.PI/nt),pt(i*2*Math.PI/ns,(j+1)*2*Math.PI/nt));return}
 if(kind==='sphere'){let r=params.radius;const pt=(a,b)=>[r*Math.cos(a)*Math.cos(b),r*Math.sin(b),r*Math.sin(a)*Math.cos(b)];for(let i=0;i<24;i++)for(let j=0;j<12;j++){let a=i*Math.PI/12,b=(i+1)*Math.PI/12,u=-Math.PI/2+j*Math.PI/12,v=u+Math.PI/12;quad(pt(a,u),pt(b,u),pt(b,v),pt(a,v))}return}
 if(kind==='dome'){let R=params.radius,rise=params.rise,t=params.thickness,seg=48,rows=16;const pt=(a,b,inner)=>{let rr=R-t/2+(inner?-1:1)*t/(2*(rise/R));return[Math.cos(a)*Math.cos(b)*rr,Math.sin(b)*rr*rise/R,Math.sin(a)*Math.cos(b)*rr]};for(let i=0;i<seg;i++)for(let j=0;j<rows;j++)for(let side=0;side<2;side++){let a=i*2*Math.PI/seg,b=(i+1)*2*Math.PI/seg,u=j*Math.PI/2/rows,v=(j+1)*Math.PI/2/rows;quad(pt(a,u,side),pt(b,u,side),pt(b,v,side),pt(a,v,side))}return}
 if(kind==='triangle'){
  let w=params.width,rise=params.rise,d=params.depth,poly=[[-w/2,-rise/2],[w/2,-rise/2],[0,rise/2]],hole=params.hole;
  if(hole){let [cx,cy,rr]=hole;let angles=Array.from({length:80},(_,i)=>i*2*Math.PI/80).concat(poly.map(p=>(Math.atan2(p[1]-cy,p[0]-cx)+2*Math.PI)%(2*Math.PI))).sort((a,b)=>a-b);
   const outer=a=>{let dx=Math.cos(a),dy=Math.sin(a),ts=[];for(let i=0;i<3;i++){let P=poly[i],Q=poly[(i+1)%3],vx=Q[0]-P[0],vy=Q[1]-P[1],den=dx*vy-dy*vx;if(Math.abs(den)<1e-8)continue;let t=((P[0]-cx)*vy-(P[1]-cy)*vx)/den,u=((P[0]-cx)*dy-(P[1]-cy)*dx)/den;if(t>0&&u>=-1e-8&&u<=1+1e-8)ts.push(t)}let t=Math.min(...ts);return[cx+t*dx,cy+t*dy]};
   for(let i=0;i<angles.length;i++){let a=angles[i],b=angles[(i+1)%angles.length],A=outer(a),B=outer(b),C=[cx+rr*Math.cos(b),cy+rr*Math.sin(b)],D=[cx+rr*Math.cos(a),cy+rr*Math.sin(a)];for(let z of[-d/2,d/2])quad([...A,z],[...B,z],[...C,z],[...D,z]);quad([...A,-d/2],[...B,-d/2],[...B,d/2],[...A,d/2]);quad([...D,-d/2],[...C,-d/2],[...C,d/2],[...D,d/2])}
  }else{for(let z of[-d/2,d/2])tri(...poly.map(q=>[...q,z]));for(let i=0;i<3;i++)quad([...poly[i],-d/2],[...poly[(i+1)%3],-d/2],[...poly[(i+1)%3],d/2],[...poly[i],d/2])}return
 }
 throw Error('Unimplemented parameter shape '+kind)
}
export function gridSolid(xs,ys,zs,inside,emit){let I=(x,y,z)=>inside([(xs[x]+xs[x+1])/2,(ys[y]+ys[y+1])/2,(zs[z]+zs[z+1])/2]);for(let x=0;x<xs.length-1;x++)for(let y=0;y<ys.length-1;y++)for(let z=0;z<zs.length-1;z++){if(!I(x,y,z))continue;let a=xs[x],b=ys[y],c=zs[z],X=xs[x+1],Y=ys[y+1],Z=zs[z+1];const faces=[[[a,b,c],[a,Y,c],[X,Y,c],[X,b,c]],[[a,b,Z],[X,b,Z],[X,Y,Z],[a,Y,Z]],[[a,b,c],[X,b,c],[X,b,Z],[a,b,Z]],[[a,Y,c],[a,Y,Z],[X,Y,Z],[X,Y,c]],[[a,b,c],[a,b,Z],[a,Y,Z],[a,Y,c]],[[X,b,c],[X,Y,c],[X,Y,Z],[X,b,Z]]],neigh=[[x,y,z-1],[x,y,z+1],[x,y-1,z],[x,y+1,z],[x-1,y,z],[x+1,y,z]];for(let j=0;j<6;j++){let q=neigh[j];if(q[0]>=0&&q[1]>=0&&q[2]>=0&&q[0]<xs.length-1&&q[1]<ys.length-1&&q[2]<zs.length-1&&I(...q))continue;let p=faces[j];emit(p[0],p[1],p[2]);emit(p[0],p[2],p[3])}}}
