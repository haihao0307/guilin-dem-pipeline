/** Construction-only adapter for the unchanged frozen-B station rail recorders.
 * No material approximation: every returned HitField goes to the B GPU mother.
 * Coordinates are original station-local metres, Y up. This is an authored
 * rendering layout, not a surveyed railway or an engineering clearance approval.
 */
import {STATION_SCORE} from './frozen-B/station-score.mjs';
import {STATION_RAIL,stationRailCurves} from './frozen-B/native-station-rail.mjs';

const back=STATION_SCORE.shed.front-STATION_SCORE.shed.length;
const front=STATION_SCORE.shed.front;
const crown=.086,offset=.752425,foot=crown-STATION_RAIL.heightM;
const sleeperCenter=foot-.03-.08,pitch=.64;
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;};
export const STATION_RAIL_LAYOUT=freeze({
  sourceCommit:'1f46ba78170752a07086caa3e66c87f2fa4c7fcf',
  source:'frozen-B/station-field.mjs, default construction=null; native-station-rail.mjs; station-score.mjs',
  units:'metres',coordinateSpace:'station-local-metres-Y-up',authoredNotSurveyed:true,
  trackAxesX:[...STATION_SCORE.tracks.centers],gaugeM:STATION_SCORE.tracks.gauge,
  railCenterOffsetM:offset,railHeadReferenceWidthM:STATION_RAIL.headWidthM,
  railTopY:crown,railFootY:foot,railHeightM:STATION_RAIL.heightM,
  shed:{frontZ:front,backZ:back,centerZ:front-STATION_SCORE.shed.length/2},
  main:{zRange:[back-76,front+2],shedCandidateZRange:[back-2,front+2],runningCandidateZRange:[back-76,back],displayJoinZ:back-2},
  siding:{axisX:STATION_SCORE.site.siding.x,zRange:[STATION_SCORE.site.siding.back,STATION_SCORE.site.siding.front],included:true,role:'original separate freight siding; not a seventh passenger axis'},
  sleeper:{pitchM:pitch,centerY:sleeperCenter,halfExtent:[1.165,.080,.115],mainIndexRange:[Math.floor((back-76)/pitch),-13],sidingIndexRange:[-265,-19]},
  bearingPlate:{centerY:foot-.015,halfExtent:[.09,.015,.11]},
  buffers:{centerZ:front-.8,zRange:[front-.8-.18,front-.8+.18],topY:.85,legOffsetsX:[-.72,.72],legCenterY:.40,legHalfExtent:[.14,.35,.135],beamCenterY:.75,beamHalfExtent:[1.075,.10,.18]},
  trackBed:{center:[0,-.35,(back-76+front)*.5],halfExtent:[29,.10,(front-back+76)*.5]},
  camera:{
    meaning:'Conservative viewing routes within the authored static layout; not operational railway safety certification.',
    platformTopY:.85,platformAxesX:[...STATION_SCORE.platforms.centers],platformHalfWidthM:STATION_SCORE.platforms.halfWidth,
    railFootOuterHalfWidthM:offset+STATION_RAIL.footWidthM/2,sleeperHalfWidthM:1.165,
    nearestPlatformEdgeFromTrackAxisM:5-STATION_SCORE.platforms.halfWidth,
    assumedVehicleHalfWidthM:STATION_SCORE.tracks.assumedVehicleHalfWidth,
    authoredVehicleToPlatformGapM:5-STATION_SCORE.platforms.halfWidth-STATION_SCORE.tracks.assumedVehicleHalfWidth,
    nativeMotherDisplacementEnvelopeM:.03001,
    alongTrack:{axesX:[...STATION_SCORE.tracks.centers],eyeY:crown+1.7,zRange:[back-74,front-.8-.18-2],maximumLateralOffsetM:.5,bufferStopMarginM:2,directionTowardTerminal:[0,0,1]},
    platformNearView:{eyeY:2.45,eyeHeightAboveDeckM:1.6,trackFacingOffsetsFromPlatformAxisX:[-2.4,2.4],zRange:[back+4,front-4],edgeSetbackM:1,datum:'platform deck .85 m + viewer 1.6 m; source VIEWS.platform at 2.5 m is a separate legacy authored shot'},
    caveat:'These routes clear the rail/sleeper/buffer and platform bounds. Check all other station members and map terrain in the director/runtime collision tests; do not treat shed eave height as full headroom.'
  },
  displayOwnership:'Shed candidate owns the two-metre raw-geometry overlap. Running display clips at z=-147 with no internal cap. Original candidate q.z and full native distance extents remain unchanged. This is not the full displaced-material candidate union.',
  unbuilt:'No points, crossover, turnout, throat or six-to-one merge is invented.'
});

const curves=stationRailCurves();
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const dot=(a,b)=>a[0]*b[0]+a[1]*b[1];
const tau=2*Math.PI,mod=x=>(x%tau+tau)%tau;
const cachedCurves=curves.map(m=>m.type==='line'?{...m,e:[m.b[0]-m.a[0],m.b[1]-m.a[1]]}:m);
/** Same native line/arc field; only immutable stationRailCurves() is cached. */
export function railProfileDistance(query){
  const q=[Math.abs(query[0]),query[1]];let d=1e9,width=-1;
  for(const m of cachedCurves){let distance;
    if(m.type==='line'){
      const v=[q[0]-m.a[0],q[1]-m.a[1]],t=clamp(dot(v,m.e)/dot(m.e,m.e),0,1);
      distance=Math.hypot(v[0]-m.e[0]*t,v[1]-m.e[1]*t);
    }else{
      const x=q[0]-m.center[0],y=q[1]-m.center[1],delta=mod((Math.atan2(y,x)-m.start)*Math.sign(m.sweep));
      distance=delta<=Math.abs(m.sweep)+1e-13?Math.abs(Math.hypot(x,y)-m.radius):Math.min(Math.hypot(q[0]-m.a[0],q[1]-m.a[1]),Math.hypot(q[0]-m.b[0],q[1]-m.b[1]));
    }
    d=Math.min(d,distance);
    if(q[1]<=Math.max(m.a[1],m.b[1])+1e-13&&q[1]>=Math.min(m.a[1],m.b[1])-1e-13&&Math.abs(m.a[1]-m.b[1])>1e-13){
      width=m.type==='line'?m.a[0]+(m.b[0]-m.a[0])*(q[1]-m.a[1])/(m.b[1]-m.a[1]):m.center[0]+Math.sign(Math.cos(m.start+m.sweep/2))*Math.sqrt(Math.max(0,m.radius*m.radius-(q[1]-m.center[1])**2));
    }
  }
  return d*(q[1]<=0&&q[1]>=-STATION_RAIL.heightM&&q[0]<=width?-1:1);
}
const box=(q,e)=>{const d=q.map((v,k)=>Math.abs(v)-e[k]);return Math.hypot(...d.map(v=>Math.max(v,0)))+Math.min(Math.max(...d),0);};

function buildMembers(){
  const out=[];
  const put=m=>out.push({...m,index:out.length});
  const addRail=(trackX,side,segment,nativeZRange,displayZRange,caps,siding=false)=>put({id:`rail:${siding?'siding':trackX}:${side}:${segment}`,kind:'rail',trackX,side,segment,siding,nativeZRange,displayZRange,caps,center:[trackX+side*offset,crown,(nativeZRange[0]+nativeZRange[1])/2]});
  for(const trackX of STATION_RAIL_LAYOUT.trackAxesX)for(const side of[-1,1]){
    addRail(trackX,side,'shed',[back-2,front+2],[back-2,front+2],[false,true]);
    addRail(trackX,side,'running',[back-76,back],[back-76,back-2],[true,false]);
  }
  const siding=STATION_RAIL_LAYOUT.siding;
  for(const side of[-1,1])addRail(siding.axisX,side,'siding',siding.zRange,siding.zRange,[true,true],true);
  for(const [trackX,range,isSiding] of [...STATION_RAIL_LAYOUT.trackAxesX.map(x=>[x,STATION_RAIL_LAYOUT.sleeper.mainIndexRange,false]),[siding.axisX,STATION_RAIL_LAYOUT.sleeper.sidingIndexRange,true]]){
    for(let cell=range[0];cell<=range[1];cell++){
      const prefix=isSiding?'siding':trackX;
      put({id:`sleeper:${prefix}:${cell}`,kind:'sleeper',trackX,cell,siding:isSiding,center:[trackX,sleeperCenter,cell*pitch],halfExtent:STATION_RAIL_LAYOUT.sleeper.halfExtent});
      for(const side of[-1,1])put({id:`bearing:${prefix}:${cell}:${side}`,kind:'bearing',trackX,cell,side,siding:isSiding,center:[trackX+side*offset,foot-.015,cell*pitch],halfExtent:STATION_RAIL_LAYOUT.bearingPlate.halfExtent});
    }
  }
  for(const trackX of STATION_RAIL_LAYOUT.trackAxesX){
    for(const side of[-1,1])put({id:`buffer-leg:${trackX}:${side}`,kind:'buffer-leg',trackX,side,center:[trackX+side*.72,.40,front-.8],halfExtent:STATION_RAIL_LAYOUT.buffers.legHalfExtent});
    put({id:`buffer-beam:${trackX}`,kind:'buffer-beam',trackX,center:[trackX,.75,front-.8],halfExtent:STATION_RAIL_LAYOUT.buffers.beamHalfExtent});
  }
  put({id:'track-bed:original',kind:'track-bed',center:STATION_RAIL_LAYOUT.trackBed.center,halfExtent:STATION_RAIL_LAYOUT.trackBed.halfExtent});
  return out;
}
export const railMembers=freeze(buildMembers());

/** Explicit member only. No nearest-member material guess or gray fallback. */
export function railMemberSample(member,p){
  const m=typeof member==='number'?railMembers[member]:member;
  if(!m||railMembers[m.index]!==m)throw Error('Unknown frozen-B rail member');
  if(p?.length!==3||!p.every(Number.isFinite))throw Error('Rail sample requires finite station-local position');
  let q,id=3,seed,extent=[1,1,1],sourceSeed=0,baseD;
  const x=p[0]-(m.trackX??0);
  if(m.kind==='rail'){
    q=[Math.abs(x)-offset,p[1]-crown,p[2]-m.center[2]];seed=55;
    baseD=Math.max(railProfileDistance(q),Math.abs(q[2])-(m.nativeZRange[1]-m.nativeZRange[0])/2);
  }else if(m.kind==='bearing'){
    q=[Math.abs(x)-offset,p[1]-m.center[1],p[2]-m.center[2]];seed=189;baseD=box(q,m.halfExtent);
  }else if(m.kind==='sleeper'){
    q=[x,p[1]-sleeperCenter,p[2]-m.center[2]];id=4;seed=30;extent=[...m.halfExtent];baseD=box(q,m.halfExtent);
    sourceSeed=Math.round(p[2]/pitch)+(m.siding?810:Math.round((p[0]-5)/10)*301);
  }else if(m.kind==='buffer-leg'){
    q=[Math.abs(x)-.72,p[1]-.40,p[2]-(front-.8)];seed=189;baseD=box(q,m.halfExtent);
  }else if(m.kind==='buffer-beam'){
    q=[x,p[1]-.75,p[2]-(front-.8)];seed=188;baseD=box(q,m.halfExtent);
  }else if(m.kind==='track-bed'){
    q=p.map((v,k)=>v-m.center[k]);id=2;seed=190;baseD=box(q,m.halfExtent);
  }else throw Error('Unbound frozen-B rail kind '+m.kind);
  return {d:baseD,baseD,id,q,seed,extent,sourceSeed,componentId:m.id};
}

/** Exact candidate descriptors for GPU/CPU component probes. */
export function railProbeFixtures(){
  const pick=(kind,predicate=()=>true)=>railMembers.find(m=>m.kind===kind&&predicate(m));
  const probes=[];
  const add=(name,m,p,n)=>probes.push({name,member:m.index,position:p,normal:n,hit:railMemberSample(m,p)});
  for(const side of[-1,1]){
    const m=pick('rail',m=>m.trackX===5&&m.side===side&&m.segment==='shed');
    add('rail-crown-'+side,m,[5+side*offset,crown,-50],[0,1,0]);
    add('rail-web-'+side,m,[5+side*(offset+.01),crown-.085,-50],[side,0,0]);
  }
  const running=pick('rail',m=>m.trackX===5&&m.side===1&&m.segment==='running');
  add('running-rail-crown',running,[5+offset,crown,-180],[0,1,0]);
  const sleeper=pick('sleeper',m=>m.trackX===5&&m.cell===-80);
  add('sleeper-original-stock',sleeper,[5,sleeperCenter+.08,-80*pitch],[0,1,0]);
  const plate=pick('bearing',m=>m.trackX===5&&m.cell===-80&&m.side===-1);
  add('bearing-recordPart-defaults',plate,[5-offset,foot,-80*pitch],[0,1,0]);
  const leg=pick('buffer-leg',m=>m.trackX===5&&m.side===-1);
  add('buffer-leg-mirrored-q',leg,[5-.72,.75,front-.8],[0,1,0]);
  const beam=pick('buffer-beam',m=>m.trackX===5);
  add('buffer-crossbeam',beam,[5,.85,front-.8],[0,1,0]);
  const bed=pick('track-bed');add('track-bed-original-stone',bed,[0,-.25,-100],[0,1,0]);
  const siding=pick('sleeper',m=>m.siding&&m.cell===-80);
  add('siding-original-stock',siding,[50,sleeperCenter+.08,-80*pitch],[0,1,0]);
  return probes;
}
