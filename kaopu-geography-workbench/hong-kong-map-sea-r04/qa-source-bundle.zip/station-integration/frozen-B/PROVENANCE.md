> Retained R04 historical audit. R05 changes and current verification are documented in HERITAGE-R05.md; this inherited report is not R05 acceptance.

# Kowloon terminal R04 function candidate

Independent authored station following the relationships visible in eight privately supplied station photographs: the long low hall, attached clock tower, sea-facing forecourt and landward train sheds. Image dates, exact dimensions and photographic rights are not inferred. No source photograph is distributed. The spatial design is an interpretation, not a surveyed historical replica.

R02 is retained as the stable train-game reference. R03's source-generated Three geometry is frozen; this candidate does not resurrect that route. R04 has one procedural whole-station distance domain, three fullscreen receiver vertices and no scene mesh, index, appearance texture or per-brick array. It is a separate research preview, not yet connected to the driving simulator.

Original material leaves are copied byte-for-byte and locked in SOURCE_LOCK.json: R3.12 brick geometry and surface; Library v3 timber macro displacement and complete material channels; STONE_STUDY original kind-0 surface; R3.12 thin plaster field; FH88 noise/material with the previously declared new corrosion bridge. New architecture, spatial receiver, drainage/repair domains and lighting are authored here. Stone surface displacement is not the original full stone SDF/damage-event model. The clock's cream paint is not a recovered ceramic mother. Glazing transport is not yet implemented. These limits must not be described as complete mature material validation.

Geometry and surface resolve the same metric coordinates, material identity, age, wetness and repair state. Timber's original core does not contain a calibrated age law; it is not relabelled as one. Source subpixel height affects microscopic appearance only where the receiver explicitly consumes it. Full-source microstructure is not claimed resolved at 480×320. All unresolved rays are counted and painted magenta instead of being silently treated as background.

GPU compile, device completion, same-commit exterior / hall / platform / tower / bench images and independent art review are required. CPU source tests are not visual approval. Software WebGPU timings are not user-device frame-rate claims. R04 must remain a candidate until these gates pass.

The first GPU pass was rejected: original kind-0 stone frequency was too dense on large members, front columns obstructed opening centres, and grazing ground rays exhausted. New host bindings use a 0.65 m source-frequency domain for stone, the original R3.12 thin warm plaster for coated architectural trim, offset columns, analytical domain-clipped ground intersections, and six tracks with four islands. The 0.1 m boarding gap assumes a 1.5 m vehicle half-width and is not dynamic clearance certification.

The current common-matter refactor is described in CONSTRUCTION-MATTER-AUDIT.md. It supersedes the earlier nominal-core-first receiver. Platform deck now uses the existing KST1 concrete arithmetic, with a new WGSL translation and physical-height binding. Actual tower recesses are added without pretending that glass transmission is complete.

