# Add this helper beside director_state/assert_director in qa/browser_check.py.
# It intentionally removes the guessed '< 4m' travel criterion.
def capture_platform_collision(page):
    evidence = page.evaluate(r"""async () => {
      const {createStationWalkNav}=await import('./interior-audit/station-walk-nav.mjs');
      const nav=createStationWalkNav(window.HK_WALK_DATA);
      if(!HKMap.focusDirector('station-platform'))throw Error('Platform preset unavailable');
      const initial=HKMap.getDirectorState(),trace=[],distance=(a,b)=>Math.hypot(...a.map((v,k)=>v-b[k]));
      // Native key delivery is already covered by the preceding real page.keyboard
      // WASD checks. Keep this exact 160-tick collision sequence in one JS task:
      // no RAF movement can occur between keydown, samples and finally-keyup.
      try {
        window.dispatchEvent(new KeyboardEvent('keydown',{key:'d',code:'KeyD',bubbles:true}));
        for(let step=0;step<160;step++){
          const before=HKMap.getDirectorState(),camera=HKDirector.directorCamera();
          const requested=before.eyeMap.map((v,k)=>k===1?v:v+camera.right[k]*1.4*.05);
          const requestedAllowed=nav.canMoveMap(before.eyeMap,requested);
          HKDirector.tickDirector(.05);
          const after=HKMap.getDirectorState(),expected=requestedAllowed?requested:before.eyeMap;
          trace.push({step:step+1,fromMap:before.eyeMap,toMap:after.eyeMap,
            fromLocal:before.eyeLocal,toLocal:after.eyeLocal,requestedLocal:nav.mapToLocal(requested),
            requestedAllowed,appliedPointAllowed:nav.isAllowedMap(after.eyeMap),
            appliedSweepAllowed:nav.canMoveMap(before.eyeMap,after.eyeMap),
            appliedMatchesDecision:distance(after.eyeMap,expected)<1e-8,
            moved:distance(before.eyeMap,after.eyeMap)>1e-8,
            acceptedDelta:after.acceptedMoves-before.acceptedMoves,
            blockedDelta:after.blockedMoves-before.blockedMoves});
        }
      } finally {
        window.dispatchEvent(new KeyboardEvent('keyup',{key:'d',code:'KeyD',bubbles:true}));
      }
      const final=HKMap.getDirectorState(),camera=HKDirector.directorCamera();
      const next=final.eyeMap.map((v,k)=>k===1?v:v+camera.right[k]*1.4*.05);
      return {initial,final,trace,nextRequestedLocal:nav.mapToLocal(next),
        nextRequestAllowed:nav.canMoveMap(final.eyeMap,next),
        // Frozen STATION_SCORE: centers [-30,-10,10,30], halfWidth 3.4m.
        sourcePlatform:{centerX:10,halfWidthM:3.4,deckEdgesX:[6.6,13.4],
          bodyRadiusM:window.HK_WALK_DATA.bodyRadiusM,deckY:.85,eyeLocalY:2.45},
        noPhantomInteriors:{currentAllowed:nav.isAllowedMap(final.eyeMap),
          towerAllowed:nav.isAllowedLocal([24,2.45,4]),
          absentForecourtAllowed:nav.isAllowedLocal([3.75,2.45,12]),
          trackVoidAllowed:nav.isAllowedLocal([0,2.45,-25])},
        method:'Actual runtime key handler and 160 fixed 0.05s ticks in one JS task; full supercover nav sweep recorded for every applied step. Not wall-clock/GPU performance.'};
    }""")
    a, b, trace = evidence['initial'], evidence['final'], evidence['trace']
    assert_director(a)
    assert_director(b)
    check(len(trace) == 160, 'Incomplete lateral collision trace')
    check(b['blockedMoves'] > a['blockedMoves'], 'No boundary rejection observed')
    check(any(t['moved'] for t in trace), 'Collision test never moved')
    check(all(t['appliedPointAllowed'] and t['appliedSweepAllowed'] and t['appliedMatchesDecision'] for t in trace),
          'An applied lateral step escaped the certified grid or ignored its decision')
    check(all(t['moved'] == t['requestedAllowed'] and t['acceptedDelta'] + t['blockedDelta'] == 1 for t in trace),
          'A requested lateral step was skipped, duplicated or applied despite rejection')
    # Derive the real body-center range from this source platform, not an
    # arbitrary travel distance measured from an off-center camera preset.
    platform = evidence['sourcePlatform']
    left, right = platform['deckEdgesX']
    radius = platform['bodyRadiusM']
    check(abs(radius - .30) < 1e-9, 'Collision body radius changed')
    points = [a['eyeLocal']] + [t['toLocal'] for t in trace]
    check(all(left + radius - 1e-8 <= p[0] <= right - radius + 1e-8
              and abs(p[1] - 2.45) < 1e-8 and abs(p[2] + 24) < 1e-8 for p in points),
          'Applied body footprint escaped the actual platform or changed its tested cross-section')
    # Fixed 0.07m proposals should stop before the body leaves the deck. The
    # first next step would overhang the real edge, and must remain rejected.
    check(not evidence['nextRequestAllowed'], 'Next outward step was incorrectly admitted')
    check(b['eyeLocal'][0] + radius <= right + 1e-8
          and evidence['nextRequestedLocal'][0] + radius > right,
          'Rejection was not at the expected physical platform boundary')
    nav = evidence['noPhantomInteriors']
    check(nav['currentAllowed'] and not any(nav[k] for k in
          ['towerAllowed', 'absentForecourtAllowed', 'trackVoidAllowed']),
          'Phantom interior/walkable void admitted')
    return evidence


# Replace the old station-platform focus / 'd' loop / <4 assertion / nav block
# (currently lines 320-331) with the following inside the scene method:
#
#         swept = capture_platform_collision(page)
#         a, b, nav = swept['initial'], swept['final'], swept['noPhantomInteriors']
#         case['wasd'] = {'movement': movement, 'collisionBefore': a,
#                         'collisionAfter': b, 'noPhantomInteriors': nav,
#                         'collisionTrace': swept}
#
# The following station-hall focus/frame cadence/rail tests remain unchanged.
