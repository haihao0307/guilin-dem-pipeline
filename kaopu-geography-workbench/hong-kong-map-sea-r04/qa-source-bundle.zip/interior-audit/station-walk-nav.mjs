/** Tiny runtime API. Data is precomputed; no source geometry sampling per frame. */
export function createStationWalkNav(data){
 if(data?.schema!=='hong-kong-r04.conservative-walk-grid/1'||!data.contract?.entireCellCertified)throw Error('Uncertified station walk grid');
 const text=typeof atob==='function'?atob(data.allowedBase64):Buffer.from(data.allowedBase64,'base64').toString('binary');
 const bits=Uint8Array.from(text,c=>c.charCodeAt(0));
 const {width,height,cellSizeM:cell,originXZ:[ox,oz],eyeY}=data;
 const validPoint=p=>Array.isArray(p)&&p.length===3&&p.every(Number.isFinite)&&Math.abs(p[1]-eyeY)<1e-5;
 const coord=p=>[Math.floor((p[0]-ox)/cell),Math.floor((p[2]-oz)/cell)];
 const cellAllowed=(x,z)=>{if(x<0||z<0||x>=width||z>=height)return false;const n=z*width+x;return !!(bits[n>>>3]&(1<<(n&7)));};
 const isAllowedLocal=p=>validPoint(p)&&cellAllowed(...coord(p));
 function canMoveLocal(from,to){
  if(!isAllowedLocal(from)||!isAllowedLocal(to))return false;
  let [x,z]=coord(from);const [endX,endZ]=coord(to),dx=to[0]-from[0],dz=to[2]-from[2],sx=Math.sign(dx),sz=Math.sign(dz);
  if(x===endX&&z===endZ)return true;
  const deltaX=sx?cell/Math.abs(dx):Infinity,deltaZ=sz?cell/Math.abs(dz):Infinity;
  let tx=sx?(ox+(x+(sx>0?1:0))*cell-from[0])/dx:Infinity,tz=sz?(oz+(z+(sz>0?1:0))*cell-from[2])/dz:Infinity;
  // Supercover grid traversal prevents tunnelling over a blocked cell even for
  // a large frame delta. At a touched corner require both side cells as well.
  const max=width+height+4;for(let n=0;n<max;n++){
   if(Math.abs(tx-tz)<1e-10){if(!cellAllowed(x+sx,z)||!cellAllowed(x,z+sz))return false;x+=sx;z+=sz;tx+=deltaX;tz+=deltaZ;}
   else if(tx<tz){x+=sx;tx+=deltaX;}else{z+=sz;tz+=deltaZ;}
   if(!cellAllowed(x,z))return false;
   if(x===endX&&z===endZ)return true;
  }return false;
 }
 const localToMap=p=>[1477.171-(p[2]-4),3.90+p[1],9824.015+(p[0]-24)];
 const mapToLocal=p=>[p[2]-9824.015+24,p[1]-3.90,4-(p[0]-1477.171)];
 const isAllowedMap=p=>Array.isArray(p)&&p.length===3&&isAllowedLocal(mapToLocal(p));
 const canMoveMap=(from,to)=>Array.isArray(from)&&Array.isArray(to)&&from.length===3&&to.length===3&&canMoveLocal(mapToLocal(from),mapToLocal(to));
 // Rejected moves retain the old point. Camera height remains fixed; no snap,
 // automatic teleport, geometry scale change, or hidden wall-crossing fallback.
 const tryMoveMap=(from,to)=>canMoveMap(from,to)?to.slice():from.slice();
 return Object.freeze({isAllowedLocal,canMoveLocal,isAllowedMap,canMoveMap,tryMoveMap,localToMap,mapToLocal,eyeLocalY:eyeY,eyeMapY:3.90+eyeY,cellSizeM:cell,contract:data.contract});
}
