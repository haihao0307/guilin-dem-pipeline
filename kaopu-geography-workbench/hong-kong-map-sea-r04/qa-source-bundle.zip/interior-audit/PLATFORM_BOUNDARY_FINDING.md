# Run 2 侧移碰撞断言：误报原因及替换证据

## 结论

`math.dist(initial, final) < 4` 的前提不成立。源平台中心 X=10、半宽3.4，实体边界 X=[6.6,13.4]。`station-platform` 眼点从 X=9 开始，不在平台中心。半径0.30m的身体中心可以到 X=13.1，即从该预设向右有4.1m名义支撑范围。

真实run2的desktop/mobile均停在 X=13.05999999998312；脚体最外侧 X=13.36，仍距实体边缘约4cm。下一次0.07m请求会到 X=13.13、脚体外侧13.43，已超出真实平台，系统拒绝。这不是把4m阈值提高后放过；应删除猜测位移阈值，直接验证源平台支撑与每条实际位移的完整sweep。

## 可重复证据

在本案例源码解包目录运行：

`node --experimental-vm-modules interior-audit/reproduce-platform-boundary.mjs`

使用当前真实camera-runtime.js、真实nav位集和源码采样器，重演同一个预设、D键及160次tickDirector(.05)：

- 58步接受，每步0.07m，总4.06m
- 102步拒绝
- 最终坐标与run2两种viewport完全一致
- 160条已应用线段均通过canMoveMap完整supercover检查
- 每个请求与实际应用/拒绝决定一致
- 全运动轨迹再经权威CPU构件/地板支撑验证：collision=0，unsupported=0
- 最低人体保守净空0.075736m，相机0.252130m
- 每个脚体左右极端点也直接通过原platformDeckSample的实体内符号检查

详细结果：`PLATFORM_BOUNDARY_REPRO.json`，含160步轨迹；精简命令记录：`PLATFORM_BOUNDARY_REPRO.txt`。

run2原报告只保存了失败时终点，没有完整浏览器轨迹。完整逐步轨迹目前由本机CPU精确重演提供；下一轮使用下面的替换代码收集浏览器自身的每步证据，不能把CPU重演误称为原run2已记录过的轨迹。

## browser_check.py 明确替换

`BROWSER_COLLISION_REPLACEMENT.py` 提供可直接复制的helper `capture_platform_collision(page)`；文件末尾给出scene段替换代码。父线程拥有browser_check.py，本任务未修改它。

helper保留前面page.keyboard原生WASD可用性检查；侧移碰撞fixture在一个JS任务内发送同一真实运行时键盘处理器的KeyD，再记录160个tick，finally释放键。这样不会有未记录的RAF位移混进采样间隙。

验证内容：

1. 每个已应用点与完整线段均位于已验nav
2. 每次请求都严格遵守nav接受/拒绝决定
3. 每个身体支撑圆盘都在源平台边界内，Y=2.45、Z=-24不变
4. 下一请求确实越出实体边界，且被拒绝
5. 塔内、未建前广场、轨道间隙仍不可步行

替换JS本身也已在同一个真实camera-runtime VM中执行，58/102步结果一致：`BROWSER_COLLISION_REPLACEMENT_VALIDATION.json`。没有修改camera-runtime.js、nav算法或网格来掩盖失败。

## 原始构造出处

- 冻结B `station-score.mjs`：platform centers [-30,-10,10,30]、halfWidth 3.4
- R03 `member-resolver.mjs` 的platformDeckSample：box half-size [3.4,.575,68.8]
- 当前 `CAMERA_PRESETS.json`：station-platform local eye [9,2.45,-24]
- 原失败精简证据：`RUN2_PLATFORM_COLLISION_FIXTURE.json`，assembly-02 / commit `1fffe8f19dc43f34318f55be0af03a7d04fb6a1e`，desktop/mobile坐标及阻挡次数。运行时不读取CI产物目录。


## 干净源码包

所有源模块均由本包`../station-integration/`读取，没有R03目录或工作区绝对路径依赖。固定run2 fixture只保存run/commit/html哈希和case、eyeLocal、blockedMoves。与CI相同，先在本包根目录运行`node station-integration/export-mesh.mjs`，再运行repro。缺少MESH_MANIFEST.json或mesh-positions.f32时明确报错并提示该前置步骤；helper不会创建第二套bootstrap，也不读取网络或GPU。
