import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {obstacleSample,floorSupport,evaluatePath,mapPoint,inverseMap,shapes,paths,presets,sourceDigest,before} from './audit-station-interior.mjs';
const definition=(id,eye)=>({id,label:id,purpose:'negative regression',eye,target:[0,3,0],speedMps:1});
test('all five accepted paths have support and full-body/camera clearance',()=>{for(const p of paths){assert.equal(p.collisionFailures,0);assert.equal(p.unsupportedFailures,0);assert(p.minBodyClearanceLowerBoundM>.075);assert(p.minCameraClearanceLowerBoundM>.25);}});
test('six normal perspective cameras preserve nominal 1.6m eye height and unit scale',()=>{assert.equal(presets.length,6);for(const p of presets){assert.equal(p.projection,'perspective');assert.equal(p.eyeHeightAboveNominalDeckM,1.6);assert.equal(p.modelScale,1);assert(Math.abs(p.eye[1]-.85-1.6)<1e-9);assert(Math.abs(p.eyeMap[1]-6.35)<1e-9);assert(p.verticalFovDegrees>=45&&p.verticalFovDegrees<=60);}});
test('closed public lower-wall bay rejects direct crossing',()=>assert.throws(()=>evaluatePath(definition('closed-public-bay',[[-18.75,2.45,5],[-18.75,2.45,8.35]])),/collision/));
test('rail pier rejects path through its center',()=>assert.throws(()=>evaluatePath(definition('rail-pier',[[7.5,2.45,-4],[7.5,2.45,-12]])),/collision/));
test('cast-column center rejects centerline platform walk',()=>assert.throws(()=>evaluatePath(definition('column',[[10,2.45,-14],[10,2.45,-9]])),/collision/));
test('track-space flyover rejects missing floor',()=>assert.throws(()=>evaluatePath(definition('unsupported-track',[[0,2.45,-14],[0,2.45,-20]])),/unsupported feet/));
test('omitted public forecourt rejects unsupported continuation',()=>assert.throws(()=>evaluatePath(definition('missing-forecourt',[[3.75,2.45,8.35],[3.75,2.45,12]])),/unsupported feet/));
test('flat flight from approach at hall height rejects missing contact',()=>assert.throws(()=>evaluatePath(definition('ignore-stairs',[[-39,2.45,0],[-31.7,2.45,0]])),/unsupported feet/));
test('hollow tower does not imply an available ground-level entry',()=>assert.throws(()=>evaluatePath(definition('tower-entry',[[19,2.45,4],[24,2.45,4]])),/collision/));
test('spatial query agrees with exhaustive source samplers below its cap',()=>{
 const points=[[-31.7,1.15,0],[-31.7,2.45,0],[-20,2.45,0],[-18.75,2.45,8],[7.5,1.15,-8],[7.5,2.45,-8],[9,1.15,-10],[9,2.45,-10],[10,1.15,-10],[10,2.45,-10],[9,2.45,-17.5],[9,1.15,-25],[24,2.45,4],[20.9,2.45,4],[3.75,2.45,8]];
 let seed=131031;for(let i=0;i<30;i++){const next=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};points.push([-33+next()*63,.85+.3+next()*1.3,-55+next()*64]);}
 for(const p of points){let exact=.8;for(const s of shapes)exact=Math.min(exact,s.sample(p).d);assert(Math.abs(exact-obstacleSample(p).d)<1e-8,'indexed field mismatch at '+p);}
});
test('map transform is metric and invertible',()=>{const a=[9,2.45,-24],b=[-31.7,2.45,0],A=mapPoint(a),B=mapPoint(b);assert(Math.abs(Math.hypot(...a.map((v,i)=>v-b[i]))-Math.hypot(...A.map((v,i)=>v-B[i])))<1e-9);assert(Math.hypot(...inverseMap(A).map((v,i)=>v-a[i]))<1e-9);});
test('frozen B SHA-256 hashes were not changed',()=>assert.deepEqual(sourceDigest(),before));
