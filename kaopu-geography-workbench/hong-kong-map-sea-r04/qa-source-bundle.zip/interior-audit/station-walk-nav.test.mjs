import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {createStationWalkNav} from './station-walk-nav.mjs';
const data=JSON.parse(fs.readFileSync(new URL('./STATION_WALK_GRID.json',import.meta.url))),nav=createStationWalkNav(data);
const {presets}=JSON.parse(fs.readFileSync(new URL('./CAMERA_PRESETS.json',import.meta.url))),{paths}=JSON.parse(fs.readFileSync(new URL('./CONTINUOUS_PATHS.json',import.meta.url)));
test('all authored cameras and director segments use the allowed nav region',()=>{for(const p of presets){assert(nav.isAllowedLocal(p.eye),p.id);assert(nav.isAllowedMap(p.eyeMap),p.id);}for(const p of paths)for(let i=0;i<p.eye.length-1;i++)assert(nav.canMoveLocal(p.eye[i],p.eye[i+1]),p.id);});
test('canMove checks whole displacement and rejects large-frame tunnelling',()=>{assert(nav.isAllowedLocal([9,2.45,-14]));assert(nav.isAllowedLocal([11,2.45,-6]));assert(!nav.canMoveLocal([9,2.45,-14],[11,2.45,-6]));assert(!nav.canMoveLocal([-3.75,2.45,-7],[-3.75,2.45,-15]));});
test('all four platforms connect to the main hall at eye height',()=>{
 const bits=Buffer.from(data.allowedBase64,'base64'),W=data.width,H=data.height,is=i=>!!(bits[i>>>3]&(1<<(i&7))),idx=p=>Math.floor((p[2]-data.originXZ[1])/data.cellSizeM)*W+Math.floor((p[0]-data.originXZ[0])/data.cellSizeM);
 const first=idx([-20,2.45,0]),seen=new Uint8Array(W*H),queue=new Int32Array(W*H);let r=0,w=1;queue[0]=first;seen[first]=1;
 while(r<w){const v=queue[r++],x=v%W,z=Math.floor(v/W);for(const [dx,dz]of [[-1,0],[1,0],[0,-1],[0,1]]){const xx=x+dx,zz=z+dz;if(xx<0||zz<0||xx>=W||zz>=H)continue;const n=zz*W+xx;if(!seen[n]&&is(n)){seen[n]=1;queue[w++]=n;}}}
 for(const x of [-31,-11,9,29])assert(seen[idx([x,2.45,-100])],'disconnected platform '+x);
 fs.writeFileSync(new URL('./WALK_GRID_CONNECTIVITY.json',import.meta.url),JSON.stringify({reachableAllowedCells:w,totalAllowedCells:data.stats.allowedCells,unreachableAllowedCells:data.stats.allowedCells-w,fourPlatformsReachable:true,seedLocalEye:[-20,2.45,0]},null,2));
});
test('outside floors, tower and lower approach remain forbidden',()=>{for(const p of [[3.75,2.45,12],[0,2.45,-25],[24,2.45,4],[-39,2.45,0],[9,2.45,-147],[100,2.45,0]])assert(!nav.isAllowedLocal(p),p.toString());});
test('wrong eye height and nonfinite values reject rather than teleport',()=>{for(const p of [[9,3,-24],[9,1.6,-24],[NaN,2.45,-24],[9,Infinity,-24]])assert(!nav.isAllowedLocal(p));const a=nav.localToMap([9,2.45,-24]),b=nav.localToMap([10,2.45,-25]);assert.deepEqual(nav.tryMoveMap(a,b),a);});
test('map/local APIs are equivalent',()=>{const a=[9,2.45,-14],b=[9,2.45,-52];assert.equal(nav.canMoveLocal(a,b),nav.canMoveMap(nav.localToMap(a),nav.localToMap(b)));assert(!nav.canMoveMap(nav.localToMap(a),nav.localToMap([9,3,-52])));});
test('corner supercover cannot use diagonal gap between blocked cells',()=>{const tiny={...data,originXZ:[0,0],width:2,height:2,cellSizeM:1,allowedBase64:Buffer.from([0b1001]).toString('base64')},n=createStationWalkNav(tiny);assert(n.isAllowedLocal([.5,2.45,.5]));assert(n.isAllowedLocal([1.5,2.45,1.5]));assert(!n.canMoveLocal([.5,2.45,.5],[1.5,2.45,1.5]));});
