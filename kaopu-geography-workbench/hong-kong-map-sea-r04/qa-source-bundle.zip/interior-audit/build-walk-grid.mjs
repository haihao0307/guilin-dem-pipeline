/** Offline conservative walk grid; only frozen exported B at nominal floor .85. */
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import assert from 'node:assert/strict';
import {obstacleSample,paths,presets} from './audit-station-interior.mjs';
import {hall} from '../station-integration/member-resolver.mjs';
import {terminalHallMemberBounds} from '../station-integration/frozen-B/native-terminal-hall.mjs';
import {createStationWalkNav} from './station-walk-nav.mjs';
const ROOT=path.dirname(fileURLToPath(import.meta.url)),start=performance.now();
const cell=.20,origin=[-34.1,-147.1],width=341,height=781,floorY=.85,radius=.30,bodyHeight=1.80,eyeHeight=1.60;
const verticalStep=.06,materialEnvelope=.03001,L=1.25,cover=Math.sqrt(cell*cell/2+verticalStep*verticalStep/4);
const allowed=new Uint8Array(Math.ceil(width*height/8));
const rects=hall.parts.filter(m=>m.isFloor&&m.kind==='box'&&!/joint/.test(m.id)).map(m=>{const b=terminalHallMemberBounds(m,0);return{id:m.id,min:b.min,max:b.max};}).filter(b=>Math.abs(b.max[1]-floorY)<1e-7);
for(const x of [-30,-10,10,30])rects.push({id:'platform:'+x,min:[x-3.4,-.3,-146.3],max:[x+3.4,.85,-8.7]});
// Prove the entire square containing every 0.30m support disc in this cell is
// covered by the union, not merely its center/corners. This preserves the true
// slab/apron/platform overlaps without pretending a gap has support.
function supportSquare(x,z){
 const r=radius+cell/2,loX=x-r,hiX=x+r,loZ=z-r,hiZ=z+r;
 const near=rects.filter(b=>b.min[0]<=hiX&&b.max[0]>=loX&&b.min[2]<=hiZ&&b.max[2]>=loZ);
 if(!near.length)return false;
 const xs=[loX,hiX,...near.flatMap(b=>[Math.max(loX,b.min[0]),Math.min(hiX,b.max[0])])].sort((a,b)=>a-b);
 for(let i=0;i<xs.length-1;i++){
  if(xs[i+1]-xs[i]<1e-9)continue;const mid=(xs[i]+xs[i+1])/2;
  const zs=near.filter(b=>b.min[0]<=mid&&b.max[0]>=mid).map(b=>[Math.max(loZ,b.min[2]),Math.min(hiZ,b.max[2])]).sort((a,b)=>a[0]-b[0]);
  let end=loZ;for(const [a,b] of zs){if(a>end+1e-9)return false;end=Math.max(end,b);if(end>=hiZ-1e-9)break;}if(end<hiZ-1e-9)return false;
 }return true;
}
let supported=0,count=0,minClearance=Infinity,queries=0;
for(let j=0;j<height;j++)for(let i=0;i<width;i++){
 const x=origin[0]+(i+.5)*cell,z=origin[1]+(j+.5)*cell;
 if(!supportSquare(x,z))continue;supported++;
 let raw=Infinity;
 for(let k=0;k<=20;k++){
  const d=obstacleSample([x,floorY+radius+k*verticalStep,z]).d;queries++;raw=Math.min(raw,d);
  if((raw-materialEnvelope)/L-radius-cover<0)break;
 }
 const clearance=(raw-materialEnvelope)/L-radius-cover;
 if(clearance<0)continue;
 // Camera center at eye 1.6m with radius .25m extends 5cm above the 1.8m
 // body, so certify its complete cell separately rather than assuming containment.
 const cameraRaw=obstacleSample([x,floorY+eyeHeight,z]).d;queries++;
 const cameraClearance=(cameraRaw-materialEnvelope)/L-.25-cell/Math.sqrt(2);
 if(cameraClearance<0)continue;
 const index=j*width+i;allowed[index>>>3]|=1<<(index&7);count++;minClearance=Math.min(minClearance,clearance);
}
// Retain only the region physically connected to the hall by safe shared edges.
// Five tiny isolated admissible cells are removed rather than exposed as spawns.
const total=width*height,seen=new Uint8Array(total),queue=new Int32Array(total);
const seed=Math.floor((0-origin[1])/cell)*width+Math.floor((-20-origin[0])/cell);
let read=0,write=1;queue[0]=seed;seen[seed]=1;
const bitAt=n=>!!(allowed[n>>>3]&(1<<(n&7)));
while(read<write){const v=queue[read++],x=v%width,z=Math.floor(v/width);for(const [dx,dz] of [[-1,0],[1,0],[0,-1],[0,1]]){const xx=x+dx,zz=z+dz;if(xx<0||zz<0||xx>=width||zz>=height)continue;const n=zz*width+xx;if(!seen[n]&&bitAt(n)){seen[n]=1;queue[write++]=n;}}}
let prunedDisconnectedCells=0;for(let n=0;n<total;n++)if(bitAt(n)&&!seen[n]){allowed[n>>>3]&=~(1<<(n&7));prunedDisconnectedCells++;}
count-=prunedDisconnectedCells;
const data={schema:'hong-kong-r04.conservative-walk-grid/1',sourceCommit:'1f46ba78170752a07086caa3e66c87f2fa4c7fcf',units:'metres',coordinateFrame:'station-local-Y-up',cellSizeM:cell,originXZ:origin,width,height,floorY,eyeY:floorY+eyeHeight,bodyRadiusM:radius,bodyHeightM:bodyHeight,eyeHeightM:eyeHeight,cameraRadiusM:.25,bitOrder:'LSB first, row-major z then x',allowedBase64:Buffer.from(allowed).toString('base64'),contract:{entireCellCertified:true,support:'Entire square enclosing every cell position and 0.30m foot disc is covered by the exact union of existing nominal floor rectangles.',collision:'Authoritative exported-B CPU fields; radius0.30 height1.80 capsule, field envelope and between-sample/cell cover. Floors support body; they are not walls.',materialEnvelopeM:materialEnvelope,fieldLipschitzBound:L,verticalSampleStepM:verticalStep,cellAndVerticalCoverRadiusM:cover,excluded:['lower road approach and stair climbing','outside forecourt/quay','space between platforms','inside tower','future added obstacles','map terrain interference'],invalidatesOn:['different floor or eye height','larger body','changed station geometry','new obstacles intersecting allowed cells']},stats:{supportedCells:supported,allowedCells:count,blockedSupportedCells:supported-count,prunedDisconnectedCells,minCellClearanceLowerBoundM:minClearance,queries,cpuGenerationSeconds:(performance.now()-start)/1000}};
const nav=createStationWalkNav(data);
for(const p of presets)assert(nav.isAllowedLocal(p.eye),'preset outside grid: '+p.id);
for(const p of paths)for(let i=0;i<p.eye.length-1;i++)assert(nav.canMoveLocal(p.eye[i],p.eye[i+1]),'path blocked: '+p.id+' segment '+i);
assert(!nav.canMoveLocal([9,2.45,-14],[10,2.45,-10]));
assert(!nav.canMoveLocal([3.75,2.45,8.35],[3.75,2.45,12]));
fs.writeFileSync(path.join(ROOT,'STATION_WALK_GRID.json'),JSON.stringify(data));
fs.writeFileSync(path.join(ROOT,'WALK_GRID_RECEIPT.json'),JSON.stringify({...data,allowedBase64:undefined,validation:{presets:presets.length,paths:paths.length,presetAndOriginalSegmentChecks:'passed',negativeColumnAndForecourtChecks:'passed'}},null,2));
console.log(JSON.stringify({status:'PASS',...data.stats,bytes:allowed.length},null,2));
