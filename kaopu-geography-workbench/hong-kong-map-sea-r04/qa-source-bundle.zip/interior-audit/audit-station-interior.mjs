/** Read-only audit of frozen B; writes only this independent audit directory. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {hall,tower,columns,platformEdges,clockMemberSample,hallMemberSample,shedMemberSample,castColumnMemberSample,platformEdgeMemberSample,platformDeckSample} from '../station-integration/member-resolver.mjs';
import {createTerminalHallSampler,terminalHallMemberBounds,terminalHallMemberSample,HALL_MATERIAL_ENVELOPE} from '../station-integration/frozen-B/native-terminal-hall.mjs';
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const SOURCE=path.resolve(ROOT,'../station-integration');
const manifest=JSON.parse(fs.readFileSync(path.join(SOURCE,'MESH_MANIFEST.json')));
const sourceLock=JSON.parse(fs.readFileSync(path.join(SOURCE,'SOURCE_LOCK.json')));
const bytes=fs.readFileSync(path.join(SOURCE,'mesh-positions.f32'));
const positions=new Float32Array(bytes.buffer,bytes.byteOffset,bytes.byteLength/4);
const EPS=1e-9,MARGIN=HALL_MATERIAL_ENVELOPE,LIP=1.25,RADIUS=.30,HEIGHT=1.80,EYE_HEIGHT=1.60,STEP=.10,CAPTURE_RADIUS=.25;
const VERTICAL_STEP=.10;
const uncertainty=.5*Math.hypot(STEP,VERTICAL_STEP);
const threshold=LIP*(RADIUS+uncertainty)+MARGIN;
const bloat=.10;
const mapPoint=p=>[1477.171-(p[2]-4),3.90+p[1],9824.015+(p[0]-24)];
const inverseMap=p=>[p[2]-9824.015+24,p[1]-3.90,4-(p[0]-1477.171)];
const add=(a,b)=>a.map((x,i)=>x+b[i]);
const sub=(a,b)=>a.map((x,i)=>x-b[i]);
const length=p=>Math.hypot(...p);
const distance=(a,b)=>length(sub(a,b));
const lerp=(a,b,t)=>a.map((x,i)=>x+(b[i]-x)*t);
const round=n=>Number(n.toFixed(6));
const rounded=p=>p.map(round);
const boundsForGroup=(g,i)=>{const end=manifest.groups[i+1]?.start??manifest.vertexCount,lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];for(let j=g.start;j<end;j++)for(let k=0;k<3;k++){lo[k]=Math.min(lo[k],positions[3*j+k]);hi[k]=Math.max(hi[k],positions[3*j+k]);}return{min:lo,max:hi};};
const eaveIndices=new Map(platformEdges.map((m,i)=>[m.id,i]));
const sourceDigest=()=>Object.fromEntries(sourceLock.files.map(f=>[f.path,crypto.createHash('sha256').update(fs.readFileSync(path.join(SOURCE,'frozen-B',f.path))).digest('hex')]));
const before=sourceDigest();
for(const f of sourceLock.files)assert.equal(before[f.path],f.sha256,'Frozen B hash differs: '+f.path);
const shapes=[];
for(const [i,g] of manifest.groups.entries()){
 let sample=null,kind=null;
 if(g.family==='hall'){
  const m=hall.parts[g.member];if(m.isFloor)continue;
  sample=p=>hallMemberSample(g.member,p);kind='hall';
 }else if(g.family==='clock'){sample=p=>clockMemberSample(g.member,p);kind='clock';}
 else if(g.label.startsWith('column:')){const [,centerX,j,member]=g.label.split(':').map((v,k)=>k?Number(v):v);sample=p=>castColumnMemberSample(member,p,{centerX,bayCenterZ:-10-j*7.5});kind='column';}
 else if(g.label.startsWith('shed:')){const [,barrel,type,member]=g.label.split(':');sample=p=>shedMemberSample(type,Number(member),p,{barrel:Number(barrel)});kind='shed';}
 else if(g.label.startsWith('truss:')){const [,barrel,j,member]=g.label.split(':').map((v,k)=>k?Number(v):v);sample=p=>shedMemberSample('truss',member,p,{barrel,bayCenterZ:-10-j*7.5});kind='truss';}
 else if(g.label.startsWith('platform-edge:')){const member=eaveIndices.get(g.label.slice(14));if(platformEdges[member].family!=='eave')continue;sample=p=>platformEdgeMemberSample(member,p);kind='platform-eave';}
 else continue;
 const b=g.family==='hall'?terminalHallMemberBounds(hall.parts[g.member],bloat):boundsForGroup(g,i);
 // The 100 mm broad-phase padding exceeds coarse mesh/chord discrepancies and
 // the 30.01 mm material envelope. All low-height shapes near audited routes are
 // boxes, exact cones or bounded flute shafts. Roofs remain in the source list.
 const pad=g.family==='hall'?0:bloat;
 shapes.push({label:g.label,kind,sample,min:b.min.map(v=>v-pad),max:b.max.map(v=>v+pad)});
}
// Bounded collision query. Members excluded by the spatial index have > 0.8 m
// distance to their conservative enclosure, exceeding every tested capsule.
const gridSize=2,queryBand=.8,grid=new Map();
for(const s of shapes){if(s.min[1]>3.1||s.max[1]<.8)continue;for(let x=Math.floor((s.min[0]-queryBand)/gridSize);x<=Math.floor((s.max[0]+queryBand)/gridSize);x++)for(let z=Math.floor((s.min[2]-queryBand)/gridSize);z<=Math.floor((s.max[2]+queryBand)/gridSize);z++){const key=x+','+z;if(!grid.has(key))grid.set(key,[]);grid.get(key).push(s);}}
function obstacleSample(p){let best={d:queryBand,componentId:'conservative-query-band',bounded:true};for(const s of grid.get(Math.floor(p[0]/gridSize)+','+Math.floor(p[2]/gridSize))||[]){if(p[1]<s.min[1]-queryBand||p[1]>s.max[1]+queryBand)continue;const q=s.sample(p);if(q.d<best.d)best={...q,componentId:s.label,bounded:false};}return best;}
const floorMembers=hall.parts.filter(m=>m.isFloor);
const floorRects=floorMembers.filter(m=>m.kind==='box'&&!/joint/.test(m.id)).map(m=>{const b=terminalHallMemberBounds(m,0);return{id:m.id,min:b.min,max:b.max,top:b.max[1],sample:p=>terminalHallMemberSample(m,p,hall.plan)};});
for(const centerX of [-30,-10,10,30])floorRects.push({id:'platform:'+centerX,min:[centerX-3.4,-.3,-146.3],max:[centerX+3.4,.85,-8.7],top:.85,sample:p=>platformDeckSample(p,{centerX})});
function floorSupport(foot){return floorRects.find(f=>Math.abs(f.top-foot[1])<1e-7&&foot[0]-RADIUS>=f.min[0]-EPS&&foot[0]+RADIUS<=f.max[0]+EPS&&foot[2]-RADIUS>=f.min[2]-EPS&&foot[2]+RADIUS<=f.max[2]+EPS&&f.sample([foot[0],foot[1]-.02,foot[2]]).d<0);}
const fullHallSampler=createTerminalHallSampler({...hall.plan},{compact:false,includeDeferredGlass:true});
function hallOnly(p,skipFloor=true){return fullHallSampler(p,{skipFloor});}
const doorwayChecks=[];
for(let i=0;i<8;i++){
 const x=30-(i+.5)*7.5;
 for(const side of ['rail','sea']){
  const p=[x,.85+1.60,side==='rail'?-8:8],h=hallOnly(p);
  doorwayChecks.push({side,sourceBay:i,stationEye:p,rawFieldM:round(h.d),nearest:h.componentId,openAtEye:h.d>RADIUS,expectedOpen:side==='rail'||i===3||i===4});
  assert.equal(h.d>RADIUS,side==='rail'||i===3||i===4,'door topology '+side+i);
 }
}
const emptyHallProbe={point:[0,2.45,0],...hallOnly([0,2.45,0])};
assert(emptyHallProbe.d>3,'Hall center must be open air');
const pathDefinitions=[
 {id:'entry-to-hall',label:'短端柱廊进入主厅',purpose:'True entrance opening; starts on existing level landing, not through a facade.',eye:[[ -31.7,2.45,0],[-27,2.45,0],[-20,2.45,0]],target:[0,4.0,0],speedMps:1.15},
 {id:'hall-long-axis',label:'主厅内部步行',purpose:'Normal eye-height inspection of floor, piers, side openings and roof underside.',eye:[[-20,2.45,0],[-6,2.45,0]],target:[17,4.0,0],speedMps:1.15},
 {id:'hall-to-platform',label:'主厅经真实门洞进入棚下',purpose:'Cross the rail-side bay near x=9 m, avoiding the pier at 7.5 m and column at [10,-10].',eye:[[-6,2.45,0],[9,2.45,-4],[9,2.45,-14]],target:[9,3.6,-36],speedMps:1.15},
 {id:'platform-forward',label:'沿轨道方向站台前进',purpose:'Along existing platform beside the rail corridor; does not walk on or certify absent rails.',eye:[[9,2.45,-14],[9,2.45,-52]],target:[9,3.5,-74],speedMps:1.2},
 {id:'public-door-interior',label:'公众侧门洞向内',purpose:'Starts on the existing hall slab at the open central public bay; no claim of a built exterior forecourt.',eye:[[3.75,2.45,8.35],[3.75,2.45,5],[0,2.45,0]],target:[-6,3.7,-6],speedMps:1.0}
];
function evaluatePath(def){
 const samples=[];let routeLength=0,minBody=Infinity,minEye=Infinity,nearest=null;let collisions=0,unsupported=0;
 for(let seg=0;seg<def.eye.length-1;seg++){
  const a=def.eye[seg],b=def.eye[seg+1],len=distance(a,b),n=Math.max(1,Math.ceil(len/STEP));routeLength+=len;
  for(let i=seg?1:0;i<=n;i++){
   const eye=lerp(a,b,i/n),foot=[eye[0],eye[1]-EYE_HEIGHT,eye[2]],floor=floorSupport(foot);if(!floor)unsupported++;
   let raw=Infinity,member=null;
   for(let y=RADIUS;y<=HEIGHT-RADIUS+1e-8;y+=VERTICAL_STEP){const q=obstacleSample([foot[0],foot[1]+y,foot[2]]);if(q.d<raw){raw=q.d;member=q.componentId;}}
   // The complete capsule sweep between horizontal and vertical samples lies
   // within this Euclidean covering radius. Raw field/L gives a conservative
   // external distance; subtract the bounded material offset before division.
   const body=(raw-MARGIN)/LIP-RADIUS-uncertainty;
   const q=obstacleSample(eye),camera=(q.d-MARGIN)/LIP-CAPTURE_RADIUS-STEP/2;
   if(body<minBody){minBody=body;nearest={member,eye:rounded(eye),rawFieldM:round(raw)};}
   minEye=Math.min(minEye,camera);if(body<0||camera<0)collisions++;
   samples.push({eyeLocal:rounded(eye),eyeMap:rounded(mapPoint(eye)),footDatumM:round(foot[1]),support:floor?.id??null,bodyClearanceLowerBoundM:round(body),cameraClearanceLowerBoundM:round(camera)});
  }
 }
 assert.equal(collisions,0,def.id+' collision');assert.equal(unsupported,0,def.id+' unsupported feet');
 return{...def,eyeMap:def.eye.map(p=>rounded(mapPoint(p))),targetMap:rounded(mapPoint(def.target)),lengthM:round(routeLength),durationSeconds:round(routeLength/def.speedMps),sampleCount:samples.length,collisionFailures:collisions,unsupportedFailures:unsupported,minBodyClearanceLowerBoundM:round(minBody),minCameraClearanceLowerBoundM:round(minEye),nearestBodyObstacle:nearest,samples};
}
const paths=pathDefinitions.map(evaluatePath);
const presets=[
 {id:'station-entry',label:'1.6m 入口',eye:[-31.7,2.45,0],target:[-10,4.2,0],visible:['four-profiled-column portico sides','open entrance returns','long hall depth','roof underside'],path:'entry-to-hall'},
 {id:'station-hall',label:'1.6m 主厅',eye:[-20,2.45,0],target:[12,4.2,-1],visible:['hollow hall','ground-bearing slab and joints','side brick piers and open rail bays','under-roof surface'],path:'hall-long-axis'},
 {id:'station-door',label:'1.6m 通向站台',eye:[9,2.45,-4],target:[9,3.8,-22],visible:['real rail-side aperture','first cast column offset from route','apron and platform connection','shed mouth'],path:'hall-to-platform'},
 {id:'station-platform',label:'1.6m 站台',eye:[9,2.45,-24],target:[9,3.5,-58],visible:['6.8m platform','cast column foot/plinth/shaft/collars','finite edge coping','repeated roof truss bays'],path:'platform-forward'},
 {id:'station-canopy',label:'棚下结构',eye:[9,2.45,-32],target:[0,7.3,-24],visible:['roof underside','arch-truss members','purlins','cast iron support'],path:'platform-forward'},
 {id:'station-public-door',label:'公众侧真实门洞',eye:[3.75,2.45,8.35],target:[-6,3.7,-6],visible:['central open public bay','lower walls in neighboring closed bays','hall depth'],path:'public-door-interior'}
].map(p=>({...p,eyeMap:rounded(mapPoint(p.eye)),targetMap:rounded(mapPoint(p.target)),projection:'perspective',verticalFovDegrees:52,nearPlaneM:.05,farPlaneM:60000,eyeHeightAboveNominalDeckM:1.60,modelScale:1}));
for(const p of presets){const test=evaluatePath({id:p.id,label:p.label,purpose:'static camera collision check',eye:[p.eye,p.eye],target:p.target,speedMps:1});assert.equal(test.collisionFailures,0);assert.equal(test.unsupportedFailures,0);p.clearance={bodyLowerBoundM:test.minBodyClearanceLowerBoundM,cameraLowerBoundM:test.minCameraClearanceLowerBoundM};}
// Metric transform is one proper 90-degree rotation and a translation, not a scale.
const metricProbes=[[0,0,0],[1,0,0],[0,1,0],[0,0,1],[24,44,4],[-31.7,2.45,0]];
for(const a of metricProbes){assert(distance(a,inverseMap(mapPoint(a)))<1e-9);for(const b of metricProbes)assert(Math.abs(distance(a,b)-distance(mapPoint(a),mapPoint(b)))<1e-9);}
const hallGroups=manifest.groups.filter(g=>g.family==='hall');assert.equal(hallGroups.length,646);
assert.deepEqual(new Set(hallGroups.map(g=>g.member)),new Set(hall.parts.filter(m=>!m.binding.deferred).map(m=>m.member)));
const mouthClearSpan=7.5-1.5;
const report={schema:'hong-kong-r04.interiors.audit/1',sourceCommit:manifest.sourceCommit,frozenSourceSha256:before,units:'metres',authoredNotSurveyed:true,status:'passed CPU geometry/export and bounded path audit; visual/runtime terrain acceptance remains separate',
 transform:{formula:'map=[1477.171-(local.z-4),3.90+local.y,9824.015+(local.x-24)]',rotationDeterminant:1,scale:1,eyeOnDeckLocalY:2.45,eyeOnDeckMapY:6.35,nominalDeckLocalY:.85,nominalDeckMapY:4.75},
 hall:{construction:'hollow open hall, not a filled solid',widthM:60,depthM:16,deckTopM:.85,eaveM:12,ridgeM:14.3,floorSlabNominalRect:{x:[-31.2,31.2],z:[-8.8,8.8]},partCount:647,exportedOpaqueParts:646,deferredGlassParts:1,exportOmittedOpaqueParts:0,sourceInteriorRooms:false,towerOccupiesPartOfHallEnd:{pivot:[24,0,4],notCertifiedWalkable:true,reason:'The independent tower has a hollow shaft but no ground-level door or authored internal stair route in the frozen recipe. Do not place a walking camera inside merely because the shaft has empty space.'},emptyCenterProbe:{point:emptyHallProbe.point,rawFieldM:round(emptyHallProbe.d),nearest:emptyHallProbe.componentId},doorwayChecks,nominalMinimumBayFootLevelClearWidthM:mouthClearSpan,openRailBays:8,openPublicBays:[3,4],closedPublicLowerWallBays:[0,1,2,5,6,7],shortEndEntrance:{direction:'station -X',porticoColumnX:-30.9,columnZ:[-6.45,-2.15,2.15,6.45],unblockedCenterlineZ:0,slabAndLandingContinuous:true,levelPathStartsX:-31.7},roadApproach:{localX:[-43,-33.64],topM:.15,stairs:{centersX:[-33.46,-33.09,-32.72,-32.35],topsM:[.19,.41,.63,.85],maxRiserM:.22,treadPitchM:.37},certifiedContinuousLevelCameraRoute:false,reason:'Physical steps are present. This audit starts the continuous 1.6m route on the upper landing; do not linearly fly through stair solids or describe this as step-free access.'}},
 stationExport:{vertexCount:manifest.vertexCount,triangleCount:manifest.triangleCount,maxNominalFieldResidualM:manifest.maxConstructionFieldResidualM,groupsByPrefix:Object.fromEntries(Object.entries(manifest.groups.reduce((a,g)=>(a[g.label.split(':')[0]]=(a[g.label.split(':')[0]]||0)+1,a),{}))),present:['tower shell/window cuts','full hall opaque construction including underside faces','shed roofs/purlins/trusses','all four support rows','four platform slabs and edge coping'],absent:['native rail/running surface recipe','benches','lamps','footbridge/stairs','station lettering outlines','goods shed','quay/forecourt circulation slabs','hotel/boats and other reservations'],limited:['one oculus glass descriptor retained but optics not emitted','authored dimensions/orientation; no surveyed historical-registration claim','mesh floor-joint cuts are not completely represented by the box tessellator','finite tessellation and baked vertex materials do not resolve arbitrary close-up detail']},
 collisionMethod:{authoritativeCPUFunctions:['createTerminalHallSampler (exhaustive topology checks)','hallMemberSample','clockMemberSample','castColumnMemberSample','shedMemberSample','platformEdgeMemberSample','platformDeckSample'],radiusM:RADIUS,heightM:HEIGHT,cameraSphereRadiusM:CAPTURE_RADIUS,eyeHeightM:EYE_HEIGHT,pathSampleStepMaxM:STEP,capsuleAxisStepMaxM:VERTICAL_STEP,coveringRadiusM:uncertainty,conservativeFieldLipschitzBound:LIP,materialFieldEnvelopeM:MARGIN,broadPhaseBoundsPaddingM:bloat,scope:'Frozen B exported structure; traversable floors are support surfaces, not lateral obstacles. Entire 0.30m support disk fits an existing rectangular floor. No collision certification of map terrain, added rails, trains or other later content.',positiveClearanceMeaning:'Conservative lower bound after field envelope, capsule radius and between-sample cover. Capped far distances are deliberately lower bounds, not measured nearest-surface distances.',materialLimitation:'Raw authoritative CPU field plus bounded geometry envelope; no new GPU material-distance bake or exact foot microrelief simulation.'},
 paths:paths.map(({samples,...p})=>p),cameraPresets:presets,evidence:{sourceFiles:['frozen-B/native-terminal-hall.mjs','frozen-B/station-score.mjs','member-resolver.mjs','export-mesh.mjs','mesh-primitives.mjs','MESH_MANIFEST.json','SOURCE_LOCK.json'],readOnlyFrozenB:true,longGpuRun:false,meshExportRerun:false}};
assert.deepEqual(sourceDigest(),before,'Frozen B changed during audit');
fs.writeFileSync(path.join(ROOT,'INTERIOR_AUDIT.json'),JSON.stringify(report,null,2));
fs.writeFileSync(path.join(ROOT,'CAMERA_PRESETS.json'),JSON.stringify({schema:'hong-kong-r04.metric-camera-presets/1',defaultFovDegrees:52,defaultNearM:.05,modelScale:1,presets},null,2));
fs.writeFileSync(path.join(ROOT,'CONTINUOUS_PATHS.json'),JSON.stringify({schema:'hong-kong-r04.audited-walk-paths/1',interpolation:'Piecewise linear only; arbitrary spline smoothing is not certified. Re-audit after altering control points or new obstacles.',paths},null,2));
console.log(JSON.stringify({status:'PASS',sourceCommit:manifest.sourceCommit,hallOpaqueParts:hallGroups.length,doors:doorwayChecks.filter(d=>d.openAtEye).length,presets:presets.length,paths:paths.map(({id,sampleCount,minBodyClearanceLowerBoundM,minCameraClearanceLowerBoundM})=>({id,sampleCount,minBodyClearanceLowerBoundM,minCameraClearanceLowerBoundM})),sourceUnchanged:true},null,2));

export {obstacleSample,floorSupport,evaluatePath,mapPoint,inverseMap,shapes,paths,presets,sourceDigest,before};
