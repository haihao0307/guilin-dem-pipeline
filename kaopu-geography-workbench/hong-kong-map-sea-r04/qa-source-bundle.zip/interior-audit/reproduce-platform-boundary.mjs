/** Exact browser-run2 lateral collision sequence, with every motion recorded. */
import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
import {createStationWalkNav} from './station-walk-nav.mjs';
import {STATION_SCORE} from '../station-integration/frozen-B/station-score.mjs';
import {platformDeckSample} from '../station-integration/member-resolver.mjs';
const read=name=>fs.readFileSync(new URL(name,import.meta.url),'utf8');
// The single host/CI mesh export is a prerequisite, not a second bootstrap.
const stationRoot=new URL('../station-integration/',import.meta.url);
const missingMeshInputs=['MESH_MANIFEST.json','mesh-positions.f32'].filter(name=>!fs.existsSync(new URL(name,stationRoot)));
if(missingMeshInputs.length)throw Error('Missing local audit inputs: '+missingMeshInputs.join(', ')+'. First run node station-integration/export-mesh.mjs from this package root.');
const {evaluatePath,floorSupport}=await import('./audit-station-interior.mjs');
class Events{constructor(){this.listeners=new Map();}addEventListener(t,f){if(!this.listeners.has(t))this.listeners.set(t,[]);this.listeners.get(t).push(f);}dispatch(t,e={}){e.preventDefault??=()=>{};e.stopImmediatePropagation??=()=>{};e.target??={tagName:'BODY'};for(const f of this.listeners.get(t)||[])f(e);}}
const window=new Events(),document=new Events(),canvas=new Events();document.hidden=false;document.querySelectorAll=()=>[];document.querySelector=()=>null;
window.HK_WALK_DATA=JSON.parse(read('STATION_WALK_GRID.json'));window.HK_CAMERA_DATA=JSON.parse(read('CAMERA_PRESETS.json'));window.HK_PATH_DATA=JSON.parse(read('CONTINUOUS_PATHS.json'));window.HKMap={};
const context=vm.createContext({window,document,canvas,mapState:{mode:'orbit',stationAvailable:true},qa:{},needFrame:false,HK:{},mapFocus:()=>{},console,Buffer,atob});
const module=new vm.SourceTextModule(read('station-walk-nav.mjs'),{context});await module.link(()=>{});await module.evaluate();
const runtime=new vm.SourceTextModule(read('../camera-runtime.js'),{context,importModuleDynamically:async()=>module});await runtime.link(()=>{});await runtime.evaluate();
const api=window.HKMap,nav=createStationWalkNav(window.HK_WALK_DATA),radius=window.HK_WALK_DATA.bodyRadiusM;
api.bindDirectorControls();assert(api.focusDirector('station-platform'));
const initial=api.getDirectorState(),center=STATION_SCORE.platforms.centers.find(x=>Math.abs(initial.eyeLocal[0]-x)<STATION_SCORE.platforms.halfWidth),half=STATION_SCORE.platforms.halfWidth;
const deckEdges=[center-half,center+half],bodyCenterBounds=[deckEdges[0]+radius,deckEdges[1]-radius],trace=[];
window.dispatch('keydown',{code:'KeyD'});
for(let step=0;step<160;step++){
 const before=api.getDirectorState(),camera=api.directorCamera(),requested=before.eyeMap.map((v,k)=>k===1?v:v+camera.right[k]*1.4*.05);
 const requestedAllowed=nav.canMoveMap(before.eyeMap,requested);
 api.tickDirector(.05);const after=api.getDirectorState(),moved=Math.hypot(...after.eyeMap.map((v,k)=>v-before.eyeMap[k]))>1e-8;
 const sweepAllowed=nav.canMoveMap(before.eyeMap,after.eyeMap),pointAllowed=nav.isAllowedMap(after.eyeMap),expected=requestedAllowed?requested:before.eyeMap;
 assert(Math.hypot(...after.eyeMap.map((v,k)=>v-expected[k]))<1e-8,'runtime did not apply nav decision');
 assert(sweepAllowed&&pointAllowed,'illegal applied sweep');assert.equal(moved,requestedAllowed);
 assert(after.eyeLocal[0]>=bodyCenterBounds[0]-1e-8&&after.eyeLocal[0]<=bodyCenterBounds[1]+1e-8,'body crossed deck edge');
 assert(Math.abs(after.eyeLocal[1]-2.45)<1e-8&&Math.abs(after.eyeLocal[2]+24)<1e-8,'unexpected transverse/vertical movement');
 const foot=[after.eyeLocal[0],.85,after.eyeLocal[2]];assert(floorSupport(foot));
 // Independent native floor sign probes at both lateral extremities of each
 // footprint, below the real top. Entire swept support is also checked by the
 // conservative offline grid and the source evaluatePath audit below.
 for(const sign of [-1,1])assert(platformDeckSample([foot[0]+sign*radius,.83,foot[2]],{centerX:center}).d<0,'foot footprint outside native deck');
 trace.push({step:step+1,fromMap:before.eyeMap,toMap:after.eyeMap,fromLocal:before.eyeLocal,toLocal:after.eyeLocal,requestedMap:requested,requestedLocal:nav.mapToLocal(requested),requestedAllowed,appliedSweepAllowed:sweepAllowed,appliedPointAllowed:pointAllowed,moved});
}
window.dispatch('keyup',{code:'KeyD'});
const final=api.getDirectorState(),accepted=trace.filter(p=>p.moved).length,blocked=trace.length-accepted;
assert.equal(accepted,58);assert.equal(blocked,102);assert(Math.abs(final.eyeLocal[0]-13.06)<1e-8);
const firstBlocked=trace.find(p=>!p.moved);assert(firstBlocked.requestedLocal[0]+radius>deckEdges[1]);
const sourceAudit=evaluatePath({id:'run2-lateral-full-trace',label:'run2 complete KeyD trace',purpose:'Every applied motion, including blocked stays, checked against authoritative CPU solids and real support',eye:[Array.from(initial.eyeLocal),...trace.map(p=>Array.from(p.toLocal))],target:[10,3,-24],speedMps:1.4});
const run=JSON.parse(read('RUN2_PLATFORM_COLLISION_FIXTURE.json'));
assert.equal(run.schema,'hong-kong-r04.run2-platform-collision-fixture/1');
const matchingRun2=run.cases.map(c=>({case:c.case,eyeLocal:c.eyeLocal,blockedMoves:c.blockedMoves,matchLocal:Math.hypot(...c.eyeLocal.map((v,k)=>v-final.eyeLocal[k]))<1e-8}));
assert(matchingRun2.length>=2&&matchingRun2.every(c=>c.matchLocal&&c.blockedMoves===102));
const report={status:'PASS',meshInputs:'present after the host export-mesh prerequisite',run2Evidence:{run:run.runLabel,commit:run.commit,htmlSha256:run.htmlSha256},diagnosis:'Incorrect fixed 4m travel assertion, not a demonstrated navigation escape.',sourceCommit:'1f46ba78170752a07086caa3e66c87f2fa4c7fcf',platform:{centerX:center,halfWidthM:half,deckEdgesX:deckEdges,bodyRadiusM:radius,bodyCenterBoundsX:bodyCenterBounds,deckY:.85,eyeY:2.45},initialLocal:initial.eyeLocal,finalLocal:final.eyeLocal,travelM:Math.hypot(...final.eyeMap.map((v,k)=>v-initial.eyeMap[k])),perTickM:.07,ticks:160,accepted,blocked,finalFootOuterX:final.eyeLocal[0]+radius,firstRejectedBodyOuterX:firstBlocked.requestedLocal[0]+radius,firstRejectedTargetLocal:firstBlocked.requestedLocal,matchingRun2,fullTraceValidation:{allAppliedPointsAllowed:trace.every(p=>p.appliedPointAllowed),allAppliedSweepsAllowed:trace.every(p=>p.appliedSweepAllowed),navDecisionMatchesEveryTick:true,authoritativeCpuCollisionFailures:sourceAudit.collisionFailures,authoritativeCpuUnsupportedFailures:sourceAudit.unsupportedFailures,minBodyClearanceLowerBoundM:sourceAudit.minBodyClearanceLowerBoundM,minCameraClearanceLowerBoundM:sourceAudit.minCameraClearanceLowerBoundM},trace};
fs.writeFileSync(new URL('./PLATFORM_BOUNDARY_REPRO.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({...report,trace:undefined},null,2));

// Execute the proposed browser helper's exact JavaScript against this same real
// camera module, rather than trusting an untested replacement snippet.
const replacement=read('BROWSER_COLLISION_REPLACEMENT.py').match(/page\.evaluate\(r"""([\s\S]*?)"""\)/)[1];
window.dispatchEvent=e=>window.dispatch(e.type,e);context.KeyboardEvent=class{constructor(type,options){this.type=type;Object.assign(this,options);}};context.HKMap=api;context.HKDirector=window.HKDirector;
const verify=new vm.SourceTextModule('globalThis.browserReplacementEvidence=await ('+replacement+')();',{context,importModuleDynamically:async()=>module});await verify.link(()=>{});await verify.evaluate();
const replacementEvidence=context.browserReplacementEvidence;assert.equal(replacementEvidence.trace.length,160);assert(replacementEvidence.trace.every(t=>t.appliedPointAllowed&&t.appliedSweepAllowed&&t.appliedMatchesDecision));assert.equal(replacementEvidence.trace.filter(t=>t.moved).length,58);assert.equal(replacementEvidence.final.blockedMoves-replacementEvidence.initial.blockedMoves,102);
fs.writeFileSync(new URL('./BROWSER_COLLISION_REPLACEMENT_VALIDATION.json',import.meta.url),JSON.stringify({status:'PASS',exactReplacementJavaScriptExecuted:true,ticks:160,accepted:58,blocked:102,allSweepsAllowed:true,finalLocal:replacementEvidence.final.eyeLocal,nextRejectedLocal:replacementEvidence.nextRequestedLocal},null,2));
console.log('Exact browser replacement JavaScript: PASS');
