# 独立 camera-runtime.js 接入

仅新建了 `../camera-runtime.js` 和本审计目录内容，没有改 build_map.py / map-integration.js，没有增加渲染。

## 主模块接入点

1. 在主模块执行之前，提供：
   - `window.HK_WALK_DATA` = STATION_WALK_GRID.json 内容
   - `window.HK_CAMERA_DATA` = CAMERA_PRESETS.json 内容
   - `window.HK_PATH_DATA` = CONTINUOUS_PATHS.json 内容（只保留每条路径的 id / label / eyeMap / targetMap / speedMps 即可，运行时不用 995 个验证样本）
2. 将 camera-runtime.js 内联到已能访问 mapState、qa、canvas、needFrame、mapFocus 的主模块中。它顶层 await import('./interior-audit/station-walk-nav.mjs')，发布时必须保留该模块 URL。
3. 最终 window.HKMap 创建之后调用 `bindDirectorControls()`；此调用把接口重新合并到最终对象，不替换原有 HKMap API。重复调用不会重复绑定事件。
4. `mapCamera()` 最开始查询 `directorCamera()`，非 null 时直接返回。旧 orbit 返回仍按原代码运行。
5. `common` 用 `c.fov ?? 55` 的角度数生成 tanFov；director 返回 52°。统一 near 0.05m / far 60000m，与主集成要求相同。返回 c.near=0.05，但若 shader 写死 near，仍由 host 统一修改。这里没有改 shader 或深度。
6. 每帧调用 `tickDirector(dtSeconds)`，放在暂停/needFrame 提前返回之前。dt 单位为秒；内部把一次恢复停顿上限限制为 0.10 秒，避免重新获得焦点时大跳步。
7. `mapFocus` 切换旧总览前调用 `exitDirector()` 或设置 mapState.mode='orbit'。旧 orbit 输入处理器仍建议按 mode 拦截；本模块在 director 状态下也以 capture + stopImmediatePropagation 拦截 pointer/wheel，避免双重动作。

## 返回相机

`directorCamera()` 返回 `{cam, fw, right, up, flat, fov, near, far, mode}`，或者非近景模式时 null。坐标为地图空间；眼高固定 map Y=6.35m，即名义平台顶4.75m上1.6m。看向可上下转动，但绝不改变眼点高度。没有缩放模型。

近景状态 `mapState.mode='director'`；退出为 `'orbit'`。静态镜头切换/开始新镜头是切到已验起点，不把两个相隔位置之间的直线冒充可步行路径。

## 公共 API

以下接口合并到 window.HKMap，同时也在 window.HKDirector：

- `focusDirector(key)`：6 个 CAMERA_PRESETS 中的 id
- `startDirectorPath(key)`：5 个 CONTINUOUS_PATHS 中的 id
- `stopDirectorPath()`：留在当前位置，停止播放
- `pauseDirectorPath(true/false)`：暂停/恢复
- `exitDirector(optionalMapViewKey)`：退出，可选调用原 mapFocus
- `directorCamera()` / `tickDirector(dtSeconds)` / `bindDirectorControls()`
- `getDirectorState()`：状态、镜头进度、拒绝移动次数与固定尺寸

未知预设/路径返回 false。现成“沿站台向前”按钮使用 `platform-forward`；另有 `startRailDirector()` 专用轨道镜头，见下文。两者不共享行人移动权限。

## 操作

- WASD：水平步行 1.4m/s，斜行归一化
- 左键/单指拖动：视角；无鼠标锁定或额外权限请求
- 滚轮：近景时不缩放、不改变眼高
- Esc：回原 orbit
- 播放中按 WASD：停下自动镜头并接管步行
- 播放中拖视角：保持手动看向，路径继续
- blur/隐藏页面：清除按键；文字输入控件中不接管 WASD

所有自由位移调用 tryMoveMap 检查完整线段。导演路径过折点时分段检查，不用起点到最终点的弦跨角。撞墙/边界保留原位置，没有自动传送、穿墙、飞行或任意高度 fallback。

## 检查

`node --experimental-vm-modules --test hong-kong-map-sea-r04/interior-audit/camera-runtime.test.mjs`

20 项 VM/事件测试通过：六镜头正交相机、1.4m/s及斜行、五路径终点、输入接管、事件拦截、滚轮、失焦、输入框、幂等绑定、边界阻挡、暂停恢复、错误数据显式禁用。

这些是运行逻辑测试，尚不代表最终集成页面的浏览器画面或 log-depth 验收；该部分由主集成完成。


## 独立轨道导演镜头

父线程已核准原源六轨轴之一：local x=-25m，z=-215→-18m；源轨范围为-221至-8m，轨距1.435m，轨顶Y=.086m。本镜头眼点为local Y=1.686m / map Y=5.586m，沿+Z以6m/s巡视，目标看向高Y=2.5m，终点停在buffer(-10.8m)之前。没有连接假咽喉，也没有延长轨道几何。

- 公共入口 `window.HKMap.startRailDirector()`
- `kind='rail-camera'`，与`walk-camera`分离；mode仍为director
- 不调用行人nav、不声称行人能在该轨道行走
- WASD只显示“请选择站台镜头”，不能接管轨道位移
- 拖动仍可看向；`pauseDirectorPath`、`stopDirectorPath`和`exitDirector`统一作用于当前模式
- 轨道状态下Esc / 默认exitDirector回overview
- 切到站台preset或walk path立即恢复map eyeY6.35，并清除rail状态
- `getDirectorState().rail`明确记录walkNavUsed:false和pedestrianReachabilityClaim:false

轨道轴、轨顶及镜头范围是父线程此次提供并核准的构造证据；本模块只实现摄像机，不重新创建轨道或替换父线程的场景净空/画面验收。新增4项CPU测试覆盖轴线范围/6m/s/固定眼高、WASD限制、停止重启与模式切换、缺失walk网格时仍保持独立。


宿主回调保护：`exitDirector(null)`表示不重新调用mapFocus。无参数退出只有在原来active rail模式时才默认overview，而且在调用宿主前先清active、kind、path和rail，因此mapFocus再调用exitDirector也不会递归。directorPublish同步body的director类，供宿主隐藏总览UI。两项真实宿主回调/class切换回归已通过。


车站资源门控：宿主设置`mapState.stationAvailable=!!window.HK_STATION_DATA`。只有显式false才关闭功能，undefined兼容独立测试。失败时所有view/path/rail按钮在每次publish和初始化绑定后均disabled，三个启动入口都返回false，available/walkAvailable/railAvailable均false。有效nav不代表建筑已加载，不能把按钮重新打开。活动相机遇到后续失败立即不再返回近景，下一tick以exitDirector(null)退出至orbit，无refocus；nav算法不变。3项资源失败/按钮复活/活动中失败测试通过。
