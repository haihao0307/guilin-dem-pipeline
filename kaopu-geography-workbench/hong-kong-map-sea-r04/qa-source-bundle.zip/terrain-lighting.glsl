precision highp float;
in vec3 p,n;in float water;uniform vec3 camera;uniform float exposure,uMapAir;out vec4 O;
vec3 hkFilm(vec3 c){c=max(c*exposure,0.);c=c*(2.51*c+.03)/(c*(2.43*c+.59)+.14);return pow(clamp(c,0.,1.),vec3(1./2.2));}
void main(){
 vec3 N=normalize(n);float h=max(p.y,0.);
 // Low-frequency ground cover only: no tree instances and no invented trees.
 vec3 c=mix(vec3(.185,.205,.123),vec3(.083,.133,.077),smoothstep(15.,350.,h));c=mix(c,vec3(.19,.195,.157),smoothstep(450.,950.,h));
 if(water>1.5)c=vec3(.075,.145,.16);
 vec3 ambient=(vec3(.07)+sky(normalize(vec3(N.x*.25,.95,N.z*.25)))*.32)*uLight.y;
 vec3 direct=uSunColor*uDay*uLight.x*max(0.,dot(N,normalize(uSun)))*.70;
 c*=ambient+direct;
 vec3 v=p-camera;float haz=(1.-exp(-length(v)*.001*(.018+uWeather.y*.05+uLight.w*.022)))*uMapAir;
 vec3 horizon=sky(normalize(vec3(v.x,.006*max(length(v.xz),.001),v.z)));
 c=mix(c,horizon,clamp(haz,0.,.68));O=vec4(hkFilm(c),1.);
}
