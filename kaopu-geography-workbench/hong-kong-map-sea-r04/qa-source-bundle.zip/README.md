# Hong Kong map R04 — station-level review candidate

R03 remains the comparison release. This independent case keeps the same north-aligned story bounds and fictional route/terrain decisions.

## What is present
- Existing Ocean Mother V001 24 displaced Gerstner waves plus 12 micro-wave normals; same frozen numerical source. The display sampling grid and geographic clipping were repaired.
- Water covers the complement of the actual rendered background/detail triangles. Exposed DEM edges have a vertical display closure; wet/dark response follows the existing wave height, without a new tide model. This closure is not surveyed sea-wall or bathymetry data.
- Existing Weather Mother source, shared sunlight color, exposure and ACES/gamma. Clear-map and atmospheric comparison controls change display visibility; no second weather engine.
- The rejected fuzzy distant canopy trial is no longer allocated or drawn.
- Frozen Kowloon R05 B original building members, six native 1.435m-gauge track axes, 56E1 profiles, sleepers, plates, buffer stops and the source freight siding. No invented turnout/throat or engineered six-to-one connection.
- Six 52-degree perspective station cameras; 1.6m eye above the original .85m deck. Four platforms and the hollow hall connect through actual source openings. WASD viewer movement uses a conservative .2m nav grid and whole-displacement checks; this does not replace the game production collision/physics system. Overview route/boundary annotations are hidden in these close cameras.
- Separate source-axis railway camera, x=-25m, z=-215…-18m, eye 1.6m over the .086m rail crown. It is a director camera, not permission for pedestrian track access.
- Near materials call the unchanged frozen-B mother functions at fragments with live station-local camera and pixel footprint. Far materials are paired numerical samples of the same functions. Finite mesh geometry, one-step normal projection, partial mother filtering and an approximate host BRDF remain display limitations; this is not a mesh-free engine or final art acceptance.

## Source and design boundaries
- 30m Copernicus DSM background. Five CEDD source windows: native .5m sources, 2m/5m runtime levels, 7.61838525 km² valid source coverage. Not full-corridor .5m.
- Source rasters and frozen mother modules are unchanged. Minimum display grading is confined to the source track bed/siding with short edge transitions. Parameters and volume integration are in data/station-ground-grading.json.
- Station source SI metres and map scale remain 1. Authored base height 3.90m and eastward station orientation are not a surveyed historic registration.
- Original forecourt, tower interior and lower steps are not offered as walkable areas. One original oculus glass surface remains deferred. Other geographic stations are planning layouts, and route lines are conceptual rather than engineered alignments.
- User reference photographs are not in the runtime, source archive or public assets.

## Evidence
The QA source archive is hash-checked before extraction. CPU source locks, native rail checks, metric navigation, original component/material GPU comparisons, independently compiled near-fragment comparisons and real HTTP perspective screenshots are separate stages. Browser evidence names SwiftShader explicitly; it cannot establish native-device frame rate or user visual acceptance. Runtime payload sizes and JavaScript heap are recorded separately from GPU memory.

## Current review limits
The second assembly test reached all six real station views and five continuous paths on desktop and mobile. Its four-metre lateral-travel assertion was invalid for an off-centre camera on a 6.8m-wide platform; the replacement records every applied sweep and checks the actual platform/body boundary. Near rendering is being tested with an unchanged-mother, conservative same-frame depth prepass. It is not accepted on timing or appearance until the separate A/B and browser evidence passes. Brick side-face striping, flat-looking stone pieces and the finite-mesh/normal limits remain near-art review items.
