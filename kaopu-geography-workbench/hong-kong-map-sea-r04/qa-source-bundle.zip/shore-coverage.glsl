uniform sampler2D uHKMask;
uniform highp sampler2DArray uHKDetailMask;
uniform vec4 uHKBbox,uHKDetailRect[5],uHKDetailMeta[10];
uniform vec2 uHKDetailSize[10];
uniform int uHKDetailPick[5];
bool hkBaseLand(vec2 xz){
 vec2 q=(xz-uHKBbox.xy)/30.;ivec2 size=textureSize(uHKMask,0),a=clamp(ivec2(floor(q)),ivec2(0),size-2);vec2 f=q-vec2(a);
 ivec2 b,c;if(f.x+f.y<=1.){b=a+ivec2(0,1);c=a+ivec2(1,0);}else{b=a+ivec2(1,0);c=a+ivec2(0,1);a+=ivec2(1,1);}
 return texelFetch(uHKMask,a,0).r>.001&&texelFetch(uHKMask,b,0).r>.001&&texelFetch(uHKMask,c,0).r>.001;
}
bool hkDetailLand(vec2 xz,int layer){
 vec4 m=uHKDetailMeta[layer];vec2 q=(xz-m.xy)/m.z;ivec2 a=clamp(ivec2(floor(q)),ivec2(0),ivec2(uHKDetailSize[layer])-2);vec2 f=q-vec2(a);
 ivec2 b,c;if(f.x+f.y<=1.){b=a+ivec2(0,1);c=a+ivec2(1,0);}else{b=a+ivec2(1,0);c=a+ivec2(0,1);a+=ivec2(1,1);}
 return texelFetch(uHKDetailMask,ivec3(a,layer),0).r>.001&&texelFetch(uHKDetailMask,ivec3(b,layer),0).r>.001&&texelFetch(uHKDetailMask,ivec3(c,layer),0).r>.001;
}
bool hkRenderedLand(vec2 xz){
 for(int k=0;k<5;k++){vec4 r=uHKDetailRect[k];if(xz.x>r.x&&xz.y>r.y&&xz.x<r.x+r.z&&xz.y<r.y+r.w)return hkDetailLand(xz,uHKDetailPick[k]);}
 return hkBaseLand(xz);
}
