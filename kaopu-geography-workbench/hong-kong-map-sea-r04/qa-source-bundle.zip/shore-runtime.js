// Close vertical exposed boundaries of the rendered land mesh. This is a display
// closure of the DEM sample edge, not a claim about a surveyed sea wall/bathymetry.
function shoreMeshFor(l,isBase=false){
 const w=l.width,h=l.height,mask=l.mask,H=l.heights,step=l.step,x0=isBase?hkBox[0]:l.x0-HK.origin[0],z0=isBase?hkBox[1]:HK.origin[1]-l.y0;
 const v=[],ix=[];let edges=0;
 const tri=(c,r,t)=>{if(c<0||r<0||c>=w-1||r>=h-1)return false;const j=r*w+c;return(t?[j+1,j+w,j+w+1]:[j,j+w,j+1]).every(k=>mask[k]!==0&&Number.isFinite(H[k]));};
 const edge=(a,b)=>{let ax=x0+(a%w)*step,az=z0+Math.floor(a/w)*step,bx=x0+(b%w)*step,bz=z0+Math.floor(b/w)*step;if(isBase&&insideDetail((ax+bx)/2,(az+bz)/2))return;let nx=-(bz-az),nz=bx-ax,len=Math.hypot(nx,nz),base=v.length/7;nx/=len;nz/=len;const ya=H[a],yb=H[b],bottom=Math.min(-3,ya-3,yb-3);for(let q of[[ax,ya,az],[bx,yb,bz],[ax,bottom,az],[bx,bottom,bz]])v.push(...q,nx,0,nz,0);ix.push(base,base+1,base+2,base+2,base+1,base+3);edges++;};
 for(let r=0;r<h-1;r++)for(let c=0;c<w-1;c++){const j=r*w+c,a=tri(c,r,0),b=tri(c,r,1);
  // Do not turn the outer study boundary or patch clipping edge into a shoreline.
  if(a){if(c>0&&!tri(c-1,r,1))edge(j,j+w);if(!b)edge(j+w,j+1);if(r>0&&!tri(c,r-1,1))edge(j+1,j);}
  if(b){if(!a)edge(j+1,j+w);if(r<h-2&&!tri(c,r+1,0))edge(j+w,j+w+1);if(c<w-2&&!tri(c+1,r,0))edge(j+w+1,j+1);}
 }
 const mesh=hkMesh(new Float32Array(v),ix,7);return{...mesh,edges,bytes:v.length*4+ix.length*4};
}
const shoreBase=shoreMeshFor({width:HK.width,height:HK.height,mask:hkMask,heights:hkHeights,step:HK.step},true);
for(const p of detailPatches)for(const l of Object.values(p.levels))l.shore=shoreMeshFor(l);
const shoreFS=atmosphere+`precision highp float;in vec3 p,n;uniform vec3 camera;uniform vec4 uWaveK[24],uWaveA[24];uniform float tSea,exposure;out vec4 O;
void main(){float wh=0.;for(int j=0;j<24;j++){vec4 k=uWaveK[j],a=uWaveA[j];wh+=a.x*sin(dot(k.xy,p.xz)*k.z-k.w*tSea+a.z);}float wet=1.-smoothstep(wh+.05,wh+.85,p.y);
vec3 N=normalize(n),c=mix(vec3(.105,.113,.083),vec3(.025,.042,.037),wet);
c*=vec3(.16)*uLight.y+uSunColor*uDay*uLight.x*max(0.,dot(N,normalize(uSun)))*.55;
c=max(c*exposure,0.);c=c*(2.51*c+.03)/(c*(2.43*c+.59)+.14);O=vec4(pow(clamp(c,0.,1.),vec3(1./2.2)),1.);}`;
const shoreProgram=program(hkVS,shoreFS);
function drawShore(now,s,e,c){common(shoreProgram,now,s,e,c);gl.uniform4fv(loc(shoreProgram,'uWaveK[0]'),currentK);gl.uniform4fv(loc(shoreProgram,'uWaveA[0]'),currentA);const meshes=[shoreBase,...detailPatches.map(p=>p.levels[selectedDetail(p,c)].shore)];for(const m of meshes){gl.bindVertexArray(m.vao);gl.drawElements(gl.TRIANGLES,m.count,gl.UNSIGNED_INT,0);}qa.shoreClosureEdges=meshes.reduce((a,m)=>a+m.edges,0);qa.shoreWetness='elevation relative to existing 24-wave height; no added tide';}
