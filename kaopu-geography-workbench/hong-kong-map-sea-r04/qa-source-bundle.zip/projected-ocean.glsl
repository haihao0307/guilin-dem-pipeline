// Same 24-layer Gerstner wave function; only sampling geometry is changed.
// Expanded perspective rays cover the visible sea plane even below/behind the camera.
vec2 mapSeaPoint(vec2 uv){
 vec2 ndc=(uv*2.-1.)*1.13;
 vec3 ray=fw+right*ndc.x*tanFov*aspect+up*ndc.y*tanFov;
 float dy=min(ray.y,-.00001), t=min(max(camera.y,.15)/(-dy),57000./max(length(ray.xz),.001));
 return camera.xz+ray.xz*t;
}
void main(){vec2 xz=mapSeaPoint(grid);vec3 p=vec3(xz.x,0.,xz.y),dx=vec3(1,0,0),dz=vec3(0,0,1);
float rowSpan=max(.06,length(mapSeaPoint(grid+vec2(0.,1./gridRows))-xz)),c=0.;
