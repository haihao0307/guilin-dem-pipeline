// Coverage is exactly complementary to the currently rendered land triangles.
// No nearest-mask half-cell shift, and no fictional inland water filling.
const hkMaskLayers=detailPatches.flatMap(p=>[p.levels['5'],p.levels['2']]);
const hkMaskLayerW=Math.max(...hkMaskLayers.map(l=>l.width)),hkMaskLayerH=Math.max(...hkMaskLayers.map(l=>l.height));
const hkDetailMaskTex=gl.createTexture();gl.activeTexture(gl.TEXTURE0+7);gl.bindTexture(gl.TEXTURE_2D_ARRAY,hkDetailMaskTex);gl.pixelStorei(gl.UNPACK_ALIGNMENT,1);
gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
gl.texStorage3D(gl.TEXTURE_2D_ARRAY,1,gl.R8,hkMaskLayerW,hkMaskLayerH,hkMaskLayers.length);
for(let k=0;k<hkMaskLayers.length;k++){let l=hkMaskLayers[k];gl.texSubImage3D(gl.TEXTURE_2D_ARRAY,0,0,0,k,l.width,l.height,1,gl.RED,gl.UNSIGNED_BYTE,l.mask);}
const hkDetailMeta=new Float32Array(hkMaskLayers.flatMap(l=>[l.x0-HK.origin[0],HK.origin[1]-l.y0,l.step,0]));
const hkDetailSizes=new Float32Array(hkMaskLayers.flatMap(l=>[l.width,l.height]));
const hkDetailRects=new Float32Array(detailPatches.flatMap(p=>rectLocal(p)));
function selectedDetail(p,c){const b=rectLocal(p);return Math.hypot(c.cam[0]-b[0]-b[2]/2,c.cam[2]-b[1]-b[3]/2,c.cam[1])<6000?'2':'5';}
function bindCoverage(p,c){
 gl.activeTexture(gl.TEXTURE0+6);gl.bindTexture(gl.TEXTURE_2D,hkMaskTex);i(p,'uHKMask',6);v4(p,'uHKBbox',hkBox);
 gl.activeTexture(gl.TEXTURE0+7);gl.bindTexture(gl.TEXTURE_2D_ARRAY,hkDetailMaskTex);i(p,'uHKDetailMask',7);
 gl.uniform4fv(loc(p,'uHKDetailMeta[0]'),hkDetailMeta);gl.uniform2fv(loc(p,'uHKDetailSize[0]'),hkDetailSizes);gl.uniform4fv(loc(p,'uHKDetailRect[0]'),hkDetailRects);
 gl.uniform1iv(loc(p,'uHKDetailPick[0]'),new Int32Array(detailPatches.map((q,k)=>k*2+(selectedDetail(q,c)==='2'?1:0))));
 qa.waterCoverage='complement of actual coarse/detail land triangles';qa.waterGrid='perspective projected screen grid';qa.depthConvention='log2(1+viewZ)/log2(60001), near .05m';
}
function landTriangleAt(x,z,c){
 let l=null;for(const p of detailPatches){const b=rectLocal(p);if(x>b[0]&&z>b[1]&&x<b[0]+b[2]&&z<b[1]+b[3]){l=p.levels[selectedDetail(p,c)];break;}}
 let w=l?.width||HK.width,h=l?.height||HK.height,step=l?.step||HK.step,x0=l?l.x0-HK.origin[0]:hkBox[0],z0=l?HK.origin[1]-l.y0:hkBox[1],mask=l?.mask||hkMask;
 let q=(x-x0)/step,t=(z-z0)/step,a=Math.max(0,Math.min(w-2,Math.floor(q))),b=Math.max(0,Math.min(h-2,Math.floor(t))),j=b*w+a;
 return (q-a+t-b<=1?[j,j+w,j+1]:[j+1,j+w,j+w+1]).every(k=>mask[k]!==0);
}
