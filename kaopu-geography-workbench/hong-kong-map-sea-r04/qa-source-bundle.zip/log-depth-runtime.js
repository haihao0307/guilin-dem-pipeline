// One depth convention for sea, terrain, railway, buildings and planning overlays.
// Linear clip near remains 5cm; logarithmic depth prevents far sea/terrain z-fighting.
function hkDepthShaders(v,f){
 if(!v.includes('near=.15,far=60000.'))return [v,f];
 v=v.replace('near=.15,far=60000.','near=.05,far=60000.').replace('void main(){','out highp float hkViewDepth;\nvoid main(){').replace(/gl_Position=/g,'hkViewDepth=z;gl_Position=');
 f=f.replace('void main(){','in highp float hkViewDepth;\nvoid main(){gl_FragDepth=log2(1.+max(hkViewDepth,0.))/log2(60001.);');
 return [v,f];
}
