// R04 fixed-height station camera. Inline inside the existing map module.
// No renderer, station geometry or global scale changes. dt is in seconds.
const directorState={active:false,bound:false,kind:'walk-camera',eye:[0,6.35,0],yaw:0,pitch:0,fov:52,near:.05,preset:null,path:null,rail:null,lastPath:null,keys:new Set(),drag:null,blockedMoves:0,acceptedMoves:0,error:null,notice:null};
let directorNav=null;
const directorPresets=new Map(),directorPaths=new Map();
const directorClamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const directorDistance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]);
const directorLerp=(a,b,t)=>a.map((x,i)=>x+(b[i]-x)*t);
const directorLocalToMap=p=>[1477.171-(p[2]-4),3.90+p[1],9824.015+(p[0]-24)];
const directorMapToLocal=p=>[p[2]-9824.015+24,p[1]-3.90,4-(p[0]-1477.171)];
// Separately authorized source-axis camera, never an extension of the walk nav.
const directorRailSpec=Object.freeze({id:'rail-source-x-minus25',x:-25,startZ:-215,endZ:-18,railCrownY:.086,eyeLocalY:1.686,lookLocalY:2.5,speedMps:6,lengthM:197,gaugeM:1.435,sourceBackZ:-221,sourceFrontZ:-8,bufferZ:-10.8});
// Undefined preserves standalone/test compatibility; only an explicit host
// failure closes both walking and rail cameras, regardless of valid nav data.
const directorStationAvailable=()=>mapState.stationAvailable!==false;
const directorIsActive=()=>directorStationAvailable()&&directorState.active&&mapState.mode==='director';
const directorRailButtons=()=>new Set([...document.querySelectorAll('[data-rail-director]'),document.querySelector('#stationTrackRide')].filter(Boolean));
try{
 const {createStationWalkNav}=await import('./interior-audit/station-walk-nav.mjs');
 if(!window.HK_WALK_DATA||!window.HK_CAMERA_DATA?.presets||!window.HK_PATH_DATA?.paths)throw Error('站内米制相机或走行数据缺失');
 directorNav=createStationWalkNav(window.HK_WALK_DATA);
 for(const p of window.HK_CAMERA_DATA.presets){
  const eye=(p.eyeMap??directorNav.localToMap(p.eye)).slice(),target=(p.targetMap??directorNav.localToMap(p.target)).slice();
  if(!directorNav.isAllowedMap(eye))throw Error('相机不在已验走行区：'+p.id);
  directorPresets.set(p.id,{...p,eye,target});
 }
 for(const p of window.HK_PATH_DATA.paths){
  const points=(p.eyeMap??p.eye.map(directorNav.localToMap)).map(a=>a.slice()),target=(p.targetMap??directorNav.localToMap(p.target)).slice();
  if(points.length<2||!points.every(directorNav.isAllowedMap))throw Error('镜头路径不在已验走行区：'+p.id);
  for(let j=1;j<points.length;j++)if(!directorNav.canMoveMap(points[j-1],points[j]))throw Error('镜头路径跨过阻挡：'+p.id);
  const lengths=points.slice(1).map((p,i)=>directorDistance(points[i],p));
  directorPaths.set(p.id,{...p,points,target,lengths,total:lengths.reduce((a,b)=>a+b,0)});
 }
}catch(error){directorState.error=String(error?.message??error);directorNav=null;}
function directorAim(target){
 const d=target.map((x,i)=>x-directorState.eye[i]),len=Math.hypot(...d);
 if(len>1e-9){directorState.yaw=Math.atan2(d[0],-d[2]);directorState.pitch=directorClamp(Math.asin(d[1]/len),-1.30,1.30);}
}
function getDirectorState(){
 const p=directorState.path,r=directorState.rail,rail=directorState.kind==='rail-camera';
 return{available:directorStationAvailable()&&!!directorNav,walkAvailable:directorStationAvailable()&&!!directorNav,railAvailable:directorStationAvailable(),stationAvailable:directorStationAvailable(),error:directorStationAvailable()?directorState.error:'车站数据未加载，近景不可用',notice:directorState.notice,active:directorIsActive(),mode:directorIsActive()?'director':'orbit',kind:directorState.kind,preset:directorState.preset,eyeMap:directorState.eye.slice(),eyeLocal:directorMapToLocal(directorState.eye),eyeHeightM:1.6,bodyRadiusM:rail?null:.30,bodyHeightM:rail?null:1.80,speedMps:rail?6:1.4,fovDegrees:directorState.fov,nearM:directorState.near,path:p?{key:p.definition.id,progress:p.definition.total?p.travelled/p.definition.total:1,paused:p.paused}:r?.playing?{key:directorRailSpec.id,progress:r.distance/directorRailSpec.lengthM,paused:r.paused,kind:'rail-camera'}:null,rail:r?{...directorRailSpec,distanceM:r.distance,progress:r.distance/directorRailSpec.lengthM,playing:r.playing,paused:r.paused,walkNavUsed:false,pedestrianReachabilityClaim:false}:null,lastPath:directorState.lastPath,blockedMoves:directorState.blockedMoves,acceptedMoves:directorState.acceptedMoves,modelScale:1};
}
function directorPublish(){
 qa.director=getDirectorState();
 document.body?.classList.toggle('director',directorIsActive());
 for(const el of document.querySelectorAll('[data-director-view]')){el.classList.toggle('active',directorIsActive()&&directorState.preset===el.dataset.directorView);el.disabled=!directorStationAvailable()||!directorNav;}
 for(const el of document.querySelectorAll('[data-director-path]'))el.disabled=!directorStationAvailable()||!directorNav||!directorPaths.has(el.dataset.directorPath);
 for(const el of directorRailButtons())el.disabled=!directorStationAvailable();
 const status=document.querySelector('[data-director-status]');
 if(status)status.textContent=!directorStationAvailable()?'车站数据未加载，近景不可用':directorState.error?'站内相机不可用：'+directorState.error:!directorIsActive()?'选择站内镜头':directorState.notice??(directorState.kind==='rail-camera'?(directorState.rail?.playing?(directorState.rail.paused?'已暂停 · ':'巡视中 · 6 m/s · '):'停留 · ')+'轨道导演镜头 · 非步行模式':directorState.path?(directorState.path.paused?'已暂停 · ':'播放 · ')+directorState.path.definition.label:'眼高 1.6 m · WASD 步行 · 拖动看向');
 needFrame=true;
}
function directorActivate(eye,target,preset=null){
 if(!directorStationAvailable()||!directorNav||!directorNav.isAllowedMap(eye))return false;
 directorState.active=true;directorState.kind='walk-camera';directorState.rail=null;directorState.notice=null;mapState.mode='director';directorState.eye=eye.slice();directorState.eye[1]=directorNav.eyeMapY;
 directorState.preset=preset;directorState.path=null;directorState.keys.clear();directorState.drag=null;directorState.fov=52;directorState.near=.05;directorState.error=null;
 directorAim(target);directorPublish();return true;
}
function focusDirector(key){
 if(!directorStationAvailable()){directorPublish();return false;}
 const p=directorPresets.get(key);if(!p||!directorNav)return false;
 if(!directorActivate(p.eye,p.target,p.id))return false;
 directorState.fov=p.verticalFovDegrees??52;directorState.near=.05;directorState.lastPath=null;directorPublish();return true;
}
function startDirectorPath(key){
 if(!directorStationAvailable()){directorPublish();return false;}
 const p=directorPaths.get(key);if(!p||!directorNav)return false;
 // Starting another shot is an explicit cut to its audited start, never a flight
 // through intervening walls. Movement within the shot is continuous and checked.
 if(!directorActivate(p.points[0],p.target))return false;
 directorState.path={definition:p,segment:0,offset:0,travelled:0,paused:false,manualLook:false};
 directorState.lastPath={key:p.id,status:'playing',startMode:'cut-to-certified-start'};directorPublish();return true;
}
function startRailDirector(){
 if(!directorStationAvailable()){directorPublish();return false;}
 directorState.active=true;directorState.kind='rail-camera';mapState.mode='director';directorState.eye=directorLocalToMap([directorRailSpec.x,directorRailSpec.eyeLocalY,directorRailSpec.startZ]);
 directorState.preset=null;directorState.path=null;directorState.keys.clear();directorState.drag=null;directorState.fov=52;directorState.near=.05;directorState.error=null;directorState.notice=null;
 directorState.rail={distance:0,playing:true,paused:false,manualLook:false};directorState.lastPath={key:directorRailSpec.id,status:'playing',kind:'rail-camera',startMode:'cut-to-source-axis-start'};
 directorAim(directorLocalToMap([directorRailSpec.x,directorRailSpec.lookLocalY,directorRailSpec.startZ+30]));directorPublish();return true;
}
function stopDirectorPath(){
 if(directorState.rail){directorState.rail.playing=false;directorState.lastPath={key:directorRailSpec.id,status:'stopped',kind:'rail-camera',progress:directorState.rail.distance/directorRailSpec.lengthM};}
 if(directorState.path)directorState.lastPath={key:directorState.path.definition.id,status:'stopped',progress:directorState.path.travelled/directorState.path.definition.total};
 directorState.path=null;directorPublish();
}
function pauseDirectorPath(paused=true){if(directorState.kind==='rail-camera'&&directorState.rail?.playing){directorState.rail.paused=!!paused;directorPublish();return true;}if(!directorState.path)return false;directorState.path.paused=!!paused;directorPublish();return true;}
function exitDirector(viewKey){
 const wasActiveRail=directorIsActive()&&directorState.kind==='rail-camera';
 if(viewKey===undefined&&wasActiveRail)viewKey='overview';
 // Clear the mode before invoking the host: mapFocus itself may call
 // exitDirector() again. null is an explicit no-refocus request for host calls.
 directorState.active=false;directorState.kind='walk-camera';directorState.keys.clear();directorState.drag=null;directorState.path=null;directorState.rail=null;directorState.notice=null;mapState.mode='orbit';directorPublish();
 if(typeof viewKey==='string'&&typeof mapFocus==='function')mapFocus(viewKey);
 return true;
}
function directorCamera(){
 if(!directorIsActive())return null;
 const sy=Math.sin(directorState.yaw),cy=Math.cos(directorState.yaw),sp=Math.sin(directorState.pitch),cp=Math.cos(directorState.pitch);
 return{cam:directorState.eye.slice(),fw:[sy*cp,sp,-cy*cp],right:[cy,0,sy],up:[-sy*sp,cp,cy*sp],flat:[sy,0,-cy],fov:directorState.fov,near:directorState.near,far:60000,mode:'director',kind:directorState.kind};
}
function directorTryMove(target){
 target[1]=directorNav.eyeMapY;
 const next=directorNav.tryMoveMap(directorState.eye,target),accepted=directorDistance(next,target)<1e-8;
 if(accepted){directorState.eye=next;directorState.acceptedMoves++;}else directorState.blockedMoves++;
 return accepted;
}
function tickDirector(dt){
 if(!directorStationAvailable()&&directorState.active){exitDirector(null);return false;}
 if(!directorIsActive()){directorState.keys.clear();if(directorState.active){directorState.active=false;directorState.path=null;directorState.rail=null;directorState.drag=null;directorPublish();}return false;}
 if(!Number.isFinite(dt)||dt<=0||document.hidden)return false;
 // Resume stalls do not produce giant steps. During normal frames speed is
 // exactly 1.4m/s; caller supplies elapsed seconds, not milliseconds.
 dt=Math.min(dt,.10);
 if(directorState.kind==='rail-camera'){
  const r=directorState.rail;if(!r||!r.playing||r.paused)return false;
  r.distance=Math.min(directorRailSpec.lengthM,r.distance+directorRailSpec.speedMps*dt);
  const z=directorRailSpec.startZ+r.distance;
  directorState.eye=directorLocalToMap([directorRailSpec.x,directorRailSpec.eyeLocalY,z]);
  if(!r.manualLook)directorAim(directorLocalToMap([directorRailSpec.x,directorRailSpec.lookLocalY,z+30]));
  if(r.distance>=directorRailSpec.lengthM-1e-9){r.playing=false;directorState.lastPath={key:directorRailSpec.id,status:'completed',kind:'rail-camera',progress:1};}
  directorPublish();return true;
 }
 const k=directorState.keys,forward=(k.has('KeyW')?1:0)-(k.has('KeyS')?1:0),side=(k.has('KeyD')?1:0)-(k.has('KeyA')?1:0);
 if(forward||side){
  if(directorState.path)stopDirectorPath();
  const c=directorCamera(),len=Math.hypot(forward,side),step=1.4*dt/len;
  const target=[directorState.eye[0]+(c.flat[0]*forward+c.right[0]*side)*step,directorNav.eyeMapY,directorState.eye[2]+(c.flat[2]*forward+c.right[2]*side)*step];
  directorTryMove(target);directorPublish();return true;
 }
 const pathState=directorState.path;
 if(!pathState||pathState.paused)return false;
 const p=pathState.definition;let remaining=Math.min(1.4,Number.isFinite(p.speedMps)&&p.speedMps>0?p.speedMps:1.15)*dt;
 while(remaining>1e-10&&pathState.segment<p.lengths.length){
  const j=pathState.segment,length=p.lengths[j];
  if(length<1e-10){pathState.segment++;pathState.offset=0;continue;}
  const move=Math.min(remaining,length-pathState.offset),offset=pathState.offset+move,target=directorLerp(p.points[j],p.points[j+1],offset/length);
  // Check each piece separately at bends. Joining a frame's final point by a
  // chord could cut through a corner even when the authored polyline is safe.
  if(!directorTryMove(target)){directorState.lastPath={key:p.id,status:'blocked',segment:j};directorState.path=null;directorState.error='镜头前进被走行边界阻挡';directorPublish();return false;}
  pathState.offset=offset;pathState.travelled+=move;remaining-=move;
  if(offset>=length-1e-9){pathState.segment++;pathState.offset=0;}
 }
 if(!pathState.manualLook)directorAim(p.target);
 if(pathState.segment>=p.lengths.length){directorState.lastPath={key:p.id,status:'completed',progress:1};directorState.path=null;}
 directorPublish();return true;
}
function bindDirectorControls(){
 installDirectorAPI();if(directorState.bound)return false;directorState.bound=true;
 const typing=target=>!!target&&(target.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName||''));
 const stop=e=>{e.preventDefault();e.stopImmediatePropagation?.();};
 window.addEventListener('keydown',e=>{
  if(!directorIsActive()||typing(e.target))return;
  if(['KeyW','KeyA','KeyS','KeyD'].includes(e.code)){stop(e);if(directorState.kind==='rail-camera'){directorState.notice='轨道镜头不支持步行，请先选择站台镜头';directorPublish();return;}directorState.keys.add(e.code);needFrame=true;}
  else if(e.code==='Escape'){stop(e);exitDirector();}
 },true);
 window.addEventListener('keyup',e=>{if(['KeyW','KeyA','KeyS','KeyD'].includes(e.code)){const had=directorState.keys.delete(e.code);if(directorIsActive()&&had)stop(e);}},true);
 window.addEventListener('blur',()=>{directorState.keys.clear();directorState.drag=null;});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){directorState.keys.clear();directorState.drag=null;}});
 canvas.addEventListener('pointerdown',e=>{
  if(!directorIsActive())return;stop(e);if(e.button!==0)return;
  directorState.drag={id:e.pointerId,x:e.clientX,y:e.clientY};canvas.setPointerCapture?.(e.pointerId);
 },true);
 canvas.addEventListener('pointermove',e=>{
  if(!directorIsActive())return;stop(e);const d=directorState.drag;if(!d||d.id!==e.pointerId)return;
  directorState.yaw-=(e.clientX-d.x)*.003;directorState.pitch=directorClamp(directorState.pitch-(e.clientY-d.y)*.003,-1.30,1.30);d.x=e.clientX;d.y=e.clientY;
  if(directorState.path)directorState.path.manualLook=true;if(directorState.rail)directorState.rail.manualLook=true;directorPublish();
 },true);
 const endDrag=e=>{if(directorIsActive())stop(e);if(!directorState.drag||directorState.drag.id!==e.pointerId)return;directorState.drag=null;if(canvas.hasPointerCapture?.(e.pointerId))canvas.releasePointerCapture(e.pointerId);};
 canvas.addEventListener('pointerup',endDrag,true);canvas.addEventListener('pointercancel',endDrag,true);
 canvas.addEventListener('lostpointercapture',()=>{directorState.drag=null;},true);
 canvas.addEventListener('wheel',e=>{if(directorIsActive())stop(e);},{capture:true,passive:false});
 canvas.addEventListener('contextmenu',e=>{if(directorIsActive())stop(e);},true);
 for(const el of document.querySelectorAll('[data-director-view]'))el.addEventListener('click',()=>focusDirector(el.dataset.directorView));
 for(const el of document.querySelectorAll('[data-director-path]'))el.addEventListener('click',()=>startDirectorPath(el.dataset.directorPath));
 for(const el of document.querySelectorAll('[data-director-exit]'))el.addEventListener('click',()=>exitDirector(el.dataset.directorExit||undefined));
 for(const el of document.querySelectorAll('[data-director-stop]'))el.addEventListener('click',()=>stopDirectorPath());
 for(const el of directorRailButtons()){el.disabled=!directorStationAvailable();el.textContent='沿源轨道巡视 ▶';el.title='x=-25m，z=-215至-18m；导演摄像机，非步行路线';el.addEventListener('click',()=>startRailDirector());}
 directorPublish();return true;
}
function installDirectorAPI(){
 const api={focusDirector,startDirectorPath,startRailDirector,stopDirectorPath,pauseDirectorPath,exitDirector,directorCamera,tickDirector,bindDirectorControls,getDirectorState};
 window.HKDirector=api;Object.assign(window.HKMap??={},api);return api;
}
installDirectorAPI();directorPublish();
