#!/usr/bin/env python3
"""Run bounded near-fragment or rail material QA over HTTP, never file://."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import threading
import time
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]

class QuietHandler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, '.mjs': 'text/javascript', '.wgsl': 'text/plain', '.frag': 'text/plain'}
    def log_message(self, *_):
        pass

@contextmanager
def local_server():
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(ROOT)))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}/'
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)

def browser_options():
    options = {'headless': True, 'args': ['--no-sandbox', '--disable-gpu-watchdog', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--enable-precise-memory-info']}
    if os.environ.get('STATION_CHROMIUM_PATH'):
        options['executable_path'] = os.environ['STATION_CHROMIUM_PATH']
    return options

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('probe', choices=['near', 'rail'])
    args = parser.parse_args()
    relative = 'station-integration/near-material/qa/probe.html?naga=1' if args.probe == 'near' else 'qa/rail-probe.html'
    output = ROOT / 'qa' / f'GPU_{args.probe.upper()}_QA.json'
    report = {'status': 'running', 'probe': args.probe, 'commit': os.environ.get('GITHUB_SHA'), 'physicalGpuTested': False, 'sceneVisualAcceptance': False,
              'scope': 'Bounded RGBA32F numeric regression on Chromium SwiftShader; no native GPU or realtime claim', 'errors': [], 'consoleErrors': []}
    save = lambda: output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    save()
    try:
        with local_server() as base, sync_playwright() as p:
            browser = p.chromium.launch(**browser_options())
            try:
                page = browser.new_page(viewport={'width': 1000, 'height': 700})
                page.route('**/favicon.ico', lambda route: route.fulfill(status=204))
                page.on('pageerror', lambda e: report['errors'].append(str(e)))
                page.on('console', lambda m: report['consoleErrors'].append(m.text) if m.type == 'error' else None)
                report['url'] = base + relative
                started = time.monotonic()
                page.goto(report['url'], wait_until='domcontentloaded', timeout=60000)
                page.wait_for_function('window.DONE === true', timeout=600000)
                report['result'] = page.evaluate('window.RESULT')
                report['durationSeconds'] = time.monotonic() - started
                result = report['result']
                assert result.get('status') == 'passed', result
                assert not report['errors'], report['errors']
                assert not report['consoleErrors'], report['consoleErrors']
                expected = 31 if args.probe == 'near' else 11
                assert result.get('fixtureCount') == expected, f'Expected {expected} fixtures, got {result.get("fixtureCount")}'
                if args.probe == 'near':
                    assert result.get('naga') is True, 'Near probe did not use the independently compiled Naga entry'
                    assert result.get('totalSamples') == 744, 'Near probe must cover 31 × 4 pixels × 2 eyes × 3 ages'
                report['status'] = 'passed'
            finally:
                browser.close()
    except Exception as error:
        report['status'] = 'failed'
        report['error'] = str(error)
    finally:
        save()
        print(json.dumps({'probe': args.probe, 'status': report['status'], 'durationSeconds': report.get('durationSeconds'), 'error': report.get('error')}, ensure_ascii=False), flush=True)
    return 0 if report['status'] == 'passed' else 1

if __name__ == '__main__':
    raise SystemExit(main())
