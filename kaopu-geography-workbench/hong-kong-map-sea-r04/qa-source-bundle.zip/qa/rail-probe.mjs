/** 11 original rail candidates, independently Naga-compiled query versus pinned B mother GLSL.
 * The source CPU tests establish recorder metadata. This checks numeric material transport,
 * not a whole-station nearest-member ownership or scene-lighting equivalence claim. */
import {createStationSampler} from '../station-integration/material-sampler.mjs';

export async function run(){
 const response=await fetch(new URL('../station-integration/qa/RAIL-PROBE-FIXTURES.json',import.meta.url));
 if(!response.ok)throw Error('Rail fixtures HTTP '+response.status);
 const {fixtures,sourceCommit}=await response.json();
 if(fixtures.length!==11)throw Error('Expected exactly eleven original rail fixtures');
 const positions=new Float32Array(fixtures.flatMap(f=>f.position));
 const normals=new Float32Array(fixtures.flatMap(f=>f.normal));
 const packedHits=new Float32Array(fixtures.flatMap(({hit:h})=>[...h.q,h.id,...h.extent,h.seed,h.baseD,h.sourceSeed,0,0]));
 const candidates=[];let compiled,reference;
 const fields=['colors','roughness','geometryDistance','matterDistance','materialKey','detail','state'];
 const tolerance=3e-6;
 try{
  compiled=await createStationSampler({maxBatch:32,fragmentURL:new URL('../station-integration/generated/material-query-naga.frag',import.meta.url)});
  reference=await createStationSampler({maxBatch:32,fragmentURL:new URL('../station-integration/generated/material-query-entry-adapted.frag',import.meta.url)});
  const errors=[];let maxAbsError=0;
  for(const footprintM of [.0005,.5])for(const age of [0,.5,1]){
   const input={positions,normals,packedHits,footprintM,age,eye:[9,2.45,-24]};
   const actual=await compiled.sample(input),expected=await reference.sample(input);
   let max=0;
   for(let i=0;i<fixtures.length;i++){
    if(actual.failureFlags[i]||expected.failureFlags[i])errors.push({fixture:fixtures[i].name,actualFailure:actual.failureFlags[i],referenceFailure:expected.failureFlags[i]});
   }
   for(const name of fields){
    const a=actual[name],b=expected[name],width=a.length/fixtures.length;
    for(let i=0;i<a.length;i++){
     const delta=Math.abs(a[i]-b[i]);max=Math.max(max,delta);
     if(!Number.isFinite(a[i])||!Number.isFinite(b[i])||delta>(name==='materialKey'?0:tolerance))errors.push({fixture:fixtures[Math.floor(i/width)].name,field:name,component:i%width,age,footprintM,actual:a[i],expected:b[i],delta});
    }
   }
   maxAbsError=Math.max(maxAbsError,max);
   candidates.push({age,footprintM,samples:fixtures.length,maxAbsError:max,compiledDurationMs:actual.durationMs,referenceDurationMs:expected.durationMs});
  }
  return{status:errors.length?'failed':'passed',sourceCommit,fixtureCount:fixtures.length,totalSamples:candidates.reduce((n,c)=>n+c.samples,0),fixtureNames:fixtures.map(f=>f.name),maxAbsError,tolerance,cases:candidates,errors,
   backend:compiled.backend,compiledQuery:compiled.compile,pinnedMotherReference:reference.compile,
   scope:'Eleven rail/sleeper/bearing/buffer/bed candidates × three ages × two footprints. Identical packed source records; independently Naga-compiled query versus unchanged pinned B mother prefix. No all-station ownership, visual, native GPU or realtime claim.'};
 }finally{compiled?.dispose();reference?.dispose();}
}
