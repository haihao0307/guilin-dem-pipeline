#!/usr/bin/env python3
"""R04 actual perspective assembly QA. Software-rendered screenshots are not art acceptance.

Run without an argument for a loopback HTTP server. An explicit public HTTP(S) URL
is also supported; no automatic publication and no inherited R03 public trigger.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import time
import traceback
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright
from gpu_probe import ROOT, local_server, browser_options

QA = ROOT / 'qa'
PARTIAL = os.environ.get('ALLOW_INCOMPLETE_STATION') == '1'
STAGE_TIMEOUT = 120000
NEAR_TIMEOUT = 420000  # First mother shader compile on a software GPU may be slow.
VIEWPORTS = [('desktop', {'width': 1600, 'height': 1000}), ('mobile', {'width': 844, 'height': 390})]
NAMED_VIEWS = ['overview', 'harbour', 'harboursea', 'lion', 'station2', 'shatin', 'detail', 'taipo']
PRESETS = json.loads((ROOT / 'interior-audit/CAMERA_PRESETS.json').read_text())['presets']
PATHS = json.loads((ROOT / 'interior-audit/CONTINUOUS_PATHS.json').read_text())['paths']


def json_write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def with_query(url, **values):
    s = urlsplit(url)
    q = dict(parse_qsl(s.query)); q.update(values)
    return urlunsplit((s.scheme, s.netloc, s.path, urlencode(q), s.fragment))


def frame_count(page):
    return page.evaluate('window.OceanMother?.qa.completedFrames || 0')


def wait_render(page, previous, timeout=STAGE_TIMEOUT):
    page.wait_for_function('(n) => window.OceanMother?.qa.completedFrames > n', arg=previous, timeout=timeout, polling=100)


def director_state(page):
    return page.evaluate('HKMap.getDirectorState()')


def assert_director(state):
    check(state['available'] and not state['error'], 'Director nav is unavailable: ' + str(state))
    check(state['active'], 'Director camera did not activate')
    check(abs(state['eyeMap'][1] - 6.35) < 1e-5, 'Station walk eye must stay 1.6 m above authored deck')
    check(abs(state['eyeLocal'][1] - 2.45) < 1e-5, 'Local station eye changed datum')
    check(state['eyeHeightM'] == 1.6 and state['modelScale'] == 1, 'Metric eye/model contract changed')
    check(45 <= state['fovDegrees'] <= 60 and abs(state['nearM'] - .05) < 1e-8, 'Perspective/near-plane contract changed')


def diagnostic_metrics(page):
    return page.evaluate('''() => {
      const s=HKMap.getState(), q=s.qa, canvas=document.querySelector('canvas'), gl=canvas?.getContext('webgl2');
      const debug=gl?.getExtension('WEBGL_debug_renderer_info');
      const resources=performance.getEntriesByType('resource').map(r=>({name:r.name,initiatorType:r.initiatorType,
        transferSize:r.transferSize,encodedBodySize:r.encodedBodySize,decodedBodySize:r.decodedBodySize,durationMs:r.duration}));
      const nav=performance.getEntriesByType('navigation')[0];
      return {renderer:gl?gl.getParameter(debug?debug.UNMASKED_RENDERER_WEBGL:gl.RENDERER):null,
        glVersion:gl?.getParameter(gl.VERSION),drawingBuffer:gl?[gl.drawingBufferWidth,gl.drawingBufferHeight]:null,
        performanceMemory:performance.memory?{usedJSHeapSize:performance.memory.usedJSHeapSize,totalJSHeapSize:performance.memory.totalJSHeapSize,jsHeapSizeLimit:performance.memory.jsHeapSizeLimit}:null,
        heapScope:'JS heap only; excludes driver/GPU allocation. Browser may not expose it.',
        resources,resourceDecodedBodyBytes:resources.reduce((n,r)=>n+r.decodedBodySize,0),
        navigation:nav?{encodedBodySize:nav.encodedBodySize,decodedBodySize:nav.decodedBodySize,transferSize:nav.transferSize,durationMs:nav.duration}:null,
        runtimeResourceAccounting:q.resources??null,runtimeMemory:q.memory??null,
        counts:{terrainTriangles:s.terrainTriangles,detailPatches:q.detailPatches,canopyRoots:s.canopyRoots,
          stationVertices:q.kowloonStation?.renderVertices,stationTriangles:q.kowloonStation?.renderTriangles,
          stationComponents:q.kowloonStation?.componentCount,near:q.nearStation??null},
        camera:q.mapCamera,depthConvention:q.depthConvention,lastGLerror:q.lastGLerror};
    }''')


def frame_timing(page):
    """Count only actual completed render frames, never idle requestAnimationFrame ticks."""
    page.evaluate('''() => {
      const start=performance.now(); let previous=start,lastFrame=OceanMother.qa.completedFrames;
      window.__r04FrameTiming={startedMs:start,intervalsMs:[],complete:false,kind:'render completion cadence, not GPU timer query'};
      const tick=()=>{const now=performance.now(),frame=OceanMother.qa.completedFrames;
        if(frame!==lastFrame){__r04FrameTiming.intervalsMs.push(now-previous);previous=now;lastFrame=frame;}
        if(__r04FrameTiming.intervalsMs.length>=8||now-start>=20000){__r04FrameTiming.complete=true;__r04FrameTiming.elapsedMs=now-start;return;}
        requestAnimationFrame(tick);
      }; HKBackgroundSea.play();requestAnimationFrame(tick);
    }''')
    page.wait_for_function('window.__r04FrameTiming.complete', timeout=90000)
    result = page.evaluate('window.__r04FrameTiming')
    page.evaluate('HKBackgroundSea.pause()')
    values = result['intervalsMs'][1:]  # First interval includes the resume boundary.
    result.update({'sampleCount': len(values), 'medianMs': float(np.median(values)) if values else None,
                   'p95Ms': float(np.percentile(values, 95)) if values else None,
                   'physicalGpuTested': False, 'realtimeClaim': False,
                   'limitation': 'SwiftShader/software rendering and browser render-completion cadence; not native GPU time, interactive hardware FPS, or realtime acceptance.'})
    return result


def coverage_mask(page, screenshot):
    """Classify only definite rendered-sea holes, excluding legitimate sky/horizon.

    A magenta pixel is eligible only if its downward ray intersects display y=0
    inside the study bounds and below the 55 km range; the four neighboring
    water-plane points must all be water according to the runtime land triangles.
    This conservative test does not prove every land/shore pixel is correct.
    """
    rgb = np.asarray(Image.open(screenshot).convert('RGB'))
    h, w = rgb.shape[:2]
    coords = [[x, y] for y in range(3, h - 3, 5) for x in range(3, w - 3, 5)]
    samples = page.evaluate('''(coords) => {
      const s=HKMap.getState(),c=s.qa.mapCamera,H=window.HK_MAP_DATA;
      if(!c||!H||typeof HKMap.landTriangleAt!=='function')throw Error('Missing coverage camera or triangle classifier');
      const canvas=document.querySelector('canvas'),W=innerWidth,Hh=innerHeight,tan=Math.tan((c.fov||55)*Math.PI/360),aspect=canvas.width/canvas.height;
      const box=[H.x0-H.origin[0],H.origin[1]-H.y0,H.step*(H.width-1),H.step*(H.height-1)];
      const out=[];let sky=0,outside=0,landOrEdge=0;
      for(const [x,y] of coords){const nx=(2*(x+.5)/W-1)*tan*aspect,ny=(1-2*(y+.5)/Hh)*tan;
        const ray=c.fw.map((v,k)=>v+c.right[k]*nx+c.up[k]*ny);
        if(ray[1]>=-.002||c.cam[1]<=0){sky++;continue;}
        const t=-c.cam[1]/ray[1],xx=c.cam[0]+ray[0]*t,zz=c.cam[2]+ray[2]*t;
        if(t<0||t>55000||xx<box[0]+5||xx>box[0]+box[2]-5||zz<box[1]+5||zz>box[1]+box[3]-5){outside++;continue;}
        // A 3m safety band avoids equating a displaced wave edge with a hole.
        if([[0,0],[3,0],[-3,0],[0,3],[0,-3]].some(([dx,dz])=>HKMap.landTriangleAt(xx+dx,zz+dz))){landOrEdge++;continue;}
        out.push([x,y,xx,zz]);
      }
      return {samples:out,excludedSky:sky,excludedOutside:outside,excludedLandOrBoundary:landOrEdge,camera:c,box};
    }''', coords)
    hits = []
    corner_counts = {k: {'tested': 0, 'magenta': 0} for k in ['topLeft', 'topRight', 'bottomLeft', 'bottomRight']}
    for x, y, xx, zz in samples.pop('samples'):
        pixel = rgb[y, x]
        magenta = bool(pixel[0] >= 230 and pixel[1] <= 30 and pixel[2] >= 230)
        quadrant = ('top' if y < h / 2 else 'bottom') + ('Left' if x < w / 2 else 'Right')
        corner_counts[quadrant]['tested'] += 1
        corner_counts[quadrant]['magenta'] += int(magenta)
        if magenta and len(hits) < 100:
            hits.append({'pixel': [x, y], 'waterPlanePoint': [xx, zz]})
    tested = sum(v['tested'] for v in corner_counts.values())
    leaks = sum(v['magenta'] for v in corner_counts.values())
    return {**samples, 'testedWaterPixels': tested, 'magentaWaterPixels': leaks, 'quadrants': corner_counts,
            'examples': hits, 'passed': tested > 20 and leaks == 0,
            'scope': 'Sparse 5px grid, all four viewport quadrants. Excludes legitimate sky, outside study bounds, grazing horizon, and 3m shoreline band. A pass is not full shoreline/visual acceptance.'}


class Run:
    def __init__(self, url):
        self.report = {'schema': 'hong-kong-r04.browser-qa/1', 'url': url, 'partialTerrainOnly': PARTIAL,
                       'htmlSha256': hashlib.sha256((ROOT / 'index.html').read_bytes()).hexdigest(),
                       'commit': os.environ.get('GITHUB_SHA'), 'status': 'running', 'cases': [], 'stages': [],
                       'physicalGpuTested': False, 'visualAcceptance': False, 'realtimeAccepted': False,
                       'limitations': ['Actual ordinary-perspective scene screenshots and state regressions on Chromium SwiftShader.',
                                       'No headless screenshot is automatically accepted as final art.', 'No native hardware GPU timing or realtime performance claim.']}
        self.output = QA / 'BROWSER_QA.json'
        self.started = time.monotonic()
        self.save()

    def save(self):
        self.report['elapsedSeconds'] = time.monotonic() - self.started
        json_write(self.output, self.report)

    def stage(self, name):
        self.report['stages'].append({'stage': name, 'elapsedSeconds': time.monotonic() - self.started})
        self.save()
        print('R04_BROWSER_STAGE ' + name, flush=True)

    def shot(self, page, case, label):
        path = QA / f'{case["name"]}-{label}.png'
        page.screenshot(path=str(path), timeout=STAGE_TIMEOUT)
        state = page.evaluate('HKMap.getState()')
        check(state['qa']['lastGLerror'] == 0, f'{label}: GL error')
        case['screenshots'].append({'name': label, 'file': path.name, 'camera': state['qa'].get('mapCamera'),
                                     'station': state['qa'].get('kowloonStation'), 'near': state['qa'].get('nearStation')})
        self.save()
        return path

    def open(self, browser, name, viewport, url):
        case = {'name': name, 'viewport': viewport, 'screenshots': [], 'errors': [], 'consoleErrors': [], 'failedRequests': [], 'status': 'running'}
        self.report['cases'].append(case)
        page = browser.new_page(viewport=viewport, device_scale_factor=1)
        page.set_default_timeout(STAGE_TIMEOUT)
        page.route('**/favicon.ico', lambda route: route.fulfill(status=204))
        page.on('pageerror', lambda error: case['errors'].append(str(error)))
        page.on('console', lambda message: case['consoleErrors'].append(message.text) if message.type == 'error' else None)
        page.on('requestfailed', lambda request: case['failedRequests'].append({'url': request.url, 'failure': request.failure}))
        started = time.monotonic()
        self.stage(name + ':load-http')
        page.goto(url, wait_until='load', timeout=180000)
        page.wait_for_function('window.HKMap?.getState().ready && window.OceanMother?.qa.ready && OceanMother.qa.completedFrames > 2', timeout=300000)
        page.evaluate('HKBackgroundSea.pause()')
        case['readySeconds'] = time.monotonic() - started
        return page, case

    def scene(self, browser, name, viewport):
        page, case = self.open(browser, name, viewport, self.report['url'])
        try:
            state = page.evaluate('HKMap.getState()')
            check(state['northAligned'], 'Map is no longer north aligned')
            check(len(state['stationMarkers']) == 4, 'Expected four story station markers')
            check(state['heightExaggeration'] == 1 and state['resolutionM'] == 30, 'Terrain scale/source resolution changed')
            check(state['mapState']['rail'] is False, 'Modern reference rail line should start hidden')
            check(state.get('canopyRoots') == 0, 'Rejected 85,058-root canopy must not be allocated')
            check(state['qa'].get('canopyRoots', 0) == 0, 'Rejected canopy remains in runtime QA')
            if not PARTIAL:
                station = state['qa'].get('kowloonStation', {})
                check(station.get('renderVertices', 0) > 750000 and station.get('renderTriangles', 0) > 500000, 'Assembly is missing the rebuilt approximately 783k-point station/rail mesh')
                check(station.get('sourceMotherMutated') is False, 'Station source-mother immutability was not recorded')
            for view in NAMED_VIEWS + ([] if PARTIAL else ['kowloon']):
                self.stage(name + ':view:' + view)
                before = frame_count(page)
                page.evaluate('(key) => HKMap.focus(key)', view)
                wait_render(page, before)
                self.shot(page, case, view)
            self.stage(name + ':ordinary-controls')
            for selector, key in [('#showStory', 'story'), ('#showRail', 'rail'), ('#showLabels', 'labels'), ('#showCoverage', 'coverage')]:
                old = page.evaluate('(key)=>HKMap.getState().mapState[key]', key)
                page.locator(selector).evaluate('(el)=>el.click()')
                check(page.evaluate('(key)=>HKMap.getState().mapState[key]', key) != old, selector + ' failed')
                page.locator(selector).evaluate('(el)=>el.click()')
            page.locator('#togglePanel').evaluate('(el)=>el.click()')
            check(page.locator('#panel').is_visible(), 'Panel failed to open')
            page.locator('#togglePanel').evaluate('(el)=>el.click()')
            check(not page.locator('#panel').is_visible(), 'Panel failed to close')
            page.evaluate("HKMap.focus('overview')")
            yaw = page.evaluate('HKMap.getState().mapState.yaw')
            x, y = viewport['width'] * .55, viewport['height'] * .72
            page.mouse.move(x, y); page.mouse.down(); page.mouse.move(x + 45, y + 12, steps=3); page.mouse.up()
            check(page.evaluate('HKMap.getState().mapState.yaw') != yaw, 'Orbit drag did not rotate')
            page.locator('#reset').evaluate('(el)=>el.click()')
            check(page.evaluate('HKMap.getState().mapState.yaw') == yaw, 'Reset did not return overview')
            self.stage(name + ':frame-cadence-overview')
            case['overviewFrameTiming'] = frame_timing(page)
            if not PARTIAL:
                self.director(page, case)
            case['metrics'] = diagnostic_metrics(page)
            case['state'] = page.evaluate('HKMap.getState()')
            check(not case['errors'], 'Page errors: ' + str(case['errors']))
            check(not case['consoleErrors'], 'Console errors: ' + str(case['consoleErrors']))
            check(not case['failedRequests'], 'Failed resources: ' + str(case['failedRequests']))
            case['status'] = 'passed'
        except Exception as error:
            case['status'] = 'failed'; case['error'] = str(error); case['traceback'] = traceback.format_exc()
            try:
                case['failureState'] = page.evaluate('window.HKMap?.getState()')
                page.screenshot(path=str(QA / (name + '-failure.png')), timeout=30000)
            except Exception:
                pass
            raise
        finally:
            self.save(); page.close()

    def director(self, page, case):
        name = case['name']
        case['directorPresets'] = []; case['directorPaths'] = []
        for preset in PRESETS:
            self.stage(name + ':director:' + preset['id'])
            before = frame_count(page)
            check(page.evaluate('(key)=>HKMap.focusDirector(key)', preset['id']), 'Preset rejected: ' + preset['id'])
            if not case['directorPresets']:
                page.wait_for_function("['ready','failed'].includes(HKMap.getState().qa.nearStation?.status)", timeout=NEAR_TIMEOUT, polling=250)
                near = page.evaluate('HKMap.getState().qa.nearStation')
                check(near['status'] == 'ready', 'Near original-mother renderer failed: ' + str(near))
                case['nearFirstCompile'] = near
                before = frame_count(page)
                page.evaluate('(key)=>HKMap.focusDirector(key)', preset['id'])
            wait_render(page, before)
            near_frame = page.evaluate('HKMap.getState().qa.nearStation?.frame')
            check(near_frame and near_frame.get('drawCalls', 0) > 0 and near_frame.get('triangles', 0) > 0, 'No original-mother near-fragment draw was observed')
            current = director_state(page); assert_director(current)
            check(math.dist(current['eyeMap'], preset['eyeMap']) < 1e-5, 'Preset camera differs from audited metric camera')
            case['directorPresets'].append(current)
            self.shot(page, case, preset['id'])
        for definition in PATHS:
            self.stage(name + ':path:' + definition['id'])
            check(page.evaluate('(key)=>HKMap.startDirectorPath(key)', definition['id']), 'Path rejected')
            initial = director_state(page); assert_director(initial)
            before = frame_count(page); wait_render(page, before)
            started = director_state(page); assert_director(started)
            check(started['path'] is not None and started['path']['progress'] > 0, 'Real RAF playback did not advance')
            check(started['blockedMoves'] == initial['blockedMoves'], 'Audited path blocked on first real frame')
            # Complete the actual runtime integrator at fixed .05s ticks, not wall-clock
            # playback. This isolates collision/progress correctness from software GPU speed.
            middle = page.evaluate('''() => {for(let n=0;n<2000;n++){const s=HKMap.getDirectorState();if(!s.path||s.path.progress>=.5)break;HKDirector.tickDirector(.05);}return HKMap.getDirectorState();}''')
            assert_director(middle)
            if definition['id'] in ['hall-long-axis', 'platform-forward']:
                before = frame_count(page); page.evaluate('HKDirector.pauseDirectorPath(true)'); wait_render(page, before)
                self.shot(page, case, definition['id'] + '-midpoint')
                page.evaluate('HKDirector.pauseDirectorPath(false)')
            completed = page.evaluate('''() => {for(let n=0;n<2000&&HKMap.getDirectorState().path;n++)HKDirector.tickDirector(.05);return HKMap.getDirectorState();}''')
            assert_director(completed)
            check(completed['lastPath']['status'] == 'completed', 'Path did not reach audited endpoint')
            check(math.dist(completed['eyeMap'], definition['eyeMap'][-1]) < 1e-4, 'Path endpoint differs from original polyline')
            check(completed['blockedMoves'] == initial['blockedMoves'], 'Audited path unexpectedly blocked')
            case['directorPaths'].append({'id': definition['id'], 'realFrameStart': started, 'midpoint': middle, 'completed': completed,
                                          'mode': 'Real RAF playback start, then actual runtime tickDirector(.05) for bounded polyline/collision regression. Not a real-time speed measurement.'})
            self.save()
        self.stage(name + ':wasd-and-collision')
        movement = []
        for key in ['w', 'a', 's', 'd']:
            page.evaluate("HKMap.focusDirector('station-hall')")
            a = director_state(page)
            page.keyboard.down(key)
            page.evaluate('() => {for(let i=0;i<8;i++)HKDirector.tickDirector(.05)}')
            page.keyboard.up(key)
            b = director_state(page); assert_director(b)
            check(b['acceptedMoves'] > a['acceptedMoves'] and math.dist(a['eyeMap'], b['eyeMap']) > .1, 'WASD key did not move: ' + key)
            movement.append({'key': key, 'before': a, 'after': b})
        page.evaluate("HKMap.focusDirector('station-platform')")
        a = director_state(page)
        page.keyboard.down('d')
        page.evaluate('() => {for(let i=0;i<160;i++)HKDirector.tickDirector(.05)}')
        page.keyboard.up('d')
        b = director_state(page); assert_director(b)
        check(b['blockedMoves'] > a['blockedMoves'], 'Repeated lateral WASD movement crossed the platform/collision boundary')
        check(math.dist(a['eyeMap'], b['eyeMap']) < 4, 'Collision test travelled through unwalkable rail/column space')
        nav = page.evaluate('''async()=>{const {createStationWalkNav}=await import('./interior-audit/station-walk-nav.mjs');const n=createStationWalkNav(window.HK_WALK_DATA);return{currentAllowed:n.isAllowedMap(HKMap.getDirectorState().eyeMap),towerAllowed:n.isAllowedLocal([24,2.45,4]),absentForecourtAllowed:n.isAllowedLocal([3.75,2.45,12]),trackVoidAllowed:n.isAllowedLocal([0,2.45,-25])};}''')
        check(nav['currentAllowed'] and not any(nav[k] for k in ['towerAllowed', 'absentForecourtAllowed', 'trackVoidAllowed']), 'Phantom interior/walkable void admitted')
        case['wasd'] = {'movement': movement, 'collisionBefore': a, 'collisionAfter': b, 'noPhantomInteriors': nav}
        page.evaluate("HKMap.focusDirector('station-hall')")
        self.stage(name + ':frame-cadence-near-hall')
        case['nearFrameTiming'] = frame_timing(page)
        self.rail_director(page, case)
        # Escape must exit and release held keys; re-entry must remain deterministic.
        page.keyboard.press('Escape')
        check(not director_state(page)['active'], 'Escape did not leave director mode')
        check(page.evaluate("HKMap.focusDirector('station-entry')"), 'Repeated director entry failed')
        assert_director(director_state(page))
        page.evaluate("HKMap.focus('overview')")
        check(not director_state(page)['active'], 'Named overview did not leave director mode')

    def rail_director(self, page, case):
        self.stage(case['name'] + ':source-rail-director')
        check(page.evaluate('HKDirector.startRailDirector()'), 'Source rail camera did not start')
        initial = director_state(page)
        check(initial['kind'] == 'rail-camera' and abs(initial['eyeMap'][1] - 5.586) < 1e-6, 'Rail eye datum differs from source rail crown + 1.6m')
        check(initial['rail']['walkNavUsed'] is False and initial['rail']['pedestrianReachabilityClaim'] is False, 'Rail camera must not claim pedestrian navigation')
        before = frame_count(page); wait_render(page, before)
        running = director_state(page)
        check(running['rail']['distanceM'] > 0, 'Source rail camera failed to advance on a real frame')
        page.evaluate('HKDirector.pauseDirectorPath(true)')
        frozen = director_state(page)
        page.keyboard.press('w')
        after_key = director_state(page)
        check(after_key['kind'] == 'rail-camera' and after_key['eyeMap'] == frozen['eyeMap'], 'WASD moved the rail camera or silently switched navigation modes')
        check(bool(after_key.get('notice')), 'Rail WASD rejection did not explain the separate platform walk mode')
        page.evaluate('HKDirector.pauseDirectorPath(false)')
        middle = page.evaluate("() => {for(let i=0;i<2000 && HKMap.getDirectorState().rail.progress<.5;i++)HKDirector.tickDirector(.05);HKDirector.pauseDirectorPath(true);return HKMap.getDirectorState();}")
        before = frame_count(page); page.evaluate('HKDirector.pauseDirectorPath(true)'); wait_render(page, before)
        self.shot(page, case, 'source-rail-director-midpoint')
        page.evaluate('HKDirector.pauseDirectorPath(false)')
        final = page.evaluate("() => {for(let i=0;i<2000 && HKMap.getDirectorState().rail.playing;i++)HKDirector.tickDirector(.05);return HKMap.getDirectorState();}")
        check(final['lastPath']['status'] == 'completed', 'Source rail camera failed to reach its authored endpoint')
        check(abs(final['eyeLocal'][0]+25)<1e-6 and abs(final['eyeLocal'][2]+18)<1e-5 and abs(final['eyeMap'][1]-5.586)<1e-6, 'Rail endpoint escaped its original metric axis')
        page.keyboard.press('Escape')
        check(not director_state(page)['active'], 'Escape did not exit rail camera')
        check(page.evaluate("HKMap.focusDirector('station-platform')"), 'Rail-to-walk camera transition failed')
        walk = director_state(page); assert_director(walk)
        check(walk['kind'] == 'walk-camera' and walk['rail'] is None, 'Rail state leaked into platform walking')
        case['railDirector'] = {'initial': initial, 'realFramePlayback': running, 'wasdRejection': after_key,
                                'midpoint': middle, 'completed': final, 'returnToPlatform': walk,
                                'scope': 'Camera along the existing native x=-25m rail axis, not pedestrian reachability or invented track throats.'}
        self.save()

    def shore(self, browser, name, viewport):
        page, case = self.open(browser, name + '-coverage', viewport, with_query(self.report['url'], coverageDebug='1'))
        try:
            case['coverage'] = []
            configs = []
            for height in [100, 800, 1190, 1210]:
                pitch = -.85
                configs.append((f'coast-height-{height}', {'target': [1477, 0, 9794], 'distance': height / -math.sin(pitch), 'yaw': 0, 'pitch': pitch}))
            # Two low-height/pitch orientations stress viewport corners at the coast.
            for yaw in [-.7, .7]:
                configs.append((f'coast-lowpitch-{"west" if yaw < 0 else "east"}', {'target': [1559.61, 0, 10070], 'distance': 12 / -math.sin(-.06), 'yaw': yaw, 'pitch': -.06}))
            for label, orbit in configs:
                self.stage(case['name'] + ':' + label)
                before = frame_count(page)
                page.evaluate('(p)=>HKMap.setOrbit({...p,story:false,rail:false,labels:false,coverage:false})', orbit)
                wait_render(page, before)
                screenshot = self.shot(page, case, label)
                result = coverage_mask(page, screenshot)
                case['coverage'].append({'name': label, 'orbit': orbit, **result})
                self.save()
            check(all(c['passed'] for c in case['coverage']), 'Coverage magenta in eligible rendered-water pixels, or insufficient eligible pixels; inspect separate coverage report')
            check(not case['errors'] and not case['consoleErrors'] and not case['failedRequests'], 'Coverage page errors/resources failed')
            case['status'] = 'passed'; case['metrics'] = diagnostic_metrics(page)
        except Exception as error:
            case['status'] = 'failed'; case['error'] = str(error); raise
        finally:
            self.save(); page.close()

    def execute(self):
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(**browser_options())
                try:
                    # Finish other independent viewport groups even if one fails.
                    for name, viewport in VIEWPORTS:
                        for method in [self.scene, self.shore]:
                            try:
                                method(browser, name, viewport)
                            except Exception as error:
                                self.report.setdefault('failures', []).append({'case': name, 'group': method.__name__, 'error': str(error)})
                                self.stage(name + ':' + method.__name__ + ':failed:' + str(error)[:160])
                finally:
                    browser.close()
        except Exception as error:
            self.report.setdefault('failures', []).append({'group': 'browser-launch-or-close', 'error': str(error)})
        self.report['passed'] = len(self.report['cases']) == 4 and all(c['status'] == 'passed' for c in self.report['cases']) and not self.report.get('failures')
        self.report['status'] = 'passed' if self.report['passed'] else 'failed'
        self.save()
        print('R04_BROWSER_RESULT ' + self.report['status'], flush=True)
        return 0 if self.report['passed'] else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('url', nargs='?', help='Optional HTTP(S) deployment URL. Default serves this R04 directory locally.')
    args = parser.parse_args()
    if args.url:
        check(urlsplit(args.url).scheme in ['http', 'https'], 'Use HTTP(S), not file://, for fetched JSON and ES modules')
        return Run(args.url).execute()
    with local_server() as base:
        return Run(base + 'index.html').execute()

if __name__ == '__main__':
    raise SystemExit(main())
