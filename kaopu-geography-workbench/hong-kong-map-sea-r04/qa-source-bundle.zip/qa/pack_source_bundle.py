from pathlib import Path
import zipfile,hashlib,json,base64
R=Path(__file__).resolve().parents[1]
excluded={'qa/isolated-root.txt','workflow/map.yml','qa/SOURCE_BUNDLE_RECEIPT.json','index.html','map-data.json','station-data.json','terrain-detail.json','walk-data.json','camera-data.json','path-data.json','SOURCE_MANIFEST.json','station-integration/MESH_MANIFEST.json','station-integration/baked-map-station.json','data/background-pack.json','detail-data/runtime-patches.json'}
roots={'data','detail-data','interior-audit','qa','research','station-integration','workflow'}
allowed={'.mjs','.js','.cjs','.py','.glsl','.html','.json','.md','.txt','.rs','.toml','.lock','.yml','.frag','.wgsl','.vert'}
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R);key=rel.as_posix()
 if key in excluded or (len(rel.parts)>1 and rel.parts[0] not in roots):continue
 if any(x in rel.parts for x in ['__pycache__','node_modules','target','baked','results','component-results']):continue
 if p.suffix not in allowed:continue
 if key.startswith('research/') and key!='research/ocean-approved-r01c.html':continue
 if p.stat().st_size>1_000_000:raise ValueError(('unexpected large source',key,p.stat().st_size))
 files.append((p,key))
z=R/'qa-source-bundle.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p,key in files:out.writestr(zipfile.ZipInfo(key,date_time=(2026,10,13,0,0,0)),p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
receipt={'schema':'r04-own-source-bundle/1','sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'bytes':z.stat().st_size,'files':[{'path':key,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p,key in files],'excludes':['private-reference images','native raster source arrays','generated runtime JSON assets','mesh binaries','baked numeric results','environment files'],'expandTo':'kaopu-geography-workbench/hong-kong-map-sea-r04'}
(R/'qa/SOURCE_BUNDLE_RECEIPT.json').write_text(json.dumps(receipt,indent=2));(R/'qa-source-bundle.b64').write_text(base64.b64encode(z.read_bytes()).decode());print(json.dumps({k:v for k,v in receipt.items() if k!='files'}));print('files',len(files))
