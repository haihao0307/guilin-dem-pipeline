# Bounded near-camera QA

Use `near_tier_check.py` against a **freshly built** R04 folder containing its real
baked station JSON and compiled Naga near shader. Do not substitute an old artifact
HTML if the host has since changed.

```sh
python3 -m unittest discover -s qa -p 'near_tier_check_test.py'
python3 qa/near_tier_check.py --root . --output qa/near-tier-results
```

The default sequence is:

1. `station-entry`, near off: original-source far-baked control
2. `station-hall`, near off: original-source far-baked control
3. `station-entry`, near on: live original-mother fragment pass
4. `station-hall`, near on: live original-mother fragment pass

Each combination has a new browser/process group. Far cases have a 120 second
wall-clock deadline; near cases have 300 seconds including cold shader loading.
The supervisor writes a timeout receipt and terminates **only its own isolated
process group** if page evaluation, a GPU fence, screenshots or browser shutdown
stalls. Already-completed cases and their screenshots remain available.

Optional bounds and single-camera use:

```sh
python3 qa/near_tier_check.py --cameras station-entry --far-timeout 120 --near-timeout 180
```

## Evidence and scope

- Fixed 256×144 viewport **and** drawing buffer, device scale 1. Normal perspective
  uses the original audited entry/hall presets with a 1.6 m eye above the deck.
- `?still=1` freezes the original sea/weather clock. The original `fine` quality
  control gives render scale 1. HTML overlays are hidden for the small canvas PNG.
- No source file is edited. The local HTTP response wraps the unique host
  `nearWanted` expression in an explicit QA gate. Every receipt records the exact
  replacement and original/served HTML hashes. Geometry, inputs, camera data and
  mother functions are unchanged.
- A draw submission is insufficient: after the host fence reaches the selected
  camera, three additional same-camera redraws each use an independent
  `fenceSync`/`clientWaitSync` completion check. Median/p95 are reported for this
  deliberately small sample. Request-to-fence includes CPU/RAF scheduling and is
  not a GPU timer query; screenshots and cold compile are excluded.
- Browser Resource Timing records actual decoded payload bytes, with navigation
  bytes and the application JSON arrayBuffer receipt separately identified. JS
  heap is reported when available. Transparent bufferData/deleteBuffer accounting
  reports known live/peak GPU buffer storage; textures and driver overhead are
  explicitly excluded.
- Each case writes a JSON receipt, PNG and log; the summary compares source/camera
  identity, frozen scene configuration, completion cost and pixel differences.
- Each case is cold. Near compile/init and software-raster completion cost are not
  hardware FPS or warmed interactive performance.
- Geometry counts, nonblank pixel summaries and paired screenshots are evidence,
  **not** an automatic visible-surface coverage proof. Far/near display lighting
  differs, so image equality is not a pass requirement.
- Passing this tier means the small normal-perspective diagnostic completed. It
  does not accept final 1600×1000 imagery, visual style, realtime performance or
  native GPU compatibility. The existing full browser suite is unchanged.
