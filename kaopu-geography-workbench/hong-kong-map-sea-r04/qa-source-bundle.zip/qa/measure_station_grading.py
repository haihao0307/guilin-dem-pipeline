from pathlib import Path
import json,numpy as np,gzip,base64
R=Path(__file__).resolve().parents[1];q=next(p for p in json.loads((R/'detail-data/runtime-patches.json').read_text())['patches'] if p['id']=='clocktower');regions=[dict(cx=0,cz=-115.5,hx=29,hz=105.5,y=3.42,margin=6),dict(cx=50,cz=-91,hx=1.4,hz=79,y=3.58,margin=3)];report={'schema':'station-minimum-display-grading/1','regionsStationLocalMetres':regions,'stationBaseMapY':3.90,'nativeSourceModified':False,'formula':'cut only, cubic smoothstep over exterior margin; Y minimum with authored grade. No change to native DTM or public source pack.','levels':[]}
for key,l in q['levels'].items():
 h=np.frombuffer(gzip.decompress(base64.b64decode(l['heights'])),np.float32).reshape(l['height'],l['width']);mask=np.frombuffer(gzip.decompress(base64.b64decode(l['mask'])),np.uint8).reshape(h.shape);r,c=np.indices(h.shape);mx=l['x0']-834000+c*l['step'];mz=827000-l['y0']+r*l['step'];sx=mz-9800.015;sz=1481.171-mx;v=h.astype(float).copy()
 for b in regions:
  d=np.hypot(np.maximum(np.abs(sx-b['cx'])-b['hx'],0),np.maximum(np.abs(sz-b['cz'])-b['hz'],0));t=np.clip(d/b['margin'],0,1);w=1-t*t*(3-2*t);v=np.minimum(v,h-(h-np.minimum(h,b['y']))*w)
 v=np.where(mask>0,v,h).astype(np.float32);cuts=h-v
 a,b,c,d=cuts[:-1,:-1],cuts[:-1,1:],cuts[1:,:-1],cuts[1:,1:];ma,mb,mc,md=mask[:-1,:-1]>0,mask[:-1,1:]>0,mask[1:,:-1]>0,mask[1:,1:]>0;ta=ma&mb&mc;tb=mb&mc&md;area=l['step']**2/2;volume=float(np.sum(np.where(ta,a+b+c,0)+np.where(tb,b+c+d,0))*area/3);changed=int(np.sum((ta&((a+b+c)>0)))+np.sum(tb&((b+c+d)>0)))
 report['levels'].append({'levelM':int(key),'changedNodes':int((cuts>0).sum()),'maxCutM':float(cuts.max()),'removedVolumeM3':volume,'changedRenderedTriangleAreaM2':float(changed*area)})
 np.savez_compressed(R/f'qa/STATION_GRADE_MASK_{key}m.npz',cutM=cuts,mask=cuts>0)
(R/'data/station-ground-grading.json').write_text(json.dumps(report,indent=2));print(json.dumps(report['levels']))
