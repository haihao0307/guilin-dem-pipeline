"""Exact raster triangle coverage regression; no image based coastline guess."""
from pathlib import Path
import numpy as np,json,gzip,base64
R=Path(__file__).resolve().parents[1];D=json.loads((R/'data/scene.json').read_text());mask=np.load(R/'data/mask.npy');h=np.load(R/'data/heights.npy');patch=json.loads((R/'detail-data/runtime-patches.json').read_text())
assert not np.any((mask!=0)&~np.isfinite(h))
report={'method':'Each cell uses original A-C-B / B-C-D rendered triangles; water is their logical complement. Patch bounds are aligned to background cell boundaries.','patches':[],'passed':True}
assert mask.shape==(D['height'],D['width'])
for p in patch['patches']:
 b=p['bounds_epsg2326'];assert all(abs((x-D['x0'])/30-round((x-D['x0'])/30))<1e-8 for x in[b[0],b[2]]);assert all(abs((D['y0']-y)/30-round((D['y0']-y)/30))<1e-8 for y in[b[1],b[3]])
 for level,l in p['levels'].items():
  m=np.frombuffer(gzip.decompress(base64.b64decode(l['mask'])),np.uint8).reshape(l['height'],l['width']);z=np.frombuffer(gzip.decompress(base64.b64decode(l['heights'])),np.float32).reshape(m.shape);assert not np.any((m!=0)&~np.isfinite(z));a=m[:-1,:-1]!=0;b0=m[:-1,1:]!=0;c=m[1:,:-1]!=0;d=m[1:,1:]!=0;t0=a&b0&c;t1=b0&c&d
  report['patches'].append({'id':p['id'],'levelM':int(level),'landTriangles':int(t0.sum()+t1.sum()),'gapTriangles':int(((~t0)&t0).sum()+((~t1)&t1).sum())})
# Projected mesh covers any downward screen ray whose sea-plane hit lies within
# the map and the 57km map sampling radius. Test previous failing pitch and yaws.
report['projectedSeaCases']=[]
for pitch in[-.15,-.3,-.85,-1.45]:
 for yaw in[-3,-1.7,0,1.6]:
  f=np.array([np.sin(yaw)*np.cos(pitch),np.sin(pitch),-np.cos(yaw)*np.cos(pitch)]);right=np.cross(f,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,f);maxerr=0
  for nx in np.linspace(-1,1,41):
   for ny in np.linspace(-1,1,27):
    ray=f+right*nx*np.tan(np.radians(27.5))*1.6+up*ny*np.tan(np.radians(27.5))
    if ray[1]>=-.00001:continue
    # inverse expanded projected-grid coordinates must cover full screen.
    uv=(np.array([nx,ny])/1.13+1)/2;assert np.all((uv>=0)&(uv<=1));q=(uv*2-1)*1.13;maxerr=max(maxerr,float(np.max(np.abs(q-[nx,ny]))))
  report['projectedSeaCases'].append({'pitch':pitch,'yaw':yaw,'screenRayRoundtripMax':maxerr})
(R/'qa/COVERAGE_CPU.json').write_text(json.dumps(report,indent=2));print('COVERAGE_CPU passed',len(report['patches']),len(report['projectedSeaCases']))
