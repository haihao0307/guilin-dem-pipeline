#!/usr/bin/env python3
"""Bounded 256×144 actual-camera far/near diagnostics, with process-level deadlines.

Only the HTTP response is instrumented: the host's nearWanted condition receives
an explicit QA-only gate. Source files, geometry, baked inputs and camera data are
not edited. Each camera/mode has its own browser process, JSON, PNG and log.
This low-resolution diagnostic is not full-resolution visual acceptance.
"""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = Path(__file__).resolve()
CAMERAS = ('station-entry', 'station-hall')
WIDTH, HEIGHT = 256, 144


def utc():
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def instrument_html(raw):
    """Fail closed if the host no longer has the exact single nearWanted gate."""
    source = raw.decode('utf-8')
    pattern = r'const nearWanted=([^;\n]+);'
    matches = list(re.finditer(pattern, source))
    if len(matches) != 1:
        raise ValueError(f'Expected one host nearWanted gate; found {len(matches)}')
    original = matches[0].group(0)
    changed = 'const nearWanted=window.__R04_TIER_NEAR_ENABLED!==false&&(' + matches[0].group(1) + ');'
    patched = source[:matches[0].start()] + changed + source[matches[0].end():]
    return patched.encode('utf-8'), {'kind': 'QA-only HTTP response near-pass enable gate',
        'original': original, 'replacement': changed, 'sourceHtmlSha256': sha(raw),
        'servedHtmlSha256': sha(patched.encode('utf-8')), 'sourceFilesModified': False,
        'motherFunctionsModified': False, 'geometryModified': False, 'cameraModified': False}


class TierHandler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, '.mjs': 'text/javascript', '.frag': 'text/plain', '.wgsl': 'text/plain'}
    def log_message(self, *_):
        pass
    def do_GET(self):
        if urlsplit(self.path).path in ('/', '/index.html'):
            data = self.server.tier_html
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers(); self.wfile.write(data)
        elif urlsplit(self.path).path == '/favicon.ico':
            self.send_response(204); self.end_headers()
        else:
            super().do_GET()


@contextmanager
def server_for(root, html):
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(TierHandler, directory=str(root)))
    server.tier_html = html
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}/index.html?still=1'
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)


BUFFER_ACCOUNTING = r'''(() => {
 const P=globalThis.WebGL2RenderingContext?.prototype;if(!P)return;
 const sourceData=P.bufferData,sourceDelete=P.deleteBuffer,contexts=new WeakMap();
 const records=[];window.__r04BufferAccounting={contexts:records,instrumentationErrors:0,
   scope:'Known WebGL bufferData storage bytes minus deleteBuffer; excludes textures, framebuffer surfaces, driver overhead and CPU copies.'};
 function record(gl){let r=contexts.get(gl);if(!r){r={sizes:new Map(),public:{liveBufferBytes:0,peakBufferBytes:0,liveBuffers:0,bufferDataCalls:0}};contexts.set(gl,r);records.push(r.public);}return r;}
 function binding(gl,target){const key=({34962:34964,34963:34965,36662:36662,36663:36663,35051:35053,35052:35055,35982:35983,35345:35368})[target];return key?gl.getParameter(key):null;}
 P.bufferData=function(target,data,usage,offset,length){
   const result=sourceData.apply(this,arguments);
   try{const r=record(this),buffer=binding(this,target);if(buffer){let bytes=typeof data==='number'?data:data?.byteLength??0;
     if(typeof data!=='number'&&offset!==undefined){const unit=data?.BYTES_PER_ELEMENT??1;bytes=length?length*unit:Math.max(0,bytes-offset*unit);}
     const previous=r.sizes.get(buffer)??0;r.sizes.set(buffer,bytes);r.public.liveBufferBytes+=bytes-previous;
     r.public.liveBuffers=r.sizes.size;r.public.bufferDataCalls++;r.public.peakBufferBytes=Math.max(r.public.peakBufferBytes,r.public.liveBufferBytes);}}
   catch{window.__r04BufferAccounting.instrumentationErrors++;}return result;
 };
 P.deleteBuffer=function(buffer){const result=sourceDelete.apply(this,arguments);try{const r=record(this);r.public.liveBufferBytes-=r.sizes.get(buffer)??0;r.sizes.delete(buffer);r.public.liveBuffers=r.sizes.size;}catch{window.__r04BufferAccounting.instrumentationErrors++;}return result;};
})();'''


START_FENCE_SAMPLE = r'''(camera) => {
 const gl=document.querySelector('canvas').getContext('webgl2'),q=OceanMother.qa;
 const sample={requestedAt:performance.now(),submittedBefore:q.frames,status:'waiting-for-render'};
 window.__r04TierFenceSample=sample;
 HKMap.focusDirector(camera);
 const poll=()=>{
   if(q.errors.length){sample.status='failed';sample.error=q.errors.join('\n');return;}
   if(!sample.fence && q.frames>sample.submittedBefore){sample.submissionObservedAt=performance.now();sample.submittedFrame=q.frames;
     sample.fence=gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE,0);if(!sample.fence){sample.status='failed';sample.error='Unable to create own GPU fence';return;}
     gl.flush();sample.status='waiting-for-independent-fence';}
   if(sample.fence){const r=gl.clientWaitSync(sample.fence,0,0);
     if(r===gl.WAIT_FAILED){sample.status='failed';sample.error='Own fence WAIT_FAILED';gl.deleteSync(sample.fence);sample.fence=null;return;}
     if(r===gl.ALREADY_SIGNALED||r===gl.CONDITION_SATISFIED){const now=performance.now();sample.status='complete';
       sample.requestToFenceMs=now-sample.requestedAt;sample.submissionObservedToFenceMs=now-sample.submissionObservedAt;
       sample.completedAt=now;gl.deleteSync(sample.fence);sample.fence=null;return;}}
   requestAnimationFrame(poll);
 };requestAnimationFrame(poll);
}'''


def fence_samples(page, camera, stage, report):
    samples=[]
    for i in range(3):
        stage('warm-fence-sample-'+str(i+1))
        page.evaluate(START_FENCE_SAMPLE,camera)
        page.wait_for_function("['complete','failed'].includes(window.__r04TierFenceSample?.status)",timeout=90000,polling=200)
        result=page.evaluate('''()=>{const {fence,...r}=window.__r04TierFenceSample;return r;}''')
        samples.append(result)
        report['warmFenceSamples']=samples
        if result['status']!='complete':
            raise RuntimeError('Independent GPU-fence sample failed: '+str(result))
    import numpy as np
    values=[v['requestToFenceMs'] for v in samples]
    report['warmFenceTiming']={'sampleCount':len(values),'requestToFenceMedianMs':float(np.median(values)),
        'requestToFenceP95Ms':float(np.percentile(values,95)),
        'afterSubmissionMedianMs':float(np.median([v['submissionObservedToFenceMs'] for v in samples])),
        'scope':'Three explicit same-camera redraws with independent WebGL fence completion. Request-to-fence includes CPU submission and RAF scheduling. Not a GPU timer query, sustained FPS or hardware benchmark. Screenshot/cold compile excluded.'}
    stage('three-independent-gpu-fences-completed')


SNAPSHOT = '''() => {
 const h=window.HKMap,q=window.OceanMother?.qa,s=h?.getState(),canvas=document.querySelector('canvas');
 return {ready:!!s?.ready,submittedFrames:q?.frames??0,completedFrames:q?.completedFrames??0,
   errors:q?.errors??[],lastGLerror:q?.lastGLerror??null,near:q?.nearStation??null,
   station:q?.kowloonStation?{renderVertices:q.kowloonStation.renderVertices,renderTriangles:q.kowloonStation.renderTriangles,
     sourceCommit:q.kowloonStation.sourceCommit,nearMaterialStatus:q.kowloonStation.nearMaterialStatus}:null,
   camera:q?.mapCamera??null,director:h?.getDirectorState?.()??null,
   waveTime:q?.waveTime??null,renderSize:q?.renderSize??null,
   canvas:canvas?{width:canvas.width,height:canvas.height}:null,
   memory:performance.memory?{usedJSHeapSize:performance.memory.usedJSHeapSize,totalJSHeapSize:performance.memory.totalJSHeapSize}:null,
   resourceAccounting:q?.resources??null,knownGPUBufferStorage:window.__r04BufferAccounting??null,nearEnabled:window.__R04_TIER_NEAR_ENABLED};
}'''


def worker(args):
    # Import browser dependencies only in isolated children; parent remains able
    # to record a timeout even if Chromium/CDP or browser.close is unresponsive.
    from playwright.sync_api import sync_playwright
    from gpu_probe import browser_options
    started = time.monotonic()
    key = f'{args.camera}-{args.mode}'
    output = args.output / f'{key}.json'
    report = {'schema': 'hong-kong-r04.low-resolution-near-tier/1', 'case': key,
              'cameraPreset': args.camera, 'mode': args.mode, 'status': 'running', 'startedAt': utc(),
              'viewport': [WIDTH, HEIGHT], 'requestedDrawingBuffer': [WIDTH, HEIGHT], 'stages': [],
              'pageErrors': [], 'consoleErrors': [], 'failedRequests': [], 'physicalGpuTested': False,
              'fullResolutionVisualAcceptance': False, 'realtimeAccepted': False,
              'scope': 'Normal perspective, 1.6m eye, original geometry/source inputs at 256×144. Bounded geometry/material diagnostic only; not final imagery or hardware performance.',
              'costScope': 'Each mode is a separate cold browser. Near-on includes original shader compilation; no warmed-cache FPS claim.'}

    def save():
        report['elapsedSeconds'] = time.monotonic() - started
        atomic_json(output, report)

    def stage(name, **detail):
        report['currentStage'] = name
        report['stages'].append({'name': name, 'at': utc(), 'elapsedSeconds': time.monotonic() - started, **detail})
        save(); print('R04_TIER_STAGE ' + key + ' ' + name, flush=True)

    save()
    try:
        raw = (args.root / 'index.html').read_bytes()
        html, instrumentation = instrument_html(raw)
        report['instrumentation'] = instrumentation
        inputs = ['map-data.json', 'terrain-detail.json', 'station-data.json', 'camera-data.json', 'walk-data.json', 'path-data.json']
        report['inputFiles'] = {name: {'bytes': (args.root / name).stat().st_size, 'sha256': sha((args.root / name).read_bytes())} for name in inputs}
        preset = next(p for p in json.loads((args.root / 'camera-data.json').read_text())['presets'] if p['id'] == args.camera)
        report['expectedCamera'] = preset
        stage('launch')
        with server_for(args.root, html) as url, sync_playwright() as p:
            browser = p.chromium.launch(**browser_options())
            # Do not synchronously close on a known case error. The supervisor
            # owns final process-group cleanup whether success, failure or timeout.
            page = browser.new_page(viewport={'width': WIDTH, 'height': HEIGHT}, device_scale_factor=1)
            page.set_default_timeout(20000)
            page.on('pageerror', lambda e: report['pageErrors'].append(str(e)))
            page.on('console', lambda m: report['consoleErrors'].append(m.text) if m.type == 'error' else None)
            page.on('requestfailed', lambda r: report['failedRequests'].append({'url': r.url, 'failure': r.failure}))
            page.add_init_script('window.__R04_TIER_NEAR_ENABLED=false;')
            page.add_init_script(BUFFER_ACCOUNTING)
            report['url'] = url
            stage('load-http-still')
            page.goto(url, wait_until='domcontentloaded', timeout=60000)
            page.wait_for_function('window.HKMap?.getState().ready && window.OceanMother?.qa.ready', timeout=90000, polling=200)
            initial = page.evaluate(SNAPSHOT); report['initial'] = initial
            # The actual host quality control sets render scale 1. The ocean,
            # mother parameters, source mesh and camera presets remain unchanged.
            page.evaluate("() => {OceanMother.pause();const q=document.getElementById('quality');q.value='fine';q.dispatchEvent(new Event('change',{bubbles:true}));}")
            # Remove only HTML UI overlays for these tiny canvas evidence images.
            page.add_style_tag(content='body *:not(canvas){visibility:hidden!important}canvas{visibility:visible!important}')
            before = page.evaluate(SNAPSHOT)
            stage('select-metric-camera', completedBefore=before['completedFrames'], submittedBefore=before['submittedFrames'])
            accepted = page.evaluate('''({camera,near})=>{window.__R04_TIER_NEAR_ENABLED=near;return HKMap.focusDirector(camera);}''', {'camera': args.camera, 'near': args.mode == 'near'})
            if not accepted:
                raise RuntimeError('Audited station camera was rejected')
            last_stage = None
            # Small completed-fence polling receipts survive a later hung CDP call.
            while True:
                snapshot = page.evaluate(SNAPSHOT)
                report['latest'] = snapshot
                director = snapshot.get('director') or {}
                near = snapshot.get('near') or {}
                if snapshot['errors'] or report['pageErrors'] or snapshot['lastGLerror'] not in (None, 0):
                    raise RuntimeError('Host/page GL failure: ' + str(snapshot['errors'] + report['pageErrors']))
                if near.get('status') == 'failed':
                    raise RuntimeError('Near shader initialization failed: ' + str(near))
                if not director.get('active') or abs(director['eyeMap'][1] - 6.35) > 1e-6 or abs(director['eyeHeightM']-1.6)>1e-8:
                    raise RuntimeError('Metric camera or 1.6m eye changed')
                if any(abs(a-b)>1e-5 for a,b in zip(director['eyeMap'],preset['eyeMap'])):
                    raise RuntimeError('Camera position differs from audited source preset')
                if snapshot['canvas'] != {'width':WIDTH,'height':HEIGHT}:
                    current='waiting-for-exact-256x144-buffer'
                elif args.mode=='near' and near.get('status')!='ready':
                    current='near-compiling-or-loading'
                elif args.mode=='near' and not (near.get('frame') or {}).get('drawCalls',0):
                    current='waiting-for-near-draw-submission'
                else:
                    current='waiting-for-gpu-fence-completion'
                    frame_camera=snapshot.get('camera') or {}
                    correct_camera=frame_camera.get('mode')=='director' and all(abs(a-b)<1e-5 for a,b in zip(frame_camera.get('cam',[]),preset['eyeMap'])) and len(frame_camera.get('cam',[]))==3
                    if correct_camera and snapshot['submittedFrames']>before['submittedFrames'] and 'targetSubmittedFrame' not in report:
                        report['targetSubmittedFrame']=snapshot['submittedFrames']
                        report['submissionObservedAtSeconds']=time.monotonic()-started
                        stage('target-frame-submitted', frame=report['targetSubmittedFrame'])
                    target=report.get('targetSubmittedFrame')
                    if target is not None and snapshot['completedFrames']>=target:
                        report['completedFrameObservedAtSeconds']=time.monotonic()-started
                        break
                if current!=last_stage:
                    stage(current);last_stage=current
                else:
                    save()
                page.wait_for_timeout(500)
            stage('actual-gpu-frame-completed', frame=report['targetSubmittedFrame'])
            if args.mode=='far' and report['latest']['near'] is not None:
                raise RuntimeError('Far-bake control unexpectedly initialized the near adapter')
            fence_samples(page,args.camera,stage,report)
            report['latest']=page.evaluate(SNAPSHOT)
            report['actualResourceBytes']=page.evaluate('''()=>{const rs=performance.getEntriesByType('resource').map(r=>({name:r.name,encodedBodyBytes:r.encodedBodySize,decodedBodyBytes:r.decodedBodySize,transferBytes:r.transferSize,durationMs:r.duration}));const n=performance.getEntriesByType('navigation')[0];return{resources:rs,decodedResourceBytes:rs.reduce((a,r)=>a+r.decodedBodyBytes,0),navigation:n?{decodedBodyBytes:n.decodedBodySize,encodedBodyBytes:n.encodedBodySize,transferBytes:n.transferSize}:null,loadedJSON:window.HK_LOAD_RECEIPT,scope:'Actual browser Resource Timing decoded bodies and application arrayBuffer JSON bytes. Compressed base64 arrays inside JSON are accounted separately by known GPU buffers; no KB-only payload claim.'};}''')
            report['configuration']=page.evaluate('OceanMother.getConfiguration()')
            report['geometryCoverageEvidence']={'stationTriangles':report['latest']['station'].get('renderTriangles'),
                'nearDraw':(report['latest'].get('near') or {}).get('frame'),
                'scope':'Submitted geometry counts plus the completed-frame image. Counts alone do not prove visible pixel coverage; inspect the paired screenshots.'}
            report['backend']=page.evaluate('''()=>{const gl=document.querySelector('canvas').getContext('webgl2'),d=gl.getExtension('WEBGL_debug_renderer_info');return{renderer:gl.getParameter(d?d.UNMASKED_RENDERER_WEBGL:gl.RENDERER),version:gl.getParameter(gl.VERSION)}}''')
            screenshot=args.output/f'{key}.png'
            stage('capture-canvas')
            capture=time.monotonic()
            page.locator('canvas').first.screenshot(path=str(screenshot), timeout=30000)
            report['screenshot']={'file':screenshot.name,'bytes':screenshot.stat().st_size,'sha256':sha(screenshot.read_bytes()),'seconds':time.monotonic()-capture}
            # Pixel coverage is evidence, not a semantic pass: the far and near
            # lighting paths intentionally differ and must not be pixel-equal.
            from PIL import Image
            import numpy as np
            pixels=np.asarray(Image.open(screenshot).convert('RGB'))
            report['pixelEvidence']={'size':[int(pixels.shape[1]),int(pixels.shape[0])],
                'uniqueRGB':int(len(np.unique(pixels.reshape(-1,3),axis=0))),
                'meanRGB':[float(x) for x in pixels.mean(axis=(0,1))],
                'blackPixels':int(np.all(pixels<3,axis=2).sum()),'pixelCount':int(pixels.shape[0]*pixels.shape[1]),
                'scope':'Nonblank image diagnostics only. No automatic material/style/geometry visual acceptance.'}
            if pixels.shape[:2]!=(HEIGHT,WIDTH):
                raise RuntimeError('Screenshot is not the requested 256×144 normal-perspective canvas')
            if report['pageErrors'] or report['consoleErrors'] or report['failedRequests']:
                raise RuntimeError('Browser reported page/console/resource errors')
            report['status']='passed';report['completedAt']=utc();stage('complete')
            # The receipt is already durable before shutdown; browser close is
            # itself outside the rendering result and bounded by the supervisor.
            browser.close()
    except BaseException as error:
        report['status']='failed';report['error']=str(error);report['completedAt']=utc()
        stage('failed')
    finally:
        save()
    return 0 if report['status']=='passed' else 1


def terminate_group(process):
    # Only the exact isolated process group created by this supervisor.
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    # The direct child can exit before its Chromium descendants. Give the
    # owned group a short grace period, then kill that same group explicitly.
    time.sleep(.5)
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=3)


def compare_pair(root, camera):
    far_path=root/f'{camera}-far.json';near_path=root/f'{camera}-near.json'
    if not far_path.exists() or not near_path.exists():
        return {'camera':camera,'status':'incomplete'}
    far=json.loads(far_path.read_text());near=json.loads(near_path.read_text())
    matched=(far.get('inputFiles')==near.get('inputFiles') and far.get('expectedCamera')==near.get('expectedCamera')
             and far.get('instrumentation',{}).get('sourceHtmlSha256')==near.get('instrumentation',{}).get('sourceHtmlSha256'))
    report={'camera':camera,'status':'compared' if far['status']==near['status']=='passed' and matched else 'incomplete-or-failed',
            'sameSourceInputsAndCamera':matched,'sameFrozenSceneConfiguration':far.get('configuration')==near.get('configuration'),'farStatus':far['status'],'nearStatus':near['status'],
            'farCompletedSeconds':far.get('completedFrameObservedAtSeconds'),'nearCompletedSeconds':near.get('completedFrameObservedAtSeconds'),
            'scope':'Same original geometry, input resources, camera and 1.6m eye. Near-on includes a cold compile. Reduced sampling, not final-image acceptance.'}
    if report['status']=='compared':
        from PIL import Image
        import numpy as np
        a=np.asarray(Image.open(root/f'{camera}-far.png').convert('RGB'),dtype=np.float32)
        b=np.asarray(Image.open(root/f'{camera}-near.png').convert('RGB'),dtype=np.float32)
        report['imageDifference']={'meanAbsoluteRGB':float(np.abs(a-b).mean()),'pixelsDifferent':int(np.any(a!=b,axis=2).sum()),'fractionPixelsDifferent':float(np.any(a!=b,axis=2).mean()),
            'notAnEquivalenceThreshold':True,'reason':'Far vertex-baked and live per-fragment material/illumination are distinct display paths.'}
    return report


def supervise(args):
    args.output.mkdir(parents=True,exist_ok=True)
    summary={'schema':'hong-kong-r04.near-tier-suite/1','status':'running','startedAt':utc(),'viewport':[WIDTH,HEIGHT],
             'physicalGpuTested':False,'fullResolutionVisualAcceptance':False,'cases':[],'comparisons':[],
             'scope':'Four isolated, hard-deadline low-resolution cases; far entry/hall first, then near entry/hall.'}
    summary_path=args.output/'summary.json';atomic_json(summary_path,summary)
    for mode in ('far','near'):
        for camera in args.cameras:
            budget=args.far_timeout if mode=='far' else args.near_timeout
            key=f'{camera}-{mode}';receipt=args.output/f'{key}.json';log=args.output/f'{key}.log'
            command=[sys.executable,str(SCRIPT),'--worker','--root',str(args.root),'--output',str(args.output),'--camera',camera,'--mode',mode]
            started=time.monotonic()
            print(f'R04_TIER_CASE {key} hard-deadline={budget}s',flush=True)
            with log.open('w') as stream:
                process=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                timed_out=False
                try:
                    process.wait(timeout=budget)
                except subprocess.TimeoutExpired:
                    timed_out=True;terminate_group(process)
                finally:
                    # Reap any descendant Chromium processes even after child exit.
                    terminate_group(process)
            report=json.loads(receipt.read_text()) if receipt.exists() else {'case':key,'status':'failed','error':'Child produced no receipt'}
            if timed_out and report.get('status')!='passed':
                report['status']='timeout';report['error']=f'Isolated case exceeded {budget}s wall-clock deadline; browser group terminated'
                report['completedAt']=utc()
            report['supervisor']={'hardDeadlineSeconds':budget,'elapsedSeconds':time.monotonic()-started,'processReturnCode':process.returncode,'terminatedAtDeadline':timed_out,'log':log.name}
            atomic_json(receipt,report)
            summary['cases'].append({'case':key,'status':report['status'],'receipt':receipt.name,'lastStage':report.get('currentStage'),'elapsedSeconds':report['supervisor']['elapsedSeconds']})
            summary['comparisons']=[compare_pair(args.output,c) for c in args.cameras]
            atomic_json(summary_path,summary)
            print(f'R04_TIER_RESULT {key} {report["status"]}',flush=True)
    summary['status']='passed' if all(c['status']=='passed' for c in summary['cases']) and all(c['sameSourceInputsAndCamera'] and c['sameFrozenSceneConfiguration'] for c in summary['comparisons']) else 'failed'
    summary['completedAt']=utc();atomic_json(summary_path,summary)
    return 0 if summary['status']=='passed' else 1


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT,help='Assembled R04 directory, including compiled near shader and baked station JSON')
    p.add_argument('--output',type=Path,default=ROOT/'qa/near-tier-results')
    p.add_argument('--far-timeout',type=int,default=120,help='Hard wall-clock seconds per far control browser')
    p.add_argument('--near-timeout',type=int,default=300,help='Hard wall-clock seconds per near browser including cold compile')
    p.add_argument('--cameras',nargs='+',choices=CAMERAS,default=list(CAMERAS))
    p.add_argument('--worker',action='store_true',help=argparse.SUPPRESS)
    p.add_argument('--camera',choices=CAMERAS,help=argparse.SUPPRESS)
    p.add_argument('--mode',choices=['far','near'],help=argparse.SUPPRESS)
    args=p.parse_args();args.root=args.root.resolve();args.output=args.output.resolve()
    if args.far_timeout<10 or args.near_timeout<10:
        p.error('Case deadlines must be at least ten seconds')
    return worker(args) if args.worker else supervise(args)

if __name__=='__main__':
    raise SystemExit(main())
