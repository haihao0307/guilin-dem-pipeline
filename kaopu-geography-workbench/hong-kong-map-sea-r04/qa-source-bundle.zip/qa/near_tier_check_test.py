"""Pure harness tests. No GPU or browser is launched by these tests."""
from argparse import Namespace
import json
from pathlib import Path
import tempfile
import unittest
import near_tier_check as tier

class TierContract(unittest.TestCase):
    def test_only_near_gate_changes(self):
        raw=b'const mother="UNCHANGED";\nconst nearWanted=mapState.mode===\'director\'||distance<280;\noriginalDraw();'
        changed, receipt=tier.instrument_html(raw)
        self.assertEqual(changed.decode().replace(receipt['replacement'],receipt['original']),raw.decode())
        self.assertFalse(receipt['motherFunctionsModified'])
        self.assertFalse(receipt['cameraModified'])
        self.assertFalse(receipt['geometryModified'])
        self.assertFalse(receipt['sourceFilesModified'])
        self.assertNotEqual(receipt['sourceHtmlSha256'],receipt['servedHtmlSha256'])

    def test_gate_must_be_unique(self):
        for raw in [b'no host gate',b'const nearWanted=true;\nconst nearWanted=false;']:
            with self.assertRaises(ValueError):tier.instrument_html(raw)

    def test_current_assembled_host_gate(self):
        changed, receipt=tier.instrument_html((tier.ROOT/'index.html').read_bytes())
        self.assertEqual(changed.count(receipt['replacement'].encode()),1)
        self.assertIn('window.__R04_TIER_NEAR_ENABLED!==false',receipt['replacement'])

    def test_atomic_receipt_and_failed_pair(self):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name)
            for mode in ['far','near']:
                tier.atomic_json(root/f'station-entry-{mode}.json',{'status':'timeout' if mode=='near' else 'passed','inputFiles':{'source':'same'},'expectedCamera':{'eye':[1,6.35,2]},'instrumentation':{'sourceHtmlSha256':'same'},'configuration':{'frozen':True}})
            result=tier.compare_pair(root,'station-entry')
            self.assertTrue(result['sameSourceInputsAndCamera'])
            self.assertEqual(result['nearStatus'],'timeout')
            self.assertEqual(result['status'],'incomplete-or-failed')
            self.assertNotIn('imageDifference',result)
            self.assertFalse(list(root.glob('*.tmp')))

    def test_low_resolution_defaults(self):
        self.assertEqual((tier.WIDTH,tier.HEIGHT),(256,144))
        self.assertEqual(tier.CAMERAS,('station-entry','station-hall'))

if __name__=='__main__':unittest.main()
