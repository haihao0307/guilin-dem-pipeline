#!/usr/bin/env python3
"""Bounded GPU equality check for same-source visibility rejection only."""
import argparse
import json
import os
import time
from playwright.sync_api import sync_playwright
from gpu_probe import ROOT, local_server, browser_options

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--scene',action='store_true')
    args=parser.parse_args()
    mode='scene' if args.scene else 'fixtures'
    output=ROOT/'qa'/f'VISIBILITY_{mode.upper()}_QA.json'
    report={'status':'running','mode':mode,'commit':os.environ.get('GITHUB_SHA'),
            'physicalGpuTested':False,'visualAcceptance':False,'errors':[],'consoleErrors':[]}
    started=time.monotonic()
    def save():
        report['elapsedSeconds']=time.monotonic()-started
        output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    save()
    try:
        with local_server() as base,sync_playwright() as p:
            browser=p.chromium.launch(**browser_options())
            try:
                page=browser.new_page(viewport={'width':800,'height':500})
                page.route('**/favicon.ico',lambda route:route.fulfill(status=204))
                page.on('pageerror',lambda error:report['errors'].append(str(error)))
                page.on('console',lambda message:report['consoleErrors'].append(message.text) if message.type=='error' else None)
                report['url']=base+'station-integration/near-material/qa/visibility-probe.html?naga=1'+('&scene=1' if args.scene else '')
                page.goto(report['url'],wait_until='domcontentloaded',timeout=60000)
                deadline=time.monotonic()+480
                while time.monotonic()<deadline:
                    state=page.evaluate('({done:window.DONE,progress:window.PROGRESS,result:window.RESULT})')
                    report['progress']=state['progress'];save()
                    if state['done']:
                        report['result']=state['result'];break
                    page.wait_for_timeout(1000)
                result=report.get('result',{})
                assert result.get('status')=='passed',result or 'Bounded visibility GPU deadline'
                assert result.get('naga') is True and result.get('pairCount',0)>0,result
                assert all(x['passed'] for x in result['reports']),result
                assert (result['width'],result['height'])==((256,144) if args.scene else (128,72)),result
                assert not report['errors'] and not report['consoleErrors'],report
                report['status']='passed'
            finally:
                browser.close()
    except Exception as error:
        report['status']='failed';report['error']=str(error)
    save()
    print(json.dumps({'mode':mode,'status':report['status'],'elapsedSeconds':report['elapsedSeconds'],'error':report.get('error')}),flush=True)
    return 0 if report['status']=='passed' else 1

if __name__=='__main__':
    raise SystemExit(main())
