#!/usr/bin/env python3
"""Keep the four GPU claims separate and fail on missing or stale-count evidence."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def load(relative):
    value = json.loads((ROOT / relative).read_text())
    assert value['status'] == 'passed', (relative, value)
    return value

component = load('station-integration/qa/component-results/receipt.json')['probe']
material = load('station-integration/qa/results/receipt.json')['probe']
rail = load('qa/GPU_RAIL_QA.json')['result']
near = load('qa/GPU_NEAR_QA.json')['result']
component_count = sum(len(c['rows']) for c in component['cases'])
material_count = sum(c['samples'] for c in material['cases'])
assert component_count == 16, component_count
assert material_count == 186, material_count
assert rail['fixtureCount'] == 11 and rail['totalSamples'] == 66, rail
assert near['naga'] and near['fixtureCount'] == 31 and near['totalSamples'] == 744, near
assert all(c['compile']['fragmentOK'] and c['compile']['linkOK'] for c in component['cases'])
assert material['compile']['fragmentOK'] and material['compile']['linkOK']
report = {'status': 'passed', 'originalComponentProbes': component_count,
          'originalMaterialComparisons': material_count, 'railUniqueFixtures': 11, 'railMaterialComparisons': 66,
          'nearUniqueFixtures': 31, 'nearRasterSamples': 744,
          'separateCalls': True, 'physicalGpuTested': False, 'sceneVisualAcceptance': False,
          'scope': 'Four separate numeric GPU receipts. Neither screenshot acceptance nor full station ownership proof.'}
(ROOT / 'qa/GPU_SEPARATE_RECEIPTS.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
