/**
 * Thin, renderer-free scene API for the unchanged FH88 R04 driving runtime.
 * All simulation outputs come from that original 120 Hz model.
 * Route geometry is owned by the host: sample it at snapshot().positionM.
 */
import {DrivingPhysics} from './physics/driving-physics.mjs';
import {createDemoStart, motionReason} from './drive-assist.mjs';

export function createTrainDrive(parameters, {initial = {}, paused = true} = {}) {
  if (typeof paused !== 'boolean') throw new TypeError('paused must be boolean');
  let physics = new DrivingPhysics(parameters);
  physics.reset(initial);
  physics.setPaused(paused);
  const frozenParameters = physics.p;
  const assist = createDemoStart({
    snapshot: () => physics.snapshot(),
    applyControls: patch => physics.setControls(patch),
    setPaused: flag => physics.setPaused(flag),
  });
  const snapshot = () => {
    const state = physics.snapshot();
    const demo = assist.state();
    return {
      ...state,
      speedKph: state.speedMps * 3.6,
      distanceM: state.positionM,
      displacementM: state.positionM - state.rollingOriginPositionM,
      mechanical: physics.mechanicalState(),
      demo: {...demo, available: assist.available()},
      motion: motionReason(state, demo),
    };
  };
  const setControls = patch => {
    physics.setControls(patch);
    assist.manual();
    return snapshot();
  };
  const setPaused = flag => {
    physics.setPaused(flag);
    return snapshot();
  };
  return Object.freeze({
    parameters: frozenParameters,
    snapshot,
    /** Call once per rendered frame; seconds, never milliseconds. */
    tick(elapsedS) {
      const before = physics.snapshot().positionM;
      physics.advance(elapsedS);
      return {...snapshot(), deltaDistanceM: physics.snapshot().positionM - before};
    },
    setControls,
    controls: setControls,
    setPaused,
    pause: (flag = true) => setPaused(flag),
    /** Route grade is rise/run in the increasing-distance direction. */
    setGrade(grade) {
      physics.setControls({grade});
      return snapshot();
    },
    startDemo() {
      const result = assist.start();
      return {...result, state: snapshot()};
    },
    /** Command full brake and close throttle; never teleport speed to zero. */
    emergencyStop() {
      assist.emergency();
      return snapshot();
    },
    /** Fresh hot start, not a continuation of an archived boiler state. */
    reset(nextInitial = {}) {
      const candidate = new DrivingPhysics(frozenParameters);
      candidate.reset(nextInitial);
      candidate.setPaused(true);
      physics = candidate;
      assist.reset();
      return snapshot();
    },
  });
}

/** Uses a URL relative to this module, independent of the host page depth. */
export async function loadTrainDrive({
  parametersUrl = new URL('./physics/parameters.json', import.meta.url),
  initial = {}, paused = true,
} = {}) {
  const response = await fetch(parametersUrl);
  if (!response.ok) throw new Error(`FH88 parameters failed: ${response.status}`);
  return createTrainDrive(await response.json(), {initial, paused});
}
