import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createTrainDrive} from './train-drive.mjs';
import {DrivingPhysics} from './physics/driving-physics.mjs';
import {createDemoStart} from './drive-assist.mjs';

const read = p => fs.readFile(new URL(p, import.meta.url), 'utf8');
const parameters = JSON.parse(await read('./physics/parameters.json'));
const checks = [], evidence = {};
const check = async (name, run) => {
  try { await run(); checks.push({name, pass:true}); console.log('PASS', name); }
  catch (error) { checks.push({name, pass:false, error:String(error.stack)}); console.error('FAIL', name, error); }
};
const advance = (drive, seconds, fps = 60) => {
  for (let i = 0; i < Math.round(seconds * fps); i++) drive.tick(1 / fps);
  return drive.snapshot();
};
const raw = state => Object.fromEntries(Object.keys(new DrivingPhysics(parameters).snapshot()).map(key => [key, state[key]]));
const near = (actual, expected, tolerance = 1e-8) => assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);

await check('all six original files are byte-for-byte identical to gh-pages Git blob hashes', async () => {
  const manifest = JSON.parse(await read('./SOURCE_MANIFEST.json'));
  for (const file of manifest.files) {
    const bytes = await fs.readFile(new URL(file.path, import.meta.url));
    const sha = createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
    assert.equal(sha, file.gitBlobSha, file.path);
  }
});

await check('new scene starts paused, full brake, zero speed; run alone does not move', () => {
  const drive = createTrainDrive(parameters);
  assert.equal(drive.snapshot().paused, true);
  assert.equal(drive.snapshot().controls.brake, 1);
  drive.pause(false);
  const s = advance(drive, 10);
  assert.equal(s.positionM, 0); assert.equal(s.speedMps, 0);
});

await check('adapter exactly matches original R04 physics and demo recipe after eight seconds', () => {
  const drive = createTrainDrive(parameters, {initial:{positionM:123.45}});
  const physics = new DrivingPhysics(parameters);
  physics.reset({positionM:123.45}); physics.setPaused(true);
  const assist = createDemoStart({snapshot:()=>physics.snapshot(), applyControls:p=>physics.setControls(p), setPaused:p=>physics.setPaused(p)});
  drive.startDemo(); assist.start();
  const state = drive.tick(8), baseline = physics.advance(8);
  assert.deepEqual(raw(state), baseline);
  near(state.deltaDistanceM, state.positionM - 123.45);
  near(state.speedKph, state.speedMps * 3.6);
  near(state.displacementM, state.wheelRadiusM * state.wheelAngleRad);
  near(state.mechanical.commonThetaRad, state.initialMechanicalThetaRad - state.wheelAngleRad);
  assert.ok(state.positionM > 123.45); assert.ok(state.speedMps > 0);
  evidence.demoAtEightSeconds = {speedMps:state.speedMps, speedKph:state.speedKph, distanceM:state.displacementM, brakeFraction:state.brakeFraction};
});

await check('higher throttle produces stronger launch; ordinary coasting slows the train', () => {
  const launch = throttle => {
    const drive = createTrainDrive(parameters);
    drive.controls({throttle, brake:0}); drive.pause(false);
    advance(drive, 20);
    return drive;
  };
  const low = launch(.3), high = launch(.7);
  assert.ok(high.snapshot().speedMps > low.snapshot().speedMps);
  const before = high.snapshot(); high.controls({throttle:0});
  const after = advance(high, 10);
  assert.ok(after.speedMps < before.speedMps && after.speedMps > 0);
  assert.ok(after.positionM > before.positionM);
  evidence.launchAndCoast = {lowThrottleSpeedMps:low.snapshot().speedMps, highThrottleSpeedMps:before.speedMps, coastingTenSecondsSpeedMps:after.speedMps};
});

await check('emergency is a force-driven stop with brake lag, no rebound or automatic restart', () => {
  const drive = createTrainDrive(parameters); drive.startDemo();
  const before = advance(drive, 20);
  const command = drive.emergencyStop();
  assert.equal(command.speedMps, before.speedMps);
  assert.equal(command.controls.throttle, 0); assert.equal(command.controls.brake, 1);
  assert.ok(command.brakeFraction < 1);
  let stop = command, seconds = 0;
  while (stop.speedMps !== 0 && seconds < 120) { stop = drive.tick(.25); seconds += .25; }
  assert.equal(stop.speedMps, 0); assert.ok(seconds > 0);
  const held = advance(drive, 30);
  assert.equal(held.speedMps, 0); assert.equal(held.positionM, stop.positionM);
  assert.equal(drive.startDemo().applied, false);
  assert.equal(held.demo.emergencyLocked, true);
  evidence.emergency = {fromSpeedMps:before.speedMps, stopAfterS:seconds, stoppingDistanceM:stop.positionM-before.positionM, noReboundS:30};
  drive.controls({throttle:.3, brake:0});
  assert.ok(advance(drive, 8).speedMps > 0);
  assert.equal(drive.snapshot().demo.emergencyLocked, true);
  drive.reset(); assert.equal(drive.startDemo().applied, true);
});

await check('service brake also stops without passive reversal', () => {
  const drive = createTrainDrive(parameters); drive.startDemo(); advance(drive, 20);
  drive.controls({throttle:0, brake:.45});
  advance(drive, 90);
  assert.equal(drive.snapshot().speedMps, 0);
  const parked = drive.snapshot().positionM;
  advance(drive, 30); assert.equal(drive.snapshot().positionM, parked);
  assert.equal(drive.snapshot().demo.emergencyLocked, false);
});

await check('pause freezes all physical state; resume has no hidden elapsed-time catch-up', () => {
  const drive = createTrainDrive(parameters); drive.startDemo(); advance(drive, 8);
  drive.pause(); const before = drive.snapshot();
  drive.tick(120); assert.deepEqual(drive.snapshot(), before);
  drive.pause(false); drive.tick(1);
  near(drive.snapshot().timeS, before.timeS + 1);
});

await check('moving direction change is rejected atomically; reverse is available after stop', () => {
  const drive = createTrainDrive(parameters); drive.startDemo(); advance(drive, 20);
  const before = drive.snapshot();
  assert.throws(()=>drive.controls({reverser:-1, throttle:0}), /DIRECTION_CHANGE_REQUIRES_NEAR_STOP/);
  assert.deepEqual(drive.snapshot(), before);
  drive.reset({positionM:50}); drive.controls({reverser:-1, throttle:0}); drive.controls({throttle:.3, brake:0}); drive.pause(false);
  const reversed = advance(drive, 8);
  assert.ok(reversed.speedMps < 0 && reversed.positionM < 50);
  near(reversed.positionM - 50, reversed.wheelRadiusM * reversed.wheelAngleRad);
});

await check('bad controls, NaN time, bad grade and bad reset do not corrupt previous state', () => {
  const drive = createTrainDrive(parameters); drive.startDemo(); advance(drive, 8);
  for (const fn of [()=>drive.controls({throttle:2}), ()=>drive.tick(NaN), ()=>drive.tick(-1), ()=>drive.setGrade(.11), ()=>drive.reset({speedMps:Infinity})]) {
    const before = drive.snapshot(); assert.throws(fn); assert.deepEqual(drive.snapshot(), before);
  }
});

await check('30/60/144 FPS produce bit-identical physical states at a common ten-second tick', () => {
  const results = [30,60,144].map(fps => {const drive = createTrainDrive(parameters); drive.startDemo(); return raw(advance(drive,10,fps));});
  assert.deepEqual(results[0], results[1]); assert.deepEqual(results[1], results[2]);
});

await check('long frames retain the original capped-step backlog and allow explicit drain', () => {
  const drive = createTrainDrive(parameters); drive.startDemo();
  const first = drive.tick(12); near(first.timeS,10); near(first.backlogS,2);
  const drained = drive.tick(0); near(drained.timeS,12); near(drained.backlogS,0);
});

await check('route grade changes force only and does not steal manual/demo control state', () => {
  const drive = createTrainDrive(parameters); drive.startDemo();
  assert.equal(drive.setGrade(.001).demo.mode,'demo');
  const state = advance(drive,8);
  assert.ok(state.diagnostics.gradeForceN < 0);
});

await check('mass/energy residuals and distance-wheel identity remain bounded for sixty seconds', () => {
  const drive = createTrainDrive(parameters); drive.startDemo(); const state = advance(drive,60);
  near(state.positionM - state.rollingOriginPositionM, state.wheelRadiusM * state.wheelAngleRad,1e-7);
  for (const [key,value] of Object.entries(state.residuals)) near(value,0,key.endsWith('Kg')?1e-7:.01);
  evidence.sixtySeconds = {speedMps:state.speedMps, positionM:state.positionM, boilerPressurePa:state.boilerPressurePa, residuals:state.residuals};
});

const report = {schema:'HK_TRAIN88_DRIVE_ADAPTER_NODE_VALIDATION_R01', checkedAt:new Date().toISOString(), passed:checks.filter(x=>x.pass).length, failed:checks.filter(x=>!x.pass).length, checks, evidence, limitations:['Numerical/module integration tests only; no browser, route, collision, wheel-slip or train art validation.', 'Original parameters are uncalibrated game research assumptions, not real train safety or stopping-distance certification.']};
await fs.writeFile(new URL('./TEST_RESULTS.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
if (report.failed) process.exitCode = 1;
