# 88 驾驶逻辑的同场接入层

本目录只封装原有 FH88 R04 驾驶逻辑；不包含或替换旧车外形、原研究台页面、地图或线路数据，也未发布。原模块和依赖均已完整落地，不需要 Three.js、npm 或远程脚本。

## 来源和完整性

来源固定为 `haihao0307/guilin-dem-pipeline` 的 `gh-pages` 分支，目录 `kaopu-minigame-workbench/voxel-train-study/game/fh88-drive-r04`。六个原文件未改动，逐文件 Git blob SHA-1 见 `SOURCE_MANIFEST.json`，测试会验证实际字节。`drive-viewer.mjs` 已审读，它的 DOM/直线场景/旧研究外形不是本次运行依赖，因此没有复制成缺依赖的页面。

- 原物理内核：`physics/driving-physics.mjs`，零外部依赖
- 原一次起步/急刹控制：`drive-assist.mjs`，零外部依赖
- 原桥接：`physics/adapter-bridge.mjs`，只依赖同目录物理内核，供需要原桥接的宿主选择使用
- 原参数与边界：`physics/parameters.json`、`physics/MODEL.md`、`physics/INTEGRATION.md`
- 新薄封装：`train-drive.mjs`
- 新数值测试与结果：`test-train-drive.mjs`、`TEST_RESULTS.json`

## 最小接口

```js
import {loadTrainDrive} from './train-drive/train-drive.mjs';

const drive = await loadTrainDrive({initial:{positionM:0}});
// 默认暂停、热车、零速、全制动，不会加载后自动开车。
drive.startDemo(); // 只一次：前进、松刹、30%油门、55%截汽，并运行时钟

function frame(dtSeconds) {
  const s = drive.tick(dtSeconds);
  const pose = route.sampleAtDistance(s.positionM); // 宿主自己的真实线路采样
  // 把 pose 给车体父组；不要再次用 speed * dt 积分另一个车体位置。
  // 用 s.wheelAngleRad 或 s.mechanical 更新车轮/连杆。
  return s;
}

drive.controls({throttle:.7, brake:0});
drive.controls({throttle:0, brake:.5}); // 常用制动
drive.emergencyStop();                // 收油 + 全刹；靠原制动力逐渐停车
drive.pause(true);                    // 冻结时钟/位置/燃烧等全部原物理状态
drive.pause(false);
drive.reset({positionM:0});           // 新热启动并暂停，不是热力断点恢复
```

`createTrainDrive(parameters, {initial, paused})` 可直接接受宿主已加载的原参数 JSON。`loadTrainDrive()` 默认用相对当前模块的 URL 加载本地参数，支持嵌套页面路径。

`tick(dtSeconds)` 每渲染帧调用一次，返回原物理状态和以下只读派生字段：

- `positionM` / `distanceM`：相同值，沿线路正方向的米制里程；初始值由 `initial.positionM` 指定。它不是三维世界 X，不应用到任意轴后再叠加路线位移。
- `deltaDistanceM`：仅本次 `tick()` 产生的带符号米制位移。
- `displacementM`：从最近一次 reset 起的带符号总位移。
- `speedMps` / `speedKph`：带符号速度；仪表若只显示大小自行 `Math.abs()`。
- `wheelAngleRad`：纯滚动累计角，`positionM - rollingOriginPositionM = wheelRadiusM * wheelAngleRad`。
- `mechanical`：原机构接口。`commonThetaRad = initialMechanicalThetaRad - wheelAngleRad`，`omegaRadS = -wheelAngularSpeedRadS`；不要二次取反。
- `demo.available / used / emergencyLocked / mode`：起步按钮可用性和控制状态。
- `motion.code / short / text`：原始停车/起步/行驶/制动诊断。
- 原 `diagnostics`、`ledger`、`residuals`、`backlogS` 等均保留。

控制字段完全沿用原规则：`throttle` 和 `brake` 在 0..1，`cutoff` 在 .1...8，`reverser` 为 -1/0/+1。切新非空挡方向必须近停且关油门；例如先 `controls({throttle:0, reverser:-1})`，再给油。急刹锁住自动演示直到 reset；手动接管仍可用。急刹不会悄悄恢复暂停中的时钟。

`setGrade(grade)` 接入线路 rise/run 坡度（最大绝对值 .1），正坡表示里程增加方向上坡，不改变 demo/manual 状态。只有线路高程与里程均可靠时才接坡度；不要把未标定的显示高度当实测坡度。

## 宿主必须负责的部分

1. 线路弧长必须以真实米数计算，随后再将米转换为地图显示坐标。可以缩放渲染父组，但不能修改原内核速度或轮径来补偿地图比例。
2. 车体位置、沿线朝向、坡面姿态和每节车厢偏移由同一条线路的 `positionM` 采样生成；本层没有线路、弯道侧向力、车钩或脱轨求解。
3. 到达线路端点前应安排制动。禁止静默 clamp 显示位置后让物理继续跑；若只是首版游戏边界暂停，明确标注边界保护暂停，不称之为真实缓冲挡碰撞或物理刹停。
4. 页面隐藏时主动 `pause(true)`；返回后把宿主 `lastFrameTimestamp` 重置，再由用户继续。否则隐藏时间会进入原内核积压队列。
5. 原每帧最多处理 1200 ticks（10 s）；长帧的剩余时间留在 `backlogS`。原样保留，没有吞帧或变速。离线快进可用 `tick(0)` 明确排空；实时时钟不要随意混用第二个积分器。

## 验收与边界

运行：`node hong-kong-train88-r01/train-drive/test-train-drive.mjs`。

当前 13 项数值/模块检查通过，包括：源字节一致性、原 R04 数值逐值一致、加速/滑行/常用制动/急刹、制动滞后、不反弹、急刹后演示锁定与手动接管、暂停、倒车、原子拒绝坏输入、30/60/144 FPS 一致性、长帧积压、质量/能量残差。

默认演示第 8 秒：1.9773 km/h，走行 1.1713 m。演示运行 20 秒后从 2.4557 m/s 急刹，数值测试在 6 秒内停下，续行 8.4388 m，并保持 30 秒无反弹。以上仅是这组原游戏研究参数的结果，不是真实 88 列车性能或安全停车距离。

未做浏览器 UI、真实路线、外形/机构渲染或碰撞验收。完整物理缺项见保留的 `physics/MODEL.md`。
