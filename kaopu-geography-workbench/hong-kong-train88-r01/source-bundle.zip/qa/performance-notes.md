# Performance gate

The requested deliverable is the whole scene at normal display resolution. Tiny shader probes are not this gate.

- 1440×900 desktop and 844×390 mobile-landscape render sizes, no hidden quality downscale.
- Browser/GPU software identity and completed frame cadence must be disclosed.
- No live per-pixel tracing of the bureau or two buildings in this map: original fields generate finite 3D candidate display geometry beforehand.
- Locomotive source geometry and material callbacks are retained. Static parts are merged only by identical material instance; each wheel/rod keeps its original moving parent. This is draw-call batching, not a substitute model.
- Low software-renderer cadence does not certify physical-device smoothness; actual result is reported without 60 FPS claims.
