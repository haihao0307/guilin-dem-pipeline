
struct Params { eye:vec4<f32>,forward:vec4<f32>,right:vec4<f32>,up:vec4<f32>,resolution:vec4<f32>,options:vec4<f32>,clock:vec4<f32>,counts:vec4<u32>,tile:vec4<u32>,transport:vec4<f32>,tool:vec4<f32> };
struct ItemRecord {position:vec4<f32>,size:vec4<f32>};
@group(0) @binding(0) var<uniform> u:Params;

struct Hit {distance:f32,status:u32,steps:u32,mat:u32};

struct Queue {count:atomic<u32>,indices:array<u32,1024>};

struct Stats {hit:atomic<u32>,miss:atomic<u32>,exhausted:atomic<u32>,retried:atomic<u32>,maxSteps:atomic<u32>,glassRays:atomic<u32>,glassMiss:atomic<u32>,glassExhausted:atomic<u32>,visibilityRays:atomic<u32>,visibilityUnresolved:atomic<u32>,envRays:atomic<u32>,envOpen:atomic<u32>,envBlocked:atomic<u32>,envUnresolved:atomic<u32>,envInactive:atomic<u32>,envGlass:atomic<u32>,sunNearBlock:atomic<u32>,sunFarBlock:atomic<u32>,envMaxSteps:atomic<u32>,envNearBlock:atomic<u32>};

struct Transmission {distance:f32,status:u32,steps:u32,depth:f32};

struct ShadingRecord {positionDistance:vec4<f32>,normalAO:vec4<f32>,glassNormalDepth:vec4<f32>,params:vec4<f32>,localSeed:vec4<f32>,flags:vec4<u32>,frame0:vec4<f32>,frame1:vec4<f32>,frame2:vec4<f32>,frameLower:vec4<f32>,frameUpper:vec4<f32>};


// R3.12 family-0 original fitted edge waves, field and surface core.
// WGSL syntax/explicit arguments are new. No renderer, vertex or instance lists.
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }












































// Return original [chips, contour, weight] contributions instead of GLSL inout.





// Exact original family-0 distance, in metres. This is not guaranteed Lipschitz 1.0



// New explicit isotropic footprint bridge. Original wave, 17 octaves and gates
// remain; the original screen dFdx/dFdy footprint is NOT claimed equivalent.

// Raw original family-0 albedo, roughness and height. No lighting/tone mapping.


// R3.12 original macro/micro/observed field algebra. Explicit coordinates and
// derivative-free physical footprint are receiver bridges. No patch silhouette.
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}












// Syntax port of locked V26 waterWeatherMasks dependency closure.
// pField is the ORIGINAL normalized material field coordinate, not metres.
// localPosM/dimensionsM are original physical local position/size for gates.












// Existing explicitly authored unified fabric bridge, not source physical years.
struct KpFabricState { moisture:f32, damage:f32, retention:f32, thicknessM:f32, baseScale:f32, roughDelta:f32, }


// Apply the exact same resolved state used by receiver coat retention/thickness.
// Requires KpSurface from brick-core. No second independently computed age.


// User Library timber v3, exact box coordinate/noise/field formulas in WGSL.
// KpSurface must be declared by the parent brick module before this string.
// No bindings, stages, renderer, textures, geometry buffers or scene objects.
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}









































// pSourceM = member-local metres + inherited source grainOffset, +X axial.
// Signed normal displacement; use only this function in the geometry distance.

// Conservative magnitude bound for the original vertex displacement, in metres.
// Source macro noise is nonnegative with sum (0.58+0.261+0.11745)/0.94;
// original normal class multiplier is at most 1.08. This is not a Lipschitz bound.

// New screen-independent AA bridge. This is a nominal physical frequency estimate,
// not the original screen derivative and not a proof of derivative equivalence.
// fp=0 preserves the unfiltered original field exactly (up to f32 arithmetic).

// Complete source material terms before source-specific lighting or gamma.
// The caller supplies the actual member-local surface normal and face class.
// 0=longitudinal, 1=end grain, 2=joint cut, 3=weathered side.
// No camera-ray parallax march is hidden in this pure field call.


// Original fragment micro-height: PBR normal detail, NOT a replacement for macro geometry.

// Compatibility entry: top longitudinal face of the original default box timber.
// age/wet/repair are reserved host arguments; the original v3 has no such model.
// Scene overlays must be explicit outside this source-preserving material leaf.


// STONE_STUDY same-page stoneFields, kind 0 (the stone receiver's default).
// KpSurface is supplied once by the shared brick core; do not redefine it here.
// No texture, mesh, voxel atlas, material cache or additional noise family.
// Authored unit bridge: a 0.42 m longest side maps to 3.4 specimen units.
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_KIND:i32 = 0;
const KP_STONE_MASTER_SEED:u32 = 8231u;
// Original normalizeSeedDNA offsets: color +401, pore +307, weather +601.
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;








// New explicit isotropic footprint bridge replacing screen-space fwidth(line).
// It reevaluates the ORIGINAL line and warp at three metric axis offsets.
// This bound-like footprint is not screen-space fwidth equivalence and is not
// complete band-limiting of the original noise; zero footprint keeps 0.008.

// Original kind-0 stoneFields arithmetic. Fixed original material controls:
// sSurface.x=1, sSurface.y=0.7, sDisplay.w=1, sRelief=1, uEventCount=0.
// Original event-loop contribution is therefore 0. Original pits still apply.
// Branches 1/2/3 and their inactive grain/phase/crystal evaluations are omitted.

// New, authored age/moisture/repair bridge copied from resolveStoneFabric.
// Its original default wear=0.15 is fixed because this call has no wear input.
// No calibrated decay law, damage geometry, formation events or SDF is ported.
// Age changes original wet/rough uniforms only; original height stays intact.


// STONE_STUDY original sKind == 3 (blue-gray slate) surface branch.
// Append AFTER existing KP_STONE_WGSL; reuse its st_* source functions/seeds.
// Receiver controls below are explicit design bindings, NOT physical calibration.
// Original event count remains 0, matching the current surface-only port.
struct KpStoneSlateParams {
 sourceScaleM:f32, materialScale:f32, mineral:f32, chroma:f32, relief:f32,
};


// Same existing authored age/moisture/repair bridge; only source branch differs.











struct MaterialFrame { worldToLocal:mat3x3<f32>, lower:vec3<f32>, upper:vec3<f32>, enabled:f32 };
fn identityFrame()->MaterialFrame {return MaterialFrame(mat3x3<f32>(vec3<f32>(1.,0.,0.),vec3<f32>(0.,1.,0.),vec3<f32>(0.,0.,1.)),vec3<f32>(0.),vec3<f32>(0.),0.);}
fn rigidIdentity()->mat3x3<f32>{return mat3x3<f32>(vec3<f32>(1.,0.,0.),vec3<f32>(0.,1.,0.),vec3<f32>(0.,0.,1.));}
fn rigidWest()->mat3x3<f32>{return mat3x3<f32>(vec3<f32>(0.,0.,1.),vec3<f32>(0.,1.,0.),vec3<f32>(1.,0.,0.));}





struct Field { d:f32, mat:u32, local:vec3<f32>, seed:f32, age:f32, wet:f32, component:MaterialFrame };
fn box(p:vec3<f32>,b:vec3<f32>)->f32 {let q=abs(p)-b;return length(max(q,vec3<f32>(0.)))+min(max(q.x,max(q.y,q.z)),0.);}
fn cylinder(p:vec3<f32>,r:f32,h:f32)->f32 {let q=vec2<f32>(length(p.xz)-r,abs(p.y)-h);return min(max(q.x,q.y),0.)+length(max(q,vec2<f32>(0.)));}
fn capsule(p:vec3<f32>,a:vec3<f32>,b:vec3<f32>,r:f32)->f32 {let q=p-a;let v=b-a;return length(q-v*clamp(dot(q,v)/dot(v,v),0.,1.))-r;}
fn shell(d:f32,p:vec3<f32>)->f32 {if(u.options.x>.5){return max(d,p.y-1.1);}return d;}
fn field(d:f32,mat:u32,p:vec3<f32>,seed:f32)->Field {
 let outside=select(0.,1.,p.x< -42.9||p.x>49.8||p.z< -40.8||p.z>40.||p.y>11.7);
 let runoff=1.-smoothstep(.04,.28,abs(fract((p.x+p.z*.13)/5.5)-.06)*5.5);
 let splash=(1.-smoothstep(.05,1.1,p.y))*.38;
 let wet=clamp(.025+outside*(.08+runoff*.34+splash),0.,.85);
 return Field(d,mat,p,seed,u.options.y,wet,identityFrame());
}


fn take(a:Field,b:Field)->Field {if(b.d<a.d){return b;}return a;}
fn repeatX(x:f32,pitch:f32,limit:f32)->f32 {return x-clamp(round(x/pitch),-limit,limit)*pitch;}
fn glyph(code:u32)->u32 {switch(code){
case 65u:{return 18415150u;}
case 66u:{return 16301615u;}
case 68u:{return 16303663u;}
case 69u:{return 32554047u;}
case 70u:{return 1096767u;}
case 71u:{return 32044094u;}
case 72u:{return 18415153u;}
case 73u:{return 32641183u;}
case 75u:{return 18128177u;}
case 76u:{return 32539681u;}
case 78u:{return 18667121u;}
case 79u:{return 15255086u;}
case 82u:{return 18136623u;}
case 83u:{return 16267326u;}
case 84u:{return 4329631u;}
case 85u:{return 15255089u;}
case 67u:{return 31491134u;}
case 38u:{return 23894310u;}
case 49u:{return 14815428u;}
case 57u:{return 15235630u;}
case 46u:{return 4194304u;}
default:{return 0u;}}}
fn textRow(p:vec3<f32>,line:u32)->f32 {
let place=array<u32,18>(72u,79u,78u,71u,32u,75u,79u,78u,71u,32u,65u,46u,68u,46u,49u,57u,49u,49u);
let office=array<u32,27>(71u,69u,78u,69u,82u,65u,76u,32u,76u,79u,83u,84u,32u,38u,32u,70u,79u,85u,78u,68u,32u,79u,70u,70u,73u,67u,69u);
let scale=select(.088,.073,line==1u);let count=select(18.,27.,line==1u);let baseline=select(7.00,6.53,line==1u);
let q=vec3<f32>(p.x+count*scale*3.,baseline-p.y,p.z);var d=100.;let cell=i32(floor(q.x/(scale*6.)));
for(var g=-1;g<=1;g++){let index=cell+g;if(index<0||f32(index)>=count){continue;}var code=0u;if(line==0u){code=place[u32(index)];}else{code=office[u32(index)];}let mask=glyph(code);let local=vec2<f32>(q.x-f32(index)*scale*6.,q.y+2.5*scale);let ix=i32(floor(local.x/scale));let iy=i32(floor(local.y/scale));for(var dy=-1;dy<=1;dy++){for(var dx=-1;dx<=1;dx++){let xx=ix+dx;let yy=iy+dy;if(xx<0||xx>4||yy<0||yy>4){continue;}if((mask&(1u<<u32(yy*5+xx)))!=0u){let r=vec3<f32>(local.x-(f32(xx)+.5)*scale,local.y-(f32(yy)+.5)*scale,q.z);d=min(d,box(r,vec3<f32>(scale*.43,scale*.43,.017)));}}}}return d;}
fn entranceText(p:vec3<f32>)->f32 {let bound=box(p-vec3<f32>(0.,6.78,0.),vec3<f32>(6.6,.51,.04));if(bound>.1){return 100.;}return min(textRow(p,0u),textRow(p,1u));}
// Round-headed openings and their stone archivolts share the same field.
fn archOpening(q:vec3<f32>,radius:f32,spring:f32,depth:f32)->f32 {
 let plan=min(max(abs(q.x)-radius,max(-q.y,q.y-spring)),length(vec2<f32>(q.x,q.y-spring))-radius);
 return max(plan,abs(q.z)-depth);
}

fn sashWindow(q:vec3<f32>,radius:f32,spring:f32,seed:f32,worldToWindow:mat3x3<f32>)->Field {
 let opening=archOpening(q,radius,spring,.8);
 let reveal=max(archOpening(vec3<f32>(q.xy,q.z+.08),radius+.14,spring,.27),-opening);
 var f=field(reveal,3u,q,seed);
 let frameOuter=archOpening(vec3<f32>(q.xy,q.z-.11),radius-.025,spring,.10);
 let frameInner=archOpening(vec3<f32>(q.xy,q.z-.11),radius-.13,spring,.24);
 var frame=max(frameOuter,-frameInner);
 // Two vertically sliding sashes, recessed glazing and arched fanlight.
 let meeting=spring*.51;let centre=box(q-vec3<f32>(0.,spring*.5,.12),vec3<f32>(.035,spring*.5,.06));
 let rail=box(q-vec3<f32>(0.,meeting,.12),vec3<f32>(radius-.10,.045,.065));
 let transom=box(q-vec3<f32>(0.,spring,.12),vec3<f32>(radius-.09,.05,.08));
 let bar=box(q-vec3<f32>(0.,spring*.25,.13),vec3<f32>(radius-.10,.022,.044));
 let upperbar=box(q-vec3<f32>(0.,spring*.76,.13),vec3<f32>(radius-.10,.022,.044));
 frame=min(frame,min(min(centre,rail),min(transom,min(bar,upperbar))));
 for(var i=0;i<3;i++){let a=.78539816*f32(i+1);let end=vec3<f32>(cos(a)*(radius-.11),spring+sin(a)*(radius-.11),.12);frame=min(frame,capsule(q,vec3<f32>(0.,spring,.12),end,.021));}
 frame=max(frame,archOpening(q,radius-.025,spring,.26));
 f=take(f,field(frame,14u,q,seed));
 let glass=max(archOpening(q,radius-.12,spring,.6),abs(q.z-.165)-.0045);
 f=take(f,field(glass,8u,q,seed));
 let sill=box(q-vec3<f32>(0.,-.09,-.13),vec3<f32>(radius+.23,.09,.42));f=take(f,field(sill,3u,q,seed));
 let apron=box(q-vec3<f32>(0.,-.24,.025),vec3<f32>(radius+.10,.075,.19));f=take(f,field(apron,3u,q,seed));
 // Hardware lives at the meeting rail; sheltered contact polishes the handle.
 let handle=capsule(q,vec3<f32>(-.12,meeting+.09,.225),vec3<f32>(.12,meeting+.09,.225),.018);
 f=take(f,field(handle,9u,q,seed));f.wet=.035;
 // The complete timber frame has these actual local metre extents. No normal,
 // tangent or footprint may silently switch back to world axes.
 if(f.mat==14u){f.component=MaterialFrame(worldToWindow,vec3<f32>(-radius+.025,0.,.01),vec3<f32>(radius-.025,spring+radius-.025,.21),1.);}return f;
}


fn entryJoinery(p:vec3<f32>)->Field {
 let bound=box(p-vec3<f32>(-39.6,2.9,-18.),vec3<f32>(5.4,3.0,4.1));
 if(bound>1.){return field(bound,0u,p,0.);}
 let q=vec3<f32>(p.z+18.,p.y,p.x+38.7);
 let opening=archOpening(q,3.4,2.2,1.);
 let trim=max(archOpening(vec3<f32>(q.xy,q.z+.15),3.65,2.2,.24),-opening);
 var f=field(shell(trim,p),3u,p,20.);
 // The threshold bridges a 33 mm interior finish, without imaginary tall stairs.
 let threshold=box(p-vec3<f32>(-38.70,.0165,-18.),vec3<f32>(.38,.0165,3.38));
 f=take(f,field(threshold,3u,p,20.));
 let outerLanding=box(p-vec3<f32>(-43.5,-.008,-18.),vec3<f32>(1.15,.008,4.3));f=take(f,field(outerLanding,3u,p,20.));
 // Four timber leaves form two inward-folded pairs. Each leaf is 1.56 m
 // wide: the folded stack stays beside the jamb and intrudes only 1.62 m.
 // The central 6.08 m entry axis stays open rather than a 3 m leaf filling it.
 for(var leafIndex=0;leafIndex<4;leafIndex++){let side=leafIndex/2;let folded=leafIndex%2;let sg=select(-1.,1.,side==1);
 let door=vec3<f32>(p.x+38.62-.81,p.y-1.56,(p.z+18.-sg*3.24)*sg+f32(folded)*.14);
 var leaf=box(door,vec3<f32>(.78,1.53,.050));let paneHole=box(door-vec3<f32>(0.,.59,0.),vec3<f32>(.58,.62,.20));leaf=max(leaf,-paneHole);
 f=take(f,field(shell(leaf,p),4u,door,22.+f32(leafIndex)));
 let pane=max(paneHole,abs(door.z)-.0045);f=take(f,field(shell(pane,p),8u,door,22.+f32(leafIndex)));
 let glazingBars=min(box(door-vec3<f32>(0.,.59,0.),vec3<f32>(.025,.65,.075)),box(door-vec3<f32>(0.,.59,0.),vec3<f32>(.60,.025,.075)));f=take(f,field(shell(glazingBars,p),14u,door,22.+f32(leafIndex)));
 let bottomPanel=max(box(door-vec3<f32>(0.,-.77,.056),vec3<f32>(.60,.53,.022)),-box(door-vec3<f32>(0.,-.77,.056),vec3<f32>(.53,.45,.10)));f=take(f,field(shell(bottomPanel,p),18u,door,22.+f32(leafIndex)));
 let pull=capsule(door,vec3<f32>(-.52,-.1,.11),vec3<f32>(-.52,.3,.11),.027);f=take(f,field(shell(pull,p),9u,door,22.+f32(leafIndex)));
 let hinge=cylinder(vec3<f32>(p.x+37.04,p.y-1.56,(p.z+18.-sg*3.17)*sg),.035,.17);f=take(f,field(shell(hinge,p),9u,p,24.));
 }
 // Fanlight follows the same opening outline, not a second opaque arch plate.
 let fan=max(opening,max(3.14-q.y,abs(q.z-.14)-.0045));f=take(f,field(shell(fan,p),8u,q,20.));
 let transom=box(q-vec3<f32>(0.,3.12,.12),vec3<f32>(3.27,.065,.09));f=take(f,field(shell(transom,p),14u,q,20.));
 let fanU=repeatX(q.x,.82,3.);let fanBar=max(box(vec3<f32>(fanU,q.y-4.30,q.z-.12),vec3<f32>(.026,1.17,.065)),max(opening,3.14-q.y));f=take(f,field(shell(fanBar,p),14u,q,20.));return f;
}


// A distant enclosing-box result is a marching bound, never a visible object.
// Every bound encloses its complete child function, including trims and lamps.



// Shared by physical lamp geometry and the receiver's illumination. No duplicate
// hand-maintained light positions are needed in renderer.mjs.



// Raised seven-segment brass numbers. Evaluation is seven bounded segments per
// digit, independent of the number of windows, rows, bays, or shelf levels.




// A fixture has a ceiling rose, real suspension rod, reflector lip and a bulb.
// The bulb centre is exactly interiorLightPosition(), including tower mounting.










// A slab is a rounded plan extruded through its actual thickness. Its form is
// the ray-intersection field, not a painted rounded rectangle on a box.


// Thin paper packets use a new, explicit authored cellulose approximation.
// It is not plaster, brass or a claimed recovered material mother. The same
// bounded fibre-height function drives its solid and surface micro-normal.





// Local chair faces +z; the bench faces +x. Both have real legs to the floor.



















fn archWindow(q:vec3<f32>,radius:f32,spring:f32,depth:f32)->f32 {return archOpening(q,radius,spring,depth);}
fn arcade(q:vec3<f32>,span:f32)->Field {
 let u0=repeatX(q.x,5.5,20.);let opening=archOpening(vec3<f32>(u0,q.y,q.z),2.14,2.75,1.);
 let wall=max(box(q-vec3<f32>(0.,2.68,0.),vec3<f32>(span,2.68,.32)),-opening);
 let band=max(archOpening(vec3<f32>(u0,q.y,q.z),2.48,2.75,.39),-opening);
 var f=field(shell(max(wall,box(q-vec3<f32>(0.,2.7,0.),vec3<f32>(span,2.7,.4))),q),2u,q,4.);
 f=take(f,field(shell(max(band,box(q-vec3<f32>(0.,2.7,0.),vec3<f32>(span,2.7,.42))),q),3u,q,4.));
 let pier=abs(u0)-2.75;let foot=box(vec3<f32>(pier,q.y-.18,q.z),vec3<f32>(.55,.18,.48));
 let cap=box(vec3<f32>(pier,q.y-2.7,q.z),vec3<f32>(.48,.16,.46));
 f=take(f,field(shell(max(min(foot,cap),box(q-vec3<f32>(0.,2.7,0.),vec3<f32>(span,2.7,.5))),q),3u,q,4.));return f;
}
// Upper and lower loggias share a bay axis and outer bearing line.
fn upperLoggia(q:vec3<f32>,span:f32)->Field {
 let u0=repeatX(q.x,5.5,20.);let opening=archOpening(vec3<f32>(u0,q.y-5.6,q.z),1.92,2.55,1.);
 var wall=max(box(q-vec3<f32>(0.,8.36,0.),vec3<f32>(span,2.84,.34)),-opening);
 let rim=max(archOpening(vec3<f32>(u0,q.y-5.6,q.z),2.14,2.55,.43),-opening);
 var f=field(shell(wall,q),2u,q,6.);f=take(f,field(shell(max(rim,box(q-vec3<f32>(0.,8.36,0.),vec3<f32>(span,2.84,.46))),q),3u,q,6.));
 // Open stone balustrades close the gallery edge, not a bare projecting slab.
 let bx=repeatX(q.x,.55,100.);var bal=cylinder(vec3<f32>(bx,q.y-6.08,q.z+.10),.065,.28);
 bal=min(bal,length(vec3<f32>(bx,q.y-6.1,q.z+.10))-.11);
 bal=min(bal,box(q-vec3<f32>(0.,6.43,-.10),vec3<f32>(span,.095,.25)));
 bal=min(bal,box(q-vec3<f32>(0.,5.75,-.10),vec3<f32>(span,.095,.25)));
 f=take(f,field(shell(max(bal,box(q-vec3<f32>(0.,6.08,0.),vec3<f32>(span,.50,.45))),q),3u,q,6.));
 // Layered bearing cornice with a restrained tooth rhythm.
 let cornice=min(box(q-vec3<f32>(0.,11.18,0.),vec3<f32>(span+.16,.14,.48)),box(q-vec3<f32>(0.,11.48,-.04),vec3<f32>(span+.3,.13,.66)));
 let tooth=max(box(vec3<f32>(repeatX(q.x,.55,100.),q.y-11.30,q.z+.28),vec3<f32>(.13,.13,.29)),box(q-vec3<f32>(0.,11.3,0.),vec3<f32>(span,.3,.8)));
 f=take(f,field(shell(min(cornice,tooth),q),3u,q,6.));return f;
}
fn publicGable(q:vec3<f32>,worldToGable:mat3x3<f32>)->Field {
 let tri=max(box(q-vec3<f32>(0.,13.35,0.),vec3<f32>(5.65,2.15,.32)),q.y-(15.6-abs(q.x)*.72));
 let ux=abs(q.x)-.85;let window=archOpening(vec3<f32>(ux,q.y-11.85,q.z),.47,1.15,1.);
 var f=field(shell(max(tri,-window),q),2u,q,12.);
 var rake=capsule(q,vec3<f32>(-5.75,11.47,-.1),vec3<f32>(0.,15.75,-.1),.15);
 rake=min(rake,capsule(q,vec3<f32>(0.,15.75,-.1),vec3<f32>(5.75,11.47,-.1),.15));
 rake=min(rake,box(q-vec3<f32>(0.,11.65,-.05),vec3<f32>(5.9,.12,.43)));
 let frame=max(archOpening(vec3<f32>(ux,q.y-11.85,q.z+.1),.63,1.15,.4),-window);f=take(f,field(shell(min(rake,frame),q),3u,q,12.));
 var gw=sashWindow(vec3<f32>(ux,q.y-11.85,q.z),.47,1.15,12.,mat3x3<f32>(vec3<f32>(sign(q.x),0.,0.),vec3<f32>(0.,1.,0.),vec3<f32>(0.,0.,1.))*worldToGable);gw.d=shell(gw.d,q);f=take(f,gw);
 let finial=min(cylinder(q-vec3<f32>(0.,16.,0.),.11,.25),length(q-vec3<f32>(0.,16.25,0.))-.17);f=take(f,field(shell(finial,q),3u,q,12.));return f;
}
fn towerHalf(y:f32)->vec2<f32> {
 return vec2<f32>(7.1,8.2)-vec2<f32>(.75,1.1)*smoothstep(7.2,8.4,y)-vec2<f32>(1.3,1.7)*smoothstep(12.3,13.7,y)-vec2<f32>(1.25,1.6)*smoothstep(18.2,19.4,y);
}
fn chamferPlan(q:vec2<f32>,h:vec2<f32>,bevel:f32)->f32 {let a=abs(q);return max(max(a.x-h.x,a.y-h.y),(a.x+a.y-h.x-h.y+bevel)*.70710678);}
fn taperedTower(p:vec3<f32>)->Field {
 let tq=p-vec3<f32>(-35.5,0.,-18.);let h=towerHalf(p.y);
 // Continuous curved setbacks, chamfered corners and conservative distance bound.
 let outer=max(chamferPlan(tq.xz,h,.65)/2.3,max(-p.y,p.y-23.8));
 let inner=max(chamferPlan(tq.xz,h-vec2<f32>(.48),.42)/2.3,max(-.05-p.y,p.y-24.1));var wall=max(outer,-inner);
 let mainArch=archOpening(vec3<f32>(tq.z,p.y,tq.x+7.10),3.05,3.15,1.1);wall=max(wall,-mainArch);
 wall=max(wall,-box(p-vec3<f32>(-28.4,1.7,-20.),vec3<f32>(1.,1.75,1.75)));
 // Axial public arches join the vestibule to both lengths of the west hall.
 // Preserve the tower corners while releasing the public and custody aisles.
 let hallArch=archOpening(vec3<f32>(p.x+33.6,p.y,abs(tq.z)-8.2),3.95,1.55,1.1);wall=max(wall,-hallArch);
 // The upper office connects by a short stair to the first tower floor.
 let towerBridgePortal=box(p-vec3<f32>(-31.4,7.25,-10.1),vec3<f32>(1.03,1.90,1.65));wall=max(wall,-towerBridgePortal);
 let tier=select(select(0.,1.,p.y>12.5),2.,p.y>18.5);let baseline=select(select(8.45,14.0,tier>.5),19.6,tier>1.5);
 let pitch=select(select(4.25,3.0,tier>.5),2.25,tier>1.5);let radius=select(.95,.72,tier>1.5);
 let u0=repeatX(tq.z,pitch,1.);let v0=repeatX(tq.x,pitch*.8,1.);
 let front=archOpening(vec3<f32>(u0,p.y-baseline,abs(tq.x)-h.x),radius,1.35,1.1);
 let side=archOpening(vec3<f32>(v0,p.y-baseline,abs(tq.z)-h.y),radius,1.35,1.1);
 wall=max(max(wall,-front),-side);var f=field(shell(wall,p),2u,p,7.);
 let hallRing=max(archOpening(vec3<f32>(p.x+33.6,p.y,abs(tq.z)-8.2),4.18,1.55,.58),-hallArch);f=take(f,field(shell(hallRing,p),3u,p,20.));
 var fw=sashWindow(vec3<f32>(u0,p.y-baseline,h.x-abs(tq.x)),radius,1.35,7.,mat3x3<f32>(vec3<f32>(0.,0.,-sign(tq.x)),vec3<f32>(0.,1.,0.),vec3<f32>(1.,0.,0.)));
 var sw=sashWindow(vec3<f32>(v0,p.y-baseline,h.y-abs(tq.z)),radius,1.35,8.,mat3x3<f32>(vec3<f32>(1.,0.,0.),vec3<f32>(0.,1.,0.),vec3<f32>(0.,0.,-sign(tq.z))));
 fw.d=shell(max(fw.d,box(tq-vec3<f32>(0.,15.5,0.),vec3<f32>(7.4,8.3,8.5))),p);
 sw.d=shell(max(sw.d,box(tq-vec3<f32>(0.,15.5,0.),vec3<f32>(7.4,8.3,8.5))),p);
 fw.d=max(fw.d,-towerBridgePortal);sw.d=max(sw.d,-towerBridgePortal);f=take(f,fw);f=take(f,sw);
 // Continuous stone corner pilasters follow the inward curve rather than standing free.
 let corner=abs(abs(tq.x)+abs(tq.z)-h.x-h.y+.65)*.70710678-.16;
 let cornerBound=max(max(abs(tq.x)-h.x-.05,abs(tq.z)-h.y-.05),max(-p.y,p.y-23.8));
 f=take(f,field(shell(max(corner,cornerBound),p),3u,p,8.));
 for(var n=0;n<4;n++){let ys=array<f32,4>(7.12,12.26,18.16,23.78);let yy=ys[u32(n)];let hh=towerHalf(yy)+vec2<f32>(.32);var course=max(chamferPlan(tq.xz,hh,.7),abs(p.y-yy)-.17);course=max(course,-chamferPlan(tq.xz,hh-vec2<f32>(.58),.5));course=max(course,-towerBridgePortal);f=take(f,field(shell(course,p),3u,p,8.));}
 let portalRing=max(archOpening(vec3<f32>(tq.z,p.y,tq.x+7.22),3.55,3.15,.28),-mainArch);f=take(f,field(shell(portalRing,p),3u,p,8.));
 // Eight real treads bridge office floor 5.44m to tower finished floor 6.63m.
 let bridgeStep=clamp(floor((-p.z-8.8)/.30),0.,7.);let bridgeTop=5.44+(bridgeStep+1.)*.14875;
 let bridge=box(p-vec3<f32>(-31.4,bridgeTop-.074375,-8.8-(bridgeStep+.5)*.30),vec3<f32>(.92,.074375,.15));
 f=take(f,field(shell(bridge,p),4u,p,21.));
 f=take(f,field(shell(box(p-vec3<f32>(-31.4,6.55,-11.62),vec3<f32>(.92,.08,.45)),p),3u,p,21.));
 // Floor plates and two dogleg flights link the occupied upper tower levels.
 for(var n=0;n<3;n++){let ys=array<f32,3>(6.5,12.3,18.2);let yy=ys[u32(n)];let hh=towerHalf(yy)-vec2<f32>(.5);var slab=max(chamferPlan(tq.xz,hh,.5),abs(p.y-yy)-.13);slab=max(slab,-box(tq-vec3<f32>(0.,yy,0.),vec3<f32>(1.95,.4,3.1)));f=take(f,field(shell(slab,p),3u,p,7.));}
 for(var n=0;n<2;n++){let y0=select(6.5,12.3,n==1);let rise=select(5.8,5.9,n==1);let back=p.y>y0+rise*.5;let zz=select(tq.z,-tq.z,back);let step=clamp(floor((zz+2.4)/.3),0.,15.);let yy=y0+select(0.,rise*.5,back)+(step+1.)*rise/32.;let xx=select(-1.05,1.05,back);let tread=box(vec3<f32>(tq.x-xx,p.y-yy+.075,zz-(-2.4+(step+.5)*.3)),vec3<f32>(.68,.075,.15));f=take(f,field(shell(tread,p),3u,p,7.));f=take(f,field(shell(box(tq-vec3<f32>(0.,y0+rise*.5,2.65),vec3<f32>(1.75,.1,.4)),p),3u,p,7.));}
 if(u.options.x<.5){let hip=max(abs(p.y-(27.5-max(abs(tq.x),abs(tq.z))*.85))-.16,box(tq-vec3<f32>(0.,25.5,0.),vec3<f32>(4.35,2.5,4.35)));f=take(f,field(hip,7u,p,7.));
 let finial=min(cylinder(tq-vec3<f32>(0.,27.7,0.),.08,.3),length(tq-vec3<f32>(0.,28.,0.))-.14);f=take(f,field(finial,3u,p,7.));
 f=take(f,field(box(p-vec3<f32>(-42.93,6.78,-18.),vec3<f32>(.12,.50,6.5)),12u,p,1.));f=take(f,field(entranceText(vec3<f32>(p.z+18.,p.y,p.x+43.10)),13u,p,1.));}
 return f;
}
fn taperedChimney(p:vec3<f32>)->Field {
 let q=p-vec3<f32>(61.,0.,55.);let t=clamp((p.y-3.)/27.,0.,1.);let radius=mix(2.45,1.18,t);
 let shaft=max((length(q.xz)-radius)/1.01,max(2.8-p.y,p.y-30.));
 let flue=max(length(q.xz)-max(.74,radius-.48),max(3.2-p.y,p.y-31.4));
 var d=max(shaft,-flue);var f=field(d,2u,p,9.);
 let base=max(cylinder(q-vec3<f32>(0.,1.5,0.),3.,1.5),-cylinder(q-vec3<f32>(0.,2.,0.),1.5,1.6));f=take(f,field(base,2u,p,9.));
 let plinth=max(cylinder(q-vec3<f32>(0.,.28,0.),3.24,.28),-cylinder(q-vec3<f32>(0.,1.,0.),1.5,1.));
 let collar=max(cylinder(q-vec3<f32>(0.,3.,0.),2.7,.18),-cylinder(q-vec3<f32>(0.,3.,0.),1.85,.5));f=take(f,field(min(plinth,collar),3u,p,9.));
 // Slightly corbelled lip is proportionate to the slender throat and remains open.
 let cap=max(cylinder(q-vec3<f32>(0.,30.55,0.),1.39,.45),-cylinder(q-vec3<f32>(0.,30.55,0.),.75,.8));f=take(f,field(cap,2u,p,9.));
 let rim=max(cylinder(q-vec3<f32>(0.,30.96,0.),1.49,.10),-cylinder(q-vec3<f32>(0.,30.96,0.),.75,.3));f=take(f,field(rim,3u,p,9.));return f;
}
fn architecture(p:vec3<f32>)->Field {
 // A conservative whole-body candidate, not drawable cached geometry. Sky and
 // street rays reach this envelope before any civic-wing/tower detail expands.
 let civicBound=box(p-vec3<f32>(3.8,14.1,-.1),vec3<f32>(47.5,14.6,41.8));
 if(civicBound>.8){return field(civicBound,0u,p,0.);}
 var f=field(box(p-vec3<f32>(4.,-.24,0.),vec3<f32>(46.,.24,40.)),3u,p,1.);
 // Continuous L-shaped, 3.2m clear sheltered walk. The x-negative street is public entry.
 let westQ=vec3<f32>(p.z,p.y,p.x+42.6);let southQ=vec3<f32>(p.x-4.,p.y,p.z+40.5);
 var wa=arcade(westQ,40.7);wa.d=max(wa.d,-box(p-vec3<f32>(-42.6,3.,-18.),vec3<f32>(1.,3.1,4.0)));f=take(f,wa);
 f=take(f,arcade(southQ,46.6));
 f=take(f,field(shell(box(p-vec3<f32>(-40.7,5.42,0.),vec3<f32>(2.35,.18,40.9)),p),3u,p,1.));
 f=take(f,field(shell(box(p-vec3<f32>(4.,5.42,-38.7),vec3<f32>(46.8,.18,2.2)),p),3u,p,2.));
 let upperWest=upperLoggia(westQ,40.7);let towerVoid=box(p-vec3<f32>(-40.5,9.,-18.),vec3<f32>(3.,5.,8.7));var uw=upperWest;uw.d=max(uw.d,-towerVoid);f=take(f,uw);f=take(f,upperLoggia(southQ,46.6));
 // Recessed business hall and upper offices, coherent bays behind the arcade.
 let towerUpperVoid=box(p-vec3<f32>(-35.5,9.,-18.),vec3<f32>(7.5,3.55,8.5));let wz=repeatX(p.z,5.5,7.);var west=box(p-vec3<f32>(-38.7,5.2,0.),vec3<f32>(.3,5.2,40.));
 let winW=archWindow(vec3<f32>(wz,p.y-6.1,p.x+38.7),.87,1.35,.8);
 west=max(west,-winW);west=max(west,-archOpening(vec3<f32>(p.z+18.,p.y,p.x+38.7),3.4,2.2,1.));
 let groundW=archWindow(vec3<f32>(wz,p.y-1.25,p.x+38.7),.8,1.85,.8);west=max(west,-groundW);
 west=max(west,-towerUpperVoid);f=take(f,field(shell(west,p),2u,p,1.));
 var ww=sashWindow(vec3<f32>(wz,p.y-6.1,p.x+38.7),.87,1.35,1.,rigidWest());ww.d=shell(max(ww.d,-towerUpperVoid),p);f=take(f,ww);
 if(abs(p.z+18.)>4.){var wg=sashWindow(vec3<f32>(wz,p.y-1.25,p.x+38.7),.8,1.85,2.,rigidWest());wg.d=shell(wg.d,p);f=take(f,wg);}
 let sx=repeatX(p.x-4.,5.5,8.);var south=box(p-vec3<f32>(4.,5.2,-36.6),vec3<f32>(46.,5.2,.3));
 let sw=archWindow(vec3<f32>(sx,p.y-6.1,p.z+36.6),.9,1.35,.8);let sg=archWindow(vec3<f32>(sx,p.y-1.2,p.z+36.6),.9,1.85,.8);south=max(max(south,-sw),-sg);
 f=take(f,field(shell(south,p),2u,p,2.));
 var su=sashWindow(vec3<f32>(sx,p.y-6.1,p.z+36.6),.9,1.35,2.,rigidIdentity());su.d=shell(su.d,p);f=take(f,su);
 var sl=sashWindow(vec3<f32>(sx,p.y-1.2,p.z+36.6),.9,1.85,3.,rigidIdentity());sl.d=shell(sl.d,p);f=take(f,sl);
 // Continuous stone string courses and eave, derived from the same bay grammar.
 let bandY=select(5.6,10.35,p.y>8.);f=take(f,field(shell(max(box(p-vec3<f32>(-38.9,bandY,0.),vec3<f32>(.55,.18,40.5)),-towerUpperVoid),p),3u,p,1.));
 f=take(f,field(shell(box(p-vec3<f32>(4.,bandY,-36.8),vec3<f32>(46.5,.18,.55)),p),3u,p,2.));
 // Four occupied storeys form a continuous tapered civic tower above the west entry.
 let tc=vec3<f32>(-35.5,0.,-18.);f=take(f,taperedTower(p));
 // East and railway-facing walls; storage net boundary x44 is separate from service strip.
 let rz=repeatX(p.z-2.,6.,6.);var east=box(p-vec3<f32>(49.75,4.8,0.),vec3<f32>(.25,4.8,40.));east=max(east,-archWindow(vec3<f32>(rz,p.y-4.,49.75-p.x),.85,2.4,.8));f=take(f,field(shell(east,p),2u,p,3.));var ew=sashWindow(vec3<f32>(rz,p.y-4.0,49.75-p.x),.85,2.4,10.,mat3x3<f32>(vec3<f32>(0.,0.,-1.),vec3<f32>(0.,1.,0.),vec3<f32>(1.,0.,0.)));ew.d=shell(ew.d,p);f=take(f,ew);
 let gateX=repeatX(p.x-4.,20.,1.);let freightDoor=box(vec3<f32>(gateX,p.y-2.1,p.z-39.75),vec3<f32>(2.5,2.2,1.));var rear=box(p-vec3<f32>(4.,4.8,39.75),vec3<f32>(46.,4.8,.25));rear=max(rear,-freightDoor);f=take(f,field(shell(rear,p),2u,p,3.));
 // Warehouse clear rectangle is 72 x 62.5 m. All partitions lie OUTSIDE it.
 var westPartition=box(p-vec3<f32>(-28.3,5.9,3.25),vec3<f32>(.2,5.9,31.75));if(u.options.x<.5){let storeTop=12.9-abs(repeatX(p.z-3.25,20.833333,1.))*.25;let publicTop=14.7-.44*max(abs(p.x+35.5),max(abs(p.z)-33.3,0.));westPartition=max(westPartition,p.y-(max(storeTop,publicTop)-.10));}westPartition=max(westPartition,-box(vec3<f32>(p.x+28.3,p.y-1.65,repeatX(p.z,20.,1.)),vec3<f32>(1.,1.7,1.75)));f=take(f,field(shell(westPartition,p),1u,p,4.));
 f=take(f,field(shell(box(p-vec3<f32>(8.,5.9,-28.3),vec3<f32>(36.5,5.9,.2)),p),1u,p,4.));
 var rearPartition=box(p-vec3<f32>(8.,3.5,34.8),vec3<f32>(36.5,3.5,.2));rearPartition=max(rearPartition,-box(vec3<f32>(gateX,p.y-1.65,p.z-34.8),vec3<f32>(1.75,1.7,1.)));f=take(f,field(shell(rearPartition,p),1u,p,4.));
 var westFloor=box(p-vec3<f32>(-33.65,5.32,0.),vec3<f32>(5.1,.12,39.4));westFloor=max(westFloor,-box(p-vec3<f32>(-33.7,5.32,-18.),vec3<f32>(5.8,.4,8.4)));westFloor=max(westFloor,-box(p-vec3<f32>(-33.,5.32,30.),vec3<f32>(1.6,.4,5.5)));f=take(f,field(shell(westFloor,p),3u,p,1.));
 f=take(f,field(shell(box(p-vec3<f32>(8.,5.32,-32.4),vec3<f32>(36.4,.12,3.7)),p),3u,p,2.));
 let step=clamp(floor((p.z-25.)/.32),0.,29.);let stair=max(box(p-vec3<f32>(-33.,(step+1.)*.09,25.+(step+.5)*.32),vec3<f32>(1.3,(step+1.)*.09,.16)),box(p-vec3<f32>(-33.,2.8,29.8),vec3<f32>(1.3,2.8,4.8)));f=take(f,field(shell(stair,p),3u,p,1.));f=take(f,field(shell(box(p-vec3<f32>(-33.,5.36,35.13),vec3<f32>(1.3,.08,.61)),p),3u,p,1.));
 if(u.options.x<.5){let roofZ=repeatX(p.z-3.25,20.833333,1.);var warehouseRoof=max(abs(p.y-(12.9-abs(roofZ)*.25))-.14,box(p-vec3<f32>(8.,11.,3.25),vec3<f32>(36.6,3.,31.85)));let lightWell=box(vec3<f32>(p.x-8.,p.y-12.8,roofZ),vec3<f32>(30.9,2.,1.92));warehouseRoof=max(warehouseRoof,-lightWell);f=take(f,field(warehouseRoof,7u,p,3.));
 // Roof end enclosure closes the old open triangles above the service roof.
 // Its inner face x44.15 lies outside the fixed clear-storage boundary x44.
 let endHeight=12.9-abs(roofZ)*.25;
 let eastGable=max(box(p-vec3<f32>(44.34,11.36,3.25),vec3<f32>(.19,1.56,31.80)),p.y-(endHeight-.10));
 f=take(f,field(eastGable,2u,p,30.));
 let westGable=max(box(p-vec3<f32>(-28.34,12.11,3.25),vec3<f32>(.19,.81,31.80)),p.y-(endHeight-.10));f=take(f,field(westGable,1u,p,32.));
 let northFascia=max(box(p-vec3<f32>(8.,10.10,34.93),vec3<f32>(36.5,.38,.18)),p.y-(endHeight-.10));f=take(f,field(northFascia,2u,p,31.));
 let light=max(abs(p.y-(13.45-abs(roofZ)*.43))-.006,box(vec3<f32>(p.x-8.,p.y-13.,roofZ),vec3<f32>(31.,1.5,2.1)));f=take(f,field(light,8u,p,3.));let endX=abs(p.x-8.)-31.08;let endGlass=max(abs(endX)-.006,max(abs(roofZ)-2.10,max((12.9-abs(roofZ)*.25+.12)-p.y,p.y-(13.45-abs(roofZ)*.43))));f=take(f,field(endGlass,8u,p,3.));
 // A single L-shaped hipped roof envelope: union volumes, subtract their inset union.
 let hyW=14.7-.44*max(abs(p.x+35.5),max(abs(p.z)-33.3,0.));
 let hyS=14.48-.44*max(abs(p.z+34.),max(abs(p.x-3.7)-39.5,0.));
 let bw=box(p-vec3<f32>(-35.5,11.,0.),vec3<f32>(7.8,5.,41.1));let bs=box(p-vec3<f32>(3.7,11.,-34.),vec3<f32>(47.,5.,7.5));
 let biw=box(p-vec3<f32>(-35.5,11.,0.),vec3<f32>(8.1,5.3,41.4));let bis=box(p-vec3<f32>(3.7,11.,-34.),vec3<f32>(47.3,5.3,7.8));
 let outerRoof=min(max((p.y-hyW)*.90,bw),max((p.y-hyS)*.90,bs));
 let innerRoof=min(max((p.y-hyW+.20)*.90,biw),max((p.y-hyS+.20)*.90,bis));
 // Each street gable has a full two-pitch roof extending inward to the main ridge.
 let gx=repeatX(p.x-4.,33.,1.);let gz=repeatX(p.z,27.5,1.);
 let gs=vec3<f32>(gx,p.y,p.z+40.5);let roofWestQ=vec3<f32>(gz,p.y,p.x+42.6);
 let gsh=15.91-abs(gs.x)*.72-max(gs.z,0.)*.24;
 let gwh=15.91-abs(roofWestQ.x)*.72-max(roofWestQ.z,0.)*.24;
 let gsBound=box(gs-vec3<f32>(0.,13.5,3.1),vec3<f32>(5.99,3.,3.75));
 let gwBound=box(roofWestQ-vec3<f32>(0.,13.5,3.1),vec3<f32>(5.99,3.,3.75));
 let towerGap=-box(p-tc-vec3<f32>(0.,14.,0.),vec3<f32>(8.,6.,8.8));
 let dormerOuter=min(max((p.y-gsh)*.81,gsBound),max(max((p.y-gwh)*.81,gwBound),towerGap));
 let dormerInner=min(max((p.y-gsh+.19)*.81,gsBound-.24),max(max((p.y-gwh+.19)*.81,gwBound-.24),towerGap));
 var publicRoof=max(min(outerRoof,dormerOuter),-min(innerRoof,dormerInner));let towerCut=max(chamferPlan((p-tc).xz,towerHalf(p.y)+vec2<f32>(.08),.6)/2.3,max(-p.y,p.y-23.8));publicRoof=max(publicRoof,-towerCut);f=take(f,field(publicRoof,7u,p,1.));
 let gableX=repeatX(p.x-4.,33.,1.);f=take(f,publicGable(vec3<f32>(gableX,p.y,p.z+40.5),rigidIdentity()));
 let gableZ=repeatX(p.z,27.5,1.);var gw=publicGable(vec3<f32>(gableZ,p.y,p.x+42.6),rigidWest());gw.d=max(gw.d,-box(p-tc-vec3<f32>(0.,14.,0.),vec3<f32>(8.,6.,8.8)));f=take(f,gw);
 f=take(f,field(box(p-vec3<f32>(8.,9.7,37.5),vec3<f32>(36.5,.16,3.)),7u,p,2.));f=take(f,field(box(p-vec3<f32>(47.,9.7,3.25),vec3<f32>(3.5,.16,31.8)),7u,p,2.));}
 return f;
}











struct ReceiverResponse { surface:KpSurface,cavity:f32,specularLevel:f32,clearcoat:f32,clearcoatRoughness:f32,macroHeightM:f32,parallaxHeight01:f32 };

struct ResponseParts { diffuse:vec3<f32>,baseSpecular:vec3<f32>,coatSpecular:vec3<f32>,roughness:f32,cavity:f32,coat:f32 };
// Original frozen room-slice GGX/Schlick/Smith response, using the CURRENT bureau
// sun/ambient/fixtures instead of copying the older receiver's light constants.




struct EnvironmentRay { direction:vec4<f32>,weight:vec4<f32>,transmittance:vec4<f32>,evidence:vec4<f32> };






// One invocation per direction and one textual sceneField site. No materials.
// State 0 inactive, 1 escaped to original sky, 2 real opaque blocker, 3 unresolved.










// Bounded tangent-footprint integration of unchanged stone mothers. No texture cache.


// The original material height now participates in the resolved surface normal.



// Secondary intersection is its own compute pass. No material is evaluated here.


// Each geometry stage has one textual domain evaluation site. Four tetrahedral
// normal samples are independent invocations, not four cloned building shaders.









struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }
@group(1) @binding(0) var<storage,read> mapRays:array<SampleRay>;
@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;

fn mapField(p:vec3<f32>)->Field {return take(take(architecture(p),entryJoinery(p)),taperedChimney(p));}
fn mapDistance(p:vec3<f32>)->f32 {return mapField(p).d;}
fn mapNormal(p:vec3<f32>)->vec3<f32>{let e=.003;return normalize(vec3<f32>(mapDistance(p+vec3<f32>(e,0.,0.))-mapDistance(p-vec3<f32>(e,0.,0.)),mapDistance(p+vec3<f32>(0.,e,0.))-mapDistance(p-vec3<f32>(0.,e,0.)),mapDistance(p+vec3<f32>(0.,0.,e))-mapDistance(p-vec3<f32>(0.,0.,e))));}
@compute @workgroup_size(32) fn sampleGeometry(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapRays)){return;}let r=mapRays[i];var t=0.;var found=false;var steps=0u;for(var k=0u;k<640u;k++){steps=k+1u;let f=mapField(r.origin.xyz+r.direction.xyz*t);if(f.mat>0u&&abs(f.d)<.004){found=true;break;}t+=max(.002,abs(f.d)*.72);if(t>r.origin.w){break;}}var o:SampleOutput;o.position=vec4<f32>(0.,0.,0.,0.);o.normal=vec4<f32>(0.,1.,0.,f32(steps));o.color=vec4<f32>(0.);if(found){let p=r.origin.xyz+r.direction.xyz*t;let f=mapField(p);o.position=vec4<f32>(p,f32(f.mat));o.normal=vec4<f32>(mapNormal(p),f32(steps));}else if(t<=r.origin.w){o.normal.w=-f32(steps);}mapSamples[i]=o;}

