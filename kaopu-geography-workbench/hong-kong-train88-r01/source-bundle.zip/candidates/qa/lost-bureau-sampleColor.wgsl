
struct Params { eye:vec4<f32>,forward:vec4<f32>,right:vec4<f32>,up:vec4<f32>,resolution:vec4<f32>,options:vec4<f32>,clock:vec4<f32>,counts:vec4<u32>,tile:vec4<u32>,transport:vec4<f32>,tool:vec4<f32> };
struct ItemRecord {position:vec4<f32>,size:vec4<f32>};
@group(0) @binding(0) var<uniform> u:Params;

struct Hit {distance:f32,status:u32,steps:u32,mat:u32};

struct Queue {count:atomic<u32>,indices:array<u32,1024>};

struct Stats {hit:atomic<u32>,miss:atomic<u32>,exhausted:atomic<u32>,retried:atomic<u32>,maxSteps:atomic<u32>,glassRays:atomic<u32>,glassMiss:atomic<u32>,glassExhausted:atomic<u32>,visibilityRays:atomic<u32>,visibilityUnresolved:atomic<u32>,envRays:atomic<u32>,envOpen:atomic<u32>,envBlocked:atomic<u32>,envUnresolved:atomic<u32>,envInactive:atomic<u32>,envGlass:atomic<u32>,sunNearBlock:atomic<u32>,sunFarBlock:atomic<u32>,envMaxSteps:atomic<u32>,envNearBlock:atomic<u32>};

struct Transmission {distance:f32,status:u32,steps:u32,depth:f32};

struct ShadingRecord {positionDistance:vec4<f32>,normalAO:vec4<f32>,glassNormalDepth:vec4<f32>,params:vec4<f32>,localSeed:vec4<f32>,flags:vec4<u32>,frame0:vec4<f32>,frame1:vec4<f32>,frame2:vec4<f32>,frameLower:vec4<f32>,frameUpper:vec4<f32>};


// R3.12 family-0 original fitted edge waves, field and surface core.
// WGSL syntax/explicit arguments are new. No renderer, vertex or instance lists.
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }
fn br_h11(p:f32)->f32 {return fract(sin(p*127.1+311.7)*43758.5453123);}
fn br_hash31(pIn:vec3<f32>)->f32 {var p=fract(pIn*0.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn br_noise3(p:vec3<f32>)->f32 {let i=floor(p);var f=fract(p);f=f*f*(vec3<f32>(3.0)-2.0*f);return mix(mix(mix(br_hash31(i),br_hash31(i+vec3<f32>(1,0,0)),f.x),mix(br_hash31(i+vec3<f32>(0,1,0)),br_hash31(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(br_hash31(i+vec3<f32>(0,0,1)),br_hash31(i+vec3<f32>(1,0,1)),f.x),mix(br_hash31(i+vec3<f32>(0,1,1)),br_hash31(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn br_fbm(pIn:vec3<f32>)->f32 {var p=pIn;var s=0.0;var a=0.5;for(var i=0;i<5;i++){s+=a*br_noise3(p);p=p*2.03+vec3<f32>(7.1,-3.7,11.9);a*=0.5;}return s;}








































// Return original [chips, contour, weight] contributions instead of GLSL inout.




fn br_variant(qIn:vec3<f32>,variant:i32)->vec3<f32>{var q=qIn;if((variant&1)==1){q.x=-q.x;}if((variant&2)==2){q.z=-q.z;}return q;}
// Exact original family-0 distance, in metres. This is not guaranteed Lipschitz 1.0


fn br_xi(q:vec3<f32>)->vec3<f32>{let rr=max(length(q),1e-4);let cap=0.13*9.5;let radial2=dot(q.xy,q.xy);let angularRadius=sqrt(radial2+cap*cap*exp(-radial2/(cap*cap)));let angle=acos(clamp(q.y/angularRadius,-0.999999,0.999999));return vec3<f32>(log2(rr)-2.0,-q.z/rr-1.0,angle);}
// New explicit isotropic footprint bridge. Original wave, 17 octaves and gates
// remain; the original screen dFdx/dFdy footprint is NOT claimed equivalent.
fn br_microscope(q:vec3<f32>,qFootprint:f32)->f32 {
 let xi=br_xi(q);let e=max(qFootprint,1e-7);
 let fp=max(length(br_xi(q+vec3<f32>(e,0,0))-xi),max(length(br_xi(q+vec3<f32>(0,e,0))-xi),length(br_xi(q+vec3<f32>(0,0,e))-xi)));
 var s=0.0;var sc=1.0;for(var j=0;j<17;j++){if(fp*sc>=1.10){break;}let gate=1.0-smoothstep(0.48,1.10,fp*sc);let x=xi*sc;s+=gate*(cos(cos(x.z)*cos(x.x)+cos(x.y)*cos(x.y)+cos(x.y)*cos(x.x))-0.6556965)/sc;sc*=2.0;}return s;
}
// Raw original family-0 albedo, roughness and height. No lighting/tone mapping.
fn kpBrickOriginalSurface(pLocalM:vec3<f32>,seed:f32,variant:i32,variation:f32,physicalFootprintM:f32)->KpSurface {
 let r0=br_h11(seed+1.2);let r1=br_h11(seed+2.7);let r2=br_h11(seed+4.9);let r3=br_h11(seed+8.3);
 var q=br_variant(pLocalM/KP_BRICK_SCALE,variant);let ang=(r0-0.5)*2.2*variation;let ca=cos(ang);let sa=sin(ang);
 let oldXZ=q.xz;q.x=ca*oldXZ.x+sa*oldXZ.y;q.z=-sa*oldXZ.x+ca*oldXZ.y;
 q+=variation*vec3<f32>((r1-0.5)*18.0,(r2-0.5)*12.0,(r3-0.5)*16.0);
 let body=br_fbm(q*1.15+vec3<f32>(-2.7,4.1,8.3));let fire=br_fbm(q*2.65+vec3<f32>(7.1,-5.2,1.7));let firing=smoothstep(0.27,0.79,0.66*body+0.34*fire);
 let reduction=smoothstep(0.69,0.88,br_fbm(q*0.82+vec3<f32>(12.1,1.4,-9.7)))*smoothstep(0.38,0.82,firing);
 let poreA=br_noise3(q*29.7+vec3<f32>(2.3,9.1,-4.4));let poreB=br_noise3(q*61.3+vec3<f32>(-7.2,3.7,14.6));let pore=smoothstep(0.79,0.92,poreA)*smoothstep(0.64,0.84,poreB);
 let skin=smoothstep(0.36,0.76,br_fbm(q*5.1+vec3<f32>(1.9,-3.2,11.4)));let mm=br_microscope(q*9.5,max(physicalFootprintM,0.0)/KP_BRICK_SCALE*9.5);
 var base=mix(vec3<f32>(0.235,0.043,0.023),vec3<f32>(0.455,0.105,0.048),smoothstep(0.14,0.76,firing));base=mix(base,vec3<f32>(0.625,0.205,0.082),smoothstep(0.58,0.92,firing)*0.34);base=mix(base,vec3<f32>(0.19,0.055,0.038),reduction*0.63);
 let rough=clamp(0.90-0.10*firing+0.055*reduction+0.075*pore,0.68,0.985);
 let h=(body-0.5)*0.010+(skin-0.5)*0.004+mm*0.0034-pore*0.0048;
 base*=0.965+0.07*(skin-0.5);base*=mix(1.0,0.93+0.14*br_h11(seed+19.7),variation);
 return KpSurface(h*KP_BRICK_SCALE,base,rough);
}

// R3.12 original macro/micro/observed field algebra. Explicit coordinates and
// derivative-free physical footprint are receiver bridges. No patch silhouette.
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}
fn pl_rotate(v:vec3<f32>,axis:vec3<f32>,a:f32)->vec3<f32>{let c=cos(a);let s=sin(a);return v*c+cross(axis,v)*s+axis*dot(axis,v)*(1.0-c);}
fn pl_warp(p:vec3<f32>,phase:vec3<f32>)->vec3<f32>{let c1=vec3<f32>(0.12,1.42,0.04)+0.035*phase;let a1=normalize(vec3<f32>(0.38,0.82,0.42));let v1=p-c1;let t1=0.65*exp(-dot(v1,v1)/(2.4*2.4))*sin(1.45*dot(a1,v1)+0.7+phase.x);let q=c1+pl_rotate(v1,a1,t1);let c2=vec3<f32>(-0.16,1.63,-0.06)+0.025*phase;let a2=normalize(vec3<f32>(-0.67,0.15,0.73));let v2=q-c2;let t2=0.20*exp(-dot(v2,v2)/(2.1*2.1))*sin(4.1*dot(a2,v2)+2.0+phase.y);return c2+pl_rotate(v2,a2,t2);}
fn pl_xi(p:vec3<f32>,phase:vec3<f32>)->vec3<f32>{let q=pl_warp(p,phase)+vec3<f32>(2.73,0.91,1.37);let r=max(length(q),1e-4);return vec3<f32>(log2(r)-2.0,-q.z/r,atan2(q.x,q.y));}
fn pl_cell(xi:vec3<f32>,sc:f32)->f32{let a=cos(sc*xi.z)*cos(sc*xi.x)+cos(sc*xi.y)*cos(sc*xi.y)+cos(sc*xi.y)*cos(sc*xi.x);return cos(a)-0.6556965458313674;}
fn pl_macroFast(p:vec3<f32>)->f32{let xi=pl_xi(p,vec3<f32>(0.7,-1.3,2.1));let s=pl_cell(xi,1.0)+pl_cell(xi,2.0)*0.5+pl_cell(xi,4.0)*0.25+pl_cell(xi,8.0)*0.125+pl_cell(xi,16.0)*0.0625;return tanh(0.78*s);}
fn pl_microFast(p:vec3<f32>)->f32{let xi=pl_xi(p,vec3<f32>(0.7,-1.3,2.1));let s=pl_cell(xi,16.0)*0.0625+pl_cell(xi,32.0)*0.03125+pl_cell(xi,64.0)*0.015625;return tanh(10.5*s);}
fn pl_q(p:vec3<f32>,a:KpPlasterParams)->vec3<f32>{return vec3<f32>((p.xy-a.centerM)/max(a.halfM,vec2<f32>(0.08)),p.z*2.0);}
fn kpPlasterMacro(p:vec3<f32>,a:KpPlasterParams)->f32{let low=pl_macroFast(pl_q(p,a)+vec3<f32>(-0.17,0.31,0.09));let coarse=sin(p.x*2.7+p.y*0.9)*sin(p.y*3.2-p.x*0.7);return clamp(0.48*low+0.52*coarse,-1.0,1.0);}
fn kpPlasterMicro(p:vec3<f32>,a:KpPlasterParams)->f32{let m=pl_microFast(pl_q(p,a)*vec3<f32>(2.65,2.52,3.55)+vec3<f32>(-0.27,0.44,-0.19));let r=sin(p.x*47.0-p.y*39.0+p.z*58.0)*sin(p.x*31.0+p.y*37.0-p.z*43.0);return clamp(0.78*m+0.22*r,-1.0,1.0);}
fn pl_observed(p:vec3<f32>,a:KpPlasterParams,physicalFootprintM:f32)->f32{
 let q=pl_q(p,a);let phase=vec3<f32>(-1.3,4.7,2.2);let xi=pl_xi(q,phase);
 let e=max(physicalFootprintM,1e-7);let dq=vec3<f32>(e/max(a.halfM.x,0.08),e/max(a.halfM.y,0.08),e*2.0);
 let fp=max(length(pl_xi(q+vec3<f32>(dq.x,0,0),phase)-xi),max(length(pl_xi(q+vec3<f32>(0,dq.y,0),phase)-xi),length(pl_xi(q+vec3<f32>(0,0,dq.z),phase)-xi)));
 var sum=0.0;var sc=1.0;for(var i=0;i<17;i++){if(fp*sc>=1.12){break;}let gate=1.0-smoothstep(0.44,1.12,fp*sc);sum+=gate*pl_cell(xi,sc)/sc;sc*=2.0;}return tanh(0.86*sum);
}
fn kpPlasterOriginalField(pLocalM:vec3<f32>,a:KpPlasterParams,physicalFootprintM:f32)->KpPlasterField{
 let pm=kpPlasterMacro(pLocalM,a);let pu=kpPlasterMicro(pLocalM,a);let obs=pl_observed(pLocalM,a,physicalFootprintM);
 // Existing metric-grain correction: same direction, explicit metre period.
 let wave=max(a.grainWavelengthM,0.0003);let phase=dot(pLocalM,normalize(vec3<f32>(83.0,-61.0,97.0)))*(6.283185307179586/wave);
 let grain=sin(phase)*(1.0-smoothstep(0.35,0.90,physicalFootprintM/wave));
 let microGate=1.0-smoothstep(0.008,0.020,physicalFootprintM);
 let h=microGate*a.microM*(0.26*obs+0.18*pu)+a.grainHeightM*grain;
 let base=mix(a.paletteDark,a.paletteLight,0.58+0.08*obs+0.22*pm)*(0.94+a.grainColor*grain);
 let rough=clamp(0.95+0.032*(-obs),0.86,0.997);
 let thickness=clamp(a.thicknessM+a.reliefM*pm+a.geometryMicroM*pu,a.minThicknessM,a.maxThicknessM);
 return KpPlasterField(pm,pu,thickness,KpSurface(h,base,rough));
}

// Syntax port of locked V26 waterWeatherMasks dependency closure.
// pField is the ORIGINAL normalized material field coordinate, not metres.
// localPosM/dimensionsM are original physical local position/size for gates.












// Existing explicitly authored unified fabric bridge, not source physical years.
struct KpFabricState { moisture:f32, damage:f32, retention:f32, thicknessM:f32, baseScale:f32, roughDelta:f32, }
fn kpFabricState(age:f32,exposure:f32,sourceRunoff:f32,originalWeather:f32,drainage:f32,repair:f32,originalMacro:f32,originalMicro:f32,originalThicknessM:f32,minThicknessM:f32,maxThicknessM:f32)->KpFabricState {
 let a=clamp(age,0.0,1.0);let e=clamp(exposure,0.0,1.0);let r=clamp(repair,0.0,1.0);
 let moisture=clamp(sourceRunoff,0.0,1.0)*e*(1.0-clamp(drainage,0.0,1.0));
 let damage=clamp(a*(0.24+0.38*e+0.58*moisture+0.32*originalWeather*e)*(1.0-r),0.0,1.0);
 let bond=clamp(0.47+0.32*originalMacro+0.07*originalMicro,0.20,0.80);
 let thickness=clamp(originalThicknessM*(1.0-0.48*damage)+0.002*r,minThicknessM,maxThicknessM);
 return KpFabricState(moisture,damage,bond-damage,thickness,1.0-0.22*moisture-0.12*damage,0.035*damage-0.16*moisture);
}

// Apply the exact same resolved state used by receiver coat retention/thickness.
// Requires KpSurface from brick-core. No second independently computed age.
fn kpApplyFabricSurface(original:KpSurface,state:KpFabricState)->KpSurface {
 return KpSurface(original.height,original.albedo*state.baseScale,clamp(original.roughness+state.roughDelta,0.08,0.995));
}

// User Library timber v3, exact box coordinate/noise/field formulas in WGSL.
// KpSurface must be declared by the parent brick module before this string.
// No bindings, stages, renderer, textures, geometry buffers or scene objects.
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}
fn kpWoodDefaultParams()->KpWoodParams {
  var p:KpWoodParams;
  p.seed=0.7598925376683223;
  p.ringFrequency=22.0;
  p.ringScale=1.1240120360301806;
  p.ringWarp=1.174825141889602;
  p.fiberFrequency=8.73036012029089;
  p.fineFiberFrequency=72.0;
  p.poreFrequency=280.0;
  p.fiberStrength=0.34;
  p.colorBias=-0.015293409994337707;
  p.roughness=0.892843876922503;
  p.angleOffset=0.7194436165372647;
  p.textureScale=1.0;
  p.grainContrast=0.20902697160467504;
  p.detailFineness=1.0188769673019646;
  p.microReliefM=0.00028000000000000003;
  p.parallaxM=0.0010500000000000002;
  p.macroDisplacementM=0.0005600000000000001;
  p.reliefScale=0.7741619322448968;
  p.reliefQuality=3.0;
  p.parallaxSteps=12.0;
  p.clearcoat=0.0;
  p.clearcoatRoughness=1.0;
  p.specularLevel=0.13;
  p.distanceFadeStart=9.0;
  p.distanceFadeEnd=28.0;
  p.toolPhase=0.2499335163798811;
  p.crackPhase=1.1871775190974605;
  p.knotPhase=1.4286763223548267;
  p.pithOffset=vec2<f32>(0.04244730153121054,-0.07805894820950925);
  p.darkGrainColor=vec3<f32>(0.10224173308810132,0.06480326669290577,0.04091519690685319);
  p.lightGrainColor=vec3<f32>(0.31398871337571754,0.1946178304415758,0.11443537382697373);
  p.agedSurfaceColor=vec3<f32>(0.18782077230067787,0.13563332965520566,0.09758734714186246);
  p.weatheredColor=vec3<f32>(0.23455058216100522,0.21586050011389926,0.18782077230067787);
  p.freshCutColor=vec3<f32>(0.39157247774972326,0.26225065752969623,0.162029375639111);
  p.cavityColor=vec3<f32>(0.04091519690685319,0.027320891639074894,0.0202885630566524);
  return p;
}
fn kwSaturate(value:f32, wp:KpWoodParams, fp:f32)->f32 { return clamp(value, 0.0, 1.0); }

fn kwHash31(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  p = fract(p * 0.1031 + wp.seed * vec3<f32>(13.71, 47.13, 91.77));
  p += vec3<f32>(dot(p, p.yzx + vec3<f32>(33.33)));
  return fract((p.x + p.y) * p.z);
}

fn kwValueNoise(p:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var i:vec3<f32> = floor(p);
  var f:vec3<f32> = fract(p);
  f = f * f * (vec3<f32>(3.0) - 2.0 * f);
  return mix(
    mix(mix(kwHash31(i + vec3<f32>(0,0,0), wp, fp), kwHash31(i + vec3<f32>(1,0,0), wp, fp), f.x),
        mix(kwHash31(i + vec3<f32>(0,1,0), wp, fp), kwHash31(i + vec3<f32>(1,1,0), wp, fp), f.x), f.y),
    mix(mix(kwHash31(i + vec3<f32>(0,0,1), wp, fp), kwHash31(i + vec3<f32>(1,0,1), wp, fp), f.x),
        mix(kwHash31(i + vec3<f32>(0,1,1), wp, fp), kwHash31(i + vec3<f32>(1,1,1), wp, fp), f.x), f.y),
    f.z
  );
}

fn kwFbm(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  var result:f32 = 0.0;
  var amplitude:f32 = 0.5;
  var rotation:mat3x3<f32> = mat3x3<f32>(vec3<f32>(0.00,0.80,0.60),vec3<f32>(-0.80,0.36,-0.48),vec3<f32>(-0.60,-0.48,0.64));
  for (var i = 0; i < 5; i++) {
    result += amplitude * kwValueNoise(p, wp, fp);
    p = rotation * p * 2.03 + vec3<f32>(7.1, 3.7, 5.9);
    amplitude *= 0.5;
  }
  return result;
}

fn kwAaSine(coordinate:f32, wp:KpWoodParams, fp:f32)->f32 {
  var footprint:f32 = fp;
  var attenuation:f32 = 1.0 - smoothstep(0.42, 1.15, footprint);
  return 0.5 + 0.5 * sin(KP_WOOD_TAU * coordinate) * attenuation;
}

fn kwAaThinLine(coordinate:f32, width:f32, wp:KpWoodParams, fp:f32)->f32 {
  var distanceToLine:f32 = abs(sin(KP_WOOD_PI * coordinate));
  var footprint:f32 = min(0.22, fp * 0.75);
  return 1.0 - smoothstep(width + footprint, width + 0.085 + footprint, distanceToLine);
}

fn kwFlatAcross(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return select(g.y, g.z, abs(localNormal.y) > abs(localNormal.z));
}

fn kwFlatDepth(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return select(g.z, g.y, abs(localNormal.y) > abs(localNormal.z));
}

fn kwSidePhase(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, multiplier:f32, wp:KpWoodParams, fp:f32)->f32 {
  return kwFlatAcross(g, localNormal, wp, fp) * wp.fiberFrequency * multiplier;
}

fn kwSideAnisotropicNoise(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, axialFrequency:f32, crossFrequency:f32, phase:f32, wp:KpWoodParams, fp:f32)->f32 {
  var planarAcross:f32 = kwFlatAcross(g, localNormal, wp, fp);
  var planarDepth:f32 = kwFlatDepth(g, localNormal, wp, fp);
  var planarCoordinate:vec3<f32> = vec3<f32>(
    g.x * axialFrequency + phase,
    planarAcross * crossFrequency + wp.seed * 4.7,
    planarDepth * 0.72 + wp.seed * 9.1
  );
  return kwFbm(planarCoordinate, wp, fp);
}

fn kwSideValueNoise(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, axialFrequency:f32, crossFrequency:f32, phase:f32, wp:KpWoodParams, fp:f32)->f32 {
  var planarAcross:f32 = kwFlatAcross(g, localNormal, wp, fp);
  var planarDepth:f32 = kwFlatDepth(g, localNormal, wp, fp);
  var planarCoordinate:vec3<f32> = vec3<f32>(
    g.x * axialFrequency + phase,
    planarAcross * crossFrequency + wp.seed * 6.3,
    planarDepth * 0.54 + wp.seed * 3.8
  );
  return kwValueNoise(planarCoordinate, wp, fp);
}

fn kwRidgeFromNoise(value:f32, wp:KpWoodParams, fp:f32)->f32 {
  return 1.0 - abs(value * 2.0 - 1.0);
}

fn kwKnotSignal(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var broad:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    0.34,
    1.35,
    wp.knotPhase + 8.0
  , wp, fp);
  var compact:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    0.72,
    2.25,
    wp.knotPhase * 0.37 + 17.0
  , wp, fp);
  return smoothstep(0.71, 0.91, broad) * smoothstep(0.58, 0.86, compact);
}

fn kwWoodSignals(g:vec3<f32>, localNormal:vec3<f32>, surfaceClass:f32, wp:KpWoodParams, fp:f32)->vec4<f32> {
  var crossSection:f32 = step(0.72, abs(localNormal.x));

  var driftY:f32 = kwFbm(vec3<f32>(g.x * 0.24 + wp.seed * 3.1, 1.17, 7.93), wp, fp) - 0.5;
  var driftZ:f32 = kwFbm(vec3<f32>(g.x * 0.21 - wp.seed * 4.7, 9.31, 2.41), wp, fp) - 0.5;
  var longWarp:vec2<f32> = vec2<f32>(driftY, driftZ) * wp.ringWarp * 0.115;
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset + longWarp;
  var theta:f32 = atan2(crossPosition.y, crossPosition.x);

  var oval:f32 = 0.075 * sin(wp.seed * 31.0 + wp.angleOffset);
  var ringPosition:vec2<f32> = crossPosition * vec2<f32>(1.0 + oval, 1.0 - oval);
  var radial:f32 = length(ringPosition);
  var ringNoise:f32 = kwFbm(vec3<f32>(
    g.x * 0.18 + wp.seed * 2.4,
    ringPosition.x * 2.2,
    ringPosition.y * 2.2
  ), wp, fp);
  var ringCoordinate:f32 = radial * wp.ringFrequency * wp.ringScale;
  ringCoordinate += (ringNoise - 0.5) * wp.ringWarp * 1.18;
  ringCoordinate += sin(theta * 2.0 + wp.seed * 13.0) * 0.12 * wp.ringWarp;
  ringCoordinate += sin(theta * 5.0 - wp.seed * 7.0) * 0.045 * wp.ringWarp;
  var ringLine:f32 = kwAaThinLine(ringCoordinate, 0.060, wp, fp);
  var ringBody:f32 = kwAaSine(ringCoordinate + (ringNoise - 0.5) * 0.16, wp, fp);
  var ring:f32 = kwSaturate(ringBody * 0.62 + ringLine * 0.38, wp, fp);

  var broad:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.18, 1.55, wp.angleOffset, wp, fp);
  var flow:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.42, 3.35, wp.seed * 11.0 + 2.4, wp, fp);
  var medium:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.88, 7.20, wp.seed * 17.0 + 4.7, wp, fp);
  var knot:f32 = kwKnotSignal(g, crossPosition, localNormal, wp, fp);

  var phaseWarp:f32 = (broad - 0.5) * 5.4 + (flow - 0.5) * 2.9;
  phaseWarp += sin(g.x * 0.58 + theta * 1.7 + wp.seed * 19.0) * 0.50;
  phaseWarp += knot * (4.0 + 1.6 * sin(g.x * 1.05 + wp.knotPhase));

  var coarseLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.58, wp, fp) + phaseWarp + wp.angleOffset / KP_WOOD_TAU,
    0.065
  , wp, fp);
  var coarseVein:f32 = kwRidgeFromNoise(flow, wp, fp);
  var coarseFiber:f32 = kwSaturate(
    broad * 0.47 +
    coarseVein * 0.31 +
    coarseLine * 0.22
  , wp, fp);

  var mediumLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 1.85, wp, fp) + phaseWarp * 1.72 + wp.seed * 7.0,
    0.040
  , wp, fp);
  var mediumFiber:f32 = kwSaturate(
    medium * 0.47 +
    kwRidgeFromNoise(flow * 0.62 + medium * 0.38, wp, fp) * 0.37 +
    mediumLine * 0.16
  , wp, fp);

  var crackGate:f32 = smoothstep(
    0.79,
    0.94,
    kwSideValueNoise(g, crossPosition, localNormal, 0.32, 3.1, wp.crackPhase + 13.0, wp, fp)
  );
  var sideCrack:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.17, wp, fp)
      + phaseWarp * 0.16
      + wp.crackPhase / KP_WOOD_TAU,
    0.014
  , wp, fp) * crackGate;
  var radialGate:f32 = smoothstep(
    0.72,
    0.93,
    kwValueNoise(vec3<f32>(radial * 1.9, g.x * 0.27, wp.seed * 9.0), wp, fp)
  );
  var radialCrack:f32 = pow(max(0.0, sin(theta * 7.0 + wp.crackPhase)), 26.0)
    * smoothstep(0.08, 0.27, radial)
    * radialGate;
  var cracks:f32 = mix(sideCrack, max(sideCrack * 0.12, radialCrack), crossSection);

  return vec4<f32>(ring, coarseFiber, mediumFiber, cracks);
}

fn kwSecondarySignals(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->vec4<f32> {
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
  var broadWarp:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    0.46,
    4.4,
    wp.seed * 21.0 + 1.7
  , wp, fp);
  var fineNoise:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    1.55,
    18.0 * max(wp.detailFineness, 0.45),
    wp.seed * 29.0 + 5.3
  , wp, fp);
  var fineLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 4.6 * max(wp.detailFineness, 0.45), wp, fp)
      + (broadWarp - 0.5) * 8.5
      + wp.seed * 19.0,
    0.026
  , wp, fp);
  var fineFiber:f32 = kwSaturate(
    fineNoise * 0.53 +
    kwRidgeFromNoise(fineNoise, wp, fp) * 0.30 +
    fineLine * 0.17
  , wp, fp);

  var poreNoise:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    4.2 * max(wp.detailFineness, 0.45),
    38.0 * max(wp.detailFineness, 0.45),
    wp.seed * 23.0 + 11.0
  , wp, fp);
  var poreGate:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    0.85,
    7.0,
    wp.seed * 31.0 + 2.0
  , wp, fp);
  var pores:f32 = smoothstep(0.865, 0.982, poreNoise)
    * smoothstep(0.52, 0.82, poreGate);

  var toolWave:f32 = kwAaSine(g.x * 1.45 + kwFlatAcross(g, localNormal, wp, fp) * 0.22 + wp.toolPhase / KP_WOOD_TAU, wp, fp);
  var toolMask:f32 = smoothstep(
    0.79,
    0.96,
    kwSideValueNoise(g, crossPosition, localNormal, 0.54, 2.3, wp.toolPhase + 5.0, wp, fp)
  );
  var tool:f32 = toolWave * toolMask;

  var knot:f32 = kwKnotSignal(g, crossPosition, localNormal, wp, fp);
  return vec4<f32>(fineFiber, pores, tool, knot);
}

fn kwMacroSignal(g:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return kwFbm(g * vec3<f32>(0.12, 0.70, 0.70) + vec3<f32>(wp.seed * 5.0), wp, fp);
}

fn kwCoarseRelief(g:vec3<f32>, localNormal:vec3<f32>, surfaceClass:f32, wp:KpWoodParams, fp:f32)->f32 {
  var crossSection:f32 = step(0.72, abs(localNormal.x));
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
  var theta:f32 = atan2(crossPosition.y, crossPosition.x);
  var radial:f32 = length(crossPosition);

  var broadWarp:f32 = kwValueNoise(vec3<f32>(g.x * 0.18, crossPosition * 2.4) + vec3<f32>(wp.seed * 3.1), wp, fp);
  var sideBand:f32 = kwAaSine(
    kwSidePhase(g, crossPosition, localNormal, 0.62, wp, fp)
    + (broadWarp - 0.5) * 3.2
    + wp.angleOffset / KP_WOOD_TAU
  , wp, fp);
  var ringBand:f32 = kwAaSine(
    radial * wp.ringFrequency * wp.ringScale
    + (broadWarp - 0.5) * wp.ringWarp * 0.55
  , wp, fp);
  var sparseGate:f32 = smoothstep(
    0.84,
    0.965,
    kwValueNoise(vec3<f32>(g.x * 0.31 + wp.crackPhase, crossPosition * 4.1), wp, fp)
  );
  var sideCrack:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.20, wp, fp)
    + (broadWarp - 0.5) * 0.22
    + wp.crackPhase / KP_WOOD_TAU,
    0.015
  , wp, fp) * sparseGate;
  var radialCrack:f32 = pow(max(0.0, sin(theta * 7.0 + wp.crackPhase)), 24.0)
    * smoothstep(0.08, 0.28, radial)
    * sparseGate;

  var sideHeight:f32 = (sideBand - 0.5) * 0.36 - sideCrack * 0.60;
  var endHeight:f32 = (ringBand - 0.5) * 0.34 - radialCrack * 0.68;
  return kwSaturate(0.5 + mix(sideHeight, endHeight, crossSection), wp, fp);
}

fn kwVertexHash(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  p = fract(p * 0.1031 + wp.seed * vec3<f32>(17.17, 41.73, 83.11));
  p += vec3<f32>(dot(p, p.yzx + vec3<f32>(31.32)));
  return fract((p.x + p.y) * p.z);
}

fn kwVertexNoise(p:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var i:vec3<f32> = floor(p);
  var f:vec3<f32> = fract(p);
  f = f * f * (vec3<f32>(3.0) - 2.0 * f);
  return mix(
    mix(mix(kwVertexHash(i + vec3<f32>(0,0,0), wp, fp), kwVertexHash(i + vec3<f32>(1,0,0), wp, fp), f.x),
        mix(kwVertexHash(i + vec3<f32>(0,1,0), wp, fp), kwVertexHash(i + vec3<f32>(1,1,0), wp, fp), f.x), f.y),
    mix(mix(kwVertexHash(i + vec3<f32>(0,0,1), wp, fp), kwVertexHash(i + vec3<f32>(1,0,1), wp, fp), f.x),
        mix(kwVertexHash(i + vec3<f32>(0,1,1), wp, fp), kwVertexHash(i + vec3<f32>(1,1,1), wp, fp), f.x), f.y),
    f.z
  );
}

fn kwMacroField(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  var result:f32 = 0.0;
  var amplitude:f32 = 0.58;
  for (var i = 0; i < 3; i++) {
    result += amplitude * kwVertexNoise(p, wp, fp);
    p = p * 2.07 + vec3<f32>(5.2, 9.1, 3.7);
    amplitude *= 0.45;
  }
  return result / 0.94;
}

// pSourceM = member-local metres + inherited source grainOffset, +X axial.
// Signed normal displacement; use only this function in the geometry distance.
fn kpWoodMacroDisplacement(pSourceM:vec3<f32>, surfaceClass:f32, wp:KpWoodParams)->f32 {
  let fp=0.0;
  let grain=pSourceM*max(wp.textureScale,0.001);
    var broad:f32 = kwMacroField(grain * vec3<f32>(0.28, 1.15, 1.15) + vec3<f32>(wp.seed * 7.0), wp, fp);
    var longWave:f32 = 0.5 + 0.5 * sin(grain.x * 0.82 + wp.seed * 29.0 + broad * 1.55);
    var macroHeight:f32 = (broad - 0.5) * 0.78 + (longWave - 0.5) * 0.22;
    var classWeight:f32 = 1.0;
    if (surfaceClass > 0.5 && surfaceClass < 2.5) { classWeight = 0.0; }
    else if (surfaceClass > 2.5 && surfaceClass < 3.5) { classWeight = 1.08; }
  return macroHeight * wp.macroDisplacementM * wp.reliefScale * classWeight;
}
// Conservative magnitude bound for the original vertex displacement, in metres.
// Source macro noise is nonnegative with sum (0.58+0.261+0.11745)/0.94;
// original normal class multiplier is at most 1.08. This is not a Lipschitz bound.

// New screen-independent AA bridge. This is a nominal physical frequency estimate,
// not the original screen derivative and not a proof of derivative equivalence.
// fp=0 preserves the unfiltered original field exactly (up to f32 arithmetic).
fn kpWoodCoordinateFootprint(physicalFootprintM:f32,wp:KpWoodParams)->f32 {
  return max(physicalFootprintM,0.0)*max(wp.textureScale,0.001)*max(wp.ringFrequency*wp.ringScale,wp.fiberFrequency*4.6*max(wp.detailFineness,0.45));
}
// Complete source material terms before source-specific lighting or gamma.
// The caller supplies the actual member-local surface normal and face class.
// 0=longitudinal, 1=end grain, 2=joint cut, 3=weathered side.
// No camera-ray parallax march is hidden in this pure field call.
fn kpWoodOriginalSample(pSourceM:vec3<f32>,normalIn:vec3<f32>,surfaceClass:f32,wp:KpWoodParams,physicalFootprintM:f32,cameraDistanceM:f32)->KpWoodSample {
  let localNormal=normalize(normalIn);
  let g=pSourceM*max(wp.textureScale,0.001);
  let fp=kpWoodCoordinateFootprint(physicalFootprintM,wp);
  var baseColor=vec3<f32>(0.0);
  var heightMeters=0.0;
  var roughness=wp.roughness;
  var cavity=1.0;
    var signals:vec4<f32> = kwWoodSignals(g, localNormal, surfaceClass, wp, fp);
    var secondary:vec4<f32> = kwSecondarySignals(g, localNormal, wp, fp);
    var ring:f32 = signals.x;
    var coarseFiber:f32 = signals.y;
    var mediumFiber:f32 = signals.z;
    var cracks:f32 = signals.w;
    var fineFiber:f32 = secondary.x;
    var pores:f32 = secondary.y;
    var tool:f32 = secondary.z;
    var knot:f32 = secondary.w;
    var macroTone:f32 = kwMacroSignal(g, wp, fp);

    var crossSection:f32 = step(0.72, abs(localNormal.x));
    var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
    var radial:f32 = length(crossPosition);
    var endRay:f32 = kwAaSine(atan2(crossPosition.y, crossPosition.x) * 3.0 / KP_WOOD_TAU + radial * 2.0 + wp.seed * 7.0, wp, fp);

    var longitudinalTone:f32 =
      (coarseFiber - 0.5) * 1.02 +
      (mediumFiber - 0.5) * 0.43 +
      (macroTone - 0.5) * 0.56 +
      (fineFiber - 0.5) * 0.11 +
      knot * 0.26 -
      cracks * 0.70 -
      pores * 0.08;
    var endTone:f32 =
      (ring - 0.5) * 1.08 +
      (endRay - 0.5) * 0.19 +
      (macroTone - 0.5) * 0.38 -
      cracks * 0.72 -
      pores * 0.05;
    var grainTone:f32 = mix(longitudinalTone, endTone, crossSection) + wp.colorBias;
    var grainMix:f32 = kwSaturate(0.50 + grainTone * wp.grainContrast * 2.72, wp, fp);
    var grainColor:vec3<f32> = mix(wp.lightGrainColor, wp.darkGrainColor, grainMix);
    baseColor = mix(wp.agedSurfaceColor, grainColor, 0.78);

    if (surfaceClass > 0.5 && surfaceClass < 1.5) {
      baseColor = mix(baseColor, wp.freshCutColor, 0.20);
    } else if (surfaceClass > 1.5 && surfaceClass < 2.5) {
      baseColor = mix(baseColor, wp.freshCutColor, 0.27);
    } else if (surfaceClass > 2.5 && surfaceClass < 3.5) {
      baseColor = mix(baseColor, wp.weatheredColor, 0.53);
      roughness = min(0.98, roughness + 0.045);
    }

    baseColor *= 0.905 + macroTone * 0.19;
    baseColor = mix(baseColor, wp.cavityColor, cracks * 0.40 + pores * 0.065 + knot * 0.025);

    var distanceToCamera:f32 = cameraDistanceM;
    var detailFade:f32 = 1.0 - smoothstep(wp.distanceFadeStart, wp.distanceFadeEnd, distanceToCamera);
    var sideMicro:f32 =
      (coarseFiber - 0.5) * 0.32 +
      (mediumFiber - 0.5) * 0.24 +
      (fineFiber - 0.5) * 0.12 -
      pores * 0.30 -
      cracks * 0.94 -
      tool * 0.13 +
      knot * 0.09;
    var endMicro:f32 =
      (ring - 0.5) * 0.34 +
      (fineFiber - 0.5) * 0.05 -
      pores * 0.22 -
      cracks * 1.0;
    var microSignal:f32 = mix(sideMicro, endMicro, crossSection);
    heightMeters = microSignal * wp.microReliefM * wp.reliefScale * detailFade;

    roughness = clamp(
      roughness + pores * 0.045 + cracks * 0.075 + (0.5 - macroTone) * 0.022 - wp.clearcoat * 0.085,
      0.18,
      0.98
    );
    cavity = clamp(1.0 - cracks * 0.34 - pores * 0.06 - ring * crossSection * 0.035, 0.60, 1.0);

  return KpWoodSample(KpSurface(heightMeters,baseColor,roughness),cavity,wp.clearcoat,wp.clearcoatRoughness,wp.specularLevel,kpWoodMacroDisplacement(pSourceM,surfaceClass,wp),kwCoarseRelief(g,localNormal,surfaceClass,wp,fp));
}

// Original fragment micro-height: PBR normal detail, NOT a replacement for macro geometry.

// Compatibility entry: top longitudinal face of the original default box timber.
// age/wet/repair are reserved host arguments; the original v3 has no such model.
// Scene overlays must be explicit outside this source-preserving material leaf.


// STONE_STUDY same-page stoneFields, kind 0 (the stone receiver's default).
// KpSurface is supplied once by the shared brick core; do not redefine it here.
// No texture, mesh, voxel atlas, material cache or additional noise family.
// Authored unit bridge: a 0.42 m longest side maps to 3.4 specimen units.
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_KIND:i32 = 0;
const KP_STONE_MASTER_SEED:u32 = 8231u;
// Original normalizeSeedDNA offsets: color +401, pore +307, weather +601.
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;

fn st_hash33(pIn:vec3<f32>)->vec3<f32> {
 var p=fract(pIn*vec3<f32>(0.1031,0.1030,0.0973));
 p+=vec3<f32>(dot(p,p.yxz+vec3<f32>(33.33)));
 return fract((p.xxy+p.yxx)*p.zyx);
}
fn st_valueNoise3(p:vec3<f32>)->f32 {
 let i=floor(p);var f=fract(p);
 f=f*f*f*(f*(f*6.0-vec3<f32>(15.0))+vec3<f32>(10.0));
 return mix(mix(mix(st_hash33(i).x,st_hash33(i+vec3<f32>(1,0,0)).x,f.x),mix(st_hash33(i+vec3<f32>(0,1,0)).x,st_hash33(i+vec3<f32>(1,1,0)).x,f.x),f.y),mix(mix(st_hash33(i+vec3<f32>(0,0,1)).x,st_hash33(i+vec3<f32>(1,0,1)).x,f.x),mix(st_hash33(i+vec3<f32>(0,1,1)).x,st_hash33(i+vec3<f32>(1,1,1)).x,f.x),f.y),f.z);
}
fn st_seedVector(seed:f32,salt:f32)->vec3<f32> {
 return st_hash33(vec3<f32>(seed*0.001,salt,seed*0.00013))*49.0;
}
fn st_srgbToLinear(c:vec3<f32>)->vec3<f32> {
 return mix(c/12.92,pow((c+vec3<f32>(0.055))/1.055,vec3<f32>(2.4)),step(vec3<f32>(0.04045),c));
}
fn st_sf(p:vec3<f32>)->f32 {
 return st_valueNoise3(p)*0.57+st_valueNoise3(p*2.07+vec3<f32>(13.7))*0.28+st_valueNoise3(p*4.11+vec3<f32>(27.2))*0.15;
}
fn st_warp(p:vec3<f32>,seed:vec3<f32>)->vec3<f32> {
 return p+vec3<f32>(st_sf(p*0.8+seed),st_sf(p*0.8+seed+vec3<f32>(7.0)),st_sf(p*0.8+seed+vec3<f32>(19.0)))*0.25;
}
fn st_line(q:vec3<f32>,seed:vec3<f32>)->f32 {
 return abs(sin((q.x*0.84+q.y*0.37+q.z*0.51+st_sf(q*1.7+seed)*0.44)*12.0));
}
// New explicit isotropic footprint bridge replacing screen-space fwidth(line).
// It reevaluates the ORIGINAL line and warp at three metric axis offsets.
// This bound-like footprint is not screen-space fwidth equivalence and is not
// complete band-limiting of the original noise; zero footprint keeps 0.008.
fn st_lineAA(pos:vec3<f32>,seed:vec3<f32>,line:f32,physicalFootprintM:f32)->f32 {
 let e=max(physicalFootprintM,0.0)/KP_STONE_SCALE_M;
 if(e==0.0){return 0.008;}
 let dx=abs(st_line(st_warp(pos+vec3<f32>(e,0,0),seed),seed)-line);
 let dy=abs(st_line(st_warp(pos+vec3<f32>(0,e,0),seed),seed)-line);
 let dz=abs(st_line(st_warp(pos+vec3<f32>(0,0,e),seed),seed)-line);
 return max(dx+dy+dz,0.008);
}
// Original kind-0 stoneFields arithmetic. Fixed original material controls:
// sSurface.x=1, sSurface.y=0.7, sDisplay.w=1, sRelief=1, uEventCount=0.
// Original event-loop contribution is therefore 0. Original pits still apply.
// Branches 1/2/3 and their inactive grain/phase/crystal evaluations are omitted.
fn kpStoneOriginalSurface(pLocalM:vec3<f32>,sourceWet:f32,roughBias:f32,physicalFootprintM:f32)->KpSurface {
 let pos=pLocalM/KP_STONE_SCALE_M;
 let seed=st_seedVector(KP_STONE_COLOR_SEED,0.071);
 let q=st_warp(pos,seed);
 let broad=st_sf(q*1.35+seed);
 let region=st_sf(q*3.2+seed+vec3<f32>(11.0));
 let weather=st_sf(q*2.2+st_seedVector(KP_STONE_WEATHER_SEED,0.09));
 let line=st_line(q,seed);
 let aa=st_lineAA(pos,seed,line,physicalFootprintM);
 let vein=(1.0-smoothstep(0.028,0.064+aa,line))*smoothstep(0.34,0.63,region);
 let pits=pow(max(0.0,(st_sf(q*19.0+st_seedVector(KP_STONE_PORE_SEED,0.061))-0.57)/0.43),2.0);
 var col=mix(vec3<f32>(0.26,0.31,0.32),vec3<f32>(0.57,0.59,0.55),smoothstep(0.24,0.73,broad));
 col=mix(col,vec3<f32>(0.49,0.40,0.29),smoothstep(0.57,0.76,weather)*0.65);
 let mineral=vein*0.7;
 col=mix(col,vec3<f32>(0.83,0.81,0.70),mineral*0.90);
 let rough=mix(0.79,0.43,mineral);
 let h=(broad-0.5)*0.018+(region-0.5)*0.007+vein*0.004-pits*0.025;
 let geomCavity=0.0;
 let cav=clamp(geomCavity*0.55+pits*1.4,0.0,1.0);
 let wet=clamp(sourceWet*(0.18+0.82*smoothstep(0.32,0.75,weather+cav*0.25)),0.0,1.0);
 let lum=dot(col,vec3<f32>(0.2126,0.7152,0.0722));
 col=mix(vec3<f32>(lum),col,1.0);
 var linear=st_srgbToLinear(clamp(col,vec3<f32>(0.025),vec3<f32>(0.95)));
 linear*=1.0-wet*0.38;
 return KpSurface(h*KP_STONE_SCALE_M,linear,clamp(mix(rough+roughBias,0.17,wet),0.12,0.98));
}
// New, authored age/moisture/repair bridge copied from resolveStoneFabric.
// Its original default wear=0.15 is fixed because this call has no wear input.
// No calibrated decay law, damage geometry, formation events or SDF is ported.
// Age changes original wet/rough uniforms only; original height stays intact.
fn kpStoneSurface(pLocalM:vec3<f32>,age:f32,wet:f32,repair:f32,physicalFootprintM:f32)->KpSurface {
 let a=clamp(age,0.0,1.0);let r=clamp(repair,0.0,1.0);let m=clamp(wet,0.0,1.0);
 let retainedAge=a*(1.0-r);
 let sourceWet=clamp(m*(0.45+0.55*retainedAge)*(1.0-0.45*r),0.0,1.0);
 let roughBias=0.07*retainedAge+0.025*0.15-0.06*r;
 return kpStoneOriginalSurface(pLocalM,sourceWet,roughBias,physicalFootprintM);
}

// STONE_STUDY original sKind == 3 (blue-gray slate) surface branch.
// Append AFTER existing KP_STONE_WGSL; reuse its st_* source functions/seeds.
// Receiver controls below are explicit design bindings, NOT physical calibration.
// Original event count remains 0, matching the current surface-only port.
struct KpStoneSlateParams {
 sourceScaleM:f32, materialScale:f32, mineral:f32, chroma:f32, relief:f32,
};
fn kpStoneSlateDefaultParams()->KpStoneSlateParams {
 return KpStoneSlateParams(KP_STONE_SCALE_M,1.0,0.7,1.0,1.0);
}
fn kpStoneSlateOriginalSurface(pLocalM:vec3<f32>,params:KpStoneSlateParams,sourceWet:f32,roughBias:f32,physicalFootprintM:f32)->KpSurface {
 let pos=pLocalM/params.sourceScaleM;
 let seed=st_seedVector(KP_STONE_COLOR_SEED,0.071);
 let p=pos*params.materialScale;
 let q=st_warp(p,seed);
 let broad=st_sf(q*1.35+seed);
 let region=st_sf(q*3.2+seed+vec3<f32>(11.0));
 let weather=st_sf(q*2.2+st_seedVector(KP_STONE_WEATHER_SEED,0.09));
 let phase=q.y*5.7+q.x*0.82+q.z*0.41+st_sf(q*1.8+seed)*1.25;
 let line=st_line(q,seed);
 // Existing helper converts its input by KP_STONE_SCALE_M. Undo that fixed
 // scale here, then provide THIS receiver's explicit source + texture scale.
 // physicalFootprintM == 0 retains exactly the source's intrinsic aa floor.
 let aa=st_lineAA(p,seed,line,physicalFootprintM*KP_STONE_SCALE_M*params.materialScale/params.sourceScaleM);
 let vein=(1.0-smoothstep(0.028,0.064+aa,line))*smoothstep(0.34,0.63,region);
 let pits=pow(max(0.0,(st_sf(q*19.0+st_seedVector(KP_STONE_PORE_SEED,0.061))-0.57)/0.43),2.0);
 // Exact source kind-3 arithmetic; grain/crystal/bands are inactive here.
 let cleavage=st_sf(vec3<f32>(q.x*1.8,phase*2.8,q.z*1.8)+seed);
 var col=mix(vec3<f32>(0.10,0.15,0.19),vec3<f32>(0.30,0.37,0.40),smoothstep(0.20,0.78,cleavage*0.58+broad*0.42));
 col=mix(col,vec3<f32>(0.47,0.33,0.20),smoothstep(0.60,0.77,weather)*0.67);
 let mineral=vein*params.mineral;
 col=mix(col,vec3<f32>(0.57,0.61,0.57),mineral*0.51);
 let rough=0.48+cleavage*0.17-mineral*0.19;
 let h=(cleavage-0.5)*0.009+(broad-0.5)*0.012+sin(phase*6.28318)*0.0018-pits*0.01;
 let geomCavity=0.0;
 let cav=clamp(geomCavity*0.55+pits*1.4,0.0,1.0);
 let wet=clamp(sourceWet*(0.18+0.82*smoothstep(0.32,0.75,weather+cav*0.25)),0.0,1.0);
 let lum=dot(col,vec3<f32>(0.2126,0.7152,0.0722));
 col=mix(vec3<f32>(lum),col,params.chroma);
 var linear=st_srgbToLinear(clamp(col,vec3<f32>(0.025),vec3<f32>(0.95)));
 linear*=1.0-wet*0.38;
 return KpSurface(h*params.relief*params.sourceScaleM,linear,clamp(mix(rough+roughBias,0.17,wet),0.12,0.98));
}
// Same existing authored age/moisture/repair bridge; only source branch differs.
fn kpStoneSlateSurface(pLocalM:vec3<f32>,params:KpStoneSlateParams,age:f32,wet:f32,repair:f32,physicalFootprintM:f32)->KpSurface {
 let a=clamp(age,0.0,1.0);let r=clamp(repair,0.0,1.0);let m=clamp(wet,0.0,1.0);
 let retainedAge=a*(1.0-r);
 let sourceWet=clamp(m*(0.45+0.55*retainedAge)*(1.0-0.45*r),0.0,1.0);
 let roughBias=0.07*retainedAge+0.025*0.15-0.06*r;
 return kpStoneSlateOriginalSurface(pLocalM,params,sourceWet,roughBias,physicalFootprintM);
}


fn mt_kh(pIn:vec3<f32>)->f32{var p=fract(pIn*.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn mt_kn(p:vec3<f32>)->f32{let i=floor(p);var f=fract(p);f=f*f*(vec3<f32>(3.)-2.*f);return mix(mix(mix(mt_kh(i),mt_kh(i+vec3<f32>(1,0,0)),f.x),mix(mt_kh(i+vec3<f32>(0,1,0)),mt_kh(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(mt_kh(i+vec3<f32>(0,0,1)),mt_kh(i+vec3<f32>(1,0,1)),f.x),mix(mt_kh(i+vec3<f32>(0,1,1)),mt_kh(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn mt_kfb(p:vec3<f32>)->f32{return .57*mt_kn(p)+.28*mt_kn(p*2.13)+.15*mt_kn(p*4.17);}
fn kpMetalCorrosion(p:vec3<f32>,age:f32,wet:f32,repair:f32)->f32{let contact=(1.-smoothstep(.02,.07,abs(p.y-1.07)))*.7;let joint=(1.-smoothstep(.06,.18,p.y))+(1.-smoothstep(.01,.08,abs(p.y-.98)))*.28;return clamp(age*(1.-repair)*(wet*.7+joint*.55)*(1.-contact),0.,1.);}
fn kpMetalSurface(p:vec3<f32>,age:f32,wet:f32,repair:f32,footprintM:f32)->KpSurface{
 let kq=p+vec3<f32>(19.);let kp=mt_kfb(kq*3.1);let contact=(1.-smoothstep(.02,.07,abs(p.y-1.07)))*.7;let joint=(1.-smoothstep(.06,.18,p.y))+(1.-smoothstep(.01,.08,abs(p.y-.98)))*.28;let retained=age*(1.-repair);let corrosion=kpMetalCorrosion(p,age,wet,repair);
 var color=vec3<f32>(.17,.235,.20)*(.94+.09*kp);color=mix(color,vec3<f32>(.21,.082,.025),corrosion*.80);color*=1.-wet*.18;
 let rough=clamp(.53+(mt_kn(kq*9.)-.5)*.12+corrosion*.22-contact*.22-wet*.12,.12,.97);
 let originalHeight=(mt_kn(kq*65.)-.5)*.00025*(1.-smoothstep(.4,1.6,footprintM*65.));
 return KpSurface(originalHeight-corrosion*.0008,color,rough);
}



struct MaterialFrame { worldToLocal:mat3x3<f32>, lower:vec3<f32>, upper:vec3<f32>, enabled:f32 };
fn identityFrame()->MaterialFrame {return MaterialFrame(mat3x3<f32>(vec3<f32>(1.,0.,0.),vec3<f32>(0.,1.,0.),vec3<f32>(0.,0.,1.)),vec3<f32>(0.),vec3<f32>(0.),0.);}
fn rigidIdentity()->mat3x3<f32>{return mat3x3<f32>(vec3<f32>(1.,0.,0.),vec3<f32>(0.,1.,0.),vec3<f32>(0.,0.,1.));}
fn rigidWest()->mat3x3<f32>{return mat3x3<f32>(vec3<f32>(0.,0.,1.),vec3<f32>(0.,1.,0.),vec3<f32>(1.,0.,0.));}
fn componentVector(f:Field,v:vec3<f32>)->vec3<f32>{if(f.component.enabled>.5&&u.clock.z>.5){return f.component.worldToLocal*v;}return v;}




struct Field { d:f32, mat:u32, local:vec3<f32>, seed:f32, age:f32, wet:f32, component:MaterialFrame };
fn box(p:vec3<f32>,b:vec3<f32>)->f32 {let q=abs(p)-b;return length(max(q,vec3<f32>(0.)))+min(max(q.x,max(q.y,q.z)),0.);}
fn cylinder(p:vec3<f32>,r:f32,h:f32)->f32 {let q=vec2<f32>(length(p.xz)-r,abs(p.y)-h);return min(max(q.x,q.y),0.)+length(max(q,vec2<f32>(0.)));}
fn capsule(p:vec3<f32>,a:vec3<f32>,b:vec3<f32>,r:f32)->f32 {let q=p-a;let v=b-a;return length(q-v*clamp(dot(q,v)/dot(v,v),0.,1.))-r;}
fn shell(d:f32,p:vec3<f32>)->f32 {if(u.options.x>.5){return max(d,p.y-1.1);}return d;}
fn field(d:f32,mat:u32,p:vec3<f32>,seed:f32)->Field {
 let outside=select(0.,1.,p.x< -42.9||p.x>49.8||p.z< -40.8||p.z>40.||p.y>11.7);
 let runoff=1.-smoothstep(.04,.28,abs(fract((p.x+p.z*.13)/5.5)-.06)*5.5);
 let splash=(1.-smoothstep(.05,1.1,p.y))*.38;
 let wet=clamp(.025+outside*(.08+runoff*.34+splash),0.,.85);
 return Field(d,mat,p,seed,u.options.y,wet,identityFrame());
}
fn receiverPlasterParams()->KpPlasterParams {return KpPlasterParams(vec2<f32>(0.,5.),vec2<f32>(36.,5.),.0165,.0085,0.,.008,.025,.0002,vec3<f32>(.43,.425,.395),vec3<f32>(.64,.625,.57),.0008,.000008,.018);}
fn plasterCoordinates(p:vec3<f32>)->vec3<f32> {return select(p,p.zyx,p.x< -27.8&&p.z> -28.8);}
fn take(a:Field,b:Field)->Field {if(b.d<a.d){return b;}return a;}
fn repeatX(x:f32,pitch:f32,limit:f32)->f32 {return x-clamp(round(x/pitch),-limit,limit)*pitch;}
fn glyph(code:u32)->u32 {switch(code){
case 65u:{return 18415150u;}
case 66u:{return 16301615u;}
case 68u:{return 16303663u;}
case 69u:{return 32554047u;}
case 70u:{return 1096767u;}
case 71u:{return 32044094u;}
case 72u:{return 18415153u;}
case 73u:{return 32641183u;}
case 75u:{return 18128177u;}
case 76u:{return 32539681u;}
case 78u:{return 18667121u;}
case 79u:{return 15255086u;}
case 82u:{return 18136623u;}
case 83u:{return 16267326u;}
case 84u:{return 4329631u;}
case 85u:{return 15255089u;}
case 67u:{return 31491134u;}
case 38u:{return 23894310u;}
case 49u:{return 14815428u;}
case 57u:{return 15235630u;}
case 46u:{return 4194304u;}
default:{return 0u;}}}
fn textRow(p:vec3<f32>,line:u32)->f32 {
let place=array<u32,18>(72u,79u,78u,71u,32u,75u,79u,78u,71u,32u,65u,46u,68u,46u,49u,57u,49u,49u);
let office=array<u32,27>(71u,69u,78u,69u,82u,65u,76u,32u,76u,79u,83u,84u,32u,38u,32u,70u,79u,85u,78u,68u,32u,79u,70u,70u,73u,67u,69u);
let scale=select(.088,.073,line==1u);let count=select(18.,27.,line==1u);let baseline=select(7.00,6.53,line==1u);
let q=vec3<f32>(p.x+count*scale*3.,baseline-p.y,p.z);var d=100.;let cell=i32(floor(q.x/(scale*6.)));
for(var g=-1;g<=1;g++){let index=cell+g;if(index<0||f32(index)>=count){continue;}var code=0u;if(line==0u){code=place[u32(index)];}else{code=office[u32(index)];}let mask=glyph(code);let local=vec2<f32>(q.x-f32(index)*scale*6.,q.y+2.5*scale);let ix=i32(floor(local.x/scale));let iy=i32(floor(local.y/scale));for(var dy=-1;dy<=1;dy++){for(var dx=-1;dx<=1;dx++){let xx=ix+dx;let yy=iy+dy;if(xx<0||xx>4||yy<0||yy>4){continue;}if((mask&(1u<<u32(yy*5+xx)))!=0u){let r=vec3<f32>(local.x-(f32(xx)+.5)*scale,local.y-(f32(yy)+.5)*scale,q.z);d=min(d,box(r,vec3<f32>(scale*.43,scale*.43,.017)));}}}}return d;}
fn entranceText(p:vec3<f32>)->f32 {let bound=box(p-vec3<f32>(0.,6.78,0.),vec3<f32>(6.6,.51,.04));if(bound>.1){return 100.;}return min(textRow(p,0u),textRow(p,1u));}
// Round-headed openings and their stone archivolts share the same field.
fn archOpening(q:vec3<f32>,radius:f32,spring:f32,depth:f32)->f32 {
 let plan=min(max(abs(q.x)-radius,max(-q.y,q.y-spring)),length(vec2<f32>(q.x,q.y-spring))-radius);
 return max(plan,abs(q.z)-depth);
}

fn sashWindow(q:vec3<f32>,radius:f32,spring:f32,seed:f32,worldToWindow:mat3x3<f32>)->Field {
 let opening=archOpening(q,radius,spring,.8);
 let reveal=max(archOpening(vec3<f32>(q.xy,q.z+.08),radius+.14,spring,.27),-opening);
 var f=field(reveal,3u,q,seed);
 let frameOuter=archOpening(vec3<f32>(q.xy,q.z-.11),radius-.025,spring,.10);
 let frameInner=archOpening(vec3<f32>(q.xy,q.z-.11),radius-.13,spring,.24);
 var frame=max(frameOuter,-frameInner);
 // Two vertically sliding sashes, recessed glazing and arched fanlight.
 let meeting=spring*.51;let centre=box(q-vec3<f32>(0.,spring*.5,.12),vec3<f32>(.035,spring*.5,.06));
 let rail=box(q-vec3<f32>(0.,meeting,.12),vec3<f32>(radius-.10,.045,.065));
 let transom=box(q-vec3<f32>(0.,spring,.12),vec3<f32>(radius-.09,.05,.08));
 let bar=box(q-vec3<f32>(0.,spring*.25,.13),vec3<f32>(radius-.10,.022,.044));
 let upperbar=box(q-vec3<f32>(0.,spring*.76,.13),vec3<f32>(radius-.10,.022,.044));
 frame=min(frame,min(min(centre,rail),min(transom,min(bar,upperbar))));
 for(var i=0;i<3;i++){let a=.78539816*f32(i+1);let end=vec3<f32>(cos(a)*(radius-.11),spring+sin(a)*(radius-.11),.12);frame=min(frame,capsule(q,vec3<f32>(0.,spring,.12),end,.021));}
 frame=max(frame,archOpening(q,radius-.025,spring,.26));
 f=take(f,field(frame,14u,q,seed));
 let glass=max(archOpening(q,radius-.12,spring,.6),abs(q.z-.165)-.0045);
 f=take(f,field(glass,8u,q,seed));
 let sill=box(q-vec3<f32>(0.,-.09,-.13),vec3<f32>(radius+.23,.09,.42));f=take(f,field(sill,3u,q,seed));
 let apron=box(q-vec3<f32>(0.,-.24,.025),vec3<f32>(radius+.10,.075,.19));f=take(f,field(apron,3u,q,seed));
 // Hardware lives at the meeting rail; sheltered contact polishes the handle.
 let handle=capsule(q,vec3<f32>(-.12,meeting+.09,.225),vec3<f32>(.12,meeting+.09,.225),.018);
 f=take(f,field(handle,9u,q,seed));f.wet=.035;
 // The complete timber frame has these actual local metre extents. No normal,
 // tangent or footprint may silently switch back to world axes.
 if(f.mat==14u){f.component=MaterialFrame(worldToWindow,vec3<f32>(-radius+.025,0.,.01),vec3<f32>(radius-.025,spring+radius-.025,.21),1.);}return f;
}


fn entryJoinery(p:vec3<f32>)->Field {
 let bound=box(p-vec3<f32>(-39.6,2.9,-18.),vec3<f32>(5.4,3.0,4.1));
 if(bound>1.){return field(bound,0u,p,0.);}
 let q=vec3<f32>(p.z+18.,p.y,p.x+38.7);
 let opening=archOpening(q,3.4,2.2,1.);
 let trim=max(archOpening(vec3<f32>(q.xy,q.z+.15),3.65,2.2,.24),-opening);
 var f=field(shell(trim,p),3u,p,20.);
 // The threshold bridges a 33 mm interior finish, without imaginary tall stairs.
 let threshold=box(p-vec3<f32>(-38.70,.0165,-18.),vec3<f32>(.38,.0165,3.38));
 f=take(f,field(threshold,3u,p,20.));
 let outerLanding=box(p-vec3<f32>(-43.5,-.008,-18.),vec3<f32>(1.15,.008,4.3));f=take(f,field(outerLanding,3u,p,20.));
 // Four timber leaves form two inward-folded pairs. Each leaf is 1.56 m
 // wide: the folded stack stays beside the jamb and intrudes only 1.62 m.
 // The central 6.08 m entry axis stays open rather than a 3 m leaf filling it.
 for(var leafIndex=0;leafIndex<4;leafIndex++){let side=leafIndex/2;let folded=leafIndex%2;let sg=select(-1.,1.,side==1);
 let door=vec3<f32>(p.x+38.62-.81,p.y-1.56,(p.z+18.-sg*3.24)*sg+f32(folded)*.14);
 var leaf=box(door,vec3<f32>(.78,1.53,.050));let paneHole=box(door-vec3<f32>(0.,.59,0.),vec3<f32>(.58,.62,.20));leaf=max(leaf,-paneHole);
 f=take(f,field(shell(leaf,p),4u,door,22.+f32(leafIndex)));
 let pane=max(paneHole,abs(door.z)-.0045);f=take(f,field(shell(pane,p),8u,door,22.+f32(leafIndex)));
 let glazingBars=min(box(door-vec3<f32>(0.,.59,0.),vec3<f32>(.025,.65,.075)),box(door-vec3<f32>(0.,.59,0.),vec3<f32>(.60,.025,.075)));f=take(f,field(shell(glazingBars,p),14u,door,22.+f32(leafIndex)));
 let bottomPanel=max(box(door-vec3<f32>(0.,-.77,.056),vec3<f32>(.60,.53,.022)),-box(door-vec3<f32>(0.,-.77,.056),vec3<f32>(.53,.45,.10)));f=take(f,field(shell(bottomPanel,p),18u,door,22.+f32(leafIndex)));
 let pull=capsule(door,vec3<f32>(-.52,-.1,.11),vec3<f32>(-.52,.3,.11),.027);f=take(f,field(shell(pull,p),9u,door,22.+f32(leafIndex)));
 let hinge=cylinder(vec3<f32>(p.x+37.04,p.y-1.56,(p.z+18.-sg*3.17)*sg),.035,.17);f=take(f,field(shell(hinge,p),9u,p,24.));
 }
 // Fanlight follows the same opening outline, not a second opaque arch plate.
 let fan=max(opening,max(3.14-q.y,abs(q.z-.14)-.0045));f=take(f,field(shell(fan,p),8u,q,20.));
 let transom=box(q-vec3<f32>(0.,3.12,.12),vec3<f32>(3.27,.065,.09));f=take(f,field(shell(transom,p),14u,q,20.));
 let fanU=repeatX(q.x,.82,3.);let fanBar=max(box(vec3<f32>(fanU,q.y-4.30,q.z-.12),vec3<f32>(.026,1.17,.065)),max(opening,3.14-q.y));f=take(f,field(shell(fanBar,p),14u,q,20.));return f;
}


// A distant enclosing-box result is a marching bound, never a visible object.
// Every bound encloses its complete child function, including trims and lamps.



// Shared by physical lamp geometry and the receiver's illumination. No duplicate
// hand-maintained light positions are needed in renderer.mjs.



// Raised seven-segment brass numbers. Evaluation is seven bounded segments per
// digit, independent of the number of windows, rows, bays, or shelf levels.




// A fixture has a ceiling rose, real suspension rod, reflector lip and a bulb.
// The bulb centre is exactly interiorLightPosition(), including tower mounting.










// A slab is a rounded plan extruded through its actual thickness. Its form is
// the ray-intersection field, not a painted rounded rectangle on a box.


// Thin paper packets use a new, explicit authored cellulose approximation.
// It is not plaster, brass or a claimed recovered material mother. The same
// bounded fibre-height function drives its solid and surface micro-normal.
fn publicPaperSurface(q:vec3<f32>,seed:f32,age:f32,footprint:f32)->KpSurface {
 let fibre=(br_noise3(q*vec3<f32>(1800.,1.,550.)+vec3<f32>(seed))-.5)*(1.-smoothstep(.0002,.002,footprint));
 let stain=br_noise3(q*7.+vec3<f32>(seed))*.025*age;
 return KpSurface(fibre*.000018,vec3<f32>(.69,.675,.60)*(1.-stain),.92);
}




// Local chair faces +z; the bench faces +x. Both have real legs to the floor.



















fn archWindow(q:vec3<f32>,radius:f32,spring:f32,depth:f32)->f32 {return archOpening(q,radius,spring,depth);}
fn arcade(q:vec3<f32>,span:f32)->Field {
 let u0=repeatX(q.x,5.5,20.);let opening=archOpening(vec3<f32>(u0,q.y,q.z),2.14,2.75,1.);
 let wall=max(box(q-vec3<f32>(0.,2.68,0.),vec3<f32>(span,2.68,.32)),-opening);
 let band=max(archOpening(vec3<f32>(u0,q.y,q.z),2.48,2.75,.39),-opening);
 var f=field(shell(max(wall,box(q-vec3<f32>(0.,2.7,0.),vec3<f32>(span,2.7,.4))),q),2u,q,4.);
 f=take(f,field(shell(max(band,box(q-vec3<f32>(0.,2.7,0.),vec3<f32>(span,2.7,.42))),q),3u,q,4.));
 let pier=abs(u0)-2.75;let foot=box(vec3<f32>(pier,q.y-.18,q.z),vec3<f32>(.55,.18,.48));
 let cap=box(vec3<f32>(pier,q.y-2.7,q.z),vec3<f32>(.48,.16,.46));
 f=take(f,field(shell(max(min(foot,cap),box(q-vec3<f32>(0.,2.7,0.),vec3<f32>(span,2.7,.5))),q),3u,q,4.));return f;
}
// Upper and lower loggias share a bay axis and outer bearing line.
fn upperLoggia(q:vec3<f32>,span:f32)->Field {
 let u0=repeatX(q.x,5.5,20.);let opening=archOpening(vec3<f32>(u0,q.y-5.6,q.z),1.92,2.55,1.);
 var wall=max(box(q-vec3<f32>(0.,8.36,0.),vec3<f32>(span,2.84,.34)),-opening);
 let rim=max(archOpening(vec3<f32>(u0,q.y-5.6,q.z),2.14,2.55,.43),-opening);
 var f=field(shell(wall,q),2u,q,6.);f=take(f,field(shell(max(rim,box(q-vec3<f32>(0.,8.36,0.),vec3<f32>(span,2.84,.46))),q),3u,q,6.));
 // Open stone balustrades close the gallery edge, not a bare projecting slab.
 let bx=repeatX(q.x,.55,100.);var bal=cylinder(vec3<f32>(bx,q.y-6.08,q.z+.10),.065,.28);
 bal=min(bal,length(vec3<f32>(bx,q.y-6.1,q.z+.10))-.11);
 bal=min(bal,box(q-vec3<f32>(0.,6.43,-.10),vec3<f32>(span,.095,.25)));
 bal=min(bal,box(q-vec3<f32>(0.,5.75,-.10),vec3<f32>(span,.095,.25)));
 f=take(f,field(shell(max(bal,box(q-vec3<f32>(0.,6.08,0.),vec3<f32>(span,.50,.45))),q),3u,q,6.));
 // Layered bearing cornice with a restrained tooth rhythm.
 let cornice=min(box(q-vec3<f32>(0.,11.18,0.),vec3<f32>(span+.16,.14,.48)),box(q-vec3<f32>(0.,11.48,-.04),vec3<f32>(span+.3,.13,.66)));
 let tooth=max(box(vec3<f32>(repeatX(q.x,.55,100.),q.y-11.30,q.z+.28),vec3<f32>(.13,.13,.29)),box(q-vec3<f32>(0.,11.3,0.),vec3<f32>(span,.3,.8)));
 f=take(f,field(shell(min(cornice,tooth),q),3u,q,6.));return f;
}
fn publicGable(q:vec3<f32>,worldToGable:mat3x3<f32>)->Field {
 let tri=max(box(q-vec3<f32>(0.,13.35,0.),vec3<f32>(5.65,2.15,.32)),q.y-(15.6-abs(q.x)*.72));
 let ux=abs(q.x)-.85;let window=archOpening(vec3<f32>(ux,q.y-11.85,q.z),.47,1.15,1.);
 var f=field(shell(max(tri,-window),q),2u,q,12.);
 var rake=capsule(q,vec3<f32>(-5.75,11.47,-.1),vec3<f32>(0.,15.75,-.1),.15);
 rake=min(rake,capsule(q,vec3<f32>(0.,15.75,-.1),vec3<f32>(5.75,11.47,-.1),.15));
 rake=min(rake,box(q-vec3<f32>(0.,11.65,-.05),vec3<f32>(5.9,.12,.43)));
 let frame=max(archOpening(vec3<f32>(ux,q.y-11.85,q.z+.1),.63,1.15,.4),-window);f=take(f,field(shell(min(rake,frame),q),3u,q,12.));
 var gw=sashWindow(vec3<f32>(ux,q.y-11.85,q.z),.47,1.15,12.,mat3x3<f32>(vec3<f32>(sign(q.x),0.,0.),vec3<f32>(0.,1.,0.),vec3<f32>(0.,0.,1.))*worldToGable);gw.d=shell(gw.d,q);f=take(f,gw);
 let finial=min(cylinder(q-vec3<f32>(0.,16.,0.),.11,.25),length(q-vec3<f32>(0.,16.25,0.))-.17);f=take(f,field(shell(finial,q),3u,q,12.));return f;
}
fn towerHalf(y:f32)->vec2<f32> {
 return vec2<f32>(7.1,8.2)-vec2<f32>(.75,1.1)*smoothstep(7.2,8.4,y)-vec2<f32>(1.3,1.7)*smoothstep(12.3,13.7,y)-vec2<f32>(1.25,1.6)*smoothstep(18.2,19.4,y);
}
fn chamferPlan(q:vec2<f32>,h:vec2<f32>,bevel:f32)->f32 {let a=abs(q);return max(max(a.x-h.x,a.y-h.y),(a.x+a.y-h.x-h.y+bevel)*.70710678);}
fn taperedTower(p:vec3<f32>)->Field {
 let tq=p-vec3<f32>(-35.5,0.,-18.);let h=towerHalf(p.y);
 // Continuous curved setbacks, chamfered corners and conservative distance bound.
 let outer=max(chamferPlan(tq.xz,h,.65)/2.3,max(-p.y,p.y-23.8));
 let inner=max(chamferPlan(tq.xz,h-vec2<f32>(.48),.42)/2.3,max(-.05-p.y,p.y-24.1));var wall=max(outer,-inner);
 let mainArch=archOpening(vec3<f32>(tq.z,p.y,tq.x+7.10),3.05,3.15,1.1);wall=max(wall,-mainArch);
 wall=max(wall,-box(p-vec3<f32>(-28.4,1.7,-20.),vec3<f32>(1.,1.75,1.75)));
 // Axial public arches join the vestibule to both lengths of the west hall.
 // Preserve the tower corners while releasing the public and custody aisles.
 let hallArch=archOpening(vec3<f32>(p.x+33.6,p.y,abs(tq.z)-8.2),3.95,1.55,1.1);wall=max(wall,-hallArch);
 // The upper office connects by a short stair to the first tower floor.
 let towerBridgePortal=box(p-vec3<f32>(-31.4,7.25,-10.1),vec3<f32>(1.03,1.90,1.65));wall=max(wall,-towerBridgePortal);
 let tier=select(select(0.,1.,p.y>12.5),2.,p.y>18.5);let baseline=select(select(8.45,14.0,tier>.5),19.6,tier>1.5);
 let pitch=select(select(4.25,3.0,tier>.5),2.25,tier>1.5);let radius=select(.95,.72,tier>1.5);
 let u0=repeatX(tq.z,pitch,1.);let v0=repeatX(tq.x,pitch*.8,1.);
 let front=archOpening(vec3<f32>(u0,p.y-baseline,abs(tq.x)-h.x),radius,1.35,1.1);
 let side=archOpening(vec3<f32>(v0,p.y-baseline,abs(tq.z)-h.y),radius,1.35,1.1);
 wall=max(max(wall,-front),-side);var f=field(shell(wall,p),2u,p,7.);
 let hallRing=max(archOpening(vec3<f32>(p.x+33.6,p.y,abs(tq.z)-8.2),4.18,1.55,.58),-hallArch);f=take(f,field(shell(hallRing,p),3u,p,20.));
 var fw=sashWindow(vec3<f32>(u0,p.y-baseline,h.x-abs(tq.x)),radius,1.35,7.,mat3x3<f32>(vec3<f32>(0.,0.,-sign(tq.x)),vec3<f32>(0.,1.,0.),vec3<f32>(1.,0.,0.)));
 var sw=sashWindow(vec3<f32>(v0,p.y-baseline,h.y-abs(tq.z)),radius,1.35,8.,mat3x3<f32>(vec3<f32>(1.,0.,0.),vec3<f32>(0.,1.,0.),vec3<f32>(0.,0.,-sign(tq.z))));
 fw.d=shell(max(fw.d,box(tq-vec3<f32>(0.,15.5,0.),vec3<f32>(7.4,8.3,8.5))),p);
 sw.d=shell(max(sw.d,box(tq-vec3<f32>(0.,15.5,0.),vec3<f32>(7.4,8.3,8.5))),p);
 fw.d=max(fw.d,-towerBridgePortal);sw.d=max(sw.d,-towerBridgePortal);f=take(f,fw);f=take(f,sw);
 // Continuous stone corner pilasters follow the inward curve rather than standing free.
 let corner=abs(abs(tq.x)+abs(tq.z)-h.x-h.y+.65)*.70710678-.16;
 let cornerBound=max(max(abs(tq.x)-h.x-.05,abs(tq.z)-h.y-.05),max(-p.y,p.y-23.8));
 f=take(f,field(shell(max(corner,cornerBound),p),3u,p,8.));
 for(var n=0;n<4;n++){let ys=array<f32,4>(7.12,12.26,18.16,23.78);let yy=ys[u32(n)];let hh=towerHalf(yy)+vec2<f32>(.32);var course=max(chamferPlan(tq.xz,hh,.7),abs(p.y-yy)-.17);course=max(course,-chamferPlan(tq.xz,hh-vec2<f32>(.58),.5));course=max(course,-towerBridgePortal);f=take(f,field(shell(course,p),3u,p,8.));}
 let portalRing=max(archOpening(vec3<f32>(tq.z,p.y,tq.x+7.22),3.55,3.15,.28),-mainArch);f=take(f,field(shell(portalRing,p),3u,p,8.));
 // Eight real treads bridge office floor 5.44m to tower finished floor 6.63m.
 let bridgeStep=clamp(floor((-p.z-8.8)/.30),0.,7.);let bridgeTop=5.44+(bridgeStep+1.)*.14875;
 let bridge=box(p-vec3<f32>(-31.4,bridgeTop-.074375,-8.8-(bridgeStep+.5)*.30),vec3<f32>(.92,.074375,.15));
 f=take(f,field(shell(bridge,p),4u,p,21.));
 f=take(f,field(shell(box(p-vec3<f32>(-31.4,6.55,-11.62),vec3<f32>(.92,.08,.45)),p),3u,p,21.));
 // Floor plates and two dogleg flights link the occupied upper tower levels.
 for(var n=0;n<3;n++){let ys=array<f32,3>(6.5,12.3,18.2);let yy=ys[u32(n)];let hh=towerHalf(yy)-vec2<f32>(.5);var slab=max(chamferPlan(tq.xz,hh,.5),abs(p.y-yy)-.13);slab=max(slab,-box(tq-vec3<f32>(0.,yy,0.),vec3<f32>(1.95,.4,3.1)));f=take(f,field(shell(slab,p),3u,p,7.));}
 for(var n=0;n<2;n++){let y0=select(6.5,12.3,n==1);let rise=select(5.8,5.9,n==1);let back=p.y>y0+rise*.5;let zz=select(tq.z,-tq.z,back);let step=clamp(floor((zz+2.4)/.3),0.,15.);let yy=y0+select(0.,rise*.5,back)+(step+1.)*rise/32.;let xx=select(-1.05,1.05,back);let tread=box(vec3<f32>(tq.x-xx,p.y-yy+.075,zz-(-2.4+(step+.5)*.3)),vec3<f32>(.68,.075,.15));f=take(f,field(shell(tread,p),3u,p,7.));f=take(f,field(shell(box(tq-vec3<f32>(0.,y0+rise*.5,2.65),vec3<f32>(1.75,.1,.4)),p),3u,p,7.));}
 if(u.options.x<.5){let hip=max(abs(p.y-(27.5-max(abs(tq.x),abs(tq.z))*.85))-.16,box(tq-vec3<f32>(0.,25.5,0.),vec3<f32>(4.35,2.5,4.35)));f=take(f,field(hip,7u,p,7.));
 let finial=min(cylinder(tq-vec3<f32>(0.,27.7,0.),.08,.3),length(tq-vec3<f32>(0.,28.,0.))-.14);f=take(f,field(finial,3u,p,7.));
 f=take(f,field(box(p-vec3<f32>(-42.93,6.78,-18.),vec3<f32>(.12,.50,6.5)),12u,p,1.));f=take(f,field(entranceText(vec3<f32>(p.z+18.,p.y,p.x+43.10)),13u,p,1.));}
 return f;
}
fn taperedChimney(p:vec3<f32>)->Field {
 let q=p-vec3<f32>(61.,0.,55.);let t=clamp((p.y-3.)/27.,0.,1.);let radius=mix(2.45,1.18,t);
 let shaft=max((length(q.xz)-radius)/1.01,max(2.8-p.y,p.y-30.));
 let flue=max(length(q.xz)-max(.74,radius-.48),max(3.2-p.y,p.y-31.4));
 var d=max(shaft,-flue);var f=field(d,2u,p,9.);
 let base=max(cylinder(q-vec3<f32>(0.,1.5,0.),3.,1.5),-cylinder(q-vec3<f32>(0.,2.,0.),1.5,1.6));f=take(f,field(base,2u,p,9.));
 let plinth=max(cylinder(q-vec3<f32>(0.,.28,0.),3.24,.28),-cylinder(q-vec3<f32>(0.,1.,0.),1.5,1.));
 let collar=max(cylinder(q-vec3<f32>(0.,3.,0.),2.7,.18),-cylinder(q-vec3<f32>(0.,3.,0.),1.85,.5));f=take(f,field(min(plinth,collar),3u,p,9.));
 // Slightly corbelled lip is proportionate to the slender throat and remains open.
 let cap=max(cylinder(q-vec3<f32>(0.,30.55,0.),1.39,.45),-cylinder(q-vec3<f32>(0.,30.55,0.),.75,.8));f=take(f,field(cap,2u,p,9.));
 let rim=max(cylinder(q-vec3<f32>(0.,30.96,0.),1.49,.10),-cylinder(q-vec3<f32>(0.,30.96,0.),.75,.3));f=take(f,field(rim,3u,p,9.));return f;
}
fn architecture(p:vec3<f32>)->Field {
 // A conservative whole-body candidate, not drawable cached geometry. Sky and
 // street rays reach this envelope before any civic-wing/tower detail expands.
 let civicBound=box(p-vec3<f32>(3.8,14.1,-.1),vec3<f32>(47.5,14.6,41.8));
 if(civicBound>.8){return field(civicBound,0u,p,0.);}
 var f=field(box(p-vec3<f32>(4.,-.24,0.),vec3<f32>(46.,.24,40.)),3u,p,1.);
 // Continuous L-shaped, 3.2m clear sheltered walk. The x-negative street is public entry.
 let westQ=vec3<f32>(p.z,p.y,p.x+42.6);let southQ=vec3<f32>(p.x-4.,p.y,p.z+40.5);
 var wa=arcade(westQ,40.7);wa.d=max(wa.d,-box(p-vec3<f32>(-42.6,3.,-18.),vec3<f32>(1.,3.1,4.0)));f=take(f,wa);
 f=take(f,arcade(southQ,46.6));
 f=take(f,field(shell(box(p-vec3<f32>(-40.7,5.42,0.),vec3<f32>(2.35,.18,40.9)),p),3u,p,1.));
 f=take(f,field(shell(box(p-vec3<f32>(4.,5.42,-38.7),vec3<f32>(46.8,.18,2.2)),p),3u,p,2.));
 let upperWest=upperLoggia(westQ,40.7);let towerVoid=box(p-vec3<f32>(-40.5,9.,-18.),vec3<f32>(3.,5.,8.7));var uw=upperWest;uw.d=max(uw.d,-towerVoid);f=take(f,uw);f=take(f,upperLoggia(southQ,46.6));
 // Recessed business hall and upper offices, coherent bays behind the arcade.
 let towerUpperVoid=box(p-vec3<f32>(-35.5,9.,-18.),vec3<f32>(7.5,3.55,8.5));let wz=repeatX(p.z,5.5,7.);var west=box(p-vec3<f32>(-38.7,5.2,0.),vec3<f32>(.3,5.2,40.));
 let winW=archWindow(vec3<f32>(wz,p.y-6.1,p.x+38.7),.87,1.35,.8);
 west=max(west,-winW);west=max(west,-archOpening(vec3<f32>(p.z+18.,p.y,p.x+38.7),3.4,2.2,1.));
 let groundW=archWindow(vec3<f32>(wz,p.y-1.25,p.x+38.7),.8,1.85,.8);west=max(west,-groundW);
 west=max(west,-towerUpperVoid);f=take(f,field(shell(west,p),2u,p,1.));
 var ww=sashWindow(vec3<f32>(wz,p.y-6.1,p.x+38.7),.87,1.35,1.,rigidWest());ww.d=shell(max(ww.d,-towerUpperVoid),p);f=take(f,ww);
 if(abs(p.z+18.)>4.){var wg=sashWindow(vec3<f32>(wz,p.y-1.25,p.x+38.7),.8,1.85,2.,rigidWest());wg.d=shell(wg.d,p);f=take(f,wg);}
 let sx=repeatX(p.x-4.,5.5,8.);var south=box(p-vec3<f32>(4.,5.2,-36.6),vec3<f32>(46.,5.2,.3));
 let sw=archWindow(vec3<f32>(sx,p.y-6.1,p.z+36.6),.9,1.35,.8);let sg=archWindow(vec3<f32>(sx,p.y-1.2,p.z+36.6),.9,1.85,.8);south=max(max(south,-sw),-sg);
 f=take(f,field(shell(south,p),2u,p,2.));
 var su=sashWindow(vec3<f32>(sx,p.y-6.1,p.z+36.6),.9,1.35,2.,rigidIdentity());su.d=shell(su.d,p);f=take(f,su);
 var sl=sashWindow(vec3<f32>(sx,p.y-1.2,p.z+36.6),.9,1.85,3.,rigidIdentity());sl.d=shell(sl.d,p);f=take(f,sl);
 // Continuous stone string courses and eave, derived from the same bay grammar.
 let bandY=select(5.6,10.35,p.y>8.);f=take(f,field(shell(max(box(p-vec3<f32>(-38.9,bandY,0.),vec3<f32>(.55,.18,40.5)),-towerUpperVoid),p),3u,p,1.));
 f=take(f,field(shell(box(p-vec3<f32>(4.,bandY,-36.8),vec3<f32>(46.5,.18,.55)),p),3u,p,2.));
 // Four occupied storeys form a continuous tapered civic tower above the west entry.
 let tc=vec3<f32>(-35.5,0.,-18.);f=take(f,taperedTower(p));
 // East and railway-facing walls; storage net boundary x44 is separate from service strip.
 let rz=repeatX(p.z-2.,6.,6.);var east=box(p-vec3<f32>(49.75,4.8,0.),vec3<f32>(.25,4.8,40.));east=max(east,-archWindow(vec3<f32>(rz,p.y-4.,49.75-p.x),.85,2.4,.8));f=take(f,field(shell(east,p),2u,p,3.));var ew=sashWindow(vec3<f32>(rz,p.y-4.0,49.75-p.x),.85,2.4,10.,mat3x3<f32>(vec3<f32>(0.,0.,-1.),vec3<f32>(0.,1.,0.),vec3<f32>(1.,0.,0.)));ew.d=shell(ew.d,p);f=take(f,ew);
 let gateX=repeatX(p.x-4.,20.,1.);let freightDoor=box(vec3<f32>(gateX,p.y-2.1,p.z-39.75),vec3<f32>(2.5,2.2,1.));var rear=box(p-vec3<f32>(4.,4.8,39.75),vec3<f32>(46.,4.8,.25));rear=max(rear,-freightDoor);f=take(f,field(shell(rear,p),2u,p,3.));
 // Warehouse clear rectangle is 72 x 62.5 m. All partitions lie OUTSIDE it.
 var westPartition=box(p-vec3<f32>(-28.3,5.9,3.25),vec3<f32>(.2,5.9,31.75));if(u.options.x<.5){let storeTop=12.9-abs(repeatX(p.z-3.25,20.833333,1.))*.25;let publicTop=14.7-.44*max(abs(p.x+35.5),max(abs(p.z)-33.3,0.));westPartition=max(westPartition,p.y-(max(storeTop,publicTop)-.10));}westPartition=max(westPartition,-box(vec3<f32>(p.x+28.3,p.y-1.65,repeatX(p.z,20.,1.)),vec3<f32>(1.,1.7,1.75)));f=take(f,field(shell(westPartition,p),1u,p,4.));
 f=take(f,field(shell(box(p-vec3<f32>(8.,5.9,-28.3),vec3<f32>(36.5,5.9,.2)),p),1u,p,4.));
 var rearPartition=box(p-vec3<f32>(8.,3.5,34.8),vec3<f32>(36.5,3.5,.2));rearPartition=max(rearPartition,-box(vec3<f32>(gateX,p.y-1.65,p.z-34.8),vec3<f32>(1.75,1.7,1.)));f=take(f,field(shell(rearPartition,p),1u,p,4.));
 var westFloor=box(p-vec3<f32>(-33.65,5.32,0.),vec3<f32>(5.1,.12,39.4));westFloor=max(westFloor,-box(p-vec3<f32>(-33.7,5.32,-18.),vec3<f32>(5.8,.4,8.4)));westFloor=max(westFloor,-box(p-vec3<f32>(-33.,5.32,30.),vec3<f32>(1.6,.4,5.5)));f=take(f,field(shell(westFloor,p),3u,p,1.));
 f=take(f,field(shell(box(p-vec3<f32>(8.,5.32,-32.4),vec3<f32>(36.4,.12,3.7)),p),3u,p,2.));
 let step=clamp(floor((p.z-25.)/.32),0.,29.);let stair=max(box(p-vec3<f32>(-33.,(step+1.)*.09,25.+(step+.5)*.32),vec3<f32>(1.3,(step+1.)*.09,.16)),box(p-vec3<f32>(-33.,2.8,29.8),vec3<f32>(1.3,2.8,4.8)));f=take(f,field(shell(stair,p),3u,p,1.));f=take(f,field(shell(box(p-vec3<f32>(-33.,5.36,35.13),vec3<f32>(1.3,.08,.61)),p),3u,p,1.));
 if(u.options.x<.5){let roofZ=repeatX(p.z-3.25,20.833333,1.);var warehouseRoof=max(abs(p.y-(12.9-abs(roofZ)*.25))-.14,box(p-vec3<f32>(8.,11.,3.25),vec3<f32>(36.6,3.,31.85)));let lightWell=box(vec3<f32>(p.x-8.,p.y-12.8,roofZ),vec3<f32>(30.9,2.,1.92));warehouseRoof=max(warehouseRoof,-lightWell);f=take(f,field(warehouseRoof,7u,p,3.));
 // Roof end enclosure closes the old open triangles above the service roof.
 // Its inner face x44.15 lies outside the fixed clear-storage boundary x44.
 let endHeight=12.9-abs(roofZ)*.25;
 let eastGable=max(box(p-vec3<f32>(44.34,11.36,3.25),vec3<f32>(.19,1.56,31.80)),p.y-(endHeight-.10));
 f=take(f,field(eastGable,2u,p,30.));
 let westGable=max(box(p-vec3<f32>(-28.34,12.11,3.25),vec3<f32>(.19,.81,31.80)),p.y-(endHeight-.10));f=take(f,field(westGable,1u,p,32.));
 let northFascia=max(box(p-vec3<f32>(8.,10.10,34.93),vec3<f32>(36.5,.38,.18)),p.y-(endHeight-.10));f=take(f,field(northFascia,2u,p,31.));
 let light=max(abs(p.y-(13.45-abs(roofZ)*.43))-.006,box(vec3<f32>(p.x-8.,p.y-13.,roofZ),vec3<f32>(31.,1.5,2.1)));f=take(f,field(light,8u,p,3.));let endX=abs(p.x-8.)-31.08;let endGlass=max(abs(endX)-.006,max(abs(roofZ)-2.10,max((12.9-abs(roofZ)*.25+.12)-p.y,p.y-(13.45-abs(roofZ)*.43))));f=take(f,field(endGlass,8u,p,3.));
 // A single L-shaped hipped roof envelope: union volumes, subtract their inset union.
 let hyW=14.7-.44*max(abs(p.x+35.5),max(abs(p.z)-33.3,0.));
 let hyS=14.48-.44*max(abs(p.z+34.),max(abs(p.x-3.7)-39.5,0.));
 let bw=box(p-vec3<f32>(-35.5,11.,0.),vec3<f32>(7.8,5.,41.1));let bs=box(p-vec3<f32>(3.7,11.,-34.),vec3<f32>(47.,5.,7.5));
 let biw=box(p-vec3<f32>(-35.5,11.,0.),vec3<f32>(8.1,5.3,41.4));let bis=box(p-vec3<f32>(3.7,11.,-34.),vec3<f32>(47.3,5.3,7.8));
 let outerRoof=min(max((p.y-hyW)*.90,bw),max((p.y-hyS)*.90,bs));
 let innerRoof=min(max((p.y-hyW+.20)*.90,biw),max((p.y-hyS+.20)*.90,bis));
 // Each street gable has a full two-pitch roof extending inward to the main ridge.
 let gx=repeatX(p.x-4.,33.,1.);let gz=repeatX(p.z,27.5,1.);
 let gs=vec3<f32>(gx,p.y,p.z+40.5);let roofWestQ=vec3<f32>(gz,p.y,p.x+42.6);
 let gsh=15.91-abs(gs.x)*.72-max(gs.z,0.)*.24;
 let gwh=15.91-abs(roofWestQ.x)*.72-max(roofWestQ.z,0.)*.24;
 let gsBound=box(gs-vec3<f32>(0.,13.5,3.1),vec3<f32>(5.99,3.,3.75));
 let gwBound=box(roofWestQ-vec3<f32>(0.,13.5,3.1),vec3<f32>(5.99,3.,3.75));
 let towerGap=-box(p-tc-vec3<f32>(0.,14.,0.),vec3<f32>(8.,6.,8.8));
 let dormerOuter=min(max((p.y-gsh)*.81,gsBound),max(max((p.y-gwh)*.81,gwBound),towerGap));
 let dormerInner=min(max((p.y-gsh+.19)*.81,gsBound-.24),max(max((p.y-gwh+.19)*.81,gwBound-.24),towerGap));
 var publicRoof=max(min(outerRoof,dormerOuter),-min(innerRoof,dormerInner));let towerCut=max(chamferPlan((p-tc).xz,towerHalf(p.y)+vec2<f32>(.08),.6)/2.3,max(-p.y,p.y-23.8));publicRoof=max(publicRoof,-towerCut);f=take(f,field(publicRoof,7u,p,1.));
 let gableX=repeatX(p.x-4.,33.,1.);f=take(f,publicGable(vec3<f32>(gableX,p.y,p.z+40.5),rigidIdentity()));
 let gableZ=repeatX(p.z,27.5,1.);var gw=publicGable(vec3<f32>(gableZ,p.y,p.x+42.6),rigidWest());gw.d=max(gw.d,-box(p-tc-vec3<f32>(0.,14.,0.),vec3<f32>(8.,6.,8.8)));f=take(f,gw);
 f=take(f,field(box(p-vec3<f32>(8.,9.7,37.5),vec3<f32>(36.5,.16,3.)),7u,p,2.));f=take(f,field(box(p-vec3<f32>(47.,9.7,3.25),vec3<f32>(3.5,.16,31.8)),7u,p,2.));}
 return f;
}










fn receiverWoodSample(f:Field,n:vec3<f32>,fp:f32)->KpWoodSample {
 var wp=kpWoodDefaultParams();wp.seed+=f.seed*.013;wp.textureScale=.70;wp.roughness=select(.63,.31,f.mat==18u);wp.clearcoat=select(.08,.48,f.mat==18u);
 if(u.counts.y==1u&&f.component.enabled>.5&&(f.mat==4u||f.mat==18u)){wp.textureScale=3.;wp.grainContrast=.34;}
 let localNormal=componentVector(f,n);var ws=kpWoodOriginalSample(f.local,localNormal,select(0.,1.,abs(localNormal.x)>.7),wp,fp,0.);
 if(f.mat==14u){let wear=smoothstep(.52,.77,br_noise3(f.local*9.+vec3<f32>(f.seed)))*f.age*.20;ws.surface.albedo=mix(vec3<f32>(.19,.23,.18)*(1.+ws.surface.height*120.),ws.surface.albedo,wear);if(u.clock.w<.5){ws.surface.roughness=.46+wear*.15;}}
 ws.surface.albedo*=1.-f.age*f.wet*.12;return ws;
}
struct ReceiverResponse { surface:KpSurface,cavity:f32,specularLevel:f32,clearcoat:f32,clearcoatRoughness:f32,macroHeightM:f32,parallaxHeight01:f32 };

struct ResponseParts { diffuse:vec3<f32>,baseSpecular:vec3<f32>,coatSpecular:vec3<f32>,roughness:f32,cavity:f32,coat:f32 };
// Original frozen room-slice GGX/Schlick/Smith response, using the CURRENT bureau
// sun/ambient/fixtures instead of copying the older receiver's light constants.




struct EnvironmentRay { direction:vec4<f32>,weight:vec4<f32>,transmittance:vec4<f32>,evidence:vec4<f32> };






// One invocation per direction and one textual sceneField site. No materials.
// State 0 inactive, 1 escaped to original sky, 2 real opaque blocker, 3 unresolved.









fn surfaceRaw(f:Field,p:vec3<f32>,n:vec3<f32>,fp:f32)->KpSurface {
 let weather=f.age*f.wet;let noise=br_noise3(p*2.1);var m=KpSurface(0.,vec3<f32>(.3),.8);
 if(f.mat==1u||f.mat==19u){let pp=receiverPlasterParams();let plasterP=plasterCoordinates(p);let pf=kpPlasterOriginalField(plasterP,pp,fp);let ps=kpFabricState(f.age,f.wet,f.wet,pf.macroTone,.42,.08,pf.macroTone,pf.micro,pf.thicknessM,.004,.025);m=kpApplyFabricSurface(pf.surface,ps);m.albedo*=vec3<f32>(1.26,1.24,1.12);let dampBase=(1.-smoothstep(.15,1.25,p.y))*f.wet;let contact=(1.-smoothstep(.35,.80,abs(p.y-1.15)))*.025;let worn=f.age*clamp(dampBase*.32+contact,0.,.09);m.albedo=mix(m.albedo,vec3<f32>(.35,.30,.23),worn);m.albedo*=1.-weather*.12;}
 if(f.mat==2u){let axis=select(p.x,p.z,abs(n.x)>.6);let row=floor(p.y/.075);let stagger=fract(row*.5)*.25;let cell=floor((axis+stagger)/.25);let bx=(axis+stagger)-cell*.25;let bq=vec3<f32>(bx-.125,fract(p.y/.075)*.075-.0375,.055);let seed=cell+row*17.;m=kpBrickOriginalSurface(bq,seed,i32(abs(seed))%4,.42,fp);let edge=max(abs(bq.x)-.118,abs(bq.y)-.0305);let mortar=smoothstep(-max(.001,fp*.55),max(.001,fp*.55),edge);m.albedo=mix(m.albedo,vec3<f32>(.43,.40,.32),mortar);m.height=mix(m.height,-.003,mortar);m.albedo*=1.-weather*.16;}

 if(f.mat==3u){m=kpStoneSurface(p,f.age,f.wet*.35,0.,fp);let mineralTone=dot(m.albedo,vec3<f32>(.2126,.7152,.0722));m.albedo=vec3<f32>(.49,.445,.35)*(.92+clamp(mineralTone,.06,.40)*.32);m.height*=.22;m.roughness=clamp(m.roughness,.55,.80);if(n.y>.75&&p.y<.15){let phase=fract(p.xz/vec2<f32>(.85,.55));let edge=min(min(phase.x,1.-phase.x)*.85,min(phase.y,1.-phase.y)*.55);let joint=1.-smoothstep(.002,.005+fp*.55,edge);m.albedo=mix(m.albedo,vec3<f32>(.24,.225,.19),joint*.48);m.height-=joint*.001;}}
 if(f.mat==4u||f.mat==14u||f.mat==18u){m=receiverWoodSample(f,n,fp).surface;}
 if(f.mat==5u||f.mat==9u){m=kpMetalSurface(p,f.age,f.wet,0.,fp);if(f.mat==9u){m.albedo=mix(m.albedo,vec3<f32>(.28,.12,.035),.55);}m.albedo*=1.25;}
 if(f.mat==7u){var sp=kpStoneSlateDefaultParams();sp.sourceScaleM=.125;sp.materialScale=1.;sp.mineral=.16;sp.chroma=.22;sp.relief=.24;
 let across=select(p.z,p.x,abs(n.z)>abs(n.x));let slope=select(p.x,p.z,abs(n.z)>abs(n.x))/max(.45,abs(n.y));let row=floor(slope/.38);let shifted=across+fract(row*.5)*.30;let col=floor(shifted/.30);let phase=fract(vec2<f32>(shifted,slope)/vec2<f32>(.30,.38));let dna=st_hash33(vec3<f32>(col,row,f.seed));
 let slateP=vec3<f32>(phase.x*.30,0.,phase.y*.38)+dna*3.;m=kpStoneSlateSurface(slateP,sp,f.age,f.wet*.25,0.,fp);
 // Each cut tile has its own subdued mineral tone. Source cleavage survives in
 // roughness/height and 12% of its colour, instead of a continuous gravel map.
 let cutColour=vec3<f32>(.054,.065,.072)*(.86+.25*dna.x);m.albedo=mix(m.albedo,cutColour,.88);
 let edge=min(min(phase.x,1.-phase.x)*.30,min(phase.y,1.-phase.y)*.38);let joint=1.-smoothstep(.0015,.0035+fp*.45,edge);m.albedo*=1.-joint*.22;m.height-=joint*.0012;}

 if(f.mat==8u){m=KpSurface((br_noise3(p*5.)-.5)*.0001,vec3<f32>(.85,.93,.89),.09+f.wet*.08);}
 if(f.mat==10u){m=KpSurface(0.,mix(vec3<f32>(.21,.23,.22),vec3<f32>(.27,.29,.27),noise),.95);let line=abs(abs(p.x)-.5);if(p.z< -42.&&p.z> -53.&&line<.07){m.albedo=vec3<f32>(.69,.62,.39);}}
 if(f.mat==15u||f.mat==16u){m=kpStoneSurface(p*.45,f.age,.015,0.,fp*.45);if(f.mat==15u){let tile=floor(p.x/.52)+floor(p.z/.52);let dark=fract(tile*.5)>.25;let tilePhase=fract(p.xz/.52);let joint=min(min(tilePhase.x,1.-tilePhase.x),min(tilePhase.y,1.-tilePhase.y))*.52;let grout=1.-smoothstep(.0015,.0045+fp*.50,joint);let base=select(vec3<f32>(.53,.47,.34),vec3<f32>(.075,.105,.099),dark);m.albedo=mix(base*(.90+.20*br_noise3(p*1.3)),vec3<f32>(.29,.26,.21),grout);let walk=1.-smoothstep(.4,2.1,abs(p.x+35.3));m.roughness=.52-walk*.18;m.height*=.13;}else{let aggregateTone=dot(m.albedo,vec3<f32>(.2126,.7152,.0722));m.albedo=vec3<f32>(.275,.265,.23)*(.94+clamp(aggregateTone,.04,.40)*.24);let lane=1.-smoothstep(.6,1.6,abs(p.x-4.));m.roughness=.86-lane*.13;m.height*=.10;}}
 if(f.mat==17u){m=KpSurface(0.,vec3<f32>(1.,.77,.40),.24);}
 if(f.mat==11u){m=KpSurface(0.,vec3<f32>(1.,.32,.03),.5);}
 if(f.mat==12u){m=KpSurface(0.,vec3<f32>(.023,.065,.054),.42);}
 if(f.mat==13u){m=KpSurface(0.,vec3<f32>(.82,.72,.48),.55);}
 if(f.mat==20u){m=publicPaperSurface(f.local,f.seed,f.age,fp);}
 return m;
}
// Bounded tangent-footprint integration of unchanged stone mothers. No texture cache.


// The original material height now participates in the resolved surface normal.



// Secondary intersection is its own compute pass. No material is evaluated here.


// Each geometry stage has one textual domain evaluation site. Four tetrahedral
// normal samples are independent invocations, not four cloned building shaders.









struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }

@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;

fn mapField(p:vec3<f32>)->Field {return take(take(architecture(p),entryJoinery(p)),taperedChimney(p));}



@compute @workgroup_size(32) fn sampleColor(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w<.5){return;}let p=o.position.xyz;let f=mapField(p);let m=surfaceRaw(f,p,o.normal.xyz,.25);o.color=vec4<f32>(m.albedo,m.roughness);mapSamples[i]=o;}
