
struct Frame { eye:vec4<f32>,forward:vec4<f32>,right:vec4<f32>,up:vec4<f32>,cut:vec4<f32>,size:vec4<f32>,tile:vec4<u32>,controls:vec4<f32> }
@group(0) @binding(0) var<uniform> u:Frame;

@group(0) @binding(1) var<storage,read> worldRules:array<vec4<f32>>;
struct GeoHit{d:f32,materialId:u32,buildingId:u32,componentId:u32,stateId:u32,q:vec3<f32>,n:vec3<f32>,objectId:u32}
// Short-lived per-ray candidate keys, never persistent world/brick instances.
var<private> fieldCompetition:bool;
var<private> fieldExcluded:array<vec2<u32>,32>;
var<private> fieldExcludedCount:u32;
fn excludedFieldObject(state:u32,component:u32)->bool{if(!fieldCompetition){return false;}for(var i=0u;i<fieldExcludedCount;i++){if(all(fieldExcluded[i]==vec2<u32>(state,component))){return true;}}return false;}
fn rec(s:u32,k:u32)->vec4<f32>{return worldRules[s*8u+k];}
fn boxD(q:vec3<f32>,b:vec3<f32>)->f32{let a=abs(q)-b;return length(max(a,vec3<f32>(0.)))+min(max(a.x,max(a.y,a.z)),0.);}
fn boxN(q:vec3<f32>,b:vec3<f32>)->vec3<f32>{let a=abs(q)-b;var n=vec3<f32>(0.,0.,sign(q.z));if(a.x>=a.y&&a.x>=a.z){n=vec3<f32>(sign(q.x),0.,0.);}else if(a.y>=a.z){n=vec3<f32>(0.,sign(q.y),0.);}return n;}
fn choose(h:GeoHit,d:f32,m:u32,s:u32,c:u32,q:vec3<f32>,n:vec3<f32>)->GeoHit{if(d>=h.d||excludedFieldObject(s+1u,c)){return h;}return GeoHit(d,m,u32(rec(s,3u).x),c,s+1u,q,n,c);}
fn addBox(h:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec3<f32>,m:u32,s:u32,c:u32)->GeoHit{let q=p-center;return choose(h,boxD(q,half),m,s,c,q,boxN(q,half));}
fn woodBox(h:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec3<f32>,s:u32,c:u32,axis:u32)->GeoHit{let q=p-center;var local=q;if(axis==1u){local=q.yxz;}if(axis==2u){local=q.zyx;}return choose(h,boxD(q,half),4u,s,c*4u+axis,local,boxN(q,half));}
fn pipeD(p:vec3<f32>,a:vec3<f32>,b:vec3<f32>,r:f32)->f32{let pa=p-a;let ba=b-a;return length(pa-ba*clamp(dot(pa,ba)/dot(ba,ba),0.,1.))-r;}
fn addPipe(h:GeoHit,p:vec3<f32>,a:vec3<f32>,b:vec3<f32>,r:f32,s:u32,c:u32)->GeoHit{let ab=b-a;let q=p-a;let n=normalize(q-ab*clamp(dot(q,ab)/dot(ab,ab),0.,1.));return choose(h,pipeD(p,a,b,r),3u,s,c,q,n);}
fn rail(h0:GeoHit,p:vec3<f32>,a:vec3<f32>,b:vec3<f32>,s:u32,c:u32)->GeoHit{var h=h0;let d=b-a;let len=length(d.xz);let t=clamp(dot((p-a).xz,d.xz)/(len*len),0.,1.);let count=max(2.,ceil(len/.11));let ti=round(t*count)/count;let foot=a+d*ti;h=addPipe(h,p,a+vec3<f32>(0.,1.02,0.),b+vec3<f32>(0.,1.02,0.),.027,s,c);h=addPipe(h,p,a+vec3<f32>(0.,.22,0.),b+vec3<f32>(0.,.22,0.),.017,s,c+1u);h=addPipe(h,p,foot,foot+vec3<f32>(0.,1.,0.),.014,s,c+2u);return h;}
fn windowParts(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec2<f32>,s:u32,c:u32,side:bool,door:bool,sliding:bool)->GeoHit{var h=h0;let qq=p-center;var q=qq;if(side){q=qq.zyx;}let outer=boxD(q,vec3<f32>(half+vec2<f32>(.055),.085));let inner=boxD(q,vec3<f32>(half-vec2<f32>(.015),.15));let n=select(boxN(q,vec3<f32>(half,.1)),boxN(q,vec3<f32>(half,.1)).zyx,side);h=choose(h,max(outer,-inner),4u,s,c*4u+1u,q.yxz,n);if(!door){h=choose(h,min(boxD(q,vec3<f32>(.021,half.y,.025)),boxD(q,vec3<f32>(half.x,.019,.025))),3u,s,c+10u,q,n);h=choose(h,boxD(q,vec3<f32>(half-vec2<f32>(.04),.006)),5u,s,c+11u,q,n);}else if(sliding){let leaf=q-vec3<f32>(select(-1.5,1.5,q.x>0.)*half.x,0.,-.15);h=choose(h,boxD(leaf,vec3<f32>(half.x*.5,half.y-.025,.025)),4u,s,(c+12u)*4u+1u,leaf.yxz,n);h=addBox(h,p,center+vec3<f32>(0.,half.y+.065,-.15),vec3<f32>(half.x*2.,.022,.027),3u,s,c+11u);}else if(side&&rec(s,2u).w>0.){let inward=select(-1.,1.,rec(s,3u).x==2.);let hinge=q-vec3<f32>(-half.x,0.,inward*.15);let sn=.8660254;let leaf=vec3<f32>(hinge.x*.5+hinge.z*inward*sn-half.x*.98,hinge.y,-hinge.x*inward*sn+hinge.z*.5);let ln=boxN(leaf,vec3<f32>(half.x*.98,half.y-.025,.025));let wn=vec3<f32>(inward*sn*ln.x+.5*ln.z,ln.y,.5*ln.x-inward*sn*ln.z);h=choose(h,boxD(leaf,vec3<f32>(half.x*.98,half.y-.025,.025)),4u,s,(c+12u)*4u+1u,leaf.yxz,wn);}else{var leaf=q;leaf.x+=half.x-.035;leaf.z-=half.x*.65;let turn=vec2<f32>(leaf.x*.50+leaf.z*.866,-leaf.x*.866+leaf.z*.50);leaf=vec3<f32>(turn.x,leaf.y,turn.y);h=choose(h,boxD(leaf,vec3<f32>(half.x*.98,half.y-.025,.025)),4u,s,(c+12u)*4u+1u,leaf.yxz,n);}return h;}
fn stair(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,rise:f32,run:f32,width:f32,s:u32,c:u32,reverse:bool)->GeoHit{var h=h0;var q=p-center;if(reverse){q.z=-q.z;}let lower=boxD(q-vec3<f32>(0.,(rise+.92)*.5,0.),vec3<f32>(width*.5+.07,(rise+1.20)*.5,run*.5+.04));if(lower>h.d){return h;}let count=ceil(rise/.18);let tread=run/count;let stepH=rise/count;
 // Finite concrete treads and risers leave real walkable headroom below the next flight.
 for(var k=0u;k<u32(count);k++){let i=f32(k);let top=(i+1.)*stepH;let z=-run*.5+(i+.5)*tread;let tq=q-vec3<f32>(0.,top-.07,z);let th=vec3<f32>(width*.5,.07,tread*.5+.0001);let tn=boxN(tq,th);h=choose(h,boxD(tq,th),9u,s,c,tq,vec3<f32>(tn.xy,select(tn.z,-tn.z,reverse)));let rh=vec3<f32>(width*.5,(stepH+.14)*.5,.018);let rq=q-vec3<f32>(0.,top-rh.y,-run*.5+i*tread+.018);let rn=boxN(rq,rh);h=choose(h,boxD(rq,rh),9u,s,c,rq,vec3<f32>(rn.xy,select(rn.z,-rn.z,reverse)));}
 let zz=select(1.,-1.,reverse);let a=center+vec3<f32>(width*.5+.035,0.,-run*.5*zz);let b=center+vec3<f32>(width*.5+.035,rise,run*.5*zz);h=rail(h,p,a,b,s,c+10u);h=rail(h,p,a-vec3<f32>(width+.07,0.,0.),b-vec3<f32>(width+.07,0.,0.),s,c+10000u);return h;}
fn bed(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,s:u32,c:u32,bunk:bool)->GeoHit{var h=h0;let q=p-center;let upper=select(.0,1.22,bunk&&q.y>.95);let y=.44+upper;let lx=select(-.53,.53,q.x>0.);let lz=select(-.99,.99,q.z>0.);h=woodBox(h,p,center+vec3<f32>(lx,select(.61,1.11,bunk),lz),vec3<f32>(.042,select(.61,1.11,bunk),.042),s,c,1u);h=woodBox(h,p,center+vec3<f32>(lx,y,0.),vec3<f32>(.032,.085,1.04),s,c+1u,2u);h=woodBox(h,p,center+vec3<f32>(0.,y,lz),vec3<f32>(.55,.085,.033),s,c+2u,0u);let slat=clamp(round(q.z/.15),-6.,6.)*.15;h=woodBox(h,p,center+vec3<f32>(0.,y+.015,slat),vec3<f32>(.53,.019,.049),s,c+3u,0u);h=addBox(h,p,center+vec3<f32>(0.,y+.14,0.),vec3<f32>(.515,.09,.96),7u,s,c+4u);h=addBox(h,p,center+vec3<f32>(0.,y+.26,.72),vec3<f32>(.37,.10,.18),7u,s,c+5u);let roll=q-vec3<f32>(0.,y+.26,-.66);h=choose(h,boxD(roll,vec3<f32>(.49,.085,.22))-.035,7u,s,c+6u,roll,boxN(roll,vec3<f32>(.49,.085,.22)));return h;}
fn table(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec2<f32>,height:f32,s:u32,c:u32)->GeoHit{var h=h0;let q=p-center;h=woodBox(h,p,center+vec3<f32>(0.,height,0.),vec3<f32>(half.x,.035,half.y),s,c,0u);let corner=vec3<f32>(select(-1.,1.,q.x>0.)*(half.x-.055),height*.5,select(-1.,1.,q.z>0.)*(half.y-.055));h=woodBox(h,p,center+corner,vec3<f32>(.035,height*.5,.035),s,c+1u,1u);return h;}
fn stool(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,s:u32,c:u32)->GeoHit{return table(h0,p,center,vec2<f32>(.19),.43,s,c);}
fn roomLife(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let programmeCode=u32(b.z);let side=select(1.,-1.,u32(rec(s,3u).x)==2u);let livingX=a.x-side*1.51;let bay=select(-1.,1.,p.x>livingX);let center=vec3<f32>(livingX+bay*(a.z-3.1)*.245,a.y,max(1.30,b.x+2.20));let q=p-center;let c=200000u+s*1000u+select(0u,400u,bay>0.);
 if(programmeCode==4u||programmeCode==5u||programmeCode==8u||programmeCode==9u||programmeCode==11u||programmeCode>=12u){let compact=b.x> -1.;let ix=center.x-bay*select(.82,.95,compact);h=bed(h,p,vec3<f32>(center.x+bay*.15,a.y,min(center.z+.25,1.55)),s,c,programmeCode==5u);h=woodBox(h,p,vec3<f32>(ix,a.y+.63,select(min(center.z+1.7,2.3),b.y-.75,compact)),vec3<f32>(.35,.63,.3),s,c+20u,1u);h=table(h,p,vec3<f32>(select(center.x-.1,ix,compact),a.y,select(center.z-1.35,1.6,compact)),vec2<f32>(.48,.26),.72,s,c+21u);h=stool(h,p,vec3<f32>(select(center.x+.15,ix,compact),a.y,select(center.z-1.9,.9,compact)),s,c+23u);}
 else if(programmeCode==2u){let ix=clamp(round(q.x/.83),-1.,1.);let iz=clamp(round((q.z+.20)/1.05),-1.,1.);let tc=center+vec3<f32>(ix*.83,0.,iz*1.05);h=table(h,p,tc,vec2<f32>(.33,.22),.62,s,c+30u);h=stool(h,p,tc+vec3<f32>(0.,0.,-.43),s,c+32u);h=woodBox(h,p,vec3<f32>(a.x,a.y+1.18,b.y-.25),vec3<f32>(1.2,.48,.045),s,c+34u,0u);}
 else if(programmeCode==3u){h=stool(h,p,center,s,c+40u);h=woodBox(h,p,center+vec3<f32>(0.,.76,.13),vec3<f32>(.24,.28,.03),s,c+42u,1u);h=addBox(h,p,center+vec3<f32>(0.,1.24,1.),vec3<f32>(.36,.56,.015),5u,s,c+43u);h=table(h,p,center+vec3<f32>(0.,0.,.82),vec2<f32>(.52,.20),.85,s,c+44u);}
 else{h=table(h,p,center,vec2<f32>(.85,.6),select(.78,.93,programmeCode==0u),s,c+50u);h=stool(h,p,center+vec3<f32>(0.,0.,-.9),s,c+52u);if(programmeCode==0u||programmeCode==6u){let qm=p-(center+vec3<f32>(.15,1.04,0.));let fly=max(length(qm.yz)-.24,abs(qm.x)-.04);h=choose(h,fly,3u,s,c+54u,qm,normalize(vec3<f32>(.1,qm.yz)));h=addBox(h,p,center+vec3<f32>(-.13,.98,.03),vec3<f32>(.27,.12,.15),3u,s,c+55u);}else{let pot=p-(center+vec3<f32>(.26,1.,.12));let shell=max(max(length(pot.xz)-.22,abs(pot.y)-.19),-max(length(pot.xz)-.195,pot.y+.15));h=choose(h,shell,3u,s,c+56u,pot,normalize(vec3<f32>(pot.x,.2,pot.z)));}}
 let sh=vec3<f32>(center.x-bay*.85,a.y+1.37,b.y-.30);h=woodBox(h,p,sh,vec3<f32>(.6,.035,.22),s,c+70u,0u);h=addBox(h,p,sh+vec3<f32>(.15,.18,.01),vec3<f32>(.20,.14,.14),7u,s,c+71u);return h;}
fn wetService(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let bid=u32(rec(s,3u).x);let signX=select(-1.,1.,bid==2u);let center=vec3<f32>(a.x+signX*(a.z*.5-.75),a.y,b.y-1.05);let q=p-center;let basinQ=q-vec3<f32>(0.,.78,0.);let outer=boxD(basinQ,vec3<f32>(.5,.18,.34))-.04;let cavity=boxD(basinQ-vec3<f32>(0.,.055,0.),vec3<f32>(.46,.20,.30))-.025;h=choose(h,max(outer,-cavity),3u,s,800000u+s,basinQ,boxN(basinQ,vec3<f32>(.5,.18,.34)));let corner=vec3<f32>(select(-.43,.43,q.x>0.),.32,select(-.28,.28,q.z>0.));h=addBox(h,p,center+corner,vec3<f32>(.025,.32,.025),3u,s,800100u+s);h=addPipe(h,p,center+vec3<f32>(0.,0.,.36),center+vec3<f32>(0.,1.18,.36),.022,s,800200u+s);h=addPipe(h,p,center+vec3<f32>(0.,1.18,.36),center+vec3<f32>(0.,1.18,.10),.023,s,800300u+s);h=addPipe(h,p,center+vec3<f32>(0.,.56,0.),center+vec3<f32>(0.,.10,0.),.04,s,800400u+s);h=woodBox(h,p,center+vec3<f32>(.84,.72,.03),vec3<f32>(.26,.035,.35),s,800500u+s,0u);return h;}
fn canopy(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec2<f32>,s:u32,c:u32)->GeoHit{var h=h0;let q=p-center;let slope=.18;let yy=q.y-slope*q.z-.014*sin(q.x*52.);let sheet=boxD(vec3<f32>(q.x,yy,q.z),vec3<f32>(half.x,.025,half.y))*.94;h=choose(h,sheet,3u,s,c,q,normalize(vec3<f32>(0.,1.,-slope)));let x=select(-half.x+.1,half.x-.1,q.x>0.);h=addPipe(h,p,center+vec3<f32>(x,-slope*half.y,-half.y),center+vec3<f32>(x,slope*half.y,half.y),.035,s,c+1u);h=addPipe(h,p,center+vec3<f32>(x,slope*half.y,half.y),center+vec3<f32>(x,slope*half.y-.95,half.y),.031,s,c+2u);return h;}
// Dated household event, partitioned along existing execution groups.
fn householdFrontageShell(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let event=rec(s,3u);if(event.y<.5||u.size.w<event.w){return h;}let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let depth=event.z;let wallZ=frontZ(s,u32(event.y)-1u);let z=wallZ-depth;let base=a.y;let height=rec(s,5u).z;let c=1000000u;let fq=p-vec3<f32>(x,base+height*.5,z);
 let wh=vec2<f32>(min(.90,hw-.20),.52);let window=vec3<f32>(x,base+1.48,z);
 h=choose(h,max(boxD(fq,vec3<f32>(hw,height*.5,.065)),-boxD(p-window,vec3<f32>(wh,.20))),1u,s,c,fq,boxN(fq,vec3<f32>(hw,height*.5,.065)));
 let side=select(-1.,1.,p.x>x);let sq=p-vec3<f32>(x+side*hw,base+height*.5,wallZ-depth*.5);
 h=choose(h,boxD(sq,vec3<f32>(.055,height*.5,depth*.5)),1u,s,c+1u,sq,boxN(sq,vec3<f32>(.055,height*.5,depth*.5)));
return h;}
fn householdFrontageOpenings(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let event=rec(s,3u);if(event.y<.5||u.size.w<event.w){return h;}let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let depth=event.z;let wallZ=frontZ(s,u32(event.y)-1u);let z=wallZ-depth;let base=a.y;let height=rec(s,5u).z;let c=1000000u;let wh=vec2<f32>(min(.90,hw-.20),.52);let window=vec3<f32>(x,base+1.48,z);h=windowParts(h,p,window,wh,s,c+20u,false,false,false);return h;}
fn householdFrontageLife(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let event=rec(s,3u);if(event.y<.5||u.size.w<event.w){return h;}let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let depth=event.z;let wallZ=frontZ(s,u32(event.y)-1u);let z=wallZ-depth;let base=a.y;let height=rec(s,5u).z;let c=1000000u; if(rec(s,5u).w>.5){return h;}h=table(h,p,vec3<f32>(x+.35,base,z+.26),vec2<f32>(.48,.17),.74,s,c+40u);
 h=woodBox(h,p,vec3<f32>(x-.55,base+.91,z+.18),vec3<f32>(.30,.035,.14),s,c+44u,0u);
return h;}
fn householdFrontageStorage(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let event=rec(s,3u);if(event.y<.5||u.size.w<event.w||rec(s,5u).w<.5){return h;}let a=rec(s,0u);let b=rec(s,1u);let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let tier=clamp(round((p.y-a.y-.55)/.49),0.,2.);let center=vec3<f32>(x,a.y+.55+tier*.49,frontZ(s,u32(event.y)-1u)-event.z+.20);h=woodBox(h,p,center,vec3<f32>(hw*.70,.03,.11),s,1000040u,0u);let clothTier=clamp(round((p.y-a.y-.73)/.49),0.,2.);h=addBox(h,p,vec3<f32>(x,a.y+.73+clothTier*.49,frontZ(s,u32(event.y)-1u)-event.z+.20),vec3<f32>(hw*.46,.13,.105),7u,s,1000043u);return h;}
fn frontDrainRun(h0:GeoHit,p:vec3<f32>,s:u32,startX:f32,cell:u32,y:f32,c:u32)->GeoHit{var h=h0;let a=rec(s,0u);var x=startX;var z=frontZ(s,cell)-.14;for(var j=cell;j<3u;j++){var endX=a.x+a.z*.5-.15;if(j<2u){let next=frontZ(s,j+1u)-.14;let corner=frontageBounds(s,j).y+sign(next-z)*.15;if(abs(corner-x)>.0001){h=addPipe(h,p,vec3<f32>(x,y,z),vec3<f32>(corner,y,z),.026,s,c+j*3u);}if(abs(next-z)>.0001){h=addPipe(h,p,vec3<f32>(corner,y,z),vec3<f32>(corner,y,next),.026,s,c+j*3u+1u);}x=corner;z=next;}else{if(abs(endX-x)>.0001){h=addPipe(h,p,vec3<f32>(x,y,z),vec3<f32>(endX,y,z),.026,s,c+j*3u);}}}return h;}
fn householdFrontageExterior(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let event=rec(s,3u);if(event.y<.5||u.size.w<event.w){return h;}let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let depth=event.z;let wallZ=frontZ(s,u32(event.y)-1u);let z=wallZ-depth;let base=a.y;let height=rec(s,5u).z;let c=1000000u; h=canopy(h,p,vec3<f32>(x,base+height+.015,wallZ-depth*.5),vec2<f32>(hw+.07,depth*.5+.08),s,c+60u);
 // Drain to the existing riser.
 let gutter=vec3<f32>(x+hw+.07,base+height+.015-.18*(depth*.5+.08)-.025,z-.08);let oldPipe=vec3<f32>(gutter.x,base+.23,wallZ-.14);
 h=addPipe(h,p,vec3<f32>(x-hw-.07,gutter.y,gutter.z),gutter,.026,s,c+72u);h=addPipe(h,p,gutter,vec3<f32>(gutter.x,oldPipe.y,oldPipe.z),.026,s,c+70u);
 h=frontDrainRun(h,p,s,gutter.x,u32(event.y)-1u,oldPipe.y,c+80u);
return h;}
// Metric frontage rules are compiled with household uses, not randomized per pixel.
fn frontageCell(s:u32,x:f32)->u32{let a=rec(s,0u);let f=rec(s,4u);let u=(x-a.x)/a.z+.5;return select(select(0u,1u,u>=f.x),2u,u>=f.y);}
fn frontageBounds(s:u32,cell:u32)->vec2<f32>{let a=rec(s,0u);let f=rec(s,4u);let lo=select(select(0.,f.x,cell==1u),f.y,cell==2u);let hi=select(select(f.x,f.y,cell==1u),1.,cell==2u);return a.x-a.z*.5+vec2<f32>(lo,hi)*a.z;}
fn frontZ(s:u32,cell:u32)->f32{return rec(s,6u)[cell];}
fn frontAt(s:u32,x:f32)->f32{return frontZ(s,frontageCell(s,x));}
fn supportFrontZ(s:u32,cell:u32)->f32{return rec(s,7u)[cell];}
fn hasTerrace(s:u32,cell:u32)->bool{return (u32(rec(s,6u).w)&(1u<<cell))!=0u;}
fn hasPlatform(s:u32,cell:u32)->bool{return hasTerrace(s,cell)||(rec(s,1u).w>.5&&(frontageType(s,cell)>=3u||(u32(rec(s,4u).w)&(1u<<cell))!=0u));}
fn platformFront(s:u32,cell:u32)->f32{return select(frontZ(s,cell)-.95,supportFrontZ(s,cell),hasTerrace(s,cell));}

fn frontageType(s:u32,cell:u32)->u32{return (u32(rec(s,5u).x)>>(cell*3u))&7u;}
fn frontageAperture(s:u32,cell:u32)->vec4<f32>{let a=rec(s,0u);let fb=frontageBounds(s,cell);let pitch=fb.y-fb.x;let kind=frontageType(s,cell);let door=kind>=3u;return vec4<f32>((fb.x+fb.y)*.5,a.y+select(select(1.48,1.88,kind==0u),select(1.03,1.15,kind==4u),door),select(select(pitch*.30,pitch*.41,kind==2u),select(min(.51,pitch*.29),pitch*.40,kind==4u),door),select(select(.63,.32,kind==0u),select(1.02,1.14,kind==4u),door));}
fn frontageOpenings(h0:GeoHit,p:vec3<f32>,s:u32,c:u32)->GeoHit{var h=h0;let b=rec(s,1u);let count=min(3u,arrayLength(&worldRules));for(var cell=0u;cell<count;cell++){let ap=frontageAperture(s,cell);h=frontageOpening(h,p,s,cell,vec3<f32>(ap.xy,frontZ(s,cell)-.005),ap.zw,c+20u+cell*10000u);}return h;}
fn frontageOpening(h0:GeoHit,p:vec3<f32>,s:u32,cell:u32,center:vec3<f32>,half:vec2<f32>,c:u32)->GeoHit{var h=h0;let kind=frontageType(s,cell);if(kind!=0u){return windowParts(h,p,center,half,s,c,false,kind>=3u,(u32(rec(s,7u).w)&(1u<<cell))!=0u);}let q=p-center;let frame=max(boxD(q,vec3<f32>(half+vec2<f32>(.035),.055)),-boxD(q,vec3<f32>(half-vec2<f32>(.012),.10)));h=choose(h,frame,3u,s,c,q,vec3<f32>(0.,0.,-1.));let slatY=clamp(round(q.y/.13)*.13,-half.y+.05,half.y-.05);let sq=q-vec3<f32>(0.,slatY,0.);let tilted=vec3<f32>(sq.x,sq.y+.34*sq.z,sq.z);h=choose(h,boxD(tilted,vec3<f32>(half.x,.018,.065))*.94,3u,s,c+1u,sq,normalize(vec3<f32>(0.,.34,-1.)));return h;}
fn frontageShelter(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let f=rec(s,4u);let count=min(3u,arrayLength(&worldRules));for(var cell=0u;cell<count;cell++){if((u32(f.z)&(1u<<cell))==0u){continue;}let bounds=frontageBounds(s,cell);let x=(bounds.x+bounds.y)*.5;let width=(bounds.y-bounds.x)*.44;let drop=select(.33,.20,b.z==0.||b.z==1.);let deep=select(.44,.60,b.w>.5);let c=1200000u+cell*20u;let center=vec3<f32>(x,a.y+a.w-drop,frontZ(s,cell)-deep*.62);h=canopy(h,p,center,vec2<f32>(width,deep),s,c);let end=center+vec3<f32>(width,-.18*deep-.025,-deep);h=addPipe(h,p,end-vec3<f32>(width*2.,0.,0.),end,.028,s,c+5u);}return h;}
fn frontageDrainage(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let f=rec(s,4u);let count=min(3u,arrayLength(&worldRules));for(var cell=0u;cell<count;cell++){if((u32(f.z)&(1u<<cell))==0u){continue;}let bounds=frontageBounds(s,cell);let x=(bounds.x+bounds.y)*.5;let width=(bounds.y-bounds.x)*.44;let drop=select(.33,.20,b.z==0.||b.z==1.);let deep=select(.44,.60,b.w>.5);let c=1200000u+cell*20u;let end=vec3<f32>(x+width,a.y+a.w-drop-.18*deep-.025,frontZ(s,cell)-deep*1.62);let sink=vec3<f32>(end.x,a.y+.23,frontZ(s,cell)-.14);h=addPipe(h,p,end,sink,.026,s,c+6u);h=frontDrainRun(h,p,s,sink.x,cell,sink.y,c+7u);}return h;}
fn frontageDrying(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let mask=u32(rec(s,4u).w);if(mask==0u){return h;}let cell=select(select(0u,1u,(mask&2u)>0u),2u,(mask&4u)>0u);let bounds=frontageBounds(s,cell);let x=(bounds.x+bounds.y)*.5;let half=min((bounds.y-bounds.x)*.36,1.03);let z=platformFront(s,cell)-.25;let c=1300000u+cell*20u;h=addPipe(h,p,vec3<f32>(x-half,a.y+1.96,z),vec3<f32>(x+half,a.y+1.96,z),.009,s,c);for(var k=0u;k<2u;k++){let endX=x+select(-half,half,k==1u);let supportZ=select(frontZ(s,cell)-.10,platformFront(s,cell)+.06,hasTerrace(s,cell));h=addPipe(h,p,vec3<f32>(endX,a.y+1.96,z),vec3<f32>(endX,a.y+1.96,supportZ),.013,s,c+1u+k*3u);if(hasTerrace(s,cell)){h=addPipe(h,p,vec3<f32>(endX,a.y,supportZ),vec3<f32>(endX,a.y+1.96,supportZ),.022,s,c+10u+k);}}let side=select(-1.,1.,p.x>x);let q=p-vec3<f32>(x+side*half*.45,a.y+1.52,z);let fold=.045*sin(q.x*20.)+.025*sin(q.y*9.);let cloth=vec3<f32>(q.x,q.y,q.z-fold);h=choose(h,boxD(cloth,vec3<f32>(select(.19,.27,side>0.),select(.39,.31,side>0.),.018))*.88,7u,s,c+select(2u,3u,side>0.),q.xzy,vec3<f32>(0.,0.,-1.));return h;}
fn parcelSlabs(h0:GeoHit,p:vec3<f32>,s:u32,inner:f32,stairZ:f32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);for(var cell=0u;cell<3u;cell++){let xb=frontageBounds(s,cell);let front=frontZ(s,cell);let floorFront=min(front,supportFrontZ(s,cell));let fq=p-vec3<f32>((xb.x+xb.y)*.5,a.y-.08,(floorFront+b.y)*.5);var slab=boxD(fq,vec3<f32>((xb.y-xb.x)*.5,.10,(b.y-floorFront)*.5));if(rec(s,2u).w>0.){slab=max(slab,-boxD(p-vec3<f32>(inner,a.y-.08,stairZ),vec3<f32>(1.10,.30,2.15)));}h=choose(h,slab,9u,s,1500000u+cell,fq,vec3<f32>(0.,1.,0.));let cq=p-vec3<f32>((xb.x+xb.y)*.5,a.y+a.w-.055,(front+b.y)*.5);let ceilingD=max(boxD(cq,vec3<f32>((xb.y-xb.x)*.5,.065,(b.y-front)*.5)),-boxD(p-vec3<f32>(inner,a.y+a.w-.055,stairZ),vec3<f32>(1.10,.30,2.15)));h=choose(h,ceilingD,9u,s,1500010u+cell,cq,vec3<f32>(0.,-1.,0.));}return h;}
fn parcelFacade(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);for(var cell=0u;cell<3u;cell++){let xb=frontageBounds(s,cell);let front=frontZ(s,cell);let ap=frontageAperture(s,cell);let half=vec3<f32>((xb.y-xb.x)*.5,a.w*.5,.11);let q=p-vec3<f32>((xb.x+xb.y)*.5,a.y+a.w*.5,front);let opening=boxD(p-vec3<f32>(ap.xy,front),vec3<f32>(ap.zw,.32));h=choose(h,max(boxD(q,half),-opening),1u,s,1400000u+cell,q,boxN(q,half));if(cell<2u){let next=frontZ(s,cell+1u);if(abs(next-front)>.001){let rq=p-vec3<f32>(xb.y,a.y+a.w*.5,(front+next)*.5);let rh=vec3<f32>(.11,a.w*.5,abs(next-front)*.5);h=choose(h,boxD(rq,rh),1u,s,1400010u+cell,rq,boxN(rq,rh));}}}return h;}
fn parcelPlatforms(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);for(var cell=0u;cell<3u;cell++){if(!hasPlatform(s,cell)){continue;}let xb=frontageBounds(s,cell);let front=platformFront(s,cell);let back=frontZ(s,cell);let c=1700000u+cell*100u;if(!hasTerrace(s,cell)){h=addBox(h,p,vec3<f32>((xb.x+xb.y)*.5,a.y-.02,(front+back)*.5),vec3<f32>((xb.y-xb.x)*.5,.085,(back-front)*.5+.01),9u,s,c);}h=rail(h,p,vec3<f32>(xb.x,a.y,front+.04),vec3<f32>(xb.y,a.y,front+.04),s,c+10u);
 for(var edge=0u;edge<2u;edge++){let x=select(xb.x,xb.y,edge==1u);let outer=(cell==0u&&edge==0u)||(cell==2u&&edge==1u);let neighbour=select(select(cell-1u,cell+1u,edge==1u),cell,outer);var end=back;if(!outer){if(hasPlatform(s,neighbour)){end=platformFront(s,neighbour);if(end<=front+.001){continue;}}else{end=min(back,frontZ(s,neighbour));}}if(end>front+.045){h=rail(h,p,vec3<f32>(x,a.y,front+.04),vec3<f32>(x,a.y,end),s,c+20u+edge*4u);}}
 }return h;}
fn storey(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let c=rec(s,2u);let bid=u32(rec(s,3u).x);let halfW=a.z*.5;let middleZ=(b.x+b.y)*.5;let depth=(b.y-b.x)*.5;let fronts=rec(s,7u).xyz;let boundFront=min(b.x,min(fronts.x,min(fronts.y,fronts.z)))-1.25;let center=vec3<f32>(a.x,a.y+a.w*.5+.45,(boundFront+b.y+.1)*.5);let bound=boxD(p-center,vec3<f32>(halfW+.9,a.w*.5+.63,(b.y+.1-boundFront)*.5));if(bound>h.d+.024){return h;}if(bound>.22){return choose(h,bound-.06,0u,s,0u,p,vec3<f32>(0.,1.,0.));}
 let wall=.11;let q=p-center;let f=u32(c.w);let base=a.y;let top=base+a.w;let family=1000u+s*100u;
 // Main slab leaves a real alternating switchback stair opening next to the gap.
 let inner=select(a.x+halfW-1.90,a.x-halfW+1.90,bid==2u);let stairZ=2.4;let accessZ=.25;let slabQ=p-vec3<f32>(a.x,base-.08,middleZ);h=parcelSlabs(h,p,s,inner,stairZ);
 // Front and rear apertures programmeCode the actual storey footprint and programme.
 let cell=frontageCell(s,p.x);let fb=frontageBounds(s,cell);let pitch=fb.y-fb.x;let bx=(fb.x+fb.y)*.5;let ap=frontageAperture(s,cell);h=parcelFacade(h,p,s);h=frontageOpenings(h,p,s,family);
 let rq=p-vec3<f32>(a.x,base+a.w*.5,b.y);let rearHole=boxD(p-vec3<f32>(bx,base+1.55,b.y),vec3<f32>(pitch*.26,.58,.35));h=choose(h,max(boxD(rq,vec3<f32>(halfW,a.w*.5,wall)),-rearHole),1u,s,family+2u,rq,boxN(rq,vec3<f32>(halfW,a.w*.5,wall)));h=windowParts(h,p,vec3<f32>(bx,base+1.55,b.y),vec2<f32>(pitch*.26,.58),s,family+25u,false,false,false);
 h=householdFrontageShell(h,p,s);h=householdFrontageOpenings(h,p,s);
 // Both sides contain real windows and gap-side doors to shared landings.
 let signX=select(-1.,1.,p.x>a.x);let sideX=a.x+signX*halfW;let gapSide=(bid==1u&&signX>0.)||(bid==2u&&signX<0.);let sideFront=frontZ(s,select(0u,2u,signX>0.));let sideDepth=(b.y-sideFront)*.5;let sideMid=(b.y+sideFront)*.5;let sideCell=clamp(floor((p.z-sideFront)/2.5),0.,floor((b.y-sideFront)/2.5)-1.);let rawSZ=sideFront+(sideCell+.5)*2.5;let isDoor=gapSide&&(f==0u||s==3u||s==17u||s==7u||s==21u||s==10u||s==24u)&&abs(p.z-accessZ)<1.5;let sz=select(rawSZ,accessZ,isDoor);let sk=frontageType(s,min(u32(sideCell),2u));let sh=select(vec2<f32>(select(select(.45,.76,sk==2u),.34,sk==0u),select(.60,.30,sk==0u)),vec2<f32>(.48,1.02),isDoor);let sy=select(base+select(1.48,1.88,sk==0u),base+1.03,isDoor);let sideQ=p-vec3<f32>(sideX,base+a.w*.5,sideMid);let sideHole=boxD((p-vec3<f32>(sideX,sy,sz)).zyx,vec3<f32>(sh,.32));h=choose(h,max(boxD(sideQ,vec3<f32>(wall,a.w*.5,sideDepth)),-sideHole),1u,s,family+3u,sideQ,boxN(sideQ,vec3<f32>(wall,a.w*.5,sideDepth)));h=windowParts(h,p,vec3<f32>(sideX,sy,sz),sh,s,family+30u,true,isDoor,false);
 // Life split: side stair/service strip, small front work/sleep area, rear wet/storage.
 let partitionX=select(inner-1.12,inner+1.12,bid==2u);let coreFront=max(frontAt(s,partitionX-.075),frontAt(s,partitionX+.075))+.12;let coreBack=b.y-.12;let coreDepth=(coreBack-coreFront)*.5;let pq=p-vec3<f32>(partitionX,base+a.w*.5,(coreFront+coreBack)*.5);let pd=boxD(pq,vec3<f32>(.075,a.w*.5,coreDepth));let doorHole=boxD(p-vec3<f32>(partitionX,base+1.0,stairZ+select(-1.44,1.44,bid==2u)),vec3<f32>(.2,1.,.48));h=choose(h,max(pd,-doorHole),1u,s,family+4u,pq,boxN(pq,vec3<f32>(.075,a.w*.5,coreDepth)));let sepZ=select(2.9,3.55,b.z==0.||b.z==6.);let livingCX=a.x+select(-1.51,1.51,bid==2u);let livingHalf=(a.z-3.02)*.5;let wq=p-vec3<f32>(livingCX,base+a.w*.5,sepZ);let wetWall=boxD(wq,vec3<f32>(livingHalf,a.w*.5,.065));let wetDoor=boxD(p-vec3<f32>(partitionX+select(-.60,.60,bid==2u),base+.99,sepZ),vec3<f32>(.43,.99,.18));h=choose(h,max(wetWall,-wetDoor),1u,s,family+5u,wq,boxN(wq,vec3<f32>(livingHalf,a.w*.5,.065)));
 if(b.z==4.||b.z==5.||b.z==8.||b.z==9.||b.z==11.){let livingSide=select(1.,-1.,bid==2u);let splitX=a.x-livingSide*1.51;let partFront=max(b.x+.12,-2.0);let partRear=sepZ-.07;let partQ=p-vec3<f32>(splitX,base+a.w*.5,(partFront+partRear)*.5);let div=boxD(partQ,vec3<f32>(.065,a.w*.5,(partRear-partFront)*.5));let passageCut=boxD(p-vec3<f32>(splitX,base+1.,max(-.25,b.x+.70)),vec3<f32>(.18,1.,.42));h=choose(h,max(div,-passageCut),1u,s,family+7u,partQ,boxN(partQ,vec3<f32>(.065,a.w*.5,(partRear-partFront)*.5)));}
 // Two flights and a true half-height turning platform, with continuous handrail.
 let rev=bid==2u;let firstX=inner-.53;let secondX=inner+.53;h=stair(h,p,vec3<f32>(firstX,base,stairZ),a.w*.5,2.02,.98,s,700000u+s*100u,rev);h=stair(h,p,vec3<f32>(secondX,base+a.w*.5,stairZ),a.w*.5,2.02,.98,s,700030u+s*100u,!rev);let landingZ=stairZ+select(1.44,-1.44,rev);h=addBox(h,p,vec3<f32>(inner,base+a.w*.5-.08,landingZ),vec3<f32>(1.10,.08,.43),9u,s,family+70u);let turnGuardZ=landingZ+select(.40,-.40,rev);h=rail(h,p,vec3<f32>(inner-1.06,base+a.w*.5,turnGuardZ),vec3<f32>(inner+1.06,base+a.w*.5,turnGuardZ),s,family+72u);
 // Same handedness on successive floors: arrival and next departure share the unobstructed landing.
 let entryZ=stairZ+select(-1.44,1.44,rev);let outer=select(1.,-1.,bid==2u);h=addBox(h,p,vec3<f32>(inner,base-.08,entryZ),vec3<f32>(1.10,.08,.43),9u,s,family+190u);let entryGuardZ=entryZ+select(-.40,.40,rev);h=rail(h,p,vec3<f32>(inner-1.06,base,entryGuardZ),vec3<f32>(inner+1.06,base,entryGuardZ),s,family+192u);
 let guardX=inner+outer*1.10;let routeSign=select(1.,-1.,rev);h=rail(h,p,vec3<f32>(guardX,base,stairZ-1.01*routeSign),vec3<f32>(guardX,base,stairZ+2.15*routeSign),s,family+196u);h=rail(h,p,vec3<f32>(guardX,base,stairZ-2.15*routeSign),vec3<f32>(guardX,base,stairZ-1.87*routeSign),s,family+200u);h=rail(h,p,vec3<f32>(guardX,base+a.w*.5,landingZ-.43),vec3<f32>(guardX,base+a.w*.5,landingZ+.43),s,family+204u);
 // Shared balcony is only generated when a rent/addition event grants access.
 h=parcelPlatforms(h,p,s);
 h=frontageShelter(h,p,s);h=frontageDrying(h,p,s);
 h=householdFrontageExterior(h,p,s);
 // Joint-aligned water and drainage, not arbitrary noise streaks.
 let pipeX=a.x+halfW-.15;let pipeZ=frontZ(s,2u)-.14;let lowerZ=supportFrontZ(s,2u)-.14;h=addPipe(h,p,vec3<f32>(pipeX,base+.23,pipeZ),vec3<f32>(pipeX,top+.23,pipeZ),.047,s,family+90u);if(abs(lowerZ-pipeZ)>.001){h=addPipe(h,p,vec3<f32>(pipeX,base+.23,lowerZ),vec3<f32>(pipeX,base+.23,pipeZ),.047,s,family+93u);}h=addPipe(h,p,vec3<f32>(pipeX,base+.23,pipeZ),vec3<f32>(pipeX,base+.23,b.y),.025,s,family+91u);
 h=roomLife(h,p,s);h=householdFrontageLife(h,p,s);h=householdFrontageStorage(h,p,s);h=frontageDrainage(h,p,s);h=wetService(h,p,s);
 return h;}
fn roof(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let y=a.y+a.w;let mid=(b.x+b.y)*.5;let out=select(1.,-1.,rec(s,3u).x==2.);let inner=a.x+out*(a.z*.5-1.90);let rs=out;let ez=2.4-1.44*rs;let qf=p-vec3<f32>(a.x,y,mid);let slab=boxD(qf,vec3<f32>(a.z*.5,.10,(b.y-b.x)*.5));let hole=boxD(p-vec3<f32>(inner,y,2.4),vec3<f32>(1.10,.30,2.15));h=choose(h,max(slab,-hole),9u,s,900000u+s,qf,vec3<f32>(0.,1.,0.));h=addBox(h,p,vec3<f32>(inner,y+.02,ez),vec3<f32>(1.10,.08,.43),9u,s,920000u+s);
 for(var k=0u;k<2u;k++){let side=select(-1.,1.,k==1u);let x=inner+side*1.10;let c=921000u+s*100u+k*10u;h=rail(h,p,vec3<f32>(x,y+.1,2.4-2.15*rs),vec3<f32>(x,y+.1,2.4-1.87*rs),s,c);h=rail(h,p,vec3<f32>(x,y+.1,2.4-1.01*rs),vec3<f32>(x,y+.1,2.4+2.15*rs),s,c+3u);h=rail(h,p,vec3<f32>(inner-1.1,y+.1,2.4+side*2.15),vec3<f32>(inner+1.1,y+.1,2.4+side*2.15),s,c+6u);}
 h=rail(h,p,vec3<f32>(inner-1.1,y+.1,ez-.40*rs),vec3<f32>(inner+1.1,y+.1,ez-.40*rs),s,925000u+s*10u);h=rail(h,p,vec3<f32>(inner-1.1,y+.1,2.4-1.01*rs),vec3<f32>(inner,y+.1,2.4-1.01*rs),s,926000u+s*10u);
 let signX=select(-1.,1.,p.x>a.x);h=addBox(h,p,vec3<f32>(a.x+signX*(a.z*.5-.075),y+.60,mid),vec3<f32>(.075,.60,(b.y-b.x)*.5),1u,s,900010u+s);let signZ=select(b.x+.075,b.y-.075,p.z>mid);h=addBox(h,p,vec3<f32>(a.x,y+.60,signZ),vec3<f32>(a.z*.5,.60,.075),1u,s,900020u+s);
 let cc=vec3<f32>(a.x-out*1.51,y+2.50,mid+.15);h=canopy(h,p,cc,vec2<f32>(1.35,1.45),s,900030u+s);for(var k=0u;k<4u;k++){let dx=select(-1.25,1.25,(k&1u)>0u);let dz=select(-1.45,1.45,(k&2u)>0u);h=addPipe(h,p,vec3<f32>(cc.x+dx,y+.1,cc.z+dz),cc+vec3<f32>(dx,.18*dz,dz),.035,s,910000u+s*10u+k);}
 let q=p-vec3<f32>(a.x-out*3.6,y+.71,b.y-1.2);h=choose(h,max(length(q.xz)-.65,abs(q.y)-.61),3u,s,900040u+s,q,normalize(vec3<f32>(q.x,.15,q.z)));h=addPipe(h,p,vec3<f32>(a.x-out*2.4,y,b.x+.4),vec3<f32>(a.x-out*2.4,y+3.4,b.x+.4),.029,s,900050u+s);h=addPipe(h,p,vec3<f32>(a.x-out*2.4-.7,y+3.1,b.x+.4),vec3<f32>(a.x-out*2.4+.7,y+3.1,b.x+.4),.012,s,900052u+s);return h;}
fn borrowedStairs(h0:GeoHit,p:vec3<f32>,sa:u32,sb:u32,k:u32)->GeoHit{var h=h0;let a=rec(sa,0u);let b=rec(sb,0u);let xa=a.x+a.z*.5;let xb=b.x-b.z*.5;let z=.25;let landing=.48;let start=xa+landing;let end=xb-landing;let count=max(2u,u32(ceil(abs(b.y-a.y)/.18)));let rise=(b.y-a.y)/f32(count);let tread=(end-start)/f32(count-1u);let c=1960000u+k*100u;
 h=addBox(h,p,vec3<f32>(xa+(landing-.18)*.5,a.y-.09,z),vec3<f32>((landing+.18)*.5,.09,.58),9u,sa,c);h=addBox(h,p,vec3<f32>(xb-(landing-.18)*.5,b.y-.09,z),vec3<f32>((landing+.18)*.5,.09,.58),9u,sb,c+1u);
 for(var i=0u;i<count;i++){let level=a.y+f32(i+1u)*rise;let x=start+f32(i)*tread;let rh=vec3<f32>(.018,abs(rise)*.5+.07,.58);h=addBox(h,p,vec3<f32>(x,level-rise*.5-.07,z),rh,9u,sa,c+10u+i);if(i<count-1u){h=addBox(h,p,vec3<f32>(x+tread*.5,level-.07,z),vec3<f32>(tread*.5,.07,.58),9u,sa,c+20u+i);}}
 for(var side=0u;side<2u;side++){let zz=z+select(-.56,.56,side==1u);let id=c+40u+side*12u;h=rail(h,p,vec3<f32>(xa,a.y,zz),vec3<f32>(start,a.y,zz),sa,id);h=rail(h,p,vec3<f32>(start,a.y,zz),vec3<f32>(end,b.y,zz),sa,id+4u);h=rail(h,p,vec3<f32>(end,b.y,zz),vec3<f32>(xb,b.y,zz),sa,id+8u);}return h;}
// Three narrow linked leaves fold entirely over the level A platform.
fn borrowedGate(h0:GeoHit,p:vec3<f32>,sa:u32,k:u32,opened:bool)->GeoHit{var h=h0;let a=rec(sa,0u);let x=a.x+a.z*.5+.165;let c=1970000u+k*100u;let length=.72/3.;var hinge=vec3<f32>(x+.023,a.y,.70);
 for(var j=0u;j<3u;j++){let sign=select(1.,-1.,j==1u);let angle=select(0.,sign*1.50,opened);let sn=sin(angle);let cs=cos(angle);let normal=vec3<f32>(cs,0.,sn);let direction=vec3<f32>(sn,0.,-cs);let start=hinge-sign*.023*normal;let rel=p-(start+direction*length*.5+vec3<f32>(0.,.565,0.));let q=vec3<f32>(rel.x*cs+rel.z*sn,rel.y,rel.x*sn-rel.z*cs);let half=vec3<f32>(.023,.525,length*.5);let d=max(boxD(q,half),-boxD(q,vec3<f32>(.08,.455,length*.5-.03)));let n=boxN(q,half);h=choose(h,d,3u,sa,c+j,q,vec3<f32>(cs*n.x+sn*n.z,n.y,sn*n.x-cs*n.z));h=addPipe(h,p,hinge+vec3<f32>(0.,.06,0.),hinge+vec3<f32>(0.,1.08,0.),.009,sa,c+40u+j);hinge=start+direction*length-sign*.023*normal;}
 h=addPipe(h,p,hinge+vec3<f32>(0.,.06,0.),hinge+vec3<f32>(0.,1.08,0.),.009,sa,c+43u);
 // Fixed jamb posts stand on the same slab. Short guards close both side gaps.
 h=addPipe(h,p,vec3<f32>(x,a.y,.70),vec3<f32>(x,a.y+1.11,.70),.023,sa,c+10u);h=addPipe(h,p,vec3<f32>(x,a.y,-.02),vec3<f32>(x,a.y+1.11,-.02),.023,sa,c+11u);h=rail(h,p,vec3<f32>(x,a.y,-.31),vec3<f32>(x,a.y,-.02),sa,c+20u);h=rail(h,p,vec3<f32>(x,a.y,.70),vec3<f32>(x,a.y,.81),sa,c+30u);return h;}
fn querySettlement(p:vec3<f32>,maximum:f32)->GeoHit{var h=GeoHit(maximum,0u,0u,0u,0u,p,vec3<f32>(0.,1.,0.),0u);if(!excludedFieldObject(0u,0u)){h=GeoHit(min(maximum,p.y),6u,0u,0u,0u,p,vec3<f32>(0.,1.,0.),0u);}let storeyCount=arrayLength(&worldRules)/8u;for(var s=0u;s<storeyCount;s++){h=storey(h,p,s);}h=roof(h,p,13u);h=roof(h,p,26u);
 // Three explicitly negotiated borrowed connections. Differences are stepped,
 // never visually erased by forcing the two independently grown floors level.
 let connectionCount=min(3u,arrayLength(&worldRules)/72u);for(var k=0u;k<connectionCount;k++){let sa=array<u32,3>(3u,7u,10u)[k];let sb=array<u32,3>(17u,21u,24u)[k];let a=rec(sa,0u);let b=rec(sb,0u);let xa=a.x+a.z*.5;let xb=b.x-b.z*.5;let z=.25;let span=xb-xa;h=borrowedStairs(h,p,sa,sb,k);
 // Gate controller is a shared lease, with one time-dependent leaf in this world.
 let opened=u.size.z>=21600.&&u.size.z<79200.;h=borrowedGate(h,p,sa,k,opened);
 // Clothes hung between usable windows: the line has no navigation edge.
 let clothX=clamp(round((p.x-xa)/.58),0.,2.)*.58+xa+.22;let sag=.11*sin((clothX-xa)/max(span,.1)*3.14159265);let cq=p-vec3<f32>(clothX,min(a.y,b.y)+1.95-sag,z+1.);let fold=.045*sin(cq.x*20.)+.025*sin(cq.y*9.);h=choose(h,boxD(vec3<f32>(cq.x,cq.y,cq.z-fold),vec3<f32>(.22,.38,.018))*.88,7u,sa,950060u+k,cq.xzy,vec3<f32>(0.,0.,-1.));h=addPipe(h,p,vec3<f32>(xa,min(a.y,b.y)+2.4,z+1.),vec3<f32>(xb,min(a.y,b.y)+2.4,z+1.),.008,sa,950070u+k);}
 return h;}


// R3.12 family-0 original fitted edge waves, field and surface core.
// WGSL syntax/explicit arguments are new. No renderer, vertex or instance lists.
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }
fn br_h11(p:f32)->f32 {return fract(sin(p*127.1+311.7)*43758.5453123);}
fn br_hash31(pIn:vec3<f32>)->f32 {var p=fract(pIn*0.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn br_noise3(p:vec3<f32>)->f32 {let i=floor(p);var f=fract(p);f=f*f*(vec3<f32>(3.0)-2.0*f);return mix(mix(mix(br_hash31(i),br_hash31(i+vec3<f32>(1,0,0)),f.x),mix(br_hash31(i+vec3<f32>(0,1,0)),br_hash31(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(br_hash31(i+vec3<f32>(0,0,1)),br_hash31(i+vec3<f32>(1,0,1)),f.x),mix(br_hash31(i+vec3<f32>(0,1,1)),br_hash31(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn br_fbm(pIn:vec3<f32>)->f32 {var p=pIn;var s=0.0;var a=0.5;for(var i=0;i<5;i++){s+=a*br_noise3(p);p=p*2.03+vec3<f32>(7.1,-3.7,11.9);a*=0.5;}return s;}








































// Return original [chips, contour, weight] contributions instead of GLSL inout.




fn br_variant(qIn:vec3<f32>,variant:i32)->vec3<f32>{var q=qIn;if((variant&1)==1){q.x=-q.x;}if((variant&2)==2){q.z=-q.z;}return q;}
// Exact original family-0 distance, in metres. This is not guaranteed Lipschitz 1.0


fn br_xi(q:vec3<f32>)->vec3<f32>{let rr=max(length(q),1e-4);let cap=0.13*9.5;let radial2=dot(q.xy,q.xy);let angularRadius=sqrt(radial2+cap*cap*exp(-radial2/(cap*cap)));let angle=acos(clamp(q.y/angularRadius,-0.999999,0.999999));return vec3<f32>(log2(rr)-2.0,-q.z/rr-1.0,angle);}
// New explicit isotropic footprint bridge. Original wave, 17 octaves and gates
// remain; the original screen dFdx/dFdy footprint is NOT claimed equivalent.
fn br_microscope(q:vec3<f32>,qFootprint:f32)->f32 {
 let xi=br_xi(q);let e=max(qFootprint,1e-7);
 let fp=max(length(br_xi(q+vec3<f32>(e,0,0))-xi),max(length(br_xi(q+vec3<f32>(0,e,0))-xi),length(br_xi(q+vec3<f32>(0,0,e))-xi)));
 var s=0.0;var sc=1.0;for(var j=0;j<17;j++){if(fp*sc>=1.10){break;}let gate=1.0-smoothstep(0.48,1.10,fp*sc);let x=xi*sc;s+=gate*(cos(cos(x.z)*cos(x.x)+cos(x.y)*cos(x.y)+cos(x.y)*cos(x.x))-0.6556965)/sc;sc*=2.0;}return s;
}
// Raw original family-0 albedo, roughness and height. No lighting/tone mapping.
fn kpBrickOriginalSurface(pLocalM:vec3<f32>,seed:f32,variant:i32,variation:f32,physicalFootprintM:f32)->KpSurface {
 let r0=br_h11(seed+1.2);let r1=br_h11(seed+2.7);let r2=br_h11(seed+4.9);let r3=br_h11(seed+8.3);
 var q=br_variant(pLocalM/KP_BRICK_SCALE,variant);let ang=(r0-0.5)*2.2*variation;let ca=cos(ang);let sa=sin(ang);
 let oldXZ=q.xz;q.x=ca*oldXZ.x+sa*oldXZ.y;q.z=-sa*oldXZ.x+ca*oldXZ.y;
 q+=variation*vec3<f32>((r1-0.5)*18.0,(r2-0.5)*12.0,(r3-0.5)*16.0);
 let body=br_fbm(q*1.15+vec3<f32>(-2.7,4.1,8.3));let fire=br_fbm(q*2.65+vec3<f32>(7.1,-5.2,1.7));let firing=smoothstep(0.27,0.79,0.66*body+0.34*fire);
 let reduction=smoothstep(0.69,0.88,br_fbm(q*0.82+vec3<f32>(12.1,1.4,-9.7)))*smoothstep(0.38,0.82,firing);
 let poreA=br_noise3(q*29.7+vec3<f32>(2.3,9.1,-4.4));let poreB=br_noise3(q*61.3+vec3<f32>(-7.2,3.7,14.6));let pore=smoothstep(0.79,0.92,poreA)*smoothstep(0.64,0.84,poreB);
 let skin=smoothstep(0.36,0.76,br_fbm(q*5.1+vec3<f32>(1.9,-3.2,11.4)));let mm=br_microscope(q*9.5,max(physicalFootprintM,0.0)/KP_BRICK_SCALE*9.5);
 var base=mix(vec3<f32>(0.235,0.043,0.023),vec3<f32>(0.455,0.105,0.048),smoothstep(0.14,0.76,firing));base=mix(base,vec3<f32>(0.625,0.205,0.082),smoothstep(0.58,0.92,firing)*0.34);base=mix(base,vec3<f32>(0.19,0.055,0.038),reduction*0.63);
 let rough=clamp(0.90-0.10*firing+0.055*reduction+0.075*pore,0.68,0.985);
 let h=(body-0.5)*0.010+(skin-0.5)*0.004+mm*0.0034-pore*0.0048;
 base*=0.965+0.07*(skin-0.5);base*=mix(1.0,0.93+0.14*br_h11(seed+19.7),variation);
 return KpSurface(h*KP_BRICK_SCALE,base,rough);
}

// R3.12 original macro/micro/observed field algebra. Explicit coordinates and
// derivative-free physical footprint are receiver bridges. No patch silhouette.
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}
fn pl_rotate(v:vec3<f32>,axis:vec3<f32>,a:f32)->vec3<f32>{let c=cos(a);let s=sin(a);return v*c+cross(axis,v)*s+axis*dot(axis,v)*(1.0-c);}
fn pl_warp(p:vec3<f32>,phase:vec3<f32>)->vec3<f32>{let c1=vec3<f32>(0.12,1.42,0.04)+0.035*phase;let a1=normalize(vec3<f32>(0.38,0.82,0.42));let v1=p-c1;let t1=0.65*exp(-dot(v1,v1)/(2.4*2.4))*sin(1.45*dot(a1,v1)+0.7+phase.x);let q=c1+pl_rotate(v1,a1,t1);let c2=vec3<f32>(-0.16,1.63,-0.06)+0.025*phase;let a2=normalize(vec3<f32>(-0.67,0.15,0.73));let v2=q-c2;let t2=0.20*exp(-dot(v2,v2)/(2.1*2.1))*sin(4.1*dot(a2,v2)+2.0+phase.y);return c2+pl_rotate(v2,a2,t2);}
fn pl_xi(p:vec3<f32>,phase:vec3<f32>)->vec3<f32>{let q=pl_warp(p,phase)+vec3<f32>(2.73,0.91,1.37);let r=max(length(q),1e-4);return vec3<f32>(log2(r)-2.0,-q.z/r,atan2(q.x,q.y));}
fn pl_cell(xi:vec3<f32>,sc:f32)->f32{let a=cos(sc*xi.z)*cos(sc*xi.x)+cos(sc*xi.y)*cos(sc*xi.y)+cos(sc*xi.y)*cos(sc*xi.x);return cos(a)-0.6556965458313674;}
fn pl_macroFast(p:vec3<f32>)->f32{let xi=pl_xi(p,vec3<f32>(0.7,-1.3,2.1));let s=pl_cell(xi,1.0)+pl_cell(xi,2.0)*0.5+pl_cell(xi,4.0)*0.25+pl_cell(xi,8.0)*0.125+pl_cell(xi,16.0)*0.0625;return tanh(0.78*s);}
fn pl_microFast(p:vec3<f32>)->f32{let xi=pl_xi(p,vec3<f32>(0.7,-1.3,2.1));let s=pl_cell(xi,16.0)*0.0625+pl_cell(xi,32.0)*0.03125+pl_cell(xi,64.0)*0.015625;return tanh(10.5*s);}
fn pl_q(p:vec3<f32>,a:KpPlasterParams)->vec3<f32>{return vec3<f32>((p.xy-a.centerM)/max(a.halfM,vec2<f32>(0.08)),p.z*2.0);}
fn kpPlasterMacro(p:vec3<f32>,a:KpPlasterParams)->f32{let low=pl_macroFast(pl_q(p,a)+vec3<f32>(-0.17,0.31,0.09));let coarse=sin(p.x*2.7+p.y*0.9)*sin(p.y*3.2-p.x*0.7);return clamp(0.48*low+0.52*coarse,-1.0,1.0);}
fn kpPlasterMicro(p:vec3<f32>,a:KpPlasterParams)->f32{let m=pl_microFast(pl_q(p,a)*vec3<f32>(2.65,2.52,3.55)+vec3<f32>(-0.27,0.44,-0.19));let r=sin(p.x*47.0-p.y*39.0+p.z*58.0)*sin(p.x*31.0+p.y*37.0-p.z*43.0);return clamp(0.78*m+0.22*r,-1.0,1.0);}
fn pl_observed(p:vec3<f32>,a:KpPlasterParams,physicalFootprintM:f32)->f32{
 let q=pl_q(p,a);let phase=vec3<f32>(-1.3,4.7,2.2);let xi=pl_xi(q,phase);
 let e=max(physicalFootprintM,1e-7);let dq=vec3<f32>(e/max(a.halfM.x,0.08),e/max(a.halfM.y,0.08),e*2.0);
 let fp=max(length(pl_xi(q+vec3<f32>(dq.x,0,0),phase)-xi),max(length(pl_xi(q+vec3<f32>(0,dq.y,0),phase)-xi),length(pl_xi(q+vec3<f32>(0,0,dq.z),phase)-xi)));
 var sum=0.0;var sc=1.0;for(var i=0;i<17;i++){if(fp*sc>=1.12){break;}let gate=1.0-smoothstep(0.44,1.12,fp*sc);sum+=gate*pl_cell(xi,sc)/sc;sc*=2.0;}return tanh(0.86*sum);
}
fn kpPlasterOriginalField(pLocalM:vec3<f32>,a:KpPlasterParams,physicalFootprintM:f32)->KpPlasterField{
 let pm=kpPlasterMacro(pLocalM,a);let pu=kpPlasterMicro(pLocalM,a);let obs=pl_observed(pLocalM,a,physicalFootprintM);
 // Existing metric-grain correction: same direction, explicit metre period.
 let wave=max(a.grainWavelengthM,0.0003);let phase=dot(pLocalM,normalize(vec3<f32>(83.0,-61.0,97.0)))*(6.283185307179586/wave);
 let grain=sin(phase)*(1.0-smoothstep(0.35,0.90,physicalFootprintM/wave));
 let microGate=1.0-smoothstep(0.008,0.020,physicalFootprintM);
 let h=microGate*a.microM*(0.26*obs+0.18*pu)+a.grainHeightM*grain;
 let base=mix(a.paletteDark,a.paletteLight,0.58+0.08*obs+0.22*pm)*(0.94+a.grainColor*grain);
 let rough=clamp(0.95+0.032*(-obs),0.86,0.997);
 let thickness=clamp(a.thicknessM+a.reliefM*pm+a.geometryMicroM*pu,a.minThicknessM,a.maxThicknessM);
 return KpPlasterField(pm,pu,thickness,KpSurface(h,base,rough));
}

// Syntax port of locked V26 waterWeatherMasks dependency closure.
// pField is the ORIGINAL normalized material field coordinate, not metres.
// localPosM/dimensionsM are original physical local position/size for gates.
fn vw_hash31(pIn:vec3<f32>)->f32 {var p=fract(pIn*0.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn vw_hash33(pIn:vec3<f32>)->vec3<f32> {let p=vec3<f32>(dot(pIn,vec3<f32>(127.1,311.7,74.7)),dot(pIn,vec3<f32>(269.5,183.3,246.1)),dot(pIn,vec3<f32>(113.5,271.9,124.6)));return fract(sin(p)*43758.5453123);}
fn vw_fade(f:vec3<f32>)->vec3<f32>{return f*f*f*(f*(f*6.0-vec3<f32>(15.0))+vec3<f32>(10.0));}
fn vw_valueNoise3(p:vec3<f32>)->f32 {let i=floor(p);let f=vw_fade(fract(p));return mix(mix(mix(vw_hash31(i),vw_hash31(i+vec3<f32>(1,0,0)),f.x),mix(vw_hash31(i+vec3<f32>(0,1,0)),vw_hash31(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(vw_hash31(i+vec3<f32>(0,0,1)),vw_hash31(i+vec3<f32>(1,0,1)),f.x),mix(vw_hash31(i+vec3<f32>(0,1,1)),vw_hash31(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn vw_gcorner(i:vec3<f32>,f:vec3<f32>,o:vec3<f32>)->f32{return dot(normalize(vw_hash33(i+o)*2.0-vec3<f32>(1.0)),f-o);}
fn vw_gradientNoise3(p:vec3<f32>)->f32 {let i=floor(p);let f=fract(p);let u=vw_fade(f);let n=mix(mix(mix(vw_gcorner(i,f,vec3<f32>(0,0,0)),vw_gcorner(i,f,vec3<f32>(1,0,0)),u.x),mix(vw_gcorner(i,f,vec3<f32>(0,1,0)),vw_gcorner(i,f,vec3<f32>(1,1,0)),u.x),u.y),mix(mix(vw_gcorner(i,f,vec3<f32>(0,0,1)),vw_gcorner(i,f,vec3<f32>(1,0,1)),u.x),mix(vw_gcorner(i,f,vec3<f32>(0,1,1)),vw_gcorner(i,f,vec3<f32>(1,1,1)),u.x),u.y),u.z);return n*0.5+0.5;}
fn vw_fbmGradient(pIn:vec3<f32>)->f32 {var p=pIn;var v=0.0;var a=0.52;var total=0.0;for(var i=0;i<5;i++){v+=vw_gradientNoise3(p)*a;total+=a;p=p*2.03+vec3<f32>(19.1,7.7,13.4);a*=0.49;}return v/total;}
fn vw_ridgedFbm(pIn:vec3<f32>)->f32 {var p=pIn;var v=0.0;var a=0.56;var total=0.0;for(var i=0;i<5;i++){let n=1.0-abs(vw_gradientNoise3(p)*2.0-1.0);v+=n*n*a;total+=a;p=p*2.11+vec3<f32>(11.7,5.3,17.9);a*=0.47;}return v/total;}
fn vw_fbmValueFast(pIn:vec3<f32>)->f32 {var p=pIn;var v=0.0;var a=0.54;var total=0.0;for(var i=0;i<4;i++){v+=vw_valueNoise3(p)*a;total+=a;p=p*2.05+vec3<f32>(7.3,15.1,3.9);a*=0.48;}return v/total;}
fn vw_domainWarp(p:vec3<f32>)->vec3<f32>{return vec3<f32>(vw_fbmValueFast(p+vec3<f32>(17.1,3.8,9.2)),vw_fbmValueFast(p+vec3<f32>(4.4,19.7,12.1)),vw_fbmValueFast(p+vec3<f32>(13.8,7.2,23.4)))-vec3<f32>(0.5);}
fn vw_seedVector(s:f32,multiplier:f32)->vec3<f32>{return vec3<f32>(s*0.0113,s*0.0197,s*0.0311)*multiplier;}
fn kpV26WaterWeather(pField:vec3<f32>,n:vec3<f32>,localPosM:vec3<f32>,dimensionsM:vec3<f32>,waterSeed:f32,weatherSeed:f32)->vec2<f32>{
 let p=pField;let an=abs(n);let horizontal=select(p.x,p.z,an.x>an.z);let yNorm=clamp(localPosM.y/max(dimensionsM.y,0.001)+0.5,0.0,1.0);
 let column=horizontal*5.4+waterSeed*0.0031;let columnId=floor(column);let local=fract(column)-0.5;
 let jitter=(vw_hash31(vec3<f32>(columnId,waterSeed*0.013,7.0))-0.5)*0.56;
 let width=mix(0.045,0.16,vw_hash31(vec3<f32>(columnId,waterSeed*0.019,13.0)));
 let line=1.0-smoothstep(width,width+0.055,abs(local-jitter));
 let start=mix(0.52,1.02,vw_hash31(vec3<f32>(columnId,waterSeed*0.023,19.0)));
 let lengthV=mix(0.16,0.78,vw_hash31(vec3<f32>(columnId,waterSeed*0.029,23.0)));
 let verticalGate=smoothstep(start-lengthV-0.05,start-lengthV+0.055,yNorm)*(1.0-smoothstep(start-0.025,start+0.045,yNorm));
 let streakGate=smoothstep(0.48,0.86,vw_hash31(vec3<f32>(columnId,waterSeed*0.037,31.0)));let streak=line*verticalGate*streakGate;
 let waterCoord=vec3<f32>(horizontal*1.75,yNorm*3.0,waterSeed*0.009);
 let broad=smoothstep(0.54,0.82,vw_fbmValueFast(waterCoord+vw_domainWarp(waterCoord*0.7)*0.45));
 let lowerDamp=(1.0-smoothstep(0.06,0.34,yNorm))*smoothstep(0.35,0.78,vw_fbmValueFast(vec3<f32>(p.x*1.3,p.z*1.3,waterSeed*0.011)));
 let waterMask=clamp(streak*0.92+broad*verticalGate*0.32+lowerDamp*0.58,0.0,1.0);
 let edgeCoord=abs(localPosM)/max(dimensionsM*0.5,vec3<f32>(0.001));let edgeCount=smoothstep(0.72,0.99,edgeCoord.x)+smoothstep(0.72,0.99,edgeCoord.y)+smoothstep(0.72,0.99,edgeCoord.z);
 let edgeMask=smoothstep(1.08,1.88,edgeCount);let topExposure=smoothstep(0.05,0.72,n.y)*smoothstep(0.35,0.98,yNorm);
 let weatherNoise=vw_fbmGradient(p*1.82+vw_seedVector(weatherSeed,0.74));let weatherFine=vw_ridgedFbm(p*7.1+vw_seedVector(weatherSeed,1.31));
 let weatherMask=clamp((edgeMask*0.72+topExposure*0.55)*smoothstep(0.30,0.84,weatherNoise)+smoothstep(0.76,0.96,weatherFine)*0.18,0.0,1.0);
 return vec2<f32>(waterMask,weatherMask);
}
// Existing explicitly authored unified fabric bridge, not source physical years.
struct KpFabricState { moisture:f32, damage:f32, retention:f32, thicknessM:f32, baseScale:f32, roughDelta:f32, }
fn kpFabricState(age:f32,exposure:f32,sourceRunoff:f32,originalWeather:f32,drainage:f32,repair:f32,originalMacro:f32,originalMicro:f32,originalThicknessM:f32,minThicknessM:f32,maxThicknessM:f32)->KpFabricState {
 let a=clamp(age,0.0,1.0);let e=clamp(exposure,0.0,1.0);let r=clamp(repair,0.0,1.0);
 let moisture=clamp(sourceRunoff,0.0,1.0)*e*(1.0-clamp(drainage,0.0,1.0));
 let damage=clamp(a*(0.24+0.38*e+0.58*moisture+0.32*originalWeather*e)*(1.0-r),0.0,1.0);
 let bond=clamp(0.47+0.32*originalMacro+0.07*originalMicro,0.20,0.80);
 let thickness=clamp(originalThicknessM*(1.0-0.48*damage)+0.002*r,minThicknessM,maxThicknessM);
 return KpFabricState(moisture,damage,bond-damage,thickness,1.0-0.22*moisture-0.12*damage,0.035*damage-0.16*moisture);
}

// Apply the exact same resolved state used by receiver coat retention/thickness.
// Requires KpSurface from brick-core. No second independently computed age.
fn kpApplyFabricSurface(original:KpSurface,state:KpFabricState)->KpSurface {
 return KpSurface(original.height,original.albedo*state.baseScale,clamp(original.roughness+state.roughDelta,0.08,0.995));
}

// User Library timber v3, exact box coordinate/noise/field formulas in WGSL.
// KpSurface must be declared by the parent brick module before this string.
// No bindings, stages, renderer, textures, geometry buffers or scene objects.
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}
fn kpWoodDefaultParams()->KpWoodParams {
  var p:KpWoodParams;
  p.seed=0.7598925376683223;
  p.ringFrequency=22.0;
  p.ringScale=1.1240120360301806;
  p.ringWarp=1.174825141889602;
  p.fiberFrequency=8.73036012029089;
  p.fineFiberFrequency=72.0;
  p.poreFrequency=280.0;
  p.fiberStrength=0.34;
  p.colorBias=-0.015293409994337707;
  p.roughness=0.892843876922503;
  p.angleOffset=0.7194436165372647;
  p.textureScale=1.0;
  p.grainContrast=0.20902697160467504;
  p.detailFineness=1.0188769673019646;
  p.microReliefM=0.00028000000000000003;
  p.parallaxM=0.0010500000000000002;
  p.macroDisplacementM=0.0005600000000000001;
  p.reliefScale=0.7741619322448968;
  p.reliefQuality=3.0;
  p.parallaxSteps=12.0;
  p.clearcoat=0.0;
  p.clearcoatRoughness=1.0;
  p.specularLevel=0.13;
  p.distanceFadeStart=9.0;
  p.distanceFadeEnd=28.0;
  p.toolPhase=0.2499335163798811;
  p.crackPhase=1.1871775190974605;
  p.knotPhase=1.4286763223548267;
  p.pithOffset=vec2<f32>(0.04244730153121054,-0.07805894820950925);
  p.darkGrainColor=vec3<f32>(0.10224173308810132,0.06480326669290577,0.04091519690685319);
  p.lightGrainColor=vec3<f32>(0.31398871337571754,0.1946178304415758,0.11443537382697373);
  p.agedSurfaceColor=vec3<f32>(0.18782077230067787,0.13563332965520566,0.09758734714186246);
  p.weatheredColor=vec3<f32>(0.23455058216100522,0.21586050011389926,0.18782077230067787);
  p.freshCutColor=vec3<f32>(0.39157247774972326,0.26225065752969623,0.162029375639111);
  p.cavityColor=vec3<f32>(0.04091519690685319,0.027320891639074894,0.0202885630566524);
  return p;
}
fn kwSaturate(value:f32, wp:KpWoodParams, fp:f32)->f32 { return clamp(value, 0.0, 1.0); }

fn kwHash31(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  p = fract(p * 0.1031 + wp.seed * vec3<f32>(13.71, 47.13, 91.77));
  p += vec3<f32>(dot(p, p.yzx + vec3<f32>(33.33)));
  return fract((p.x + p.y) * p.z);
}

fn kwValueNoise(p:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var i:vec3<f32> = floor(p);
  var f:vec3<f32> = fract(p);
  f = f * f * (vec3<f32>(3.0) - 2.0 * f);
  return mix(
    mix(mix(kwHash31(i + vec3<f32>(0,0,0), wp, fp), kwHash31(i + vec3<f32>(1,0,0), wp, fp), f.x),
        mix(kwHash31(i + vec3<f32>(0,1,0), wp, fp), kwHash31(i + vec3<f32>(1,1,0), wp, fp), f.x), f.y),
    mix(mix(kwHash31(i + vec3<f32>(0,0,1), wp, fp), kwHash31(i + vec3<f32>(1,0,1), wp, fp), f.x),
        mix(kwHash31(i + vec3<f32>(0,1,1), wp, fp), kwHash31(i + vec3<f32>(1,1,1), wp, fp), f.x), f.y),
    f.z
  );
}

fn kwFbm(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  var result:f32 = 0.0;
  var amplitude:f32 = 0.5;
  var rotation:mat3x3<f32> = mat3x3<f32>(vec3<f32>(0.00,0.80,0.60),vec3<f32>(-0.80,0.36,-0.48),vec3<f32>(-0.60,-0.48,0.64));
  for (var i = 0; i < 5; i++) {
    result += amplitude * kwValueNoise(p, wp, fp);
    p = rotation * p * 2.03 + vec3<f32>(7.1, 3.7, 5.9);
    amplitude *= 0.5;
  }
  return result;
}

fn kwAaSine(coordinate:f32, wp:KpWoodParams, fp:f32)->f32 {
  var footprint:f32 = fp;
  var attenuation:f32 = 1.0 - smoothstep(0.42, 1.15, footprint);
  return 0.5 + 0.5 * sin(KP_WOOD_TAU * coordinate) * attenuation;
}

fn kwAaThinLine(coordinate:f32, width:f32, wp:KpWoodParams, fp:f32)->f32 {
  var distanceToLine:f32 = abs(sin(KP_WOOD_PI * coordinate));
  var footprint:f32 = min(0.22, fp * 0.75);
  return 1.0 - smoothstep(width + footprint, width + 0.085 + footprint, distanceToLine);
}

fn kwFlatAcross(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return select(g.y, g.z, abs(localNormal.y) > abs(localNormal.z));
}

fn kwFlatDepth(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return select(g.z, g.y, abs(localNormal.y) > abs(localNormal.z));
}

fn kwSidePhase(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, multiplier:f32, wp:KpWoodParams, fp:f32)->f32 {
  return kwFlatAcross(g, localNormal, wp, fp) * wp.fiberFrequency * multiplier;
}

fn kwSideAnisotropicNoise(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, axialFrequency:f32, crossFrequency:f32, phase:f32, wp:KpWoodParams, fp:f32)->f32 {
  var planarAcross:f32 = kwFlatAcross(g, localNormal, wp, fp);
  var planarDepth:f32 = kwFlatDepth(g, localNormal, wp, fp);
  var planarCoordinate:vec3<f32> = vec3<f32>(
    g.x * axialFrequency + phase,
    planarAcross * crossFrequency + wp.seed * 4.7,
    planarDepth * 0.72 + wp.seed * 9.1
  );
  return kwFbm(planarCoordinate, wp, fp);
}

fn kwSideValueNoise(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, axialFrequency:f32, crossFrequency:f32, phase:f32, wp:KpWoodParams, fp:f32)->f32 {
  var planarAcross:f32 = kwFlatAcross(g, localNormal, wp, fp);
  var planarDepth:f32 = kwFlatDepth(g, localNormal, wp, fp);
  var planarCoordinate:vec3<f32> = vec3<f32>(
    g.x * axialFrequency + phase,
    planarAcross * crossFrequency + wp.seed * 6.3,
    planarDepth * 0.54 + wp.seed * 3.8
  );
  return kwValueNoise(planarCoordinate, wp, fp);
}

fn kwRidgeFromNoise(value:f32, wp:KpWoodParams, fp:f32)->f32 {
  return 1.0 - abs(value * 2.0 - 1.0);
}

fn kwKnotSignal(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var broad:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    0.34,
    1.35,
    wp.knotPhase + 8.0
  , wp, fp);
  var compact:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    0.72,
    2.25,
    wp.knotPhase * 0.37 + 17.0
  , wp, fp);
  return smoothstep(0.71, 0.91, broad) * smoothstep(0.58, 0.86, compact);
}

fn kwWoodSignals(g:vec3<f32>, localNormal:vec3<f32>, surfaceClass:f32, wp:KpWoodParams, fp:f32)->vec4<f32> {
  var crossSection:f32 = step(0.72, abs(localNormal.x));

  var driftY:f32 = kwFbm(vec3<f32>(g.x * 0.24 + wp.seed * 3.1, 1.17, 7.93), wp, fp) - 0.5;
  var driftZ:f32 = kwFbm(vec3<f32>(g.x * 0.21 - wp.seed * 4.7, 9.31, 2.41), wp, fp) - 0.5;
  var longWarp:vec2<f32> = vec2<f32>(driftY, driftZ) * wp.ringWarp * 0.115;
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset + longWarp;
  var theta:f32 = atan2(crossPosition.y, crossPosition.x);

  var oval:f32 = 0.075 * sin(wp.seed * 31.0 + wp.angleOffset);
  var ringPosition:vec2<f32> = crossPosition * vec2<f32>(1.0 + oval, 1.0 - oval);
  var radial:f32 = length(ringPosition);
  var ringNoise:f32 = kwFbm(vec3<f32>(
    g.x * 0.18 + wp.seed * 2.4,
    ringPosition.x * 2.2,
    ringPosition.y * 2.2
  ), wp, fp);
  var ringCoordinate:f32 = radial * wp.ringFrequency * wp.ringScale;
  ringCoordinate += (ringNoise - 0.5) * wp.ringWarp * 1.18;
  ringCoordinate += sin(theta * 2.0 + wp.seed * 13.0) * 0.12 * wp.ringWarp;
  ringCoordinate += sin(theta * 5.0 - wp.seed * 7.0) * 0.045 * wp.ringWarp;
  var ringLine:f32 = kwAaThinLine(ringCoordinate, 0.060, wp, fp);
  var ringBody:f32 = kwAaSine(ringCoordinate + (ringNoise - 0.5) * 0.16, wp, fp);
  var ring:f32 = kwSaturate(ringBody * 0.62 + ringLine * 0.38, wp, fp);

  var broad:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.18, 1.55, wp.angleOffset, wp, fp);
  var flow:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.42, 3.35, wp.seed * 11.0 + 2.4, wp, fp);
  var medium:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.88, 7.20, wp.seed * 17.0 + 4.7, wp, fp);
  var knot:f32 = kwKnotSignal(g, crossPosition, localNormal, wp, fp);

  var phaseWarp:f32 = (broad - 0.5) * 5.4 + (flow - 0.5) * 2.9;
  phaseWarp += sin(g.x * 0.58 + theta * 1.7 + wp.seed * 19.0) * 0.50;
  phaseWarp += knot * (4.0 + 1.6 * sin(g.x * 1.05 + wp.knotPhase));

  var coarseLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.58, wp, fp) + phaseWarp + wp.angleOffset / KP_WOOD_TAU,
    0.065
  , wp, fp);
  var coarseVein:f32 = kwRidgeFromNoise(flow, wp, fp);
  var coarseFiber:f32 = kwSaturate(
    broad * 0.47 +
    coarseVein * 0.31 +
    coarseLine * 0.22
  , wp, fp);

  var mediumLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 1.85, wp, fp) + phaseWarp * 1.72 + wp.seed * 7.0,
    0.040
  , wp, fp);
  var mediumFiber:f32 = kwSaturate(
    medium * 0.47 +
    kwRidgeFromNoise(flow * 0.62 + medium * 0.38, wp, fp) * 0.37 +
    mediumLine * 0.16
  , wp, fp);

  var crackGate:f32 = smoothstep(
    0.79,
    0.94,
    kwSideValueNoise(g, crossPosition, localNormal, 0.32, 3.1, wp.crackPhase + 13.0, wp, fp)
  );
  var sideCrack:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.17, wp, fp)
      + phaseWarp * 0.16
      + wp.crackPhase / KP_WOOD_TAU,
    0.014
  , wp, fp) * crackGate;
  var radialGate:f32 = smoothstep(
    0.72,
    0.93,
    kwValueNoise(vec3<f32>(radial * 1.9, g.x * 0.27, wp.seed * 9.0), wp, fp)
  );
  var radialCrack:f32 = pow(max(0.0, sin(theta * 7.0 + wp.crackPhase)), 26.0)
    * smoothstep(0.08, 0.27, radial)
    * radialGate;
  var cracks:f32 = mix(sideCrack, max(sideCrack * 0.12, radialCrack), crossSection);

  return vec4<f32>(ring, coarseFiber, mediumFiber, cracks);
}

fn kwSecondarySignals(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->vec4<f32> {
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
  var broadWarp:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    0.46,
    4.4,
    wp.seed * 21.0 + 1.7
  , wp, fp);
  var fineNoise:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    1.55,
    18.0 * max(wp.detailFineness, 0.45),
    wp.seed * 29.0 + 5.3
  , wp, fp);
  var fineLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 4.6 * max(wp.detailFineness, 0.45), wp, fp)
      + (broadWarp - 0.5) * 8.5
      + wp.seed * 19.0,
    0.026
  , wp, fp);
  var fineFiber:f32 = kwSaturate(
    fineNoise * 0.53 +
    kwRidgeFromNoise(fineNoise, wp, fp) * 0.30 +
    fineLine * 0.17
  , wp, fp);

  var poreNoise:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    4.2 * max(wp.detailFineness, 0.45),
    38.0 * max(wp.detailFineness, 0.45),
    wp.seed * 23.0 + 11.0
  , wp, fp);
  var poreGate:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    0.85,
    7.0,
    wp.seed * 31.0 + 2.0
  , wp, fp);
  var pores:f32 = smoothstep(0.865, 0.982, poreNoise)
    * smoothstep(0.52, 0.82, poreGate);

  var toolWave:f32 = kwAaSine(g.x * 1.45 + kwFlatAcross(g, localNormal, wp, fp) * 0.22 + wp.toolPhase / KP_WOOD_TAU, wp, fp);
  var toolMask:f32 = smoothstep(
    0.79,
    0.96,
    kwSideValueNoise(g, crossPosition, localNormal, 0.54, 2.3, wp.toolPhase + 5.0, wp, fp)
  );
  var tool:f32 = toolWave * toolMask;

  var knot:f32 = kwKnotSignal(g, crossPosition, localNormal, wp, fp);
  return vec4<f32>(fineFiber, pores, tool, knot);
}

fn kwMacroSignal(g:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return kwFbm(g * vec3<f32>(0.12, 0.70, 0.70) + vec3<f32>(wp.seed * 5.0), wp, fp);
}

fn kwCoarseRelief(g:vec3<f32>, localNormal:vec3<f32>, surfaceClass:f32, wp:KpWoodParams, fp:f32)->f32 {
  var crossSection:f32 = step(0.72, abs(localNormal.x));
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
  var theta:f32 = atan2(crossPosition.y, crossPosition.x);
  var radial:f32 = length(crossPosition);

  var broadWarp:f32 = kwValueNoise(vec3<f32>(g.x * 0.18, crossPosition * 2.4) + vec3<f32>(wp.seed * 3.1), wp, fp);
  var sideBand:f32 = kwAaSine(
    kwSidePhase(g, crossPosition, localNormal, 0.62, wp, fp)
    + (broadWarp - 0.5) * 3.2
    + wp.angleOffset / KP_WOOD_TAU
  , wp, fp);
  var ringBand:f32 = kwAaSine(
    radial * wp.ringFrequency * wp.ringScale
    + (broadWarp - 0.5) * wp.ringWarp * 0.55
  , wp, fp);
  var sparseGate:f32 = smoothstep(
    0.84,
    0.965,
    kwValueNoise(vec3<f32>(g.x * 0.31 + wp.crackPhase, crossPosition * 4.1), wp, fp)
  );
  var sideCrack:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.20, wp, fp)
    + (broadWarp - 0.5) * 0.22
    + wp.crackPhase / KP_WOOD_TAU,
    0.015
  , wp, fp) * sparseGate;
  var radialCrack:f32 = pow(max(0.0, sin(theta * 7.0 + wp.crackPhase)), 24.0)
    * smoothstep(0.08, 0.28, radial)
    * sparseGate;

  var sideHeight:f32 = (sideBand - 0.5) * 0.36 - sideCrack * 0.60;
  var endHeight:f32 = (ringBand - 0.5) * 0.34 - radialCrack * 0.68;
  return kwSaturate(0.5 + mix(sideHeight, endHeight, crossSection), wp, fp);
}

fn kwVertexHash(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  p = fract(p * 0.1031 + wp.seed * vec3<f32>(17.17, 41.73, 83.11));
  p += vec3<f32>(dot(p, p.yzx + vec3<f32>(31.32)));
  return fract((p.x + p.y) * p.z);
}

fn kwVertexNoise(p:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var i:vec3<f32> = floor(p);
  var f:vec3<f32> = fract(p);
  f = f * f * (vec3<f32>(3.0) - 2.0 * f);
  return mix(
    mix(mix(kwVertexHash(i + vec3<f32>(0,0,0), wp, fp), kwVertexHash(i + vec3<f32>(1,0,0), wp, fp), f.x),
        mix(kwVertexHash(i + vec3<f32>(0,1,0), wp, fp), kwVertexHash(i + vec3<f32>(1,1,0), wp, fp), f.x), f.y),
    mix(mix(kwVertexHash(i + vec3<f32>(0,0,1), wp, fp), kwVertexHash(i + vec3<f32>(1,0,1), wp, fp), f.x),
        mix(kwVertexHash(i + vec3<f32>(0,1,1), wp, fp), kwVertexHash(i + vec3<f32>(1,1,1), wp, fp), f.x), f.y),
    f.z
  );
}

fn kwMacroField(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  var result:f32 = 0.0;
  var amplitude:f32 = 0.58;
  for (var i = 0; i < 3; i++) {
    result += amplitude * kwVertexNoise(p, wp, fp);
    p = p * 2.07 + vec3<f32>(5.2, 9.1, 3.7);
    amplitude *= 0.45;
  }
  return result / 0.94;
}

// pSourceM = member-local metres + inherited source grainOffset, +X axial.
// Signed normal displacement; use only this function in the geometry distance.
fn kpWoodMacroDisplacement(pSourceM:vec3<f32>, surfaceClass:f32, wp:KpWoodParams)->f32 {
  let fp=0.0;
  let grain=pSourceM*max(wp.textureScale,0.001);
    var broad:f32 = kwMacroField(grain * vec3<f32>(0.28, 1.15, 1.15) + vec3<f32>(wp.seed * 7.0), wp, fp);
    var longWave:f32 = 0.5 + 0.5 * sin(grain.x * 0.82 + wp.seed * 29.0 + broad * 1.55);
    var macroHeight:f32 = (broad - 0.5) * 0.78 + (longWave - 0.5) * 0.22;
    var classWeight:f32 = 1.0;
    if (surfaceClass > 0.5 && surfaceClass < 2.5) { classWeight = 0.0; }
    else if (surfaceClass > 2.5 && surfaceClass < 3.5) { classWeight = 1.08; }
  return macroHeight * wp.macroDisplacementM * wp.reliefScale * classWeight;
}
// Conservative magnitude bound for the original vertex displacement, in metres.
// Source macro noise is nonnegative with sum (0.58+0.261+0.11745)/0.94;
// original normal class multiplier is at most 1.08. This is not a Lipschitz bound.

// New screen-independent AA bridge. This is a nominal physical frequency estimate,
// not the original screen derivative and not a proof of derivative equivalence.
// fp=0 preserves the unfiltered original field exactly (up to f32 arithmetic).
fn kpWoodCoordinateFootprint(physicalFootprintM:f32,wp:KpWoodParams)->f32 {
  return max(physicalFootprintM,0.0)*max(wp.textureScale,0.001)*max(wp.ringFrequency*wp.ringScale,wp.fiberFrequency*4.6*max(wp.detailFineness,0.45));
}
// Complete source material terms before source-specific lighting or gamma.
// The caller supplies the actual member-local surface normal and face class.
// 0=longitudinal, 1=end grain, 2=joint cut, 3=weathered side.
// No camera-ray parallax march is hidden in this pure field call.
fn kpWoodOriginalSample(pSourceM:vec3<f32>,normalIn:vec3<f32>,surfaceClass:f32,wp:KpWoodParams,physicalFootprintM:f32,cameraDistanceM:f32)->KpWoodSample {
  let localNormal=normalize(normalIn);
  let g=pSourceM*max(wp.textureScale,0.001);
  let fp=kpWoodCoordinateFootprint(physicalFootprintM,wp);
  var baseColor=vec3<f32>(0.0);
  var heightMeters=0.0;
  var roughness=wp.roughness;
  var cavity=1.0;
    var signals:vec4<f32> = kwWoodSignals(g, localNormal, surfaceClass, wp, fp);
    var secondary:vec4<f32> = kwSecondarySignals(g, localNormal, wp, fp);
    var ring:f32 = signals.x;
    var coarseFiber:f32 = signals.y;
    var mediumFiber:f32 = signals.z;
    var cracks:f32 = signals.w;
    var fineFiber:f32 = secondary.x;
    var pores:f32 = secondary.y;
    var tool:f32 = secondary.z;
    var knot:f32 = secondary.w;
    var macroTone:f32 = kwMacroSignal(g, wp, fp);

    var crossSection:f32 = step(0.72, abs(localNormal.x));
    var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
    var radial:f32 = length(crossPosition);
    var endRay:f32 = kwAaSine(atan2(crossPosition.y, crossPosition.x) * 3.0 / KP_WOOD_TAU + radial * 2.0 + wp.seed * 7.0, wp, fp);

    var longitudinalTone:f32 =
      (coarseFiber - 0.5) * 1.02 +
      (mediumFiber - 0.5) * 0.43 +
      (macroTone - 0.5) * 0.56 +
      (fineFiber - 0.5) * 0.11 +
      knot * 0.26 -
      cracks * 0.70 -
      pores * 0.08;
    var endTone:f32 =
      (ring - 0.5) * 1.08 +
      (endRay - 0.5) * 0.19 +
      (macroTone - 0.5) * 0.38 -
      cracks * 0.72 -
      pores * 0.05;
    var grainTone:f32 = mix(longitudinalTone, endTone, crossSection) + wp.colorBias;
    var grainMix:f32 = kwSaturate(0.50 + grainTone * wp.grainContrast * 2.72, wp, fp);
    var grainColor:vec3<f32> = mix(wp.lightGrainColor, wp.darkGrainColor, grainMix);
    baseColor = mix(wp.agedSurfaceColor, grainColor, 0.78);

    if (surfaceClass > 0.5 && surfaceClass < 1.5) {
      baseColor = mix(baseColor, wp.freshCutColor, 0.20);
    } else if (surfaceClass > 1.5 && surfaceClass < 2.5) {
      baseColor = mix(baseColor, wp.freshCutColor, 0.27);
    } else if (surfaceClass > 2.5 && surfaceClass < 3.5) {
      baseColor = mix(baseColor, wp.weatheredColor, 0.53);
      roughness = min(0.98, roughness + 0.045);
    }

    baseColor *= 0.905 + macroTone * 0.19;
    baseColor = mix(baseColor, wp.cavityColor, cracks * 0.40 + pores * 0.065 + knot * 0.025);

    var distanceToCamera:f32 = cameraDistanceM;
    var detailFade:f32 = 1.0 - smoothstep(wp.distanceFadeStart, wp.distanceFadeEnd, distanceToCamera);
    var sideMicro:f32 =
      (coarseFiber - 0.5) * 0.32 +
      (mediumFiber - 0.5) * 0.24 +
      (fineFiber - 0.5) * 0.12 -
      pores * 0.30 -
      cracks * 0.94 -
      tool * 0.13 +
      knot * 0.09;
    var endMicro:f32 =
      (ring - 0.5) * 0.34 +
      (fineFiber - 0.5) * 0.05 -
      pores * 0.22 -
      cracks * 1.0;
    var microSignal:f32 = mix(sideMicro, endMicro, crossSection);
    heightMeters = microSignal * wp.microReliefM * wp.reliefScale * detailFade;

    roughness = clamp(
      roughness + pores * 0.045 + cracks * 0.075 + (0.5 - macroTone) * 0.022 - wp.clearcoat * 0.085,
      0.18,
      0.98
    );
    cavity = clamp(1.0 - cracks * 0.34 - pores * 0.06 - ring * crossSection * 0.035, 0.60, 1.0);

  return KpWoodSample(KpSurface(heightMeters,baseColor,roughness),cavity,wp.clearcoat,wp.clearcoatRoughness,wp.specularLevel,kpWoodMacroDisplacement(pSourceM,surfaceClass,wp),kwCoarseRelief(g,localNormal,surfaceClass,wp,fp));
}

// Original fragment micro-height: PBR normal detail, NOT a replacement for macro geometry.

// Compatibility entry: top longitudinal face of the original default box timber.
// age/wet/repair are reserved host arguments; the original v3 has no such model.
// Scene overlays must be explicit outside this source-preserving material leaf.


// STONE_STUDY same-page stoneFields, kind 0 (the stone receiver's default).
// KpSurface is supplied once by the shared brick core; do not redefine it here.
// No texture, mesh, voxel atlas, material cache or additional noise family.
// Authored unit bridge: a 0.42 m longest side maps to 3.4 specimen units.
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_KIND:i32 = 0;
const KP_STONE_MASTER_SEED:u32 = 8231u;
// Original normalizeSeedDNA offsets: color +401, pore +307, weather +601.
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;

fn st_hash33(pIn:vec3<f32>)->vec3<f32> {
 var p=fract(pIn*vec3<f32>(0.1031,0.1030,0.0973));
 p+=vec3<f32>(dot(p,p.yxz+vec3<f32>(33.33)));
 return fract((p.xxy+p.yxx)*p.zyx);
}
fn st_valueNoise3(p:vec3<f32>)->f32 {
 let i=floor(p);var f=fract(p);
 f=f*f*f*(f*(f*6.0-vec3<f32>(15.0))+vec3<f32>(10.0));
 return mix(mix(mix(st_hash33(i).x,st_hash33(i+vec3<f32>(1,0,0)).x,f.x),mix(st_hash33(i+vec3<f32>(0,1,0)).x,st_hash33(i+vec3<f32>(1,1,0)).x,f.x),f.y),mix(mix(st_hash33(i+vec3<f32>(0,0,1)).x,st_hash33(i+vec3<f32>(1,0,1)).x,f.x),mix(st_hash33(i+vec3<f32>(0,1,1)).x,st_hash33(i+vec3<f32>(1,1,1)).x,f.x),f.y),f.z);
}
fn st_seedVector(seed:f32,salt:f32)->vec3<f32> {
 return st_hash33(vec3<f32>(seed*0.001,salt,seed*0.00013))*49.0;
}
fn st_srgbToLinear(c:vec3<f32>)->vec3<f32> {
 return mix(c/12.92,pow((c+vec3<f32>(0.055))/1.055,vec3<f32>(2.4)),step(vec3<f32>(0.04045),c));
}
fn st_sf(p:vec3<f32>)->f32 {
 return st_valueNoise3(p)*0.57+st_valueNoise3(p*2.07+vec3<f32>(13.7))*0.28+st_valueNoise3(p*4.11+vec3<f32>(27.2))*0.15;
}
fn st_warp(p:vec3<f32>,seed:vec3<f32>)->vec3<f32> {
 return p+vec3<f32>(st_sf(p*0.8+seed),st_sf(p*0.8+seed+vec3<f32>(7.0)),st_sf(p*0.8+seed+vec3<f32>(19.0)))*0.25;
}
fn st_line(q:vec3<f32>,seed:vec3<f32>)->f32 {
 return abs(sin((q.x*0.84+q.y*0.37+q.z*0.51+st_sf(q*1.7+seed)*0.44)*12.0));
}
// New explicit isotropic footprint bridge replacing screen-space fwidth(line).
// It reevaluates the ORIGINAL line and warp at three metric axis offsets.
// This bound-like footprint is not screen-space fwidth equivalence and is not
// complete band-limiting of the original noise; zero footprint keeps 0.008.
fn st_lineAA(pos:vec3<f32>,seed:vec3<f32>,line:f32,physicalFootprintM:f32)->f32 {
 let e=max(physicalFootprintM,0.0)/KP_STONE_SCALE_M;
 if(e==0.0){return 0.008;}
 let dx=abs(st_line(st_warp(pos+vec3<f32>(e,0,0),seed),seed)-line);
 let dy=abs(st_line(st_warp(pos+vec3<f32>(0,e,0),seed),seed)-line);
 let dz=abs(st_line(st_warp(pos+vec3<f32>(0,0,e),seed),seed)-line);
 return max(dx+dy+dz,0.008);
}
// Original kind-0 stoneFields arithmetic. Fixed original material controls:
// sSurface.x=1, sSurface.y=0.7, sDisplay.w=1, sRelief=1, uEventCount=0.
// Original event-loop contribution is therefore 0. Original pits still apply.
// Branches 1/2/3 and their inactive grain/phase/crystal evaluations are omitted.

// New, authored age/moisture/repair bridge copied from resolveStoneFabric.
// Its original default wear=0.15 is fixed because this call has no wear input.
// No calibrated decay law, damage geometry, formation events or SDF is ported.
// Age changes original wet/rough uniforms only; original height stays intact.


// STONE_STUDY original sKind == 3 (blue-gray slate) surface branch.
// Append AFTER existing KP_STONE_WGSL; reuse its st_* source functions/seeds.
// Receiver controls below are explicit design bindings, NOT physical calibration.
// Original event count remains 0, matching the current surface-only port.
struct KpStoneSlateParams {
 sourceScaleM:f32, materialScale:f32, mineral:f32, chroma:f32, relief:f32,
};
fn kpStoneSlateDefaultParams()->KpStoneSlateParams {
 return KpStoneSlateParams(KP_STONE_SCALE_M,1.0,0.7,1.0,1.0);
}
fn kpStoneSlateOriginalSurface(pLocalM:vec3<f32>,params:KpStoneSlateParams,sourceWet:f32,roughBias:f32,physicalFootprintM:f32)->KpSurface {
 let pos=pLocalM/params.sourceScaleM;
 let seed=st_seedVector(KP_STONE_COLOR_SEED,0.071);
 let p=pos*params.materialScale;
 let q=st_warp(p,seed);
 let broad=st_sf(q*1.35+seed);
 let region=st_sf(q*3.2+seed+vec3<f32>(11.0));
 let weather=st_sf(q*2.2+st_seedVector(KP_STONE_WEATHER_SEED,0.09));
 let phase=q.y*5.7+q.x*0.82+q.z*0.41+st_sf(q*1.8+seed)*1.25;
 let line=st_line(q,seed);
 // Existing helper converts its input by KP_STONE_SCALE_M. Undo that fixed
 // scale here, then provide THIS receiver's explicit source + texture scale.
 // physicalFootprintM == 0 retains exactly the source's intrinsic aa floor.
 let aa=st_lineAA(p,seed,line,physicalFootprintM*KP_STONE_SCALE_M*params.materialScale/params.sourceScaleM);
 let vein=(1.0-smoothstep(0.028,0.064+aa,line))*smoothstep(0.34,0.63,region);
 let pits=pow(max(0.0,(st_sf(q*19.0+st_seedVector(KP_STONE_PORE_SEED,0.061))-0.57)/0.43),2.0);
 // Exact source kind-3 arithmetic; grain/crystal/bands are inactive here.
 let cleavage=st_sf(vec3<f32>(q.x*1.8,phase*2.8,q.z*1.8)+seed);
 var col=mix(vec3<f32>(0.10,0.15,0.19),vec3<f32>(0.30,0.37,0.40),smoothstep(0.20,0.78,cleavage*0.58+broad*0.42));
 col=mix(col,vec3<f32>(0.47,0.33,0.20),smoothstep(0.60,0.77,weather)*0.67);
 let mineral=vein*params.mineral;
 col=mix(col,vec3<f32>(0.57,0.61,0.57),mineral*0.51);
 let rough=0.48+cleavage*0.17-mineral*0.19;
 let h=(cleavage-0.5)*0.009+(broad-0.5)*0.012+sin(phase*6.28318)*0.0018-pits*0.01;
 let geomCavity=0.0;
 let cav=clamp(geomCavity*0.55+pits*1.4,0.0,1.0);
 let wet=clamp(sourceWet*(0.18+0.82*smoothstep(0.32,0.75,weather+cav*0.25)),0.0,1.0);
 let lum=dot(col,vec3<f32>(0.2126,0.7152,0.0722));
 col=mix(vec3<f32>(lum),col,params.chroma);
 var linear=st_srgbToLinear(clamp(col,vec3<f32>(0.025),vec3<f32>(0.95)));
 linear*=1.0-wet*0.38;
 return KpSurface(h*params.relief*params.sourceScaleM,linear,clamp(mix(rough+roughBias,0.17,wet),0.12,0.98));
}
// Same existing authored age/moisture/repair bridge; only source branch differs.
fn kpStoneSlateSurface(pLocalM:vec3<f32>,params:KpStoneSlateParams,age:f32,wet:f32,repair:f32,physicalFootprintM:f32)->KpSurface {
 let a=clamp(age,0.0,1.0);let r=clamp(repair,0.0,1.0);let m=clamp(wet,0.0,1.0);
 let retainedAge=a*(1.0-r);
 let sourceWet=clamp(m*(0.45+0.55*retainedAge)*(1.0-0.45*r),0.0,1.0);
 let roughBias=0.07*retainedAge+0.025*0.15-0.06*r;
 return kpStoneSlateOriginalSurface(pLocalM,params,sourceWet,roughBias,physicalFootprintM);
}


fn mt_kh(pIn:vec3<f32>)->f32{var p=fract(pIn*.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn mt_kn(p:vec3<f32>)->f32{let i=floor(p);var f=fract(p);f=f*f*(vec3<f32>(3.)-2.*f);return mix(mix(mix(mt_kh(i),mt_kh(i+vec3<f32>(1,0,0)),f.x),mix(mt_kh(i+vec3<f32>(0,1,0)),mt_kh(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(mt_kh(i+vec3<f32>(0,0,1)),mt_kh(i+vec3<f32>(1,0,1)),f.x),mix(mt_kh(i+vec3<f32>(0,1,1)),mt_kh(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn mt_kfb(p:vec3<f32>)->f32{return .57*mt_kn(p)+.28*mt_kn(p*2.13)+.15*mt_kn(p*4.17);}
fn kpMetalCorrosion(p:vec3<f32>,age:f32,wet:f32,repair:f32)->f32{let contact=(1.-smoothstep(.02,.07,abs(p.y-1.07)))*.7;let joint=(1.-smoothstep(.06,.18,p.y))+(1.-smoothstep(.01,.08,abs(p.y-.98)))*.28;return clamp(age*(1.-repair)*(wet*.7+joint*.55)*(1.-contact),0.,1.);}
fn kpMetalSurface(p:vec3<f32>,age:f32,wet:f32,repair:f32,footprintM:f32)->KpSurface{
 let kq=p+vec3<f32>(19.);let kp=mt_kfb(kq*3.1);let contact=(1.-smoothstep(.02,.07,abs(p.y-1.07)))*.7;let joint=(1.-smoothstep(.06,.18,p.y))+(1.-smoothstep(.01,.08,abs(p.y-.98)))*.28;let retained=age*(1.-repair);let corrosion=kpMetalCorrosion(p,age,wet,repair);
 var color=vec3<f32>(.17,.235,.20)*(.94+.09*kp);color=mix(color,vec3<f32>(.21,.082,.025),corrosion*.80);color*=1.-wet*.18;
 let rough=clamp(.53+(mt_kn(kq*9.)-.5)*.12+corrosion*.22-contact*.22-wet*.12,.12,.97);
 let originalHeight=(mt_kn(kq*65.)-.5)*.00025*(1.-smoothstep(.4,1.6,footprintM*65.));
 return KpSurface(originalHeight-corrosion*.0008,color,rough);
}



const RC_PI:f32=3.14159265359;
struct KpClothM{col:vec3<f32>,roughW:f32,roughF:f32,sheen:f32,bump:f32,trans:f32,irr:f32,fuzz:f32,slub:f32,open:f32,macroTone:f32,age:f32,farId:f32,meso:f32,den:vec2<f32>}
struct KpClothPattern{h:f32,thread:f32,orient:f32,variation:f32,gap:f32,nearW:f32,midW:f32,farW:f32,slub:f32,roughVar:f32,wear:f32,bundle:f32}
fn rc_h21(value:vec2<f32>)->f32{var p=fract(value*vec2<f32>(123.34,456.21));p+=vec2<f32>(dot(p,p+vec2<f32>(45.32)));return fract(p.x*p.y);}
fn rc_n2(p:vec2<f32>)->f32{let i=floor(p);var f=fract(p);f=f*f*(vec2<f32>(3.)-2.*f);return mix(mix(rc_h21(i),rc_h21(i+vec2<f32>(1,0)),f.x),mix(rc_h21(i+vec2<f32>(0,1)),rc_h21(i+vec2<f32>(1.)),f.x),f.y);}
fn rc_sat(x:f32)->f32{return clamp(x,0.,1.);}
fn kpClothCoarseParams()->KpClothM{return KpClothM(vec3<f32>(.39,.32,.21),.82,.77,.20,.46,.085,.78,.24,.88,.10,.38,.24,.78,1.,vec2<f32>(5.6,5.0));}
fn rc_patternR3(c:vec2<f32>,m:KpClothM,face:f32,footprintCm:vec2<f32>)->KpClothPattern{var p:KpClothPattern;var qb:vec2<f32> =c*m.den;var fw:vec2<f32> =footprintCm*m.den;var fp:f32=max(fw.x,fw.y);p.nearW=1.-smoothstep(.20,.75,fp);p.farW=smoothstep(.85,2.60,fp);p.midW=max(0.,1.-p.nearW-p.farW);var sum:f32=max(1e-4,p.nearW+p.midW+p.farW);p.nearW/=sum;p.midW/=sum;p.farW/=sum;var wc:f32=floor(qb.x);
var fc:f32=floor(qb.y);var seedW:f32=rc_h21(vec2<f32>(wc,19.7));
var seedF:f32=rc_h21(vec2<f32>(47.3,fc));var warpDrift:f32=(rc_n2(vec2<f32>(wc*.119,c.y*.074+seedW*9.))-.5)*m.irr*.30+(rc_n2(vec2<f32>(wc*.047,c.y*.021+17.))-.5)*m.irr*.15;var weftDrift:f32=(rc_n2(vec2<f32>(c.x*.067+seedF*11.,fc*.131))-.5)*m.irr*.30+(rc_n2(vec2<f32>(c.x*.019+27.,fc*.053))-.5)*m.irr*.15;var q:vec2<f32> =qb+vec2<f32>(warpDrift,weftDrift);
var id:vec2<f32> =floor(q);
var f:vec2<f32> =fract(q)-vec2<f32>(.5);var slW:f32=pow(smoothstep(.49,.88,rc_n2(vec2<f32>(id.x*.091,c.y*.048+seedW*13.))),1.22);
var slF:f32=pow(smoothstep(.51,.89,rc_n2(vec2<f32>(c.x*.044+seedF*15.,id.y*.103))),1.28);var longW:f32=rc_n2(vec2<f32>(id.x*.043,c.y*.016+35.));
var longF:f32=rc_n2(vec2<f32>(c.x*.014+43.,id.y*.039));var ww:f32=clamp(.415*(.84+.29*seedW)*(1.+m.slub*(.29*slW+.13*(longW-.5))),.31,.54);
var wf:f32=clamp(.425*(.84+.28*seedF)*(1.+m.slub*(.29*slF+.13*(longF-.5))),.32,.55);var warp:f32=pow(max(0.,1.-((f.x/ww)*(f.x/ww))),.50);
var weft:f32=pow(max(0.,1.-((f.y/wf)*(f.y/wf))),.50);var wave:f32=cos(RC_PI*(q.y-.5+floor(q.x)));if(face<.5){wave=-wave;}var zW:f32=warp*(.76+.24*wave)-.45;
var zF:f32=weft*(.76-.24*wave)-.45;
var mx:f32=max(zW,zF);var microH:f32=mx+log(exp((zW-mx)*7.)+exp((zF-mx)*7.))/7.;var orientDetail:f32=smoothstep(-.075,.075,zF-zW);var threadDetail:f32=max(warp,weft);var twistW:f32=sin((c.y*(5.6+2.3*seedW)+seedW*7.3)*RC_PI*2.);
var twistF:f32=sin((c.x*(5.2+2.1*seedF)+seedF*8.1)*RC_PI*2.);var twist:f32=mix(twistW,twistF,orientDetail);microH+=(twist*.026)*threadDetail;
var bundleW:f32=rc_n2(vec2<f32>(c.x*.175,c.y*.016)+vec2<f32>(7.,23.))-.5;
var bundleF:f32=rc_n2(vec2<f32>(c.x*.014,c.y*.158)+vec2<f32>(31.,5.))-.5;var bundleW2:f32=rc_n2(vec2<f32>(c.x*.061,c.y*.007)+vec2<f32>(57.,11.))-.5;
var bundleF2:f32=rc_n2(vec2<f32>(c.x*.006,c.y*.055)+vec2<f32>(13.,61.))-.5;var crossW:f32=.72*bundleW+.28*bundleW2;
var crossF:f32=.72*bundleF+.28*bundleF2;var bundleMag:f32=rc_sat(.48+.66*(abs(crossW)+abs(crossF)));var macroOrient:f32=smoothstep(-.08,.08,abs(crossF)-abs(crossW));var groupSlub:f32=pow(smoothstep(.50,.87,max(crossW,crossF)+.5),1.2);
/* R5.2: centimetre-scale signals replace vanished micro-weave at middle/far distance. */
var clothW:f32=rc_n2(vec2<f32>(c.x*.112,c.y*.010)+vec2<f32>(19.,67.))-.5;
var clothF:f32=rc_n2(vec2<f32>(c.x*.009,c.y*.101)+vec2<f32>(79.,29.))-.5;var clothCloud:f32=rc_n2(c*vec2<f32>(.071,.054)+vec2<f32>(47.,97.))-.5;var clothBody:f32=.50*clothW+.46*clothF+.34*clothCloud;var densityBand:f32=rc_n2(c*vec2<f32>(.024,.031)+vec2<f32>(109.,41.))-.5;var mesoId:f32=m.meso;var mesoH:f32=(crossW*.72+crossF*.62+groupSlub*.48-.13)*.105+mesoId*clothBody*.036;var farLoom:f32=rc_n2(c*vec2<f32>(.028,.020)+vec2<f32>(71.,43.))-.5;var fadeField:f32=rc_n2(c*vec2<f32>(.010,.015)+vec2<f32>(23.,83.))-.5;var wearField:f32=pow(smoothstep(.51,.83,rc_n2(c*vec2<f32>(.019,.027)+vec2<f32>(93.,17.))),1.45);var dryGrain:f32=rc_n2(c*vec2<f32>(.105,.043)+vec2<f32>(17.,37.))-.5;var yarnToneW:f32=rc_h21(vec2<f32>(id.x,3.1))-.5;
var yarnToneF:f32=rc_h21(vec2<f32>(5.7,id.y))-.5;var topTone:f32=mix(yarnToneW,yarnToneF,orientDetail);p.orient=mix(macroOrient,orientDetail,p.nearW);p.thread=p.nearW*threadDetail+p.midW*(.54+.38*bundleMag+.075*mesoId*rc_sat(.5+clothBody))+p.farW*(.49+.22*bundleMag+.10*mesoId*rc_sat(.5+clothBody));p.slub=p.nearW*mix(slW,slF,orientDetail)+(p.midW+p.farW)*groupSlub;p.bundle=rc_sat(bundleMag+mesoId*.15*rc_sat(.5+clothBody));p.wear=wearField*m.age;p.roughVar=(crossW*.11+crossF*.09)+groupSlub*.08+wearField*m.age*.12+mesoId*(clothW*.060+clothF*.052+clothCloud*.036)*(p.midW+p.farW);var farH:f32=(crossW*.42+crossF*.38+farLoom*.28)*.030*m.farId+mesoId*(clothBody*.034+densityBand*.012);p.h=microH*p.nearW+mesoH*p.midW*(.72+.28*m.farId)+farH*p.farW;var microTone:f32=topTone*m.irr*.12+(p.slub-.25)*m.macroTone*.34+twist*.035;var midTone:f32=(crossW*.57+crossF*.49)*m.macroTone+groupSlub*m.macroTone*.34+dryGrain*m.macroTone*.12+mesoId*(clothBody*.22+densityBand*.085)*m.macroTone;var farTone:f32=(farLoom*.64+fadeField*.74+crossW*.30+crossF*.27)*m.macroTone*m.farId+mesoId*(clothBody*.30+densityBand*.12)*m.macroTone;var wearTone:f32=(-.15+.30*fadeField)*p.wear;p.variation=p.nearW*microTone+p.midW*midTone+p.farW*farTone+wearTone;p.gap=p.nearW*(1.-smoothstep(.035,.27,warp))*(1.-smoothstep(.035,.27,weft))+p.midW*.035;return p;}





// Source material coordinates are centimetres. This explicit footprint bridge
// replaces screen derivatives; physical microheight always uses footprint zero.
fn kpClothCoarsePattern(uvM:vec2<f32>,footprintM:f32)->KpClothPattern{return rc_patternR3(uvM*100.,kpClothCoarseParams(),1.,vec2<f32>(footprintM*100.));}
fn kpClothCoarseBase(uvM:vec2<f32>,p:KpClothPattern)->vec3<f32>{let m=kpClothCoarseParams();return m.col*(1.+p.variation)*(1.-p.wear*.055)*(.965+.035*rc_n2(uvM*100.*.18+vec2<f32>(13.,5.)));}
fn kpClothCoarseSurface(uvM:vec2<f32>,footprintM:f32)->KpSurface{let m=kpClothCoarseParams();let p=kpClothCoarsePattern(uvM,footprintM);return KpSurface(p.h*m.bump*.00038,kpClothCoarseBase(uvM,p),clamp(mix(m.roughW,m.roughF,p.orient)+p.roughVar,.36,.97));}



fn mo_coreMacro(p:vec3<f32>)->f32{let low=pl_macroFast(p);let broad=sin(p.x*3.1+.55*sin(p.y*1.7))*sin(p.y*3.8-.42*sin(p.x*1.4));return clamp(.84*low+.16*broad,-1.,1.);}

fn mo_layerMacro(p:vec3<f32>,base:f32)->f32{let v=sin(p.x*2.25+p.y*1.62+p.z*3.10);return clamp(.87*base+.13*v,-1.,1.);}

fn mo_observed(p:vec3<f32>,physicalFootprintM:f32)->f32{
 let phase=vec3<f32>(.7,-1.3,2.1);let xi=pl_xi(p,phase);let e=max(physicalFootprintM,1e-7);
 // New explicit footprint receiver, not a claim of exact screen-derivative parity.
 let fp=max(length(pl_xi(p+vec3<f32>(e,0.,0.),phase)-xi),max(length(pl_xi(p+vec3<f32>(0.,e,0.),phase)-xi),length(pl_xi(p+vec3<f32>(0.,0.,e),phase)-xi)));
 var sum=0.;var sc=1.;for(var i=0;i<17;i++){let gate=1.-smoothstep(.44,1.12,fp*sc);if(gate==0.){break;}sum+=gate*pl_cell(xi,sc)/sc;sc*=2.;}return tanh(.86*sum);
}
fn kpMortarOriginalSurface(p:vec3<f32>,physicalFootprintM:f32)->KpSurface{
 // Exact original createMortarReceiver defaults: #77736b, layer0, colorVariation0,
 // coreMicro0. Source shadeSoil still has its .00013m grain normal-height.
 let obs=mo_observed(p,physicalFootprintM);let macroTone=mo_layerMacro(p,mo_coreMacro(p));
 let grain=sin(p.x*67.-p.y*51.+p.z*83.);let height=.00013*grain;
 let base=pow(vec3<f32>(119.,115.,107.)/255.,vec3<f32>(2.2));
 let rough=clamp(.95+.035*(-obs)+.022*macroTone,.84,.996);
 return KpSurface(height,base,rough);
}


fn kpConcreteStation(p:vec3<f32>,age:f32,wetness:f32,repair:f32,footprint:f32)->KpSurface{
 let q=p+vec3<f32>(19.,19.*.71,19.*.37);let large=mt_kn(q*.63);let meso=mt_kn(q*3.7);var fine=.5;if(footprint<.021){fine=mix(mt_kn(q*127.),.5,smoothstep(.003,.021,footprint));}
 let moisturePatch=smoothstep(.43,.72,large)*smoothstep(.28,.62,meso);let fresh=repair;let damp=clamp(moisturePatch*(.42+large*.58)*(1.-fresh*.85),0.,1.);let wet=wetness*clamp(damp+smoothstep(.60,.81,large)*.38+.22,0.,1.);
 let base=vec3<f32>(.468,.451,.381);let gray=moisturePatch*age*.18*(1.-fresh);var color=mix(base,base*.69+vec3<f32>(.027,.030,.025),gray);let chip=smoothstep(.64,.81,mt_kn(q*23.))*smoothstep(.46,.76,meso)*age;
 color=mix(color,base*vec3<f32>(.59,.56,.49),chip*.42);color=mix(color,base*vec3<f32>(.50,.56,.50),damp*age*.72);color=mix(color,mix(base,vec3<f32>(.80,.78,.69),.17),fresh*.85);color*=1.-wet*.13;
 let height=(fine-.5)*.00042-chip*.0007;let rough=clamp(.87+(fine-.5)*.07-wet*.23,.23,1.);return KpSurface(height,color,rough);
}


struct MaterialResult{surface:KpSurface,metal:f32,cavity:f32,specular:f32,coat:f32,coatRough:f32}
struct PhysicalState{age:f32,wet:f32,repair:f32,q:vec3<f32>}
fn physicalState(h:GeoHit,p:vec3<f32>)->PhysicalState{let d=dna(h);var q=h.q;var wet=.06;if(h.materialId==3u){q=vec3<f32>(h.q.x,p.y-d.w,h.q.z);wet=(1.-smoothstep(.04,.22,abs(q.y)))*.18;}else if(h.materialId==6u){q=vec3<f32>(p.x,p.z,p.y);}else if(h.materialId==9u){let a=rec(h.stateId-1u,0u);let b=rec(h.stateId-1u,1u);q=p-vec3<f32>(a.x,a.y,frontAt(h.stateId-1u,p.x));}return PhysicalState(d.x,wet,d.z,q);}
struct SettlementField{d:f32,geo:GeoHit,sectionCap:u32}
fn dna(h:GeoHit)->vec4<f32>{if(h.stateId==0u){return vec4<f32>(.24,.1,0.,0.);}let a=rec(h.stateId-1u,0u);let c=rec(h.stateId-1u,2u);let event=rec(h.stateId-1u,3u);let added=event.y>.5&&((h.componentId>=1000000u&&h.componentId<1001000u)||(h.componentId>=4000000u&&h.componentId<4004000u));let shelter=h.componentId>=1200000u&&h.componentId<1201000u;let eventYear=select(event.w,rec(h.stateId-1u,5u).y,shelter);let age=select(c.x,clamp((u.size.w-eventYear)/40.,0.,1.),added||shelter);return vec4<f32>(age,f32(h.stateId)*.731+select(0.,9.17,added),select(c.y,.05,added),a.y);}
fn materialUV(p:vec3<f32>,n:vec3<f32>)->vec2<f32>{if(abs(n.x)>.6){return p.zy;}if(abs(n.z)>.6){return p.xy;}return p.xz;}

fn sourcePlasterParams(h:GeoHit,p:vec3<f32>)->KpPlasterParams{var dark=vec3<f32>(.265,.235,.18);var light=vec3<f32>(.49,.435,.335);if(h.buildingId==2u){dark=vec3<f32>(.19,.24,.215);light=vec3<f32>(.365,.425,.365);}let d=dna(h);if(d.z>.3){dark=mix(dark,vec3<f32>(.32,.30,.245),d.z);light=mix(light,vec3<f32>(.52,.49,.405),d.z);}return KpPlasterParams(vec2<f32>(0.,1.35),vec2<f32>(2.,1.5),.0165,.0085,0.,.008,.025,.0002,dark,light,.0008,.000008,.018);}
fn wallCoordinates(h:GeoHit,p:vec3<f32>)->vec3<f32>{let uv=materialUV(p,h.n);return vec3<f32>(uv.x,p.y-dna(h).w,h.d);}
fn fabricAt(h:GeoHit,p:vec3<f32>)->KpFabricState{let a=rec(h.stateId-1u,0u);let b=rec(h.stateId-1u,1u);let d=dna(h);let q=wallCoordinates(h,p);let params=sourcePlasterParams(h,p);let cell=frontageCell(h.stateId-1u,p.x);let actualFront=frontZ(h.stateId-1u,cell);let local=p-vec3<f32>(a.x,a.y+a.w*.5,(actualFront+b.y)*.5);let water=kpV26WaterWeather(p/4.,h.n,local,vec3<f32>(a.z,a.w,b.y-actualFront),17.+d.y*53.,65.+d.y*53.);let pipeMask=(1.-smoothstep(.10,.48,length(p.xz-vec2<f32>(a.x+a.z*.5-.15,frontZ(h.stateId-1u,2u)-.14))))*(1.-smoothstep(a.w-.04,a.w+.05,p.y-a.y));let seam=(1.-smoothstep(.02,.30,abs(p.y-a.y)))*.18;let event=rec(h.stateId-1u,3u);let additionExterior=event.y>.5&&h.componentId>=1000000u&&h.componentId<1001000u;let exterior=select(.12,1.,additionExterior||(h.componentId>=1400010u&&h.componentId<1400020u)||abs(p.z-actualFront)<.25||abs(p.z-b.y)<.25||abs(abs(p.x-a.x)-a.z*.5)<.25);// Dry wall retains a coherent coat; strongest loss follows actual opening corners, joints and drains. Shape and PBR resolve this same state.
 let ap=frontageAperture(h.stateId-1u,cell);let sill=ap.y-ap.w;let below=(1.-smoothstep(sill-.04,sill+.10,p.y))*smoothstep(a.y+.08,a.y+.45,p.y);let corner=1.-smoothstep(.05,.24,abs(abs(p.x-ap.x)-ap.z));let frontContact=1.-smoothstep(.12,.26,abs(p.z-actualFront));let runoff=below*corner*frontContact;let fb=frontageBounds(h.stateId-1u,cell);let hasShelter=(u32(rec(h.stateId-1u,4u).z)&(1u<<cell))!=0u;let sheltered=hasShelter&&abs(p.x-(fb.x+fb.y)*.5)<(fb.y-fb.x)*.44&&p.y<a.y+a.w-.40;let cover=select(1.,.56,sheltered&&frontContact>.5);let wet=clamp(exterior*cover*(.05+.40*water.x+.60*runoff+.68*pipeMask+seam),0.,.95);let exposure=clamp(exterior*cover*(.30+.20*water.y+.55*runoff+.60*pipeMask+seam),0.,1.);let macroTone=kpPlasterMacro(q,params);let microTone=kpPlasterMicro(q,params);let thickness=clamp(params.thicknessM+params.reliefM*macroTone,params.minThicknessM,params.maxThicknessM);return kpFabricState(d.x,exposure,wet,water.y,.1,d.z,macroTone,microTone,thickness,.001,.025);}
fn brickCoordinate(h:GeoHit,p:vec3<f32>,baseD:f32)->vec3<f32>{let uv=materialUV(p,h.n);let row=floor(uv.y/.07);let shift=f32(i32(row)&1)*.125;return vec3<f32>(fract((uv.x-shift)/.25)*.25-.125,fract(uv.y/.07)*.07-.035,.055384615+baseD+.0165);}
fn brickIdentity(h:GeoHit,p:vec3<f32>)->vec2<f32>{let uv=materialUV(p,h.n);let row=floor(uv.y/.07);let shift=f32(i32(row)&1)*.125;let seed=dna(h).y+floor((uv.x-shift)/.25)*13.7+row*41.3;return vec2<f32>(seed,floor(br_h11(seed)*4.));}
fn woodNormal(h:GeoHit,n:vec3<f32>)->vec3<f32>{let axis=h.componentId%4u;if(axis==1u){return n.yxz;}if(axis==2u){return n.zyx;}return n;}
fn stoneParameters(h:GeoHit)->KpStoneSlateParams{var a=kpStoneSlateDefaultParams();a.sourceScaleM=select(.8,2.5,h.buildingId==0u);a.relief=.06;return a;}
fn sceneMaterial(h:GeoHit,p:vec3<f32>,n:vec3<f32>,fp:f32,cap:u32)->MaterialResult{var s=KpSurface(0.,vec3<f32>(.3),.8);var metal=0.;var cavity=1.;var spec=1.;var coat=0.;var coatRough=.25;let d=dna(h);
 if(h.stateId==0u){return MaterialResult(KpSurface(0.,vec3<f32>(.28),.92),0.,1.,1.,0.,.25);}
 if(h.materialId==1u){s=kpPlasterOriginalField(wallCoordinates(h,p),sourcePlasterParams(h,p),fp).surface;if(cap==0u){s=kpApplyFabricSurface(s,fabricAt(h,p));}}
 if(h.materialId==2u){let id=brickIdentity(h,p);s=kpBrickOriginalSurface(brickCoordinate(h,p,h.d),id.x,i32(id.y),.42,fp);if(cap==0u){s=kpApplyFabricSurface(s,fabricAt(h,p));}}
 if(h.materialId==8u){s=kpMortarOriginalSurface(wallCoordinates(h,p),fp);if(cap==0u){s=kpApplyFabricSurface(s,fabricAt(h,p));}}
 if(h.materialId==3u){let state=physicalState(h,p);s=kpMetalSurface(state.q,state.age,state.wet,state.repair,fp);metal=.70*(1.-smoothstep(.05,.30,kpMetalCorrosion(state.q,state.age,state.wet,state.repair)));}
 if(h.materialId==4u){let wn=woodNormal(h,n);let sample=kpWoodOriginalSample(h.q,wn,select(0.,1.,abs(wn.x)>.72),kpWoodDefaultParams(),fp,length(p-u.eye.xyz));s=sample.surface;cavity=sample.cavity;spec=sample.specularLevel;coat=sample.clearcoat;coatRough=sample.clearcoatRoughness;}
 if(h.materialId==5u){s=KpSurface(0.,vec3<f32>(.65,.75,.72),.12);}
 if(h.materialId==6u){let state=physicalState(h,p);s=kpStoneSlateSurface(state.q,stoneParameters(h),state.age,state.wet,state.repair,fp);}
 if(h.materialId==9u){let state=physicalState(h,p);s=kpConcreteStation(state.q,state.age,state.wet,state.repair,fp);}
 if(h.materialId==7u){s=kpClothCoarseSurface(h.q.xz,fp);spec=.6;}
 return MaterialResult(s,metal,cavity,spec,coat,coatRough);}

// Analytic current-parameter bounds are recorded in qa/material-distance-bounds.txt.
// 0.012m is deliberately wider than every possible displacement; this is a
// distance-value bound, not a claim that the displaced field is a strict SDF.
const MATERIAL_DISTANCE_BOUND:f32=.012;



struct Stats {hit:atomic<u32>,miss:atomic<u32>,exhausted:atomic<u32>,maximumSteps:atomic<u32>,retried:atomic<u32>,glassRays:atomic<u32>,boundOnly:atomic<u32>,reserved:atomic<u32>,visibilityRetried:atomic<u32>,visibilityMaximumSteps:atomic<u32>,extendedPrimary:atomic<u32>,candidateOverflows:atomic<u32>,activeQueries:atomic<u32>}

struct HitRecord { ray:vec4<f32>,local:vec4<f32>,ids:vec4<u32>,normal:vec4<f32>,glass:vec4<f32>,through:vec4<f32> }

struct RetryQueue {count:atomic<u32>,indices:array<u32,256>}




// Initial 64-step exit and final sparse continuation. No scene or material state is copied.


















struct Frag { @location(0) color:vec4<f32>, @builtin(frag_depth) depth:f32 }



struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }

@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;

fn mapHit(p:vec3<f32>)->GeoHit {fieldCompetition=true;fieldExcludedCount=1u;fieldExcluded[0]=vec2<u32>(0u,0u);return querySettlement(p,150.);}



@compute @workgroup_size(32) fn sampleColor(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w<.5){return;}let p=o.position.xyz;let h=mapHit(p);let m=sceneMaterial(h,p,o.normal.xyz,.18,0u).surface;o.color=vec4<f32>(m.albedo,m.roughness);mapSamples[i]=o;}
