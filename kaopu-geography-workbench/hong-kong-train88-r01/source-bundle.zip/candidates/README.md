# Existing scene candidates in one map

The two candidates are adapted from their original program fields. This directory does not recreate them with replacement boxes or screenshot textures. The shared WebGL2 map consumes actual sampled vertex positions, normals, indices, original mother-function albedo and roughness. No iframe or separate scene canvas is used.

## Adapter

Import `loadCandidateMesh`, `transformCandidateMesh`, and `CANDIDATES` from `candidate-adapter.mjs`. `await loadCandidateMesh('lost-bureau')` and `await loadCandidateMesh('walled-pair')` return positions, normals and colors as Float32Array, indices as Uint32Array, materialIds as Uint16Array, per-vertex roughness, and metadata. Data is in original metres, positive Y up. Both default to scale 1. Preserve the complete city pair as a single transform because its internal passage and borrowed connections share their coordinates.

Call `transformCandidateMesh(mesh,{position:[x,y,z],yaw:radians,scale:1})` to bake a placement into the vertices for the native WebGL renderer. Its output is a new mesh, leaving source buffers unchanged. A Three adapter is optional; raw WebGL is sufficient.

## What this means

This is a finite-sampled map layout candidate, not a new mother and not equivalent to the native close-up field render. Five orthographic direction grids sample the original nominal surface field; triangles that bridge major depth jumps are rejected. Small/thin geometry and hidden interiors can be missing. Material micro-displacement, native glass transmission, fine normal response and dynamic life are not reproduced. Vertex albedo and roughness are original mother outputs evaluated at a recorded fixed physical footprint, with ordinary shared-map lighting supplied at run time. No neutral-gray or invented color fallback is permitted.

The lost-property-bureau sample includes original architecture, entry joinery and chimney. Interior inventory, racks and transport remain in the native source. The city sample includes the intact original whole-growth R05 pair and excludes its infinite diagnostic ground, so the real terrain owns ground. The city's 1.70 m internal gap is pedestrian space and is not railway clearance. Source dimensions and metadata are preserved, while map positions and yaw are explicitly adjustable story placements without surveying claims. The modern FreeCAD 2D work is not substituted as 3D geometry.

## Reproduce and verify

The emitted `.wgsl` closures preserve reachable original function bytes and six/ nine mother hashes. The original city 39 runtime source files match the exact 942f27 packet. `qa/sampling-plan.json` records full source hashes, source commits, grid views and closure hashes.

1. In a WebGPU-capable Linux CI with Playwright and Chromium: `node candidates/qa/run-sampling.cjs` (prefix the path with the project directory when running from repository root).
2. `node candidates/qa/pack-samples.mjs` validates samples and writes `data/*.f32`, `.u32`, `.u16` plus mesh manifests. Set `SAMPLE_MODEL=lost-bureau` or `walled-pair` to run one model and its pack step separately.
3. `node --test candidates/qa/candidate-adapter.test.mjs` verifies loading, transform and data failure semantics.

Sampling failure remains a visible unavailable candidate. No substitute geometry is produced. GPU and visual status are separate; source/CPU tests alone do not imply a sampled mesh or successful appearance in the map.
