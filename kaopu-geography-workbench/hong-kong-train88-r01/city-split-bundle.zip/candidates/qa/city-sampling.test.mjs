import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {receiverWGSL} from '../../../walled-city-pair-r03/whole-growth-r05/runtime/receiver.mjs';
import {GEOMETRY_WGSL} from '../../../walled-city-pair-r03/whole-growth-r05/runtime/geometry.mjs';
import {CITY_MATERIAL_IDS,specializeSceneMaterial,originalSceneMaterial} from './city-sampling-source.mjs';
const source=receiverWGSL(GEOMETRY_WGSL),plan=JSON.parse(fs.readFileSync(new URL('sampling-plan.json',import.meta.url)));
const city=plan.models.find(m=>m.id==='walled-pair');
const read=name=>fs.readFileSync(new URL(name,import.meta.url),'utf8');
function functions(code){const result=new Map(),re=/(?:@\w+(?:\([^()]*\))?\s*)*fn\s+(\w+)\s*\(/g;let m;while((m=re.exec(code))){const start=m.index,open=code.indexOf('{',re.lastIndex);let d=1,i=open+1;for(;d&&i<code.length;i++){if(code[i]==='{')d++;if(code[i]==='}')d--;}result.set(m[1],code.slice(start,i));re.lastIndex=i;}return result;}
const originalFunctions=functions(source);

test('each material specialization preserves the selected branch and shared return byte-for-byte',()=>{
  const original=originalSceneMaterial(source).code;
  for(const id of CITY_MATERIAL_IDS){const s=specializeSceneMaterial(source,id);assert.ok(original.includes(s.branch));assert.ok(s.specialized.includes(s.branch));assert.equal((s.specialized.match(/if\(h\.materialId==/g)||[]).length,1);assert.ok(s.specialized.endsWith('return MaterialResult(s,metal,cavity,spec,coat,coatRough);}'));assert.ok(s.specialized.includes('if(h.stateId==0u)'));}
});

test('all reachable original mother and domain helper functions are byte-identical',()=>{
  for(const id of CITY_MATERIAL_IDS){const code=read('walled-pair-sampleColor'+id+'.wgsl'),fns=functions(code);assert.ok(!fns.has('querySettlement'));assert.ok(!fns.has('mapHit'));let preserved=0;for(const [name,fn] of fns){if(originalFunctions.has(name)&&name!=='sceneMaterial'){assert.equal(fn,originalFunctions.get(name),name+' in '+id);preserved++;}}assert.ok(preserved>0);assert.equal(fns.get('sceneMaterial'),specializeSceneMaterial(source,id).specialized);}
});

test('material entry guards its domain and reads the complete cached hit ABI',()=>{
  for(const id of CITY_MATERIAL_IDS){const code=read('walled-pair-sampleColor'+id+'.wgsl');assert.ok(code.includes(`if(o.position.w!=${id}.){return;}`));assert.ok(code.includes(`if(h.materialId!=${id}u){return;}`));assert.ok(code.includes('sceneMaterial(h,o.position.xyz,o.normal.xyz,.18,0u).surface'));assert.ok(code.includes('GeoHit(h.local.w,h.ids.x,h.ids.y,h.ids.z,h.ids.w,h.local.xyz,h.normal.xyz,h.extra.x)'));}
});

test('geometry makes one query per march step and caches that exact hit',()=>{
 const code=read('walled-pair-sampleGeometry.wgsl'),fn=functions(code).get('sampleGeometry');assert.equal((fn.match(/mapHit\(/g)||[]).length,1);assert.ok(fn.includes('found=true;hit=f;break;'));assert.ok(fn.includes('mapHits[i]=packMapHit(hit)'));assert.ok(!fn.includes('mapNormal'));const normal=functions(read('walled-pair-sampleNormal.wgsl')).get('sampleNormal');assert.ok(normal.includes('for(var j=0u;j<6u;j++)'));assert.equal((normal.match(/mapDistance\(/g)||[]).length,1);
});

test('plan and generated shader hashes agree and include every domain',()=>{
 assert.equal(city.samplingExecution.hitStrideBytes,64);assert.deepEqual(city.samplingExecution.materialIds,CITY_MATERIAL_IDS);assert.equal(city.stages.sampleColor,undefined);assert.deepEqual(Buffer.from(citySamplingRays(city).buffer),fs.readFileSync(new URL('walled-pair-rays.f32',import.meta.url)));
 for(const [entry,stage] of Object.entries(city.stages)){const code=read('walled-pair-'+entry+'.wgsl');assert.equal(Buffer.byteLength(code),stage.bytes);assert.equal(crypto.createHash('sha256').update(code).digest('hex'),stage.sha256);}
});

test('fail closed if the locked material router changes',()=>{
 assert.throws(()=>specializeSceneMaterial(source.replace('if(h.materialId==1u){s=kpPlasterOriginalField','if(h.materialId==10u){s=kpPlasterOriginalField'),1),/routing changed/);assert.throws(()=>specializeSceneMaterial(source,0),/Unknown material/);
});

import {runCitySampling,citySamplingRays} from './run-city-sampling.mjs';
function mockGPU({failEntry}={}) {
  const events=[],allocated=[];let geometryOffset=0;
  globalThis.GPUBufferUsage={UNIFORM:1,COPY_DST:2,STORAGE:4,COPY_SRC:8,MAP_READ:16};globalThis.GPUMapMode={READ:1};
  const device={
    createBuffer({size}){const b={data:new ArrayBuffer(size),destroyed:false,async mapAsync(){},getMappedRange(offset=0,size){return this.data.slice(offset,size===undefined?undefined:offset+size);},unmap(){},destroy(){this.destroyed=true;}};allocated.push(b);return b;},
    createShaderModule(){return {async getCompilationInfo(){return {messages:[]};}};},
    async createComputePipelineAsync({compute}){events.push('compile:'+compute.entryPoint);if(compute.entryPoint===failEntry)throw Error('Deliberate test compiler failure');return {entry:compute.entryPoint,getBindGroupLayout(group){return group;}};},
    createBindGroup({entries}){return new Map(entries.map(e=>[e.binding,e.resource]));},
    createCommandEncoder(){const ops=[];return {
      beginComputePass(){let pipeline;const groups=[];return {setPipeline(p){pipeline=p;},setBindGroup(i,b){groups[i]=b;},dispatchWorkgroups(groupsCount){ops.push(()=>{
        const output=groups[1].get(1),count=output.size/48,out=new Float32Array(output.buffer.data);assert.equal(groupsCount,Math.ceil(count/32));events.push('dispatch:'+pipeline.entry+':'+count);
        if(pipeline.entry==='sampleGeometry'){
          const ray=groups[1].get(0),rays=new Float32Array(ray.buffer.data),hit=groups[1].get(2),hits=new Uint32Array(hit.buffer.data);assert.equal(ray.size,count*32);assert.equal(hit.size,count*64);
          for(let i=0;i<count;i++){const index=geometryOffset+i,id=[0,1,3,4,5,6,7,9][index%8];out.set([index,2,3,id,0,1,0,5,0,0,0,0],i*12);hits.set([id,1,4,1],i*16);}geometryOffset+=count;
        }else if(pipeline.entry==='sampleNormal'){for(let i=0;i<count;i++)out.set([0,1,0],i*12+4);}
        else{const id=Number(pipeline.entry.slice('sampleColor'.length)),hit=groups[1].get(2),hits=new Uint32Array(hit.buffer.data);assert.equal(hit.size,count*64);for(let i=0;i<count;i++){assert.equal(out[i*12+3],id);assert.equal(hits[i*16],id);assert.equal(out[i*12+11],-1);out.set([id/10,.2,.3,.75],i*12+8);}}
      });},end(){}};},
      copyBufferToBuffer(a,ao,b,bo,n){ops.push(()=>new Uint8Array(b.data,bo,n).set(new Uint8Array(a.data,ao,n)));},finish(){return ops;}
    };},
    queue:{writeBuffer(buffer,offset,input){const bytes=input instanceof ArrayBuffer?new Uint8Array(input):new Uint8Array(input.buffer,input.byteOffset,input.byteLength);new Uint8Array(buffer.data,offset,bytes.byteLength).set(bytes);},submit(commands){for(const ops of commands)for(const op of ops)op();}}
  };
  return {device,events,allocated};
}
async function runMock(options={}) {
  const mock=mockGPU(options),posts=new Map(),model=structuredClone(city);model.rayCount=263;model.views=[{axis:0,sign:1,start:0,nu:15,nv:17},{axis:2,sign:-1,start:255,nu:2,nv:4}];
  const rays=new Float32Array(model.rayCount*8);for(let i=0;i<model.rayCount;i++)rays[i*8]=i;
  const report={models:[],errors:[]};let error;
  try{await runCitySampling({device:mock.device,model,world:[0,0,0,0],report,
    get:async(name,type)=>name.endsWith('-rays.f32')?rays.buffer:read(name.slice(2)),
    post:async(name,body)=>{mock.events.push('post:'+name);posts.set(name,body.slice(0));},progress:async()=>{}});}catch(e){error=e;}
  return {...mock,posts,report,model,error};
}

test('sampler checkpoints geometry, skips unhit domains and safely handles 263-ray tail',async()=>{
  const r=await runMock();assert.equal(r.error,undefined);assert.ok(r.allocated.every(b=>b.destroyed));
  assert.ok(r.events.indexOf('post:walled-pair-hits.u32')<r.events.indexOf('compile:sampleColor1'));
  assert.ok(!r.events.includes('compile:sampleColor2'));assert.ok(!r.events.includes('compile:sampleColor8'));
  assert.ok(r.events.includes('dispatch:sampleGeometry:7'));
  const checkpoint=new Float32Array(r.posts.get('walled-pair-geometry.f32')),output=new Float32Array(r.posts.get('walled-pair-samples.f32'));
  assert.equal(output.length,263*12);let hits=0;
  for(let i=0;i<263;i++){const id=output[i*12+3];if(id<.5)continue;hits++;assert.equal(checkpoint[i*12+11],-1);assert.equal(output[i*12+11],.75);assert.equal(output[i*12+8],Math.fround(id/10));assert.deepEqual(output.slice(i*12,i*12+8),checkpoint.slice(i*12,i*12+8));}
  assert.equal(r.report.models[0].colorSamples,hits);assert.equal(r.report.models[0].status,'sampled');
});

test('a material compiler failure retains checkpoints without producing a finished sample',async()=>{
  const r=await runMock({failEntry:'sampleColor4'});assert.match(r.error.message,/Deliberate test compiler failure/);assert.ok(r.posts.has('walled-pair-geometry.f32'));assert.ok(r.posts.has('walled-pair-hits.u32'));assert.ok(r.posts.has('walled-pair-colors-partial.f32'));assert.ok(!r.posts.has('walled-pair-samples.f32'));assert.equal(r.report.models[0].stages.at(-1).status,'failed');assert.ok(r.allocated.every(b=>b.destroyed));
});
