import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {shaderSource} from '../../../lost-property-bureau-r03f/candidate/renderer.mjs';
import {selectStageSource} from '../../../lost-property-bureau-r03f/candidate/stage-source.mjs';
import {buildCitySamplingStages, CITY_MATERIAL_IDS, CITY_HIT_STRIDE} from './city-sampling-source.mjs';
import {loadWorld} from '../../../walled-city-pair-r03/whole-growth-r05/runtime/world-data.mjs';
const out=path.dirname(new URL(import.meta.url).pathname), root=path.resolve(out,'../../..');
const shared=String.raw`
struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }
@group(1) @binding(0) var<storage,read> mapRays:array<SampleRay>;
@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;
`;
const lost=String.raw`
fn mapField(p:vec3<f32>)->Field {return take(take(architecture(p),entryJoinery(p)),taperedChimney(p));}
fn mapDistance(p:vec3<f32>)->f32 {return mapField(p).d;}
fn mapNormal(p:vec3<f32>)->vec3<f32>{let e=.003;return normalize(vec3<f32>(mapDistance(p+vec3<f32>(e,0.,0.))-mapDistance(p-vec3<f32>(e,0.,0.)),mapDistance(p+vec3<f32>(0.,e,0.))-mapDistance(p-vec3<f32>(0.,e,0.)),mapDistance(p+vec3<f32>(0.,0.,e))-mapDistance(p-vec3<f32>(0.,0.,e))));}
@compute @workgroup_size(32) fn sampleGeometry(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapRays)){return;}let r=mapRays[i];var t=0.;var found=false;var steps=0u;for(var k=0u;k<640u;k++){steps=k+1u;let f=mapField(r.origin.xyz+r.direction.xyz*t);if(f.mat>0u&&abs(f.d)<.004){found=true;break;}t+=max(.002,abs(f.d)*.72);if(t>r.origin.w){break;}}var o:SampleOutput;o.position=vec4<f32>(0.,0.,0.,0.);o.normal=vec4<f32>(0.,1.,0.,f32(steps));o.color=vec4<f32>(0.);if(found){let p=r.origin.xyz+r.direction.xyz*t;let f=mapField(p);o.position=vec4<f32>(p,f32(f.mat));o.normal=vec4<f32>(mapNormal(p),f32(steps));}else if(t<=r.origin.w){o.normal.w=-f32(steps);}mapSamples[i]=o;}
@compute @workgroup_size(32) fn sampleColor(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w<.5){return;}let p=o.position.xyz;let f=mapField(p);let m=surfaceRaw(f,p,o.normal.xyz,.25);o.color=vec4<f32>(m.albedo,m.roughness);mapSamples[i]=o;}
`;
const models=[{id:'lost-bureau',source:shaderSource()+shared+lost,bounds:[[-48,-.02,-43],[52,33,43]],spacing:1,commit:'5e139ef061cb2f6ed739536f2e53342a2c71c924',sourcePath:'lost-property-bureau-r03f/candidate'}, {id:'walled-pair',source:null,bounds:[[-12.5,.05,-7.5],[12,40.8,5.8]],spacing:.5,commit:'942f27bfcf966d501e79586915899ba62cff75f5',sourcePath:'walled-city-pair-r03/whole-growth-r05/runtime'}];
const manifest={schema:'same-source-finite-surface-sample-v1',created:new Date().toISOString(),models:[]};
for(const m of models){const stages={};
 const city=m.id==='walled-pair'?buildCitySamplingStages(shared):null;
 const closures=city?city.stages:Object.fromEntries(['sampleGeometry','sampleColor'].map(entry=>[entry,selectStageSource(m.source,[entry])]));
 for(const [entry,s] of Object.entries(closures)){fs.writeFileSync(path.join(out,m.id+'-'+entry+'.wgsl'),s.code);stages[entry]={bytes:s.bytes,sha256:crypto.createHash('sha256').update(s.code).digest('hex'),bindings:s.bindings,functions:s.functionNames,...(s.materialId?{materialId:s.materialId,originalBranchSha256:crypto.createHash('sha256').update(s.preservedBranch).digest('hex')}: {})};}
 if(city){m.samplingExecution={mode:'cached-hit-material-domains-v1',hitStrideBytes:CITY_HIT_STRIDE,materialIds:CITY_MATERIAL_IDS,geometryStages:['sampleGeometry','sampleNormal'],materialStages:CITY_MATERIAL_IDS.map(id=>'sampleColor'+id),originalSceneMaterialSha256:crypto.createHash('sha256').update(city.originalSceneMaterial).digest('hex')};}

 const rays=[],views=[];const [lo,hi]=m.bounds;for(const [axis,sign] of [[0,1],[0,-1],[2,1],[2,-1],[1,-1]]){const a=(axis+1)%3,b=(axis+2)%3;const nu=Math.ceil((hi[a]-lo[a])/m.spacing)+1,nv=Math.ceil((hi[b]-lo[b])/m.spacing)+1;const start=rays.length/8;for(let v=0;v<nv;v++)for(let u=0;u<nu;u++){const p=[0,0,0],d=[0,0,0];p[a]=lo[a]+u*(hi[a]-lo[a])/(nu-1);p[b]=lo[b]+v*(hi[b]-lo[b])/(nv-1);p[axis]=sign>0?lo[axis]-.2:hi[axis]+.2;d[axis]=sign;rays.push(...p,hi[axis]-lo[axis]+.4,...d,0);}views.push({axis,sign,start,nu,nv,spacing:[(hi[a]-lo[a])/(nu-1),(hi[b]-lo[b])/(nv-1)]});}
 fs.writeFileSync(path.join(out,m.id+'-rays.f32'),Buffer.from(new Float32Array(rays).buffer));manifest.models.push({...m,source:undefined,views,rayCount:rays.length/8,stages});}
fs.writeFileSync(path.join(out,'world-rules.f32'),Buffer.from(loadWorld().buffer));
const sourceHashes={};for(const src of ['lost-property-bureau-r03f/candidate','walled-city-pair-r03/runtime','walled-city-pair-r03/whole-growth-r05/runtime']){function walk(dir){for(const name of fs.readdirSync(dir)){const p=path.join(dir,name);if(fs.statSync(p).isDirectory()){walk(p);continue;}if(!p.endsWith('.mjs'))continue;sourceHashes[path.relative(root,p)]={bytes:fs.statSync(p).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')};}}walk(path.join(root,src));}
manifest.sourceHashes=sourceHashes;fs.writeFileSync(path.join(out,'sampling-plan.json'),JSON.stringify(manifest,null,2));console.log(manifest.models.map(m=>({id:m.id,rayCount:m.rayCount,stages:Object.fromEntries(Object.entries(m.stages).map(([k,v])=>[k,v.bytes]))})));
