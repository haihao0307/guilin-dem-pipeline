// QA/offline finite sampler. No dependency on the map runtime.
export function citySamplingRays(model) {
  const rays=new Float32Array(model.rayCount*8);
  let generated=0;
  for(const view of model.views) {
    const {axis,sign,nu,nv,start}=view,[lo,hi]=model.bounds,a=(axis+1)%3,b=(axis+2)%3;
    if(nu<2||nv<2||start!==generated)throw Error('Invalid city ray-grid plan');
    for(let v=0;v<nv;v++)for(let x=0;x<nu;x++) {
      const i=(start+v*nu+x)*8;
      rays[i+a]=lo[a]+x*(hi[a]-lo[a])/(nu-1);
      rays[i+b]=lo[b]+v*(hi[b]-lo[b])/(nv-1);
      rays[i+axis]=sign>0?lo[axis]-.2:hi[axis]+.2;
      rays[i+3]=hi[axis]-lo[axis]+.4;rays[i+4+axis]=sign;
    }
    generated+=nu*nv;
  }
  if(generated!==model.rayCount)throw Error('City ray count differs from plan');
  return rays;
}

export async function runCitySampling({device, model, world, get, post, report, progress}) {
  const config = model.samplingExecution;
  if (config?.mode !== 'cached-hit-material-domains-v1' || config.hitStrideBytes !== 64) {
    throw Error('Regenerate the city sampling plan before running the cached-hit sampler');
  }
  const m = {id:model.id, status:'compiling', samples:0, colorSamples:0, total:model.rayCount,
    stages:[], startedAt:new Date().toISOString(), execution:config.mode};
  report.models.push(m);
  await progress();
  const batch = 256, buffers = [];
  const create = (size, usage) => {const b=device.createBuffer({size, usage});buffers.push(b);return b;};
  const u = new Float32Array(32);
  u.set([50,30,-50,0]);u.set([0,0,0,1000],16);u.set([512,512,36000,1984],20);u[30]=1;
  const ub=create(u.byteLength,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
  const wb=create(world.length*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
  const rb=create(batch*32,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
  const ob=create(batch*48,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST|GPUBufferUsage.COPY_SRC);
  const hb=create(batch*64,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST|GPUBufferUsage.COPY_SRC);
  const read=create(batch*112,GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);
  device.queue.writeBuffer(ub,0,u);device.queue.writeBuffer(wb,0,new Float32Array(world));
  const resources={u:ub,worldRules:wb,mapRays:rb,mapSamples:ob,mapHits:hb};
  const failOnErrors=()=>{if(report.errors.length)throw Error(report.errors.join('\n'));};
  const compile=async entry=>{
    const stage={entry,status:'compiling',messages:[]};m.stages.push(stage);m.status='compiling';await progress();
    const start=performance.now();
    try {
      const module=device.createShaderModule({code:await get('./'+model.id+'-'+entry+'.wgsl')});
      const info=await module.getCompilationInfo();stage.messages=info.messages.map(x=>({type:x.type,message:x.message,line:x.lineNum}));
      if(stage.messages.some(x=>x.type==='error'))throw Error(JSON.stringify(stage.messages));
      const pipeline=await device.createComputePipelineAsync({layout:'auto',compute:{module,entryPoint:entry}});
      Object.assign(stage,{status:'compiled',compileMs:performance.now()-start});await progress();failOnErrors();
      return {entry,pipeline};
    } catch(error) {Object.assign(stage,{status:'failed',compileMs:performance.now()-start,error:String(error)});throw error;}
  };
  const dispatch=(encoder,stage,count)=>{
    const pass=encoder.beginComputePass();pass.setPipeline(stage.pipeline);
    for(const group of [0,1]) {
      const entries=model.stages[stage.entry].bindings.filter(x=>x.group===group).map(x=>{
        const buffer=resources[x.name];if(!buffer)throw Error('Unknown sampling resource '+x.name);
        const stride={mapRays:32,mapSamples:48,mapHits:64}[x.name];
        return {binding:x.binding,resource:{buffer,...(stride?{size:count*stride}:{})}};
      });
      pass.setBindGroup(group,device.createBindGroup({layout:stage.pipeline.getBindGroupLayout(group),entries}));
    }
    pass.dispatchWorkgroups(Math.ceil(count/32));pass.end();
  };
  const all=new Float32Array(model.rayCount*12),hits=new Uint32Array(model.rayCount*16);
  try {
    const geometry=[];for(const entry of config.geometryStages)geometry.push(await compile(entry));
    const rays=citySamplingRays(model);
    m.status='sampling-geometry';await progress();const startTime=performance.now();
    for(let start=0;start<model.rayCount;start+=batch) {
      const count=Math.min(batch,model.rayCount-start);device.queue.writeBuffer(rb,0,rays.subarray(start*8,(start+count)*8));
      const encoder=device.createCommandEncoder();for(const stage of geometry)dispatch(encoder,stage,count);
      encoder.copyBufferToBuffer(ob,0,read,0,count*48);encoder.copyBufferToBuffer(hb,0,read,count*48,count*64);
      device.queue.submit([encoder.finish()]);await read.mapAsync(GPUMapMode.READ,0,count*112);
      const mapped=read.getMappedRange(0,count*112);
      all.set(new Float32Array(mapped,0,count*12),start*12);hits.set(new Uint32Array(mapped,count*48,count*16),start*16);
      read.unmap();failOnErrors();m.samples=start+count;m.durationMs=performance.now()-startTime;
      if(start===0||m.samples===model.rayCount||start%(batch*16)===0)await progress();
    }
    const partitions=new Map(config.materialIds.map(id=>[id,[]]));
    for(let i=0;i<model.rayCount;i++) {
      const id=all[i*12+3];if(id<.5)continue;
      if(!partitions.has(id))throw Error('Unrecognized hit material '+id+' at '+i);
      if(hits[i*16]!==id)throw Error('Cached GeoHit material mismatch at '+i);
      partitions.get(id).push(i);
      // A sentinel makes partially colored geometry impossible to pass as a finished sample.
      all[i*12+11]=-1;
    }
    m.materialHits=Object.fromEntries([...partitions].map(([id,indices])=>[id,indices.length]));
    await post(model.id+'-geometry.f32',all.buffer);await post(model.id+'-hits.u32',hits.buffer);
    m.geometryCheckpoint={samples:model.id+'-geometry.f32',hits:model.id+'-hits.u32',hitStrideBytes:64};
    m.status='geometry-sampled';await progress();
    for(const [id,indices] of partitions) {
      const entry='sampleColor'+id;
      if(!indices.length){m.stages.push({entry,status:'skipped',reason:'No sampled hits in this material domain'});continue;}
      const stage=await compile(entry);m.status='sampling-material';m.materialId=id;await progress();
      for(let start=0;start<indices.length;start+=batch) {
        const selected=indices.slice(start,start+batch),count=selected.length;
        const samples=new Float32Array(count*12),packedHits=new Uint32Array(count*16);
        for(let j=0;j<count;j++){const i=selected[j];samples.set(all.subarray(i*12,i*12+12),j*12);packedHits.set(hits.subarray(i*16,i*16+16),j*16);}
        device.queue.writeBuffer(ob,0,samples);device.queue.writeBuffer(hb,0,packedHits);
        const encoder=device.createCommandEncoder();dispatch(encoder,stage,count);encoder.copyBufferToBuffer(ob,0,read,0,count*48);
        device.queue.submit([encoder.finish()]);await read.mapAsync(GPUMapMode.READ,0,count*48);
        const colored=new Float32Array(read.getMappedRange(0,count*48));
        for(let j=0;j<count;j++) {
          const color=colored.subarray(j*12+8,j*12+12);
          if(!color.every(Number.isFinite)||color[3]<0||color[3]>1)throw Error('Invalid original material output '+id+' at '+selected[j]);
          all.set(color,selected[j]*12+8);
        }
        read.unmap();failOnErrors();m.colorSamples+=count;
      }
      m.stages.at(-1).samples=indices.length;m.stages.at(-1).status='sampled';
      // This is explicitly partial until every visible material has succeeded.
      await post(model.id+'-colors-partial.f32',all.buffer);await progress();
    }
    const expected=[...partitions.values()].reduce((n,indices)=>n+indices.length,0);
    if(m.colorSamples!==expected)throw Error('Incomplete material domains');
    for(let i=0;i<model.rayCount;i++)if(all[i*12+3]>.5&&all[i*12+11]<0)throw Error('Uncolored hit '+i);
    await post(model.id+'-samples.f32',all.buffer);m.status='sampled';m.completedAt=new Date().toISOString();
    m.durationMs=performance.now()-startTime;delete m.materialId;await progress();
  } finally {for(const b of buffers)b.destroy();}
}
