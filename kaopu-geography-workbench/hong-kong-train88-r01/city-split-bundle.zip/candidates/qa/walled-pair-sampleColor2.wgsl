
struct Frame { eye:vec4<f32>,forward:vec4<f32>,right:vec4<f32>,up:vec4<f32>,cut:vec4<f32>,size:vec4<f32>,tile:vec4<u32>,controls:vec4<f32> }
@group(0) @binding(0) var<uniform> u:Frame;

@group(0) @binding(1) var<storage,read> worldRules:array<vec4<f32>>;
struct GeoHit{d:f32,materialId:u32,buildingId:u32,componentId:u32,stateId:u32,q:vec3<f32>,n:vec3<f32>,objectId:u32}
// Short-lived per-ray candidate keys, never persistent world/brick instances.
var<private> fieldCompetition:bool;
var<private> fieldExcluded:array<vec2<u32>,32>;
var<private> fieldExcludedCount:u32;

fn rec(s:u32,k:u32)->vec4<f32>{return worldRules[s*8u+k];}
















// Dated household event, partitioned along existing execution groups.






// Metric frontage rules are compiled with household uses, not randomized per pixel.
fn frontageCell(s:u32,x:f32)->u32{let a=rec(s,0u);let f=rec(s,4u);let u=(x-a.x)/a.z+.5;return select(select(0u,1u,u>=f.x),2u,u>=f.y);}
fn frontageBounds(s:u32,cell:u32)->vec2<f32>{let a=rec(s,0u);let f=rec(s,4u);let lo=select(select(0.,f.x,cell==1u),f.y,cell==2u);let hi=select(select(f.x,f.y,cell==1u),1.,cell==2u);return a.x-a.z*.5+vec2<f32>(lo,hi)*a.z;}
fn frontZ(s:u32,cell:u32)->f32{return rec(s,6u)[cell];}






fn frontageType(s:u32,cell:u32)->u32{return (u32(rec(s,5u).x)>>(cell*3u))&7u;}
fn frontageAperture(s:u32,cell:u32)->vec4<f32>{let a=rec(s,0u);let fb=frontageBounds(s,cell);let pitch=fb.y-fb.x;let kind=frontageType(s,cell);let door=kind>=3u;return vec4<f32>((fb.x+fb.y)*.5,a.y+select(select(1.48,1.88,kind==0u),select(1.03,1.15,kind==4u),door),select(select(pitch*.30,pitch*.41,kind==2u),select(min(.51,pitch*.29),pitch*.40,kind==4u),door),select(select(.63,.32,kind==0u),select(1.02,1.14,kind==4u),door));}











// Three narrow linked leaves fold entirely over the level A platform.




// R3.12 family-0 original fitted edge waves, field and surface core.
// WGSL syntax/explicit arguments are new. No renderer, vertex or instance lists.
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }
fn br_h11(p:f32)->f32 {return fract(sin(p*127.1+311.7)*43758.5453123);}
fn br_hash31(pIn:vec3<f32>)->f32 {var p=fract(pIn*0.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn br_noise3(p:vec3<f32>)->f32 {let i=floor(p);var f=fract(p);f=f*f*(vec3<f32>(3.0)-2.0*f);return mix(mix(mix(br_hash31(i),br_hash31(i+vec3<f32>(1,0,0)),f.x),mix(br_hash31(i+vec3<f32>(0,1,0)),br_hash31(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(br_hash31(i+vec3<f32>(0,0,1)),br_hash31(i+vec3<f32>(1,0,1)),f.x),mix(br_hash31(i+vec3<f32>(0,1,1)),br_hash31(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn br_fbm(pIn:vec3<f32>)->f32 {var p=pIn;var s=0.0;var a=0.5;for(var i=0;i<5;i++){s+=a*br_noise3(p);p=p*2.03+vec3<f32>(7.1,-3.7,11.9);a*=0.5;}return s;}








































// Return original [chips, contour, weight] contributions instead of GLSL inout.




fn br_variant(qIn:vec3<f32>,variant:i32)->vec3<f32>{var q=qIn;if((variant&1)==1){q.x=-q.x;}if((variant&2)==2){q.z=-q.z;}return q;}
// Exact original family-0 distance, in metres. This is not guaranteed Lipschitz 1.0


fn br_xi(q:vec3<f32>)->vec3<f32>{let rr=max(length(q),1e-4);let cap=0.13*9.5;let radial2=dot(q.xy,q.xy);let angularRadius=sqrt(radial2+cap*cap*exp(-radial2/(cap*cap)));let angle=acos(clamp(q.y/angularRadius,-0.999999,0.999999));return vec3<f32>(log2(rr)-2.0,-q.z/rr-1.0,angle);}
// New explicit isotropic footprint bridge. Original wave, 17 octaves and gates
// remain; the original screen dFdx/dFdy footprint is NOT claimed equivalent.
fn br_microscope(q:vec3<f32>,qFootprint:f32)->f32 {
 let xi=br_xi(q);let e=max(qFootprint,1e-7);
 let fp=max(length(br_xi(q+vec3<f32>(e,0,0))-xi),max(length(br_xi(q+vec3<f32>(0,e,0))-xi),length(br_xi(q+vec3<f32>(0,0,e))-xi)));
 var s=0.0;var sc=1.0;for(var j=0;j<17;j++){if(fp*sc>=1.10){break;}let gate=1.0-smoothstep(0.48,1.10,fp*sc);let x=xi*sc;s+=gate*(cos(cos(x.z)*cos(x.x)+cos(x.y)*cos(x.y)+cos(x.y)*cos(x.x))-0.6556965)/sc;sc*=2.0;}return s;
}
// Raw original family-0 albedo, roughness and height. No lighting/tone mapping.
fn kpBrickOriginalSurface(pLocalM:vec3<f32>,seed:f32,variant:i32,variation:f32,physicalFootprintM:f32)->KpSurface {
 let r0=br_h11(seed+1.2);let r1=br_h11(seed+2.7);let r2=br_h11(seed+4.9);let r3=br_h11(seed+8.3);
 var q=br_variant(pLocalM/KP_BRICK_SCALE,variant);let ang=(r0-0.5)*2.2*variation;let ca=cos(ang);let sa=sin(ang);
 let oldXZ=q.xz;q.x=ca*oldXZ.x+sa*oldXZ.y;q.z=-sa*oldXZ.x+ca*oldXZ.y;
 q+=variation*vec3<f32>((r1-0.5)*18.0,(r2-0.5)*12.0,(r3-0.5)*16.0);
 let body=br_fbm(q*1.15+vec3<f32>(-2.7,4.1,8.3));let fire=br_fbm(q*2.65+vec3<f32>(7.1,-5.2,1.7));let firing=smoothstep(0.27,0.79,0.66*body+0.34*fire);
 let reduction=smoothstep(0.69,0.88,br_fbm(q*0.82+vec3<f32>(12.1,1.4,-9.7)))*smoothstep(0.38,0.82,firing);
 let poreA=br_noise3(q*29.7+vec3<f32>(2.3,9.1,-4.4));let poreB=br_noise3(q*61.3+vec3<f32>(-7.2,3.7,14.6));let pore=smoothstep(0.79,0.92,poreA)*smoothstep(0.64,0.84,poreB);
 let skin=smoothstep(0.36,0.76,br_fbm(q*5.1+vec3<f32>(1.9,-3.2,11.4)));let mm=br_microscope(q*9.5,max(physicalFootprintM,0.0)/KP_BRICK_SCALE*9.5);
 var base=mix(vec3<f32>(0.235,0.043,0.023),vec3<f32>(0.455,0.105,0.048),smoothstep(0.14,0.76,firing));base=mix(base,vec3<f32>(0.625,0.205,0.082),smoothstep(0.58,0.92,firing)*0.34);base=mix(base,vec3<f32>(0.19,0.055,0.038),reduction*0.63);
 let rough=clamp(0.90-0.10*firing+0.055*reduction+0.075*pore,0.68,0.985);
 let h=(body-0.5)*0.010+(skin-0.5)*0.004+mm*0.0034-pore*0.0048;
 base*=0.965+0.07*(skin-0.5);base*=mix(1.0,0.93+0.14*br_h11(seed+19.7),variation);
 return KpSurface(h*KP_BRICK_SCALE,base,rough);
}

// R3.12 original macro/micro/observed field algebra. Explicit coordinates and
// derivative-free physical footprint are receiver bridges. No patch silhouette.
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}
fn pl_rotate(v:vec3<f32>,axis:vec3<f32>,a:f32)->vec3<f32>{let c=cos(a);let s=sin(a);return v*c+cross(axis,v)*s+axis*dot(axis,v)*(1.0-c);}
fn pl_warp(p:vec3<f32>,phase:vec3<f32>)->vec3<f32>{let c1=vec3<f32>(0.12,1.42,0.04)+0.035*phase;let a1=normalize(vec3<f32>(0.38,0.82,0.42));let v1=p-c1;let t1=0.65*exp(-dot(v1,v1)/(2.4*2.4))*sin(1.45*dot(a1,v1)+0.7+phase.x);let q=c1+pl_rotate(v1,a1,t1);let c2=vec3<f32>(-0.16,1.63,-0.06)+0.025*phase;let a2=normalize(vec3<f32>(-0.67,0.15,0.73));let v2=q-c2;let t2=0.20*exp(-dot(v2,v2)/(2.1*2.1))*sin(4.1*dot(a2,v2)+2.0+phase.y);return c2+pl_rotate(v2,a2,t2);}
fn pl_xi(p:vec3<f32>,phase:vec3<f32>)->vec3<f32>{let q=pl_warp(p,phase)+vec3<f32>(2.73,0.91,1.37);let r=max(length(q),1e-4);return vec3<f32>(log2(r)-2.0,-q.z/r,atan2(q.x,q.y));}
fn pl_cell(xi:vec3<f32>,sc:f32)->f32{let a=cos(sc*xi.z)*cos(sc*xi.x)+cos(sc*xi.y)*cos(sc*xi.y)+cos(sc*xi.y)*cos(sc*xi.x);return cos(a)-0.6556965458313674;}
fn pl_macroFast(p:vec3<f32>)->f32{let xi=pl_xi(p,vec3<f32>(0.7,-1.3,2.1));let s=pl_cell(xi,1.0)+pl_cell(xi,2.0)*0.5+pl_cell(xi,4.0)*0.25+pl_cell(xi,8.0)*0.125+pl_cell(xi,16.0)*0.0625;return tanh(0.78*s);}
fn pl_microFast(p:vec3<f32>)->f32{let xi=pl_xi(p,vec3<f32>(0.7,-1.3,2.1));let s=pl_cell(xi,16.0)*0.0625+pl_cell(xi,32.0)*0.03125+pl_cell(xi,64.0)*0.015625;return tanh(10.5*s);}
fn pl_q(p:vec3<f32>,a:KpPlasterParams)->vec3<f32>{return vec3<f32>((p.xy-a.centerM)/max(a.halfM,vec2<f32>(0.08)),p.z*2.0);}
fn kpPlasterMacro(p:vec3<f32>,a:KpPlasterParams)->f32{let low=pl_macroFast(pl_q(p,a)+vec3<f32>(-0.17,0.31,0.09));let coarse=sin(p.x*2.7+p.y*0.9)*sin(p.y*3.2-p.x*0.7);return clamp(0.48*low+0.52*coarse,-1.0,1.0);}
fn kpPlasterMicro(p:vec3<f32>,a:KpPlasterParams)->f32{let m=pl_microFast(pl_q(p,a)*vec3<f32>(2.65,2.52,3.55)+vec3<f32>(-0.27,0.44,-0.19));let r=sin(p.x*47.0-p.y*39.0+p.z*58.0)*sin(p.x*31.0+p.y*37.0-p.z*43.0);return clamp(0.78*m+0.22*r,-1.0,1.0);}



// Syntax port of locked V26 waterWeatherMasks dependency closure.
// pField is the ORIGINAL normalized material field coordinate, not metres.
// localPosM/dimensionsM are original physical local position/size for gates.
fn vw_hash31(pIn:vec3<f32>)->f32 {var p=fract(pIn*0.1031);p+=vec3<f32>(dot(p,p.yzx+vec3<f32>(33.33)));return fract((p.x+p.y)*p.z);}
fn vw_hash33(pIn:vec3<f32>)->vec3<f32> {let p=vec3<f32>(dot(pIn,vec3<f32>(127.1,311.7,74.7)),dot(pIn,vec3<f32>(269.5,183.3,246.1)),dot(pIn,vec3<f32>(113.5,271.9,124.6)));return fract(sin(p)*43758.5453123);}
fn vw_fade(f:vec3<f32>)->vec3<f32>{return f*f*f*(f*(f*6.0-vec3<f32>(15.0))+vec3<f32>(10.0));}
fn vw_valueNoise3(p:vec3<f32>)->f32 {let i=floor(p);let f=vw_fade(fract(p));return mix(mix(mix(vw_hash31(i),vw_hash31(i+vec3<f32>(1,0,0)),f.x),mix(vw_hash31(i+vec3<f32>(0,1,0)),vw_hash31(i+vec3<f32>(1,1,0)),f.x),f.y),mix(mix(vw_hash31(i+vec3<f32>(0,0,1)),vw_hash31(i+vec3<f32>(1,0,1)),f.x),mix(vw_hash31(i+vec3<f32>(0,1,1)),vw_hash31(i+vec3<f32>(1,1,1)),f.x),f.y),f.z);}
fn vw_gcorner(i:vec3<f32>,f:vec3<f32>,o:vec3<f32>)->f32{return dot(normalize(vw_hash33(i+o)*2.0-vec3<f32>(1.0)),f-o);}
fn vw_gradientNoise3(p:vec3<f32>)->f32 {let i=floor(p);let f=fract(p);let u=vw_fade(f);let n=mix(mix(mix(vw_gcorner(i,f,vec3<f32>(0,0,0)),vw_gcorner(i,f,vec3<f32>(1,0,0)),u.x),mix(vw_gcorner(i,f,vec3<f32>(0,1,0)),vw_gcorner(i,f,vec3<f32>(1,1,0)),u.x),u.y),mix(mix(vw_gcorner(i,f,vec3<f32>(0,0,1)),vw_gcorner(i,f,vec3<f32>(1,0,1)),u.x),mix(vw_gcorner(i,f,vec3<f32>(0,1,1)),vw_gcorner(i,f,vec3<f32>(1,1,1)),u.x),u.y),u.z);return n*0.5+0.5;}
fn vw_fbmGradient(pIn:vec3<f32>)->f32 {var p=pIn;var v=0.0;var a=0.52;var total=0.0;for(var i=0;i<5;i++){v+=vw_gradientNoise3(p)*a;total+=a;p=p*2.03+vec3<f32>(19.1,7.7,13.4);a*=0.49;}return v/total;}
fn vw_ridgedFbm(pIn:vec3<f32>)->f32 {var p=pIn;var v=0.0;var a=0.56;var total=0.0;for(var i=0;i<5;i++){let n=1.0-abs(vw_gradientNoise3(p)*2.0-1.0);v+=n*n*a;total+=a;p=p*2.11+vec3<f32>(11.7,5.3,17.9);a*=0.47;}return v/total;}
fn vw_fbmValueFast(pIn:vec3<f32>)->f32 {var p=pIn;var v=0.0;var a=0.54;var total=0.0;for(var i=0;i<4;i++){v+=vw_valueNoise3(p)*a;total+=a;p=p*2.05+vec3<f32>(7.3,15.1,3.9);a*=0.48;}return v/total;}
fn vw_domainWarp(p:vec3<f32>)->vec3<f32>{return vec3<f32>(vw_fbmValueFast(p+vec3<f32>(17.1,3.8,9.2)),vw_fbmValueFast(p+vec3<f32>(4.4,19.7,12.1)),vw_fbmValueFast(p+vec3<f32>(13.8,7.2,23.4)))-vec3<f32>(0.5);}
fn vw_seedVector(s:f32,multiplier:f32)->vec3<f32>{return vec3<f32>(s*0.0113,s*0.0197,s*0.0311)*multiplier;}
fn kpV26WaterWeather(pField:vec3<f32>,n:vec3<f32>,localPosM:vec3<f32>,dimensionsM:vec3<f32>,waterSeed:f32,weatherSeed:f32)->vec2<f32>{
 let p=pField;let an=abs(n);let horizontal=select(p.x,p.z,an.x>an.z);let yNorm=clamp(localPosM.y/max(dimensionsM.y,0.001)+0.5,0.0,1.0);
 let column=horizontal*5.4+waterSeed*0.0031;let columnId=floor(column);let local=fract(column)-0.5;
 let jitter=(vw_hash31(vec3<f32>(columnId,waterSeed*0.013,7.0))-0.5)*0.56;
 let width=mix(0.045,0.16,vw_hash31(vec3<f32>(columnId,waterSeed*0.019,13.0)));
 let line=1.0-smoothstep(width,width+0.055,abs(local-jitter));
 let start=mix(0.52,1.02,vw_hash31(vec3<f32>(columnId,waterSeed*0.023,19.0)));
 let lengthV=mix(0.16,0.78,vw_hash31(vec3<f32>(columnId,waterSeed*0.029,23.0)));
 let verticalGate=smoothstep(start-lengthV-0.05,start-lengthV+0.055,yNorm)*(1.0-smoothstep(start-0.025,start+0.045,yNorm));
 let streakGate=smoothstep(0.48,0.86,vw_hash31(vec3<f32>(columnId,waterSeed*0.037,31.0)));let streak=line*verticalGate*streakGate;
 let waterCoord=vec3<f32>(horizontal*1.75,yNorm*3.0,waterSeed*0.009);
 let broad=smoothstep(0.54,0.82,vw_fbmValueFast(waterCoord+vw_domainWarp(waterCoord*0.7)*0.45));
 let lowerDamp=(1.0-smoothstep(0.06,0.34,yNorm))*smoothstep(0.35,0.78,vw_fbmValueFast(vec3<f32>(p.x*1.3,p.z*1.3,waterSeed*0.011)));
 let waterMask=clamp(streak*0.92+broad*verticalGate*0.32+lowerDamp*0.58,0.0,1.0);
 let edgeCoord=abs(localPosM)/max(dimensionsM*0.5,vec3<f32>(0.001));let edgeCount=smoothstep(0.72,0.99,edgeCoord.x)+smoothstep(0.72,0.99,edgeCoord.y)+smoothstep(0.72,0.99,edgeCoord.z);
 let edgeMask=smoothstep(1.08,1.88,edgeCount);let topExposure=smoothstep(0.05,0.72,n.y)*smoothstep(0.35,0.98,yNorm);
 let weatherNoise=vw_fbmGradient(p*1.82+vw_seedVector(weatherSeed,0.74));let weatherFine=vw_ridgedFbm(p*7.1+vw_seedVector(weatherSeed,1.31));
 let weatherMask=clamp((edgeMask*0.72+topExposure*0.55)*smoothstep(0.30,0.84,weatherNoise)+smoothstep(0.76,0.96,weatherFine)*0.18,0.0,1.0);
 return vec2<f32>(waterMask,weatherMask);
}
// Existing explicitly authored unified fabric bridge, not source physical years.
struct KpFabricState { moisture:f32, damage:f32, retention:f32, thicknessM:f32, baseScale:f32, roughDelta:f32, }
fn kpFabricState(age:f32,exposure:f32,sourceRunoff:f32,originalWeather:f32,drainage:f32,repair:f32,originalMacro:f32,originalMicro:f32,originalThicknessM:f32,minThicknessM:f32,maxThicknessM:f32)->KpFabricState {
 let a=clamp(age,0.0,1.0);let e=clamp(exposure,0.0,1.0);let r=clamp(repair,0.0,1.0);
 let moisture=clamp(sourceRunoff,0.0,1.0)*e*(1.0-clamp(drainage,0.0,1.0));
 let damage=clamp(a*(0.24+0.38*e+0.58*moisture+0.32*originalWeather*e)*(1.0-r),0.0,1.0);
 let bond=clamp(0.47+0.32*originalMacro+0.07*originalMicro,0.20,0.80);
 let thickness=clamp(originalThicknessM*(1.0-0.48*damage)+0.002*r,minThicknessM,maxThicknessM);
 return KpFabricState(moisture,damage,bond-damage,thickness,1.0-0.22*moisture-0.12*damage,0.035*damage-0.16*moisture);
}

// Apply the exact same resolved state used by receiver coat retention/thickness.
// Requires KpSurface from brick-core. No second independently computed age.
fn kpApplyFabricSurface(original:KpSurface,state:KpFabricState)->KpSurface {
 return KpSurface(original.height,original.albedo*state.baseScale,clamp(original.roughness+state.roughDelta,0.08,0.995));
}

// User Library timber v3, exact box coordinate/noise/field formulas in WGSL.
// KpSurface must be declared by the parent brick module before this string.
// No bindings, stages, renderer, textures, geometry buffers or scene objects.
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}









































// pSourceM = member-local metres + inherited source grainOffset, +X axial.
// Signed normal displacement; use only this function in the geometry distance.

// Conservative magnitude bound for the original vertex displacement, in metres.
// Source macro noise is nonnegative with sum (0.58+0.261+0.11745)/0.94;
// original normal class multiplier is at most 1.08. This is not a Lipschitz bound.

// New screen-independent AA bridge. This is a nominal physical frequency estimate,
// not the original screen derivative and not a proof of derivative equivalence.
// fp=0 preserves the unfiltered original field exactly (up to f32 arithmetic).

// Complete source material terms before source-specific lighting or gamma.
// The caller supplies the actual member-local surface normal and face class.
// 0=longitudinal, 1=end grain, 2=joint cut, 3=weathered side.
// No camera-ray parallax march is hidden in this pure field call.


// Original fragment micro-height: PBR normal detail, NOT a replacement for macro geometry.

// Compatibility entry: top longitudinal face of the original default box timber.
// age/wet/repair are reserved host arguments; the original v3 has no such model.
// Scene overlays must be explicit outside this source-preserving material leaf.


// STONE_STUDY same-page stoneFields, kind 0 (the stone receiver's default).
// KpSurface is supplied once by the shared brick core; do not redefine it here.
// No texture, mesh, voxel atlas, material cache or additional noise family.
// Authored unit bridge: a 0.42 m longest side maps to 3.4 specimen units.
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_KIND:i32 = 0;
const KP_STONE_MASTER_SEED:u32 = 8231u;
// Original normalizeSeedDNA offsets: color +401, pore +307, weather +601.
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;








// New explicit isotropic footprint bridge replacing screen-space fwidth(line).
// It reevaluates the ORIGINAL line and warp at three metric axis offsets.
// This bound-like footprint is not screen-space fwidth equivalence and is not
// complete band-limiting of the original noise; zero footprint keeps 0.008.

// Original kind-0 stoneFields arithmetic. Fixed original material controls:
// sSurface.x=1, sSurface.y=0.7, sDisplay.w=1, sRelief=1, uEventCount=0.
// Original event-loop contribution is therefore 0. Original pits still apply.
// Branches 1/2/3 and their inactive grain/phase/crystal evaluations are omitted.

// New, authored age/moisture/repair bridge copied from resolveStoneFabric.
// Its original default wear=0.15 is fixed because this call has no wear input.
// No calibrated decay law, damage geometry, formation events or SDF is ported.
// Age changes original wet/rough uniforms only; original height stays intact.


// STONE_STUDY original sKind == 3 (blue-gray slate) surface branch.
// Append AFTER existing KP_STONE_WGSL; reuse its st_* source functions/seeds.
// Receiver controls below are explicit design bindings, NOT physical calibration.
// Original event count remains 0, matching the current surface-only port.
struct KpStoneSlateParams {
 sourceScaleM:f32, materialScale:f32, mineral:f32, chroma:f32, relief:f32,
};


// Same existing authored age/moisture/repair bridge; only source branch differs.











const RC_PI:f32=3.14159265359;
struct KpClothM{col:vec3<f32>,roughW:f32,roughF:f32,sheen:f32,bump:f32,trans:f32,irr:f32,fuzz:f32,slub:f32,open:f32,macroTone:f32,age:f32,farId:f32,meso:f32,den:vec2<f32>}
struct KpClothPattern{h:f32,thread:f32,orient:f32,variation:f32,gap:f32,nearW:f32,midW:f32,farW:f32,slub:f32,roughVar:f32,wear:f32,bundle:f32}










// Source material coordinates are centimetres. This explicit footprint bridge
// replaces screen derivatives; physical microheight always uses footprint zero.

















struct MaterialResult{surface:KpSurface,metal:f32,cavity:f32,specular:f32,coat:f32,coatRough:f32}
struct PhysicalState{age:f32,wet:f32,repair:f32,q:vec3<f32>}

struct SettlementField{d:f32,geo:GeoHit,sectionCap:u32}
fn dna(h:GeoHit)->vec4<f32>{if(h.stateId==0u){return vec4<f32>(.24,.1,0.,0.);}let a=rec(h.stateId-1u,0u);let c=rec(h.stateId-1u,2u);let event=rec(h.stateId-1u,3u);let added=event.y>.5&&((h.componentId>=1000000u&&h.componentId<1001000u)||(h.componentId>=4000000u&&h.componentId<4004000u));let shelter=h.componentId>=1200000u&&h.componentId<1201000u;let eventYear=select(event.w,rec(h.stateId-1u,5u).y,shelter);let age=select(c.x,clamp((u.size.w-eventYear)/40.,0.,1.),added||shelter);return vec4<f32>(age,f32(h.stateId)*.731+select(0.,9.17,added),select(c.y,.05,added),a.y);}
fn materialUV(p:vec3<f32>,n:vec3<f32>)->vec2<f32>{if(abs(n.x)>.6){return p.zy;}if(abs(n.z)>.6){return p.xy;}return p.xz;}

fn sourcePlasterParams(h:GeoHit,p:vec3<f32>)->KpPlasterParams{var dark=vec3<f32>(.265,.235,.18);var light=vec3<f32>(.49,.435,.335);if(h.buildingId==2u){dark=vec3<f32>(.19,.24,.215);light=vec3<f32>(.365,.425,.365);}let d=dna(h);if(d.z>.3){dark=mix(dark,vec3<f32>(.32,.30,.245),d.z);light=mix(light,vec3<f32>(.52,.49,.405),d.z);}return KpPlasterParams(vec2<f32>(0.,1.35),vec2<f32>(2.,1.5),.0165,.0085,0.,.008,.025,.0002,dark,light,.0008,.000008,.018);}
fn wallCoordinates(h:GeoHit,p:vec3<f32>)->vec3<f32>{let uv=materialUV(p,h.n);return vec3<f32>(uv.x,p.y-dna(h).w,h.d);}
fn fabricAt(h:GeoHit,p:vec3<f32>)->KpFabricState{let a=rec(h.stateId-1u,0u);let b=rec(h.stateId-1u,1u);let d=dna(h);let q=wallCoordinates(h,p);let params=sourcePlasterParams(h,p);let cell=frontageCell(h.stateId-1u,p.x);let actualFront=frontZ(h.stateId-1u,cell);let local=p-vec3<f32>(a.x,a.y+a.w*.5,(actualFront+b.y)*.5);let water=kpV26WaterWeather(p/4.,h.n,local,vec3<f32>(a.z,a.w,b.y-actualFront),17.+d.y*53.,65.+d.y*53.);let pipeMask=(1.-smoothstep(.10,.48,length(p.xz-vec2<f32>(a.x+a.z*.5-.15,frontZ(h.stateId-1u,2u)-.14))))*(1.-smoothstep(a.w-.04,a.w+.05,p.y-a.y));let seam=(1.-smoothstep(.02,.30,abs(p.y-a.y)))*.18;let event=rec(h.stateId-1u,3u);let additionExterior=event.y>.5&&h.componentId>=1000000u&&h.componentId<1001000u;let exterior=select(.12,1.,additionExterior||(h.componentId>=1400010u&&h.componentId<1400020u)||abs(p.z-actualFront)<.25||abs(p.z-b.y)<.25||abs(abs(p.x-a.x)-a.z*.5)<.25);// Dry wall retains a coherent coat; strongest loss follows actual opening corners, joints and drains. Shape and PBR resolve this same state.
 let ap=frontageAperture(h.stateId-1u,cell);let sill=ap.y-ap.w;let below=(1.-smoothstep(sill-.04,sill+.10,p.y))*smoothstep(a.y+.08,a.y+.45,p.y);let corner=1.-smoothstep(.05,.24,abs(abs(p.x-ap.x)-ap.z));let frontContact=1.-smoothstep(.12,.26,abs(p.z-actualFront));let runoff=below*corner*frontContact;let fb=frontageBounds(h.stateId-1u,cell);let hasShelter=(u32(rec(h.stateId-1u,4u).z)&(1u<<cell))!=0u;let sheltered=hasShelter&&abs(p.x-(fb.x+fb.y)*.5)<(fb.y-fb.x)*.44&&p.y<a.y+a.w-.40;let cover=select(1.,.56,sheltered&&frontContact>.5);let wet=clamp(exterior*cover*(.05+.40*water.x+.60*runoff+.68*pipeMask+seam),0.,.95);let exposure=clamp(exterior*cover*(.30+.20*water.y+.55*runoff+.60*pipeMask+seam),0.,1.);let macroTone=kpPlasterMacro(q,params);let microTone=kpPlasterMicro(q,params);let thickness=clamp(params.thicknessM+params.reliefM*macroTone,params.minThicknessM,params.maxThicknessM);return kpFabricState(d.x,exposure,wet,water.y,.1,d.z,macroTone,microTone,thickness,.001,.025);}
fn brickCoordinate(h:GeoHit,p:vec3<f32>,baseD:f32)->vec3<f32>{let uv=materialUV(p,h.n);let row=floor(uv.y/.07);let shift=f32(i32(row)&1)*.125;return vec3<f32>(fract((uv.x-shift)/.25)*.25-.125,fract(uv.y/.07)*.07-.035,.055384615+baseD+.0165);}
fn brickIdentity(h:GeoHit,p:vec3<f32>)->vec2<f32>{let uv=materialUV(p,h.n);let row=floor(uv.y/.07);let shift=f32(i32(row)&1)*.125;let seed=dna(h).y+floor((uv.x-shift)/.25)*13.7+row*41.3;return vec2<f32>(seed,floor(br_h11(seed)*4.));}


fn sceneMaterial(h:GeoHit,p:vec3<f32>,n:vec3<f32>,fp:f32,cap:u32)->MaterialResult{var s=KpSurface(0.,vec3<f32>(.3),.8);var metal=0.;var cavity=1.;var spec=1.;var coat=0.;var coatRough=.25;let d=dna(h);
 if(h.stateId==0u){return MaterialResult(KpSurface(0.,vec3<f32>(.28),.92),0.,1.,1.,0.,.25);}
 
 if(h.materialId==2u){let id=brickIdentity(h,p);s=kpBrickOriginalSurface(brickCoordinate(h,p,h.d),id.x,i32(id.y),.42,fp);if(cap==0u){s=kpApplyFabricSurface(s,fabricAt(h,p));}}
 
 
 
 
 
 
 
 return MaterialResult(s,metal,cavity,spec,coat,coatRough);}

// Analytic current-parameter bounds are recorded in qa/material-distance-bounds.txt.
// 0.012m is deliberately wider than every possible displacement; this is a
// distance-value bound, not a claim that the displaced field is a strict SDF.
const MATERIAL_DISTANCE_BOUND:f32=.012;



struct Stats {hit:atomic<u32>,miss:atomic<u32>,exhausted:atomic<u32>,maximumSteps:atomic<u32>,retried:atomic<u32>,glassRays:atomic<u32>,boundOnly:atomic<u32>,reserved:atomic<u32>,visibilityRetried:atomic<u32>,visibilityMaximumSteps:atomic<u32>,extendedPrimary:atomic<u32>,candidateOverflows:atomic<u32>,activeQueries:atomic<u32>}

struct HitRecord { ray:vec4<f32>,local:vec4<f32>,ids:vec4<u32>,normal:vec4<f32>,glass:vec4<f32>,through:vec4<f32> }

struct RetryQueue {count:atomic<u32>,indices:array<u32,256>}




// Initial 64-step exit and final sparse continuation. No scene or material state is copied.


















struct Frag { @location(0) color:vec4<f32>, @builtin(frag_depth) depth:f32 }



struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }

@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;

struct SampleHit { ids:vec4<u32>,local:vec4<f32>,normal:vec4<f32>,extra:vec4<u32> }
@group(1) @binding(2) var<storage,read_write> mapHits:array<SampleHit>;

fn unpackMapHit(h:SampleHit)->GeoHit{return GeoHit(h.local.w,h.ids.x,h.ids.y,h.ids.z,h.ids.w,h.local.xyz,h.normal.xyz,h.extra.x);}






@compute @workgroup_size(32) fn sampleColor2(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w!=2.){return;}let h=unpackMapHit(mapHits[i]);if(h.materialId!=2u){return;}let m=sceneMaterial(h,o.position.xyz,o.normal.xyz,.18,0u).surface;o.color=vec4<f32>(m.albedo,m.roughness);mapSamples[i]=o;}
