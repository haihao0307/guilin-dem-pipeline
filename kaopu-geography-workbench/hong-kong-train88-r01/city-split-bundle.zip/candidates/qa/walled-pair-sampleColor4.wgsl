
struct Frame { eye:vec4<f32>,forward:vec4<f32>,right:vec4<f32>,up:vec4<f32>,cut:vec4<f32>,size:vec4<f32>,tile:vec4<u32>,controls:vec4<f32> }
@group(0) @binding(0) var<uniform> u:Frame;

@group(0) @binding(1) var<storage,read> worldRules:array<vec4<f32>>;
struct GeoHit{d:f32,materialId:u32,buildingId:u32,componentId:u32,stateId:u32,q:vec3<f32>,n:vec3<f32>,objectId:u32}
// Short-lived per-ray candidate keys, never persistent world/brick instances.
var<private> fieldCompetition:bool;
var<private> fieldExcluded:array<vec2<u32>,32>;
var<private> fieldExcludedCount:u32;

fn rec(s:u32,k:u32)->vec4<f32>{return worldRules[s*8u+k];}
















// Dated household event, partitioned along existing execution groups.






// Metric frontage rules are compiled with household uses, not randomized per pixel.






















// Three narrow linked leaves fold entirely over the level A platform.




// R3.12 family-0 original fitted edge waves, field and surface core.
// WGSL syntax/explicit arguments are new. No renderer, vertex or instance lists.
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }












































// Return original [chips, contour, weight] contributions instead of GLSL inout.





// Exact original family-0 distance, in metres. This is not guaranteed Lipschitz 1.0



// New explicit isotropic footprint bridge. Original wave, 17 octaves and gates
// remain; the original screen dFdx/dFdy footprint is NOT claimed equivalent.

// Raw original family-0 albedo, roughness and height. No lighting/tone mapping.


// R3.12 original macro/micro/observed field algebra. Explicit coordinates and
// derivative-free physical footprint are receiver bridges. No patch silhouette.
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}












// Syntax port of locked V26 waterWeatherMasks dependency closure.
// pField is the ORIGINAL normalized material field coordinate, not metres.
// localPosM/dimensionsM are original physical local position/size for gates.












// Existing explicitly authored unified fabric bridge, not source physical years.
struct KpFabricState { moisture:f32, damage:f32, retention:f32, thicknessM:f32, baseScale:f32, roughDelta:f32, }


// Apply the exact same resolved state used by receiver coat retention/thickness.
// Requires KpSurface from brick-core. No second independently computed age.


// User Library timber v3, exact box coordinate/noise/field formulas in WGSL.
// KpSurface must be declared by the parent brick module before this string.
// No bindings, stages, renderer, textures, geometry buffers or scene objects.
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}
fn kpWoodDefaultParams()->KpWoodParams {
  var p:KpWoodParams;
  p.seed=0.7598925376683223;
  p.ringFrequency=22.0;
  p.ringScale=1.1240120360301806;
  p.ringWarp=1.174825141889602;
  p.fiberFrequency=8.73036012029089;
  p.fineFiberFrequency=72.0;
  p.poreFrequency=280.0;
  p.fiberStrength=0.34;
  p.colorBias=-0.015293409994337707;
  p.roughness=0.892843876922503;
  p.angleOffset=0.7194436165372647;
  p.textureScale=1.0;
  p.grainContrast=0.20902697160467504;
  p.detailFineness=1.0188769673019646;
  p.microReliefM=0.00028000000000000003;
  p.parallaxM=0.0010500000000000002;
  p.macroDisplacementM=0.0005600000000000001;
  p.reliefScale=0.7741619322448968;
  p.reliefQuality=3.0;
  p.parallaxSteps=12.0;
  p.clearcoat=0.0;
  p.clearcoatRoughness=1.0;
  p.specularLevel=0.13;
  p.distanceFadeStart=9.0;
  p.distanceFadeEnd=28.0;
  p.toolPhase=0.2499335163798811;
  p.crackPhase=1.1871775190974605;
  p.knotPhase=1.4286763223548267;
  p.pithOffset=vec2<f32>(0.04244730153121054,-0.07805894820950925);
  p.darkGrainColor=vec3<f32>(0.10224173308810132,0.06480326669290577,0.04091519690685319);
  p.lightGrainColor=vec3<f32>(0.31398871337571754,0.1946178304415758,0.11443537382697373);
  p.agedSurfaceColor=vec3<f32>(0.18782077230067787,0.13563332965520566,0.09758734714186246);
  p.weatheredColor=vec3<f32>(0.23455058216100522,0.21586050011389926,0.18782077230067787);
  p.freshCutColor=vec3<f32>(0.39157247774972326,0.26225065752969623,0.162029375639111);
  p.cavityColor=vec3<f32>(0.04091519690685319,0.027320891639074894,0.0202885630566524);
  return p;
}
fn kwSaturate(value:f32, wp:KpWoodParams, fp:f32)->f32 { return clamp(value, 0.0, 1.0); }

fn kwHash31(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  p = fract(p * 0.1031 + wp.seed * vec3<f32>(13.71, 47.13, 91.77));
  p += vec3<f32>(dot(p, p.yzx + vec3<f32>(33.33)));
  return fract((p.x + p.y) * p.z);
}

fn kwValueNoise(p:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var i:vec3<f32> = floor(p);
  var f:vec3<f32> = fract(p);
  f = f * f * (vec3<f32>(3.0) - 2.0 * f);
  return mix(
    mix(mix(kwHash31(i + vec3<f32>(0,0,0), wp, fp), kwHash31(i + vec3<f32>(1,0,0), wp, fp), f.x),
        mix(kwHash31(i + vec3<f32>(0,1,0), wp, fp), kwHash31(i + vec3<f32>(1,1,0), wp, fp), f.x), f.y),
    mix(mix(kwHash31(i + vec3<f32>(0,0,1), wp, fp), kwHash31(i + vec3<f32>(1,0,1), wp, fp), f.x),
        mix(kwHash31(i + vec3<f32>(0,1,1), wp, fp), kwHash31(i + vec3<f32>(1,1,1), wp, fp), f.x), f.y),
    f.z
  );
}

fn kwFbm(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  var result:f32 = 0.0;
  var amplitude:f32 = 0.5;
  var rotation:mat3x3<f32> = mat3x3<f32>(vec3<f32>(0.00,0.80,0.60),vec3<f32>(-0.80,0.36,-0.48),vec3<f32>(-0.60,-0.48,0.64));
  for (var i = 0; i < 5; i++) {
    result += amplitude * kwValueNoise(p, wp, fp);
    p = rotation * p * 2.03 + vec3<f32>(7.1, 3.7, 5.9);
    amplitude *= 0.5;
  }
  return result;
}

fn kwAaSine(coordinate:f32, wp:KpWoodParams, fp:f32)->f32 {
  var footprint:f32 = fp;
  var attenuation:f32 = 1.0 - smoothstep(0.42, 1.15, footprint);
  return 0.5 + 0.5 * sin(KP_WOOD_TAU * coordinate) * attenuation;
}

fn kwAaThinLine(coordinate:f32, width:f32, wp:KpWoodParams, fp:f32)->f32 {
  var distanceToLine:f32 = abs(sin(KP_WOOD_PI * coordinate));
  var footprint:f32 = min(0.22, fp * 0.75);
  return 1.0 - smoothstep(width + footprint, width + 0.085 + footprint, distanceToLine);
}

fn kwFlatAcross(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return select(g.y, g.z, abs(localNormal.y) > abs(localNormal.z));
}

fn kwFlatDepth(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return select(g.z, g.y, abs(localNormal.y) > abs(localNormal.z));
}

fn kwSidePhase(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, multiplier:f32, wp:KpWoodParams, fp:f32)->f32 {
  return kwFlatAcross(g, localNormal, wp, fp) * wp.fiberFrequency * multiplier;
}

fn kwSideAnisotropicNoise(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, axialFrequency:f32, crossFrequency:f32, phase:f32, wp:KpWoodParams, fp:f32)->f32 {
  var planarAcross:f32 = kwFlatAcross(g, localNormal, wp, fp);
  var planarDepth:f32 = kwFlatDepth(g, localNormal, wp, fp);
  var planarCoordinate:vec3<f32> = vec3<f32>(
    g.x * axialFrequency + phase,
    planarAcross * crossFrequency + wp.seed * 4.7,
    planarDepth * 0.72 + wp.seed * 9.1
  );
  return kwFbm(planarCoordinate, wp, fp);
}

fn kwSideValueNoise(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, axialFrequency:f32, crossFrequency:f32, phase:f32, wp:KpWoodParams, fp:f32)->f32 {
  var planarAcross:f32 = kwFlatAcross(g, localNormal, wp, fp);
  var planarDepth:f32 = kwFlatDepth(g, localNormal, wp, fp);
  var planarCoordinate:vec3<f32> = vec3<f32>(
    g.x * axialFrequency + phase,
    planarAcross * crossFrequency + wp.seed * 6.3,
    planarDepth * 0.54 + wp.seed * 3.8
  );
  return kwValueNoise(planarCoordinate, wp, fp);
}

fn kwRidgeFromNoise(value:f32, wp:KpWoodParams, fp:f32)->f32 {
  return 1.0 - abs(value * 2.0 - 1.0);
}

fn kwKnotSignal(g:vec3<f32>, crossPosition:vec2<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var broad:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    0.34,
    1.35,
    wp.knotPhase + 8.0
  , wp, fp);
  var compact:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    0.72,
    2.25,
    wp.knotPhase * 0.37 + 17.0
  , wp, fp);
  return smoothstep(0.71, 0.91, broad) * smoothstep(0.58, 0.86, compact);
}

fn kwWoodSignals(g:vec3<f32>, localNormal:vec3<f32>, surfaceClass:f32, wp:KpWoodParams, fp:f32)->vec4<f32> {
  var crossSection:f32 = step(0.72, abs(localNormal.x));

  var driftY:f32 = kwFbm(vec3<f32>(g.x * 0.24 + wp.seed * 3.1, 1.17, 7.93), wp, fp) - 0.5;
  var driftZ:f32 = kwFbm(vec3<f32>(g.x * 0.21 - wp.seed * 4.7, 9.31, 2.41), wp, fp) - 0.5;
  var longWarp:vec2<f32> = vec2<f32>(driftY, driftZ) * wp.ringWarp * 0.115;
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset + longWarp;
  var theta:f32 = atan2(crossPosition.y, crossPosition.x);

  var oval:f32 = 0.075 * sin(wp.seed * 31.0 + wp.angleOffset);
  var ringPosition:vec2<f32> = crossPosition * vec2<f32>(1.0 + oval, 1.0 - oval);
  var radial:f32 = length(ringPosition);
  var ringNoise:f32 = kwFbm(vec3<f32>(
    g.x * 0.18 + wp.seed * 2.4,
    ringPosition.x * 2.2,
    ringPosition.y * 2.2
  ), wp, fp);
  var ringCoordinate:f32 = radial * wp.ringFrequency * wp.ringScale;
  ringCoordinate += (ringNoise - 0.5) * wp.ringWarp * 1.18;
  ringCoordinate += sin(theta * 2.0 + wp.seed * 13.0) * 0.12 * wp.ringWarp;
  ringCoordinate += sin(theta * 5.0 - wp.seed * 7.0) * 0.045 * wp.ringWarp;
  var ringLine:f32 = kwAaThinLine(ringCoordinate, 0.060, wp, fp);
  var ringBody:f32 = kwAaSine(ringCoordinate + (ringNoise - 0.5) * 0.16, wp, fp);
  var ring:f32 = kwSaturate(ringBody * 0.62 + ringLine * 0.38, wp, fp);

  var broad:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.18, 1.55, wp.angleOffset, wp, fp);
  var flow:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.42, 3.35, wp.seed * 11.0 + 2.4, wp, fp);
  var medium:f32 = kwSideAnisotropicNoise(g, crossPosition, localNormal, 0.88, 7.20, wp.seed * 17.0 + 4.7, wp, fp);
  var knot:f32 = kwKnotSignal(g, crossPosition, localNormal, wp, fp);

  var phaseWarp:f32 = (broad - 0.5) * 5.4 + (flow - 0.5) * 2.9;
  phaseWarp += sin(g.x * 0.58 + theta * 1.7 + wp.seed * 19.0) * 0.50;
  phaseWarp += knot * (4.0 + 1.6 * sin(g.x * 1.05 + wp.knotPhase));

  var coarseLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.58, wp, fp) + phaseWarp + wp.angleOffset / KP_WOOD_TAU,
    0.065
  , wp, fp);
  var coarseVein:f32 = kwRidgeFromNoise(flow, wp, fp);
  var coarseFiber:f32 = kwSaturate(
    broad * 0.47 +
    coarseVein * 0.31 +
    coarseLine * 0.22
  , wp, fp);

  var mediumLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 1.85, wp, fp) + phaseWarp * 1.72 + wp.seed * 7.0,
    0.040
  , wp, fp);
  var mediumFiber:f32 = kwSaturate(
    medium * 0.47 +
    kwRidgeFromNoise(flow * 0.62 + medium * 0.38, wp, fp) * 0.37 +
    mediumLine * 0.16
  , wp, fp);

  var crackGate:f32 = smoothstep(
    0.79,
    0.94,
    kwSideValueNoise(g, crossPosition, localNormal, 0.32, 3.1, wp.crackPhase + 13.0, wp, fp)
  );
  var sideCrack:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.17, wp, fp)
      + phaseWarp * 0.16
      + wp.crackPhase / KP_WOOD_TAU,
    0.014
  , wp, fp) * crackGate;
  var radialGate:f32 = smoothstep(
    0.72,
    0.93,
    kwValueNoise(vec3<f32>(radial * 1.9, g.x * 0.27, wp.seed * 9.0), wp, fp)
  );
  var radialCrack:f32 = pow(max(0.0, sin(theta * 7.0 + wp.crackPhase)), 26.0)
    * smoothstep(0.08, 0.27, radial)
    * radialGate;
  var cracks:f32 = mix(sideCrack, max(sideCrack * 0.12, radialCrack), crossSection);

  return vec4<f32>(ring, coarseFiber, mediumFiber, cracks);
}

fn kwSecondarySignals(g:vec3<f32>, localNormal:vec3<f32>, wp:KpWoodParams, fp:f32)->vec4<f32> {
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
  var broadWarp:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    0.46,
    4.4,
    wp.seed * 21.0 + 1.7
  , wp, fp);
  var fineNoise:f32 = kwSideAnisotropicNoise(
    g,
    crossPosition,
    localNormal,
    1.55,
    18.0 * max(wp.detailFineness, 0.45),
    wp.seed * 29.0 + 5.3
  , wp, fp);
  var fineLine:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 4.6 * max(wp.detailFineness, 0.45), wp, fp)
      + (broadWarp - 0.5) * 8.5
      + wp.seed * 19.0,
    0.026
  , wp, fp);
  var fineFiber:f32 = kwSaturate(
    fineNoise * 0.53 +
    kwRidgeFromNoise(fineNoise, wp, fp) * 0.30 +
    fineLine * 0.17
  , wp, fp);

  var poreNoise:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    4.2 * max(wp.detailFineness, 0.45),
    38.0 * max(wp.detailFineness, 0.45),
    wp.seed * 23.0 + 11.0
  , wp, fp);
  var poreGate:f32 = kwSideValueNoise(
    g,
    crossPosition,
    localNormal,
    0.85,
    7.0,
    wp.seed * 31.0 + 2.0
  , wp, fp);
  var pores:f32 = smoothstep(0.865, 0.982, poreNoise)
    * smoothstep(0.52, 0.82, poreGate);

  var toolWave:f32 = kwAaSine(g.x * 1.45 + kwFlatAcross(g, localNormal, wp, fp) * 0.22 + wp.toolPhase / KP_WOOD_TAU, wp, fp);
  var toolMask:f32 = smoothstep(
    0.79,
    0.96,
    kwSideValueNoise(g, crossPosition, localNormal, 0.54, 2.3, wp.toolPhase + 5.0, wp, fp)
  );
  var tool:f32 = toolWave * toolMask;

  var knot:f32 = kwKnotSignal(g, crossPosition, localNormal, wp, fp);
  return vec4<f32>(fineFiber, pores, tool, knot);
}

fn kwMacroSignal(g:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  return kwFbm(g * vec3<f32>(0.12, 0.70, 0.70) + vec3<f32>(wp.seed * 5.0), wp, fp);
}

fn kwCoarseRelief(g:vec3<f32>, localNormal:vec3<f32>, surfaceClass:f32, wp:KpWoodParams, fp:f32)->f32 {
  var crossSection:f32 = step(0.72, abs(localNormal.x));
  var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
  var theta:f32 = atan2(crossPosition.y, crossPosition.x);
  var radial:f32 = length(crossPosition);

  var broadWarp:f32 = kwValueNoise(vec3<f32>(g.x * 0.18, crossPosition * 2.4) + vec3<f32>(wp.seed * 3.1), wp, fp);
  var sideBand:f32 = kwAaSine(
    kwSidePhase(g, crossPosition, localNormal, 0.62, wp, fp)
    + (broadWarp - 0.5) * 3.2
    + wp.angleOffset / KP_WOOD_TAU
  , wp, fp);
  var ringBand:f32 = kwAaSine(
    radial * wp.ringFrequency * wp.ringScale
    + (broadWarp - 0.5) * wp.ringWarp * 0.55
  , wp, fp);
  var sparseGate:f32 = smoothstep(
    0.84,
    0.965,
    kwValueNoise(vec3<f32>(g.x * 0.31 + wp.crackPhase, crossPosition * 4.1), wp, fp)
  );
  var sideCrack:f32 = kwAaThinLine(
    kwSidePhase(g, crossPosition, localNormal, 0.20, wp, fp)
    + (broadWarp - 0.5) * 0.22
    + wp.crackPhase / KP_WOOD_TAU,
    0.015
  , wp, fp) * sparseGate;
  var radialCrack:f32 = pow(max(0.0, sin(theta * 7.0 + wp.crackPhase)), 24.0)
    * smoothstep(0.08, 0.28, radial)
    * sparseGate;

  var sideHeight:f32 = (sideBand - 0.5) * 0.36 - sideCrack * 0.60;
  var endHeight:f32 = (ringBand - 0.5) * 0.34 - radialCrack * 0.68;
  return kwSaturate(0.5 + mix(sideHeight, endHeight, crossSection), wp, fp);
}

fn kwVertexHash(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  p = fract(p * 0.1031 + wp.seed * vec3<f32>(17.17, 41.73, 83.11));
  p += vec3<f32>(dot(p, p.yzx + vec3<f32>(31.32)));
  return fract((p.x + p.y) * p.z);
}

fn kwVertexNoise(p:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var i:vec3<f32> = floor(p);
  var f:vec3<f32> = fract(p);
  f = f * f * (vec3<f32>(3.0) - 2.0 * f);
  return mix(
    mix(mix(kwVertexHash(i + vec3<f32>(0,0,0), wp, fp), kwVertexHash(i + vec3<f32>(1,0,0), wp, fp), f.x),
        mix(kwVertexHash(i + vec3<f32>(0,1,0), wp, fp), kwVertexHash(i + vec3<f32>(1,1,0), wp, fp), f.x), f.y),
    mix(mix(kwVertexHash(i + vec3<f32>(0,0,1), wp, fp), kwVertexHash(i + vec3<f32>(1,0,1), wp, fp), f.x),
        mix(kwVertexHash(i + vec3<f32>(0,1,1), wp, fp), kwVertexHash(i + vec3<f32>(1,1,1), wp, fp), f.x), f.y),
    f.z
  );
}

fn kwMacroField(pIn:vec3<f32>, wp:KpWoodParams, fp:f32)->f32 {
  var p=pIn;
  var result:f32 = 0.0;
  var amplitude:f32 = 0.58;
  for (var i = 0; i < 3; i++) {
    result += amplitude * kwVertexNoise(p, wp, fp);
    p = p * 2.07 + vec3<f32>(5.2, 9.1, 3.7);
    amplitude *= 0.45;
  }
  return result / 0.94;
}

// pSourceM = member-local metres + inherited source grainOffset, +X axial.
// Signed normal displacement; use only this function in the geometry distance.
fn kpWoodMacroDisplacement(pSourceM:vec3<f32>, surfaceClass:f32, wp:KpWoodParams)->f32 {
  let fp=0.0;
  let grain=pSourceM*max(wp.textureScale,0.001);
    var broad:f32 = kwMacroField(grain * vec3<f32>(0.28, 1.15, 1.15) + vec3<f32>(wp.seed * 7.0), wp, fp);
    var longWave:f32 = 0.5 + 0.5 * sin(grain.x * 0.82 + wp.seed * 29.0 + broad * 1.55);
    var macroHeight:f32 = (broad - 0.5) * 0.78 + (longWave - 0.5) * 0.22;
    var classWeight:f32 = 1.0;
    if (surfaceClass > 0.5 && surfaceClass < 2.5) { classWeight = 0.0; }
    else if (surfaceClass > 2.5 && surfaceClass < 3.5) { classWeight = 1.08; }
  return macroHeight * wp.macroDisplacementM * wp.reliefScale * classWeight;
}
// Conservative magnitude bound for the original vertex displacement, in metres.
// Source macro noise is nonnegative with sum (0.58+0.261+0.11745)/0.94;
// original normal class multiplier is at most 1.08. This is not a Lipschitz bound.

// New screen-independent AA bridge. This is a nominal physical frequency estimate,
// not the original screen derivative and not a proof of derivative equivalence.
// fp=0 preserves the unfiltered original field exactly (up to f32 arithmetic).
fn kpWoodCoordinateFootprint(physicalFootprintM:f32,wp:KpWoodParams)->f32 {
  return max(physicalFootprintM,0.0)*max(wp.textureScale,0.001)*max(wp.ringFrequency*wp.ringScale,wp.fiberFrequency*4.6*max(wp.detailFineness,0.45));
}
// Complete source material terms before source-specific lighting or gamma.
// The caller supplies the actual member-local surface normal and face class.
// 0=longitudinal, 1=end grain, 2=joint cut, 3=weathered side.
// No camera-ray parallax march is hidden in this pure field call.
fn kpWoodOriginalSample(pSourceM:vec3<f32>,normalIn:vec3<f32>,surfaceClass:f32,wp:KpWoodParams,physicalFootprintM:f32,cameraDistanceM:f32)->KpWoodSample {
  let localNormal=normalize(normalIn);
  let g=pSourceM*max(wp.textureScale,0.001);
  let fp=kpWoodCoordinateFootprint(physicalFootprintM,wp);
  var baseColor=vec3<f32>(0.0);
  var heightMeters=0.0;
  var roughness=wp.roughness;
  var cavity=1.0;
    var signals:vec4<f32> = kwWoodSignals(g, localNormal, surfaceClass, wp, fp);
    var secondary:vec4<f32> = kwSecondarySignals(g, localNormal, wp, fp);
    var ring:f32 = signals.x;
    var coarseFiber:f32 = signals.y;
    var mediumFiber:f32 = signals.z;
    var cracks:f32 = signals.w;
    var fineFiber:f32 = secondary.x;
    var pores:f32 = secondary.y;
    var tool:f32 = secondary.z;
    var knot:f32 = secondary.w;
    var macroTone:f32 = kwMacroSignal(g, wp, fp);

    var crossSection:f32 = step(0.72, abs(localNormal.x));
    var crossPosition:vec2<f32> = g.yz + wp.pithOffset;
    var radial:f32 = length(crossPosition);
    var endRay:f32 = kwAaSine(atan2(crossPosition.y, crossPosition.x) * 3.0 / KP_WOOD_TAU + radial * 2.0 + wp.seed * 7.0, wp, fp);

    var longitudinalTone:f32 =
      (coarseFiber - 0.5) * 1.02 +
      (mediumFiber - 0.5) * 0.43 +
      (macroTone - 0.5) * 0.56 +
      (fineFiber - 0.5) * 0.11 +
      knot * 0.26 -
      cracks * 0.70 -
      pores * 0.08;
    var endTone:f32 =
      (ring - 0.5) * 1.08 +
      (endRay - 0.5) * 0.19 +
      (macroTone - 0.5) * 0.38 -
      cracks * 0.72 -
      pores * 0.05;
    var grainTone:f32 = mix(longitudinalTone, endTone, crossSection) + wp.colorBias;
    var grainMix:f32 = kwSaturate(0.50 + grainTone * wp.grainContrast * 2.72, wp, fp);
    var grainColor:vec3<f32> = mix(wp.lightGrainColor, wp.darkGrainColor, grainMix);
    baseColor = mix(wp.agedSurfaceColor, grainColor, 0.78);

    if (surfaceClass > 0.5 && surfaceClass < 1.5) {
      baseColor = mix(baseColor, wp.freshCutColor, 0.20);
    } else if (surfaceClass > 1.5 && surfaceClass < 2.5) {
      baseColor = mix(baseColor, wp.freshCutColor, 0.27);
    } else if (surfaceClass > 2.5 && surfaceClass < 3.5) {
      baseColor = mix(baseColor, wp.weatheredColor, 0.53);
      roughness = min(0.98, roughness + 0.045);
    }

    baseColor *= 0.905 + macroTone * 0.19;
    baseColor = mix(baseColor, wp.cavityColor, cracks * 0.40 + pores * 0.065 + knot * 0.025);

    var distanceToCamera:f32 = cameraDistanceM;
    var detailFade:f32 = 1.0 - smoothstep(wp.distanceFadeStart, wp.distanceFadeEnd, distanceToCamera);
    var sideMicro:f32 =
      (coarseFiber - 0.5) * 0.32 +
      (mediumFiber - 0.5) * 0.24 +
      (fineFiber - 0.5) * 0.12 -
      pores * 0.30 -
      cracks * 0.94 -
      tool * 0.13 +
      knot * 0.09;
    var endMicro:f32 =
      (ring - 0.5) * 0.34 +
      (fineFiber - 0.5) * 0.05 -
      pores * 0.22 -
      cracks * 1.0;
    var microSignal:f32 = mix(sideMicro, endMicro, crossSection);
    heightMeters = microSignal * wp.microReliefM * wp.reliefScale * detailFade;

    roughness = clamp(
      roughness + pores * 0.045 + cracks * 0.075 + (0.5 - macroTone) * 0.022 - wp.clearcoat * 0.085,
      0.18,
      0.98
    );
    cavity = clamp(1.0 - cracks * 0.34 - pores * 0.06 - ring * crossSection * 0.035, 0.60, 1.0);

  return KpWoodSample(KpSurface(heightMeters,baseColor,roughness),cavity,wp.clearcoat,wp.clearcoatRoughness,wp.specularLevel,kpWoodMacroDisplacement(pSourceM,surfaceClass,wp),kwCoarseRelief(g,localNormal,surfaceClass,wp,fp));
}

// Original fragment micro-height: PBR normal detail, NOT a replacement for macro geometry.

// Compatibility entry: top longitudinal face of the original default box timber.
// age/wet/repair are reserved host arguments; the original v3 has no such model.
// Scene overlays must be explicit outside this source-preserving material leaf.


// STONE_STUDY same-page stoneFields, kind 0 (the stone receiver's default).
// KpSurface is supplied once by the shared brick core; do not redefine it here.
// No texture, mesh, voxel atlas, material cache or additional noise family.
// Authored unit bridge: a 0.42 m longest side maps to 3.4 specimen units.
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_KIND:i32 = 0;
const KP_STONE_MASTER_SEED:u32 = 8231u;
// Original normalizeSeedDNA offsets: color +401, pore +307, weather +601.
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;








// New explicit isotropic footprint bridge replacing screen-space fwidth(line).
// It reevaluates the ORIGINAL line and warp at three metric axis offsets.
// This bound-like footprint is not screen-space fwidth equivalence and is not
// complete band-limiting of the original noise; zero footprint keeps 0.008.

// Original kind-0 stoneFields arithmetic. Fixed original material controls:
// sSurface.x=1, sSurface.y=0.7, sDisplay.w=1, sRelief=1, uEventCount=0.
// Original event-loop contribution is therefore 0. Original pits still apply.
// Branches 1/2/3 and their inactive grain/phase/crystal evaluations are omitted.

// New, authored age/moisture/repair bridge copied from resolveStoneFabric.
// Its original default wear=0.15 is fixed because this call has no wear input.
// No calibrated decay law, damage geometry, formation events or SDF is ported.
// Age changes original wet/rough uniforms only; original height stays intact.


// STONE_STUDY original sKind == 3 (blue-gray slate) surface branch.
// Append AFTER existing KP_STONE_WGSL; reuse its st_* source functions/seeds.
// Receiver controls below are explicit design bindings, NOT physical calibration.
// Original event count remains 0, matching the current surface-only port.
struct KpStoneSlateParams {
 sourceScaleM:f32, materialScale:f32, mineral:f32, chroma:f32, relief:f32,
};


// Same existing authored age/moisture/repair bridge; only source branch differs.











const RC_PI:f32=3.14159265359;
struct KpClothM{col:vec3<f32>,roughW:f32,roughF:f32,sheen:f32,bump:f32,trans:f32,irr:f32,fuzz:f32,slub:f32,open:f32,macroTone:f32,age:f32,farId:f32,meso:f32,den:vec2<f32>}
struct KpClothPattern{h:f32,thread:f32,orient:f32,variation:f32,gap:f32,nearW:f32,midW:f32,farW:f32,slub:f32,roughVar:f32,wear:f32,bundle:f32}










// Source material coordinates are centimetres. This explicit footprint bridge
// replaces screen derivatives; physical microheight always uses footprint zero.

















struct MaterialResult{surface:KpSurface,metal:f32,cavity:f32,specular:f32,coat:f32,coatRough:f32}
struct PhysicalState{age:f32,wet:f32,repair:f32,q:vec3<f32>}

struct SettlementField{d:f32,geo:GeoHit,sectionCap:u32}
fn dna(h:GeoHit)->vec4<f32>{if(h.stateId==0u){return vec4<f32>(.24,.1,0.,0.);}let a=rec(h.stateId-1u,0u);let c=rec(h.stateId-1u,2u);let event=rec(h.stateId-1u,3u);let added=event.y>.5&&((h.componentId>=1000000u&&h.componentId<1001000u)||(h.componentId>=4000000u&&h.componentId<4004000u));let shelter=h.componentId>=1200000u&&h.componentId<1201000u;let eventYear=select(event.w,rec(h.stateId-1u,5u).y,shelter);let age=select(c.x,clamp((u.size.w-eventYear)/40.,0.,1.),added||shelter);return vec4<f32>(age,f32(h.stateId)*.731+select(0.,9.17,added),select(c.y,.05,added),a.y);}







fn woodNormal(h:GeoHit,n:vec3<f32>)->vec3<f32>{let axis=h.componentId%4u;if(axis==1u){return n.yxz;}if(axis==2u){return n.zyx;}return n;}

fn sceneMaterial(h:GeoHit,p:vec3<f32>,n:vec3<f32>,fp:f32,cap:u32)->MaterialResult{var s=KpSurface(0.,vec3<f32>(.3),.8);var metal=0.;var cavity=1.;var spec=1.;var coat=0.;var coatRough=.25;let d=dna(h);
 if(h.stateId==0u){return MaterialResult(KpSurface(0.,vec3<f32>(.28),.92),0.,1.,1.,0.,.25);}
 
 
 
 
 if(h.materialId==4u){let wn=woodNormal(h,n);let sample=kpWoodOriginalSample(h.q,wn,select(0.,1.,abs(wn.x)>.72),kpWoodDefaultParams(),fp,length(p-u.eye.xyz));s=sample.surface;cavity=sample.cavity;spec=sample.specularLevel;coat=sample.clearcoat;coatRough=sample.clearcoatRoughness;}
 
 
 
 
 return MaterialResult(s,metal,cavity,spec,coat,coatRough);}

// Analytic current-parameter bounds are recorded in qa/material-distance-bounds.txt.
// 0.012m is deliberately wider than every possible displacement; this is a
// distance-value bound, not a claim that the displaced field is a strict SDF.
const MATERIAL_DISTANCE_BOUND:f32=.012;



struct Stats {hit:atomic<u32>,miss:atomic<u32>,exhausted:atomic<u32>,maximumSteps:atomic<u32>,retried:atomic<u32>,glassRays:atomic<u32>,boundOnly:atomic<u32>,reserved:atomic<u32>,visibilityRetried:atomic<u32>,visibilityMaximumSteps:atomic<u32>,extendedPrimary:atomic<u32>,candidateOverflows:atomic<u32>,activeQueries:atomic<u32>}

struct HitRecord { ray:vec4<f32>,local:vec4<f32>,ids:vec4<u32>,normal:vec4<f32>,glass:vec4<f32>,through:vec4<f32> }

struct RetryQueue {count:atomic<u32>,indices:array<u32,256>}




// Initial 64-step exit and final sparse continuation. No scene or material state is copied.


















struct Frag { @location(0) color:vec4<f32>, @builtin(frag_depth) depth:f32 }



struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }

@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;

struct SampleHit { ids:vec4<u32>,local:vec4<f32>,normal:vec4<f32>,extra:vec4<u32> }
@group(1) @binding(2) var<storage,read_write> mapHits:array<SampleHit>;

fn unpackMapHit(h:SampleHit)->GeoHit{return GeoHit(h.local.w,h.ids.x,h.ids.y,h.ids.z,h.ids.w,h.local.xyz,h.normal.xyz,h.extra.x);}






@compute @workgroup_size(32) fn sampleColor4(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w!=4.){return;}let h=unpackMapHit(mapHits[i]);if(h.materialId!=4u){return;}let m=sceneMaterial(h,o.position.xyz,o.normal.xyz,.18,0u).surface;o.color=vec4<f32>(m.albedo,m.roughness);mapSamples[i]=o;}
