// Finite sampler only. The locked city runtime and all mother functions stay intact.
import {receiverWGSL} from '../../../walled-city-pair-r03/whole-growth-r05/runtime/receiver.mjs';
import {GEOMETRY_WGSL} from '../../../walled-city-pair-r03/whole-growth-r05/runtime/geometry.mjs';
import {selectStageSource} from '../../../lost-property-bureau-r03f/candidate/stage-source.mjs';

export const CITY_MATERIAL_IDS = Object.freeze([1, 2, 3, 4, 5, 6, 7, 8, 9]);
export const CITY_HIT_STRIDE = 64;

// An explicit 4 x vec4 ABI preserves every GeoHit field, including its analytic
// normal, distance, local coordinates and integer IDs. Do not substitute the
// finite-difference shading normal for h.n: the original mothers use both.
const cache = String.raw`
struct SampleHit { ids:vec4<u32>,local:vec4<f32>,normal:vec4<f32>,extra:vec4<u32> }
@group(1) @binding(2) var<storage,read_write> mapHits:array<SampleHit>;
fn packMapHit(h:GeoHit)->SampleHit{return SampleHit(vec4<u32>(h.materialId,h.buildingId,h.componentId,h.stateId),vec4<f32>(h.q,h.d),vec4<f32>(h.n,0.),vec4<u32>(h.objectId,0u,0u,0u));}
fn unpackMapHit(h:SampleHit)->GeoHit{return GeoHit(h.local.w,h.ids.x,h.ids.y,h.ids.z,h.ids.w,h.local.xyz,h.normal.xyz,h.extra.x);}
`;
const geometry = String.raw`
fn mapHit(p:vec3<f32>)->GeoHit {fieldCompetition=true;fieldExcludedCount=1u;fieldExcluded[0]=vec2<u32>(0u,0u);return querySettlement(p,150.);}
fn mapDistance(p:vec3<f32>)->f32 {return mapHit(p).d;}
@compute @workgroup_size(32) fn sampleGeometry(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapRays)){return;}let r=mapRays[i];var t=0.;var found=false;var steps=0u;var hit:GeoHit;for(var k=0u;k<640u;k++){steps=k+1u;let f=mapHit(r.origin.xyz+r.direction.xyz*t);if(f.materialId>0u&&abs(f.d)<.003){found=true;hit=f;break;}t+=max(.0015,abs(f.d)*.67);if(t>r.origin.w){break;}}var o:SampleOutput;o.position=vec4<f32>(0.);o.normal=vec4<f32>(0.,1.,0.,f32(steps));o.color=vec4<f32>(0.);if(found){o.position=vec4<f32>(r.origin.xyz+r.direction.xyz*t,f32(hit.materialId));}else if(t<=r.origin.w){o.normal.w=-f32(steps);}mapSamples[i]=o;mapHits[i]=packMapHit(hit);}
@compute @workgroup_size(32) fn sampleNormal(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w<.5){return;}var gradient=vec3<f32>(0.);for(var j=0u;j<6u;j++){var offset=vec3<f32>(0.);let axis=j/2u;let sign=select(-1.,1.,j%2u==0u);offset[axis]=sign*.002;let d=mapDistance(o.position.xyz+offset);gradient[axis]+=sign*d;}o.normal=vec4<f32>(normalize(gradient),o.normal.w);mapSamples[i]=o;}
`;

function closingBrace(source, open) {
  let depth = 1;
  for (let i = open + 1; i < source.length; i++) {
    if (source[i] === '{') depth++;
    if (source[i] === '}' && --depth === 0) return i + 1;
  }
  throw Error('Unclosed city material block');
}

export function originalSceneMaterial(source) {
  const start = source.indexOf('fn sceneMaterial(');
  if (start < 0) throw Error('Locked sceneMaterial function missing');
  const end = closingBrace(source, source.indexOf('{', start));
  return {start, end, code: source.slice(start, end)};
}

// Keep the selected original `if` block byte-for-byte, including nested cap
// conditions, and remove only the eight mutually exclusive material blocks.
// The entry point AND CPU partition require this exact material ID, so the
// removed conditions are false for every invocation of this specialization.
export function specializeSceneMaterial(source, materialId) {
  if (!CITY_MATERIAL_IDS.includes(materialId)) throw Error('Unknown material ' + materialId);
  const original = originalSceneMaterial(source);
  const blocks = [];
  const re = /\bif\(h\.materialId==(\d+)u\)\{/g;
  let match;
  while ((match = re.exec(original.code))) {
    const end = closingBrace(original.code, re.lastIndex - 1);
    blocks.push({id: Number(match[1]), start: match.index, end, code: original.code.slice(match.index, end)});
    re.lastIndex = end;
  }
  if (blocks.map(x => x.id).sort((a, b) => a - b).join(',') !== CITY_MATERIAL_IDS.join(',')) {
    throw Error('Locked sceneMaterial routing changed; review specialization');
  }
  let code = original.code;
  for (const block of [...blocks].reverse()) if (block.id !== materialId) code = code.slice(0, block.start) + code.slice(block.end);
  return {source: source.slice(0, original.start) + code + source.slice(original.end), original: original.code,
    branch: blocks.find(x => x.id === materialId).code, specialized: code};
}

export function buildCitySamplingStages(shared) {
  const original = receiverWGSL(GEOMETRY_WGSL);
  const base = original + shared + cache + geometry;
  const stages = {};
  for (const entry of ['sampleGeometry', 'sampleNormal']) stages[entry] = selectStageSource(base, [entry]);
  for (const id of CITY_MATERIAL_IDS) {
    const entry = 'sampleColor' + id;
    const specialized = specializeSceneMaterial(base, id);
    const entrySource = `\n@compute @workgroup_size(32) fn ${entry}(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w!=${id}.){return;}let h=unpackMapHit(mapHits[i]);if(h.materialId!=${id}u){return;}let m=sceneMaterial(h,o.position.xyz,o.normal.xyz,.18,0u).surface;o.color=vec4<f32>(m.albedo,m.roughness);mapSamples[i]=o;}\n`;
    stages[entry] = {...selectStageSource(specialized.source + entrySource, [entry]), materialId:id,
      preservedBranch:specialized.branch};
    if (stages[entry].functionNames.includes('querySettlement') || stages[entry].functionNames.includes('mapHit')) {
      throw Error('Material stage must not evaluate city geometry: ' + entry);
    }
  }
  return {stages, originalSceneMaterial: originalSceneMaterial(original).code};
}
