
struct Frame { eye:vec4<f32>,forward:vec4<f32>,right:vec4<f32>,up:vec4<f32>,cut:vec4<f32>,size:vec4<f32>,tile:vec4<u32>,controls:vec4<f32> }
@group(0) @binding(0) var<uniform> u:Frame;

@group(0) @binding(1) var<storage,read> worldRules:array<vec4<f32>>;
struct GeoHit{d:f32,materialId:u32,buildingId:u32,componentId:u32,stateId:u32,q:vec3<f32>,n:vec3<f32>,objectId:u32}
// Short-lived per-ray candidate keys, never persistent world/brick instances.
var<private> fieldCompetition:bool;
var<private> fieldExcluded:array<vec2<u32>,32>;
var<private> fieldExcludedCount:u32;

fn rec(s:u32,k:u32)->vec4<f32>{return worldRules[s*8u+k];}
















// Dated household event, partitioned along existing execution groups.






// Metric frontage rules are compiled with household uses, not randomized per pixel.






















// Three narrow linked leaves fold entirely over the level A platform.




// R3.12 family-0 original fitted edge waves, field and surface core.
// WGSL syntax/explicit arguments are new. No renderer, vertex or instance lists.
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }












































// Return original [chips, contour, weight] contributions instead of GLSL inout.





// Exact original family-0 distance, in metres. This is not guaranteed Lipschitz 1.0



// New explicit isotropic footprint bridge. Original wave, 17 octaves and gates
// remain; the original screen dFdx/dFdy footprint is NOT claimed equivalent.

// Raw original family-0 albedo, roughness and height. No lighting/tone mapping.


// R3.12 original macro/micro/observed field algebra. Explicit coordinates and
// derivative-free physical footprint are receiver bridges. No patch silhouette.
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}












// Syntax port of locked V26 waterWeatherMasks dependency closure.
// pField is the ORIGINAL normalized material field coordinate, not metres.
// localPosM/dimensionsM are original physical local position/size for gates.












// Existing explicitly authored unified fabric bridge, not source physical years.
struct KpFabricState { moisture:f32, damage:f32, retention:f32, thicknessM:f32, baseScale:f32, roughDelta:f32, }


// Apply the exact same resolved state used by receiver coat retention/thickness.
// Requires KpSurface from brick-core. No second independently computed age.


// User Library timber v3, exact box coordinate/noise/field formulas in WGSL.
// KpSurface must be declared by the parent brick module before this string.
// No bindings, stages, renderer, textures, geometry buffers or scene objects.
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}









































// pSourceM = member-local metres + inherited source grainOffset, +X axial.
// Signed normal displacement; use only this function in the geometry distance.

// Conservative magnitude bound for the original vertex displacement, in metres.
// Source macro noise is nonnegative with sum (0.58+0.261+0.11745)/0.94;
// original normal class multiplier is at most 1.08. This is not a Lipschitz bound.

// New screen-independent AA bridge. This is a nominal physical frequency estimate,
// not the original screen derivative and not a proof of derivative equivalence.
// fp=0 preserves the unfiltered original field exactly (up to f32 arithmetic).

// Complete source material terms before source-specific lighting or gamma.
// The caller supplies the actual member-local surface normal and face class.
// 0=longitudinal, 1=end grain, 2=joint cut, 3=weathered side.
// No camera-ray parallax march is hidden in this pure field call.


// Original fragment micro-height: PBR normal detail, NOT a replacement for macro geometry.

// Compatibility entry: top longitudinal face of the original default box timber.
// age/wet/repair are reserved host arguments; the original v3 has no such model.
// Scene overlays must be explicit outside this source-preserving material leaf.


// STONE_STUDY same-page stoneFields, kind 0 (the stone receiver's default).
// KpSurface is supplied once by the shared brick core; do not redefine it here.
// No texture, mesh, voxel atlas, material cache or additional noise family.
// Authored unit bridge: a 0.42 m longest side maps to 3.4 specimen units.
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_KIND:i32 = 0;
const KP_STONE_MASTER_SEED:u32 = 8231u;
// Original normalizeSeedDNA offsets: color +401, pore +307, weather +601.
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;








// New explicit isotropic footprint bridge replacing screen-space fwidth(line).
// It reevaluates the ORIGINAL line and warp at three metric axis offsets.
// This bound-like footprint is not screen-space fwidth equivalence and is not
// complete band-limiting of the original noise; zero footprint keeps 0.008.

// Original kind-0 stoneFields arithmetic. Fixed original material controls:
// sSurface.x=1, sSurface.y=0.7, sDisplay.w=1, sRelief=1, uEventCount=0.
// Original event-loop contribution is therefore 0. Original pits still apply.
// Branches 1/2/3 and their inactive grain/phase/crystal evaluations are omitted.

// New, authored age/moisture/repair bridge copied from resolveStoneFabric.
// Its original default wear=0.15 is fixed because this call has no wear input.
// No calibrated decay law, damage geometry, formation events or SDF is ported.
// Age changes original wet/rough uniforms only; original height stays intact.


// STONE_STUDY original sKind == 3 (blue-gray slate) surface branch.
// Append AFTER existing KP_STONE_WGSL; reuse its st_* source functions/seeds.
// Receiver controls below are explicit design bindings, NOT physical calibration.
// Original event count remains 0, matching the current surface-only port.
struct KpStoneSlateParams {
 sourceScaleM:f32, materialScale:f32, mineral:f32, chroma:f32, relief:f32,
};


// Same existing authored age/moisture/repair bridge; only source branch differs.











const RC_PI:f32=3.14159265359;
struct KpClothM{col:vec3<f32>,roughW:f32,roughF:f32,sheen:f32,bump:f32,trans:f32,irr:f32,fuzz:f32,slub:f32,open:f32,macroTone:f32,age:f32,farId:f32,meso:f32,den:vec2<f32>}
struct KpClothPattern{h:f32,thread:f32,orient:f32,variation:f32,gap:f32,nearW:f32,midW:f32,farW:f32,slub:f32,roughVar:f32,wear:f32,bundle:f32}
fn rc_h21(value:vec2<f32>)->f32{var p=fract(value*vec2<f32>(123.34,456.21));p+=vec2<f32>(dot(p,p+vec2<f32>(45.32)));return fract(p.x*p.y);}
fn rc_n2(p:vec2<f32>)->f32{let i=floor(p);var f=fract(p);f=f*f*(vec2<f32>(3.)-2.*f);return mix(mix(rc_h21(i),rc_h21(i+vec2<f32>(1,0)),f.x),mix(rc_h21(i+vec2<f32>(0,1)),rc_h21(i+vec2<f32>(1.)),f.x),f.y);}
fn rc_sat(x:f32)->f32{return clamp(x,0.,1.);}
fn kpClothCoarseParams()->KpClothM{return KpClothM(vec3<f32>(.39,.32,.21),.82,.77,.20,.46,.085,.78,.24,.88,.10,.38,.24,.78,1.,vec2<f32>(5.6,5.0));}
fn rc_patternR3(c:vec2<f32>,m:KpClothM,face:f32,footprintCm:vec2<f32>)->KpClothPattern{var p:KpClothPattern;var qb:vec2<f32> =c*m.den;var fw:vec2<f32> =footprintCm*m.den;var fp:f32=max(fw.x,fw.y);p.nearW=1.-smoothstep(.20,.75,fp);p.farW=smoothstep(.85,2.60,fp);p.midW=max(0.,1.-p.nearW-p.farW);var sum:f32=max(1e-4,p.nearW+p.midW+p.farW);p.nearW/=sum;p.midW/=sum;p.farW/=sum;var wc:f32=floor(qb.x);
var fc:f32=floor(qb.y);var seedW:f32=rc_h21(vec2<f32>(wc,19.7));
var seedF:f32=rc_h21(vec2<f32>(47.3,fc));var warpDrift:f32=(rc_n2(vec2<f32>(wc*.119,c.y*.074+seedW*9.))-.5)*m.irr*.30+(rc_n2(vec2<f32>(wc*.047,c.y*.021+17.))-.5)*m.irr*.15;var weftDrift:f32=(rc_n2(vec2<f32>(c.x*.067+seedF*11.,fc*.131))-.5)*m.irr*.30+(rc_n2(vec2<f32>(c.x*.019+27.,fc*.053))-.5)*m.irr*.15;var q:vec2<f32> =qb+vec2<f32>(warpDrift,weftDrift);
var id:vec2<f32> =floor(q);
var f:vec2<f32> =fract(q)-vec2<f32>(.5);var slW:f32=pow(smoothstep(.49,.88,rc_n2(vec2<f32>(id.x*.091,c.y*.048+seedW*13.))),1.22);
var slF:f32=pow(smoothstep(.51,.89,rc_n2(vec2<f32>(c.x*.044+seedF*15.,id.y*.103))),1.28);var longW:f32=rc_n2(vec2<f32>(id.x*.043,c.y*.016+35.));
var longF:f32=rc_n2(vec2<f32>(c.x*.014+43.,id.y*.039));var ww:f32=clamp(.415*(.84+.29*seedW)*(1.+m.slub*(.29*slW+.13*(longW-.5))),.31,.54);
var wf:f32=clamp(.425*(.84+.28*seedF)*(1.+m.slub*(.29*slF+.13*(longF-.5))),.32,.55);var warp:f32=pow(max(0.,1.-((f.x/ww)*(f.x/ww))),.50);
var weft:f32=pow(max(0.,1.-((f.y/wf)*(f.y/wf))),.50);var wave:f32=cos(RC_PI*(q.y-.5+floor(q.x)));if(face<.5){wave=-wave;}var zW:f32=warp*(.76+.24*wave)-.45;
var zF:f32=weft*(.76-.24*wave)-.45;
var mx:f32=max(zW,zF);var microH:f32=mx+log(exp((zW-mx)*7.)+exp((zF-mx)*7.))/7.;var orientDetail:f32=smoothstep(-.075,.075,zF-zW);var threadDetail:f32=max(warp,weft);var twistW:f32=sin((c.y*(5.6+2.3*seedW)+seedW*7.3)*RC_PI*2.);
var twistF:f32=sin((c.x*(5.2+2.1*seedF)+seedF*8.1)*RC_PI*2.);var twist:f32=mix(twistW,twistF,orientDetail);microH+=(twist*.026)*threadDetail;
var bundleW:f32=rc_n2(vec2<f32>(c.x*.175,c.y*.016)+vec2<f32>(7.,23.))-.5;
var bundleF:f32=rc_n2(vec2<f32>(c.x*.014,c.y*.158)+vec2<f32>(31.,5.))-.5;var bundleW2:f32=rc_n2(vec2<f32>(c.x*.061,c.y*.007)+vec2<f32>(57.,11.))-.5;
var bundleF2:f32=rc_n2(vec2<f32>(c.x*.006,c.y*.055)+vec2<f32>(13.,61.))-.5;var crossW:f32=.72*bundleW+.28*bundleW2;
var crossF:f32=.72*bundleF+.28*bundleF2;var bundleMag:f32=rc_sat(.48+.66*(abs(crossW)+abs(crossF)));var macroOrient:f32=smoothstep(-.08,.08,abs(crossF)-abs(crossW));var groupSlub:f32=pow(smoothstep(.50,.87,max(crossW,crossF)+.5),1.2);
/* R5.2: centimetre-scale signals replace vanished micro-weave at middle/far distance. */
var clothW:f32=rc_n2(vec2<f32>(c.x*.112,c.y*.010)+vec2<f32>(19.,67.))-.5;
var clothF:f32=rc_n2(vec2<f32>(c.x*.009,c.y*.101)+vec2<f32>(79.,29.))-.5;var clothCloud:f32=rc_n2(c*vec2<f32>(.071,.054)+vec2<f32>(47.,97.))-.5;var clothBody:f32=.50*clothW+.46*clothF+.34*clothCloud;var densityBand:f32=rc_n2(c*vec2<f32>(.024,.031)+vec2<f32>(109.,41.))-.5;var mesoId:f32=m.meso;var mesoH:f32=(crossW*.72+crossF*.62+groupSlub*.48-.13)*.105+mesoId*clothBody*.036;var farLoom:f32=rc_n2(c*vec2<f32>(.028,.020)+vec2<f32>(71.,43.))-.5;var fadeField:f32=rc_n2(c*vec2<f32>(.010,.015)+vec2<f32>(23.,83.))-.5;var wearField:f32=pow(smoothstep(.51,.83,rc_n2(c*vec2<f32>(.019,.027)+vec2<f32>(93.,17.))),1.45);var dryGrain:f32=rc_n2(c*vec2<f32>(.105,.043)+vec2<f32>(17.,37.))-.5;var yarnToneW:f32=rc_h21(vec2<f32>(id.x,3.1))-.5;
var yarnToneF:f32=rc_h21(vec2<f32>(5.7,id.y))-.5;var topTone:f32=mix(yarnToneW,yarnToneF,orientDetail);p.orient=mix(macroOrient,orientDetail,p.nearW);p.thread=p.nearW*threadDetail+p.midW*(.54+.38*bundleMag+.075*mesoId*rc_sat(.5+clothBody))+p.farW*(.49+.22*bundleMag+.10*mesoId*rc_sat(.5+clothBody));p.slub=p.nearW*mix(slW,slF,orientDetail)+(p.midW+p.farW)*groupSlub;p.bundle=rc_sat(bundleMag+mesoId*.15*rc_sat(.5+clothBody));p.wear=wearField*m.age;p.roughVar=(crossW*.11+crossF*.09)+groupSlub*.08+wearField*m.age*.12+mesoId*(clothW*.060+clothF*.052+clothCloud*.036)*(p.midW+p.farW);var farH:f32=(crossW*.42+crossF*.38+farLoom*.28)*.030*m.farId+mesoId*(clothBody*.034+densityBand*.012);p.h=microH*p.nearW+mesoH*p.midW*(.72+.28*m.farId)+farH*p.farW;var microTone:f32=topTone*m.irr*.12+(p.slub-.25)*m.macroTone*.34+twist*.035;var midTone:f32=(crossW*.57+crossF*.49)*m.macroTone+groupSlub*m.macroTone*.34+dryGrain*m.macroTone*.12+mesoId*(clothBody*.22+densityBand*.085)*m.macroTone;var farTone:f32=(farLoom*.64+fadeField*.74+crossW*.30+crossF*.27)*m.macroTone*m.farId+mesoId*(clothBody*.30+densityBand*.12)*m.macroTone;var wearTone:f32=(-.15+.30*fadeField)*p.wear;p.variation=p.nearW*microTone+p.midW*midTone+p.farW*farTone+wearTone;p.gap=p.nearW*(1.-smoothstep(.035,.27,warp))*(1.-smoothstep(.035,.27,weft))+p.midW*.035;return p;}





// Source material coordinates are centimetres. This explicit footprint bridge
// replaces screen derivatives; physical microheight always uses footprint zero.
fn kpClothCoarsePattern(uvM:vec2<f32>,footprintM:f32)->KpClothPattern{return rc_patternR3(uvM*100.,kpClothCoarseParams(),1.,vec2<f32>(footprintM*100.));}
fn kpClothCoarseBase(uvM:vec2<f32>,p:KpClothPattern)->vec3<f32>{let m=kpClothCoarseParams();return m.col*(1.+p.variation)*(1.-p.wear*.055)*(.965+.035*rc_n2(uvM*100.*.18+vec2<f32>(13.,5.)));}
fn kpClothCoarseSurface(uvM:vec2<f32>,footprintM:f32)->KpSurface{let m=kpClothCoarseParams();let p=kpClothCoarsePattern(uvM,footprintM);return KpSurface(p.h*m.bump*.00038,kpClothCoarseBase(uvM,p),clamp(mix(m.roughW,m.roughF,p.orient)+p.roughVar,.36,.97));}














struct MaterialResult{surface:KpSurface,metal:f32,cavity:f32,specular:f32,coat:f32,coatRough:f32}
struct PhysicalState{age:f32,wet:f32,repair:f32,q:vec3<f32>}

struct SettlementField{d:f32,geo:GeoHit,sectionCap:u32}
fn dna(h:GeoHit)->vec4<f32>{if(h.stateId==0u){return vec4<f32>(.24,.1,0.,0.);}let a=rec(h.stateId-1u,0u);let c=rec(h.stateId-1u,2u);let event=rec(h.stateId-1u,3u);let added=event.y>.5&&((h.componentId>=1000000u&&h.componentId<1001000u)||(h.componentId>=4000000u&&h.componentId<4004000u));let shelter=h.componentId>=1200000u&&h.componentId<1201000u;let eventYear=select(event.w,rec(h.stateId-1u,5u).y,shelter);let age=select(c.x,clamp((u.size.w-eventYear)/40.,0.,1.),added||shelter);return vec4<f32>(age,f32(h.stateId)*.731+select(0.,9.17,added),select(c.y,.05,added),a.y);}









fn sceneMaterial(h:GeoHit,p:vec3<f32>,n:vec3<f32>,fp:f32,cap:u32)->MaterialResult{var s=KpSurface(0.,vec3<f32>(.3),.8);var metal=0.;var cavity=1.;var spec=1.;var coat=0.;var coatRough=.25;let d=dna(h);
 if(h.stateId==0u){return MaterialResult(KpSurface(0.,vec3<f32>(.28),.92),0.,1.,1.,0.,.25);}
 
 
 
 
 
 
 
 
 if(h.materialId==7u){s=kpClothCoarseSurface(h.q.xz,fp);spec=.6;}
 return MaterialResult(s,metal,cavity,spec,coat,coatRough);}

// Analytic current-parameter bounds are recorded in qa/material-distance-bounds.txt.
// 0.012m is deliberately wider than every possible displacement; this is a
// distance-value bound, not a claim that the displaced field is a strict SDF.
const MATERIAL_DISTANCE_BOUND:f32=.012;



struct Stats {hit:atomic<u32>,miss:atomic<u32>,exhausted:atomic<u32>,maximumSteps:atomic<u32>,retried:atomic<u32>,glassRays:atomic<u32>,boundOnly:atomic<u32>,reserved:atomic<u32>,visibilityRetried:atomic<u32>,visibilityMaximumSteps:atomic<u32>,extendedPrimary:atomic<u32>,candidateOverflows:atomic<u32>,activeQueries:atomic<u32>}

struct HitRecord { ray:vec4<f32>,local:vec4<f32>,ids:vec4<u32>,normal:vec4<f32>,glass:vec4<f32>,through:vec4<f32> }

struct RetryQueue {count:atomic<u32>,indices:array<u32,256>}




// Initial 64-step exit and final sparse continuation. No scene or material state is copied.


















struct Frag { @location(0) color:vec4<f32>, @builtin(frag_depth) depth:f32 }



struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }

@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;

struct SampleHit { ids:vec4<u32>,local:vec4<f32>,normal:vec4<f32>,extra:vec4<u32> }
@group(1) @binding(2) var<storage,read_write> mapHits:array<SampleHit>;

fn unpackMapHit(h:SampleHit)->GeoHit{return GeoHit(h.local.w,h.ids.x,h.ids.y,h.ids.z,h.ids.w,h.local.xyz,h.normal.xyz,h.extra.x);}






@compute @workgroup_size(32) fn sampleColor7(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w!=7.){return;}let h=unpackMapHit(mapHits[i]);if(h.materialId!=7u){return;}let m=sceneMaterial(h,o.position.xyz,o.normal.xyz,.18,0u).surface;o.color=vec4<f32>(m.albedo,m.roughness);mapSamples[i]=o;}
