
struct Frame { eye:vec4<f32>,forward:vec4<f32>,right:vec4<f32>,up:vec4<f32>,cut:vec4<f32>,size:vec4<f32>,tile:vec4<u32>,controls:vec4<f32> }
@group(0) @binding(0) var<uniform> u:Frame;

@group(0) @binding(1) var<storage,read> worldRules:array<vec4<f32>>;
struct GeoHit{d:f32,materialId:u32,buildingId:u32,componentId:u32,stateId:u32,q:vec3<f32>,n:vec3<f32>,objectId:u32}
// Short-lived per-ray candidate keys, never persistent world/brick instances.
var<private> fieldCompetition:bool;
var<private> fieldExcluded:array<vec2<u32>,32>;
var<private> fieldExcludedCount:u32;
fn excludedFieldObject(state:u32,component:u32)->bool{if(!fieldCompetition){return false;}for(var i=0u;i<fieldExcludedCount;i++){if(all(fieldExcluded[i]==vec2<u32>(state,component))){return true;}}return false;}
fn rec(s:u32,k:u32)->vec4<f32>{return worldRules[s*8u+k];}
fn boxD(q:vec3<f32>,b:vec3<f32>)->f32{let a=abs(q)-b;return length(max(a,vec3<f32>(0.)))+min(max(a.x,max(a.y,a.z)),0.);}
fn boxN(q:vec3<f32>,b:vec3<f32>)->vec3<f32>{let a=abs(q)-b;var n=vec3<f32>(0.,0.,sign(q.z));if(a.x>=a.y&&a.x>=a.z){n=vec3<f32>(sign(q.x),0.,0.);}else if(a.y>=a.z){n=vec3<f32>(0.,sign(q.y),0.);}return n;}
fn choose(h:GeoHit,d:f32,m:u32,s:u32,c:u32,q:vec3<f32>,n:vec3<f32>)->GeoHit{if(d>=h.d||excludedFieldObject(s+1u,c)){return h;}return GeoHit(d,m,u32(rec(s,3u).x),c,s+1u,q,n,c);}
fn addBox(h:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec3<f32>,m:u32,s:u32,c:u32)->GeoHit{let q=p-center;return choose(h,boxD(q,half),m,s,c,q,boxN(q,half));}
fn woodBox(h:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec3<f32>,s:u32,c:u32,axis:u32)->GeoHit{let q=p-center;var local=q;if(axis==1u){local=q.yxz;}if(axis==2u){local=q.zyx;}return choose(h,boxD(q,half),4u,s,c*4u+axis,local,boxN(q,half));}
fn pipeD(p:vec3<f32>,a:vec3<f32>,b:vec3<f32>,r:f32)->f32{let pa=p-a;let ba=b-a;return length(pa-ba*clamp(dot(pa,ba)/dot(ba,ba),0.,1.))-r;}
fn addPipe(h:GeoHit,p:vec3<f32>,a:vec3<f32>,b:vec3<f32>,r:f32,s:u32,c:u32)->GeoHit{let ab=b-a;let q=p-a;let n=normalize(q-ab*clamp(dot(q,ab)/dot(ab,ab),0.,1.));return choose(h,pipeD(p,a,b,r),3u,s,c,q,n);}
fn rail(h0:GeoHit,p:vec3<f32>,a:vec3<f32>,b:vec3<f32>,s:u32,c:u32)->GeoHit{var h=h0;let d=b-a;let len=length(d.xz);let t=clamp(dot((p-a).xz,d.xz)/(len*len),0.,1.);let count=max(2.,ceil(len/.11));let ti=round(t*count)/count;let foot=a+d*ti;h=addPipe(h,p,a+vec3<f32>(0.,1.02,0.),b+vec3<f32>(0.,1.02,0.),.027,s,c);h=addPipe(h,p,a+vec3<f32>(0.,.22,0.),b+vec3<f32>(0.,.22,0.),.017,s,c+1u);h=addPipe(h,p,foot,foot+vec3<f32>(0.,1.,0.),.014,s,c+2u);return h;}
fn windowParts(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec2<f32>,s:u32,c:u32,side:bool,door:bool,sliding:bool)->GeoHit{var h=h0;let qq=p-center;var q=qq;if(side){q=qq.zyx;}let outer=boxD(q,vec3<f32>(half+vec2<f32>(.055),.085));let inner=boxD(q,vec3<f32>(half-vec2<f32>(.015),.15));let n=select(boxN(q,vec3<f32>(half,.1)),boxN(q,vec3<f32>(half,.1)).zyx,side);h=choose(h,max(outer,-inner),4u,s,c*4u+1u,q.yxz,n);if(!door){h=choose(h,min(boxD(q,vec3<f32>(.021,half.y,.025)),boxD(q,vec3<f32>(half.x,.019,.025))),3u,s,c+10u,q,n);h=choose(h,boxD(q,vec3<f32>(half-vec2<f32>(.04),.006)),5u,s,c+11u,q,n);}else if(sliding){let leaf=q-vec3<f32>(select(-1.5,1.5,q.x>0.)*half.x,0.,-.15);h=choose(h,boxD(leaf,vec3<f32>(half.x*.5,half.y-.025,.025)),4u,s,(c+12u)*4u+1u,leaf.yxz,n);h=addBox(h,p,center+vec3<f32>(0.,half.y+.065,-.15),vec3<f32>(half.x*2.,.022,.027),3u,s,c+11u);}else if(side&&rec(s,2u).w>0.){let inward=select(-1.,1.,rec(s,3u).x==2.);let hinge=q-vec3<f32>(-half.x,0.,inward*.15);let sn=.8660254;let leaf=vec3<f32>(hinge.x*.5+hinge.z*inward*sn-half.x*.98,hinge.y,-hinge.x*inward*sn+hinge.z*.5);let ln=boxN(leaf,vec3<f32>(half.x*.98,half.y-.025,.025));let wn=vec3<f32>(inward*sn*ln.x+.5*ln.z,ln.y,.5*ln.x-inward*sn*ln.z);h=choose(h,boxD(leaf,vec3<f32>(half.x*.98,half.y-.025,.025)),4u,s,(c+12u)*4u+1u,leaf.yxz,wn);}else{var leaf=q;leaf.x+=half.x-.035;leaf.z-=half.x*.65;let turn=vec2<f32>(leaf.x*.50+leaf.z*.866,-leaf.x*.866+leaf.z*.50);leaf=vec3<f32>(turn.x,leaf.y,turn.y);h=choose(h,boxD(leaf,vec3<f32>(half.x*.98,half.y-.025,.025)),4u,s,(c+12u)*4u+1u,leaf.yxz,n);}return h;}
fn stair(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,rise:f32,run:f32,width:f32,s:u32,c:u32,reverse:bool)->GeoHit{var h=h0;var q=p-center;if(reverse){q.z=-q.z;}let lower=boxD(q-vec3<f32>(0.,(rise+.92)*.5,0.),vec3<f32>(width*.5+.07,(rise+1.20)*.5,run*.5+.04));if(lower>h.d){return h;}let count=ceil(rise/.18);let tread=run/count;let stepH=rise/count;
 // Finite concrete treads and risers leave real walkable headroom below the next flight.
 for(var k=0u;k<u32(count);k++){let i=f32(k);let top=(i+1.)*stepH;let z=-run*.5+(i+.5)*tread;let tq=q-vec3<f32>(0.,top-.07,z);let th=vec3<f32>(width*.5,.07,tread*.5+.0001);let tn=boxN(tq,th);h=choose(h,boxD(tq,th),9u,s,c,tq,vec3<f32>(tn.xy,select(tn.z,-tn.z,reverse)));let rh=vec3<f32>(width*.5,(stepH+.14)*.5,.018);let rq=q-vec3<f32>(0.,top-rh.y,-run*.5+i*tread+.018);let rn=boxN(rq,rh);h=choose(h,boxD(rq,rh),9u,s,c,rq,vec3<f32>(rn.xy,select(rn.z,-rn.z,reverse)));}
 let zz=select(1.,-1.,reverse);let a=center+vec3<f32>(width*.5+.035,0.,-run*.5*zz);let b=center+vec3<f32>(width*.5+.035,rise,run*.5*zz);h=rail(h,p,a,b,s,c+10u);h=rail(h,p,a-vec3<f32>(width+.07,0.,0.),b-vec3<f32>(width+.07,0.,0.),s,c+10000u);return h;}
fn bed(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,s:u32,c:u32,bunk:bool)->GeoHit{var h=h0;let q=p-center;let upper=select(.0,1.22,bunk&&q.y>.95);let y=.44+upper;let lx=select(-.53,.53,q.x>0.);let lz=select(-.99,.99,q.z>0.);h=woodBox(h,p,center+vec3<f32>(lx,select(.61,1.11,bunk),lz),vec3<f32>(.042,select(.61,1.11,bunk),.042),s,c,1u);h=woodBox(h,p,center+vec3<f32>(lx,y,0.),vec3<f32>(.032,.085,1.04),s,c+1u,2u);h=woodBox(h,p,center+vec3<f32>(0.,y,lz),vec3<f32>(.55,.085,.033),s,c+2u,0u);let slat=clamp(round(q.z/.15),-6.,6.)*.15;h=woodBox(h,p,center+vec3<f32>(0.,y+.015,slat),vec3<f32>(.53,.019,.049),s,c+3u,0u);h=addBox(h,p,center+vec3<f32>(0.,y+.14,0.),vec3<f32>(.515,.09,.96),7u,s,c+4u);h=addBox(h,p,center+vec3<f32>(0.,y+.26,.72),vec3<f32>(.37,.10,.18),7u,s,c+5u);let roll=q-vec3<f32>(0.,y+.26,-.66);h=choose(h,boxD(roll,vec3<f32>(.49,.085,.22))-.035,7u,s,c+6u,roll,boxN(roll,vec3<f32>(.49,.085,.22)));return h;}
fn table(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec2<f32>,height:f32,s:u32,c:u32)->GeoHit{var h=h0;let q=p-center;h=woodBox(h,p,center+vec3<f32>(0.,height,0.),vec3<f32>(half.x,.035,half.y),s,c,0u);let corner=vec3<f32>(select(-1.,1.,q.x>0.)*(half.x-.055),height*.5,select(-1.,1.,q.z>0.)*(half.y-.055));h=woodBox(h,p,center+corner,vec3<f32>(.035,height*.5,.035),s,c+1u,1u);return h;}
fn stool(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,s:u32,c:u32)->GeoHit{return table(h0,p,center,vec2<f32>(.19),.43,s,c);}
fn roomLife(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let programmeCode=u32(b.z);let side=select(1.,-1.,u32(rec(s,3u).x)==2u);let livingX=a.x-side*1.51;let bay=select(-1.,1.,p.x>livingX);let center=vec3<f32>(livingX+bay*(a.z-3.1)*.245,a.y,max(1.30,b.x+2.20));let q=p-center;let c=200000u+s*1000u+select(0u,400u,bay>0.);
 if(programmeCode==4u||programmeCode==5u||programmeCode==8u||programmeCode==9u||programmeCode==11u||programmeCode>=12u){let compact=b.x> -1.;let ix=center.x-bay*select(.82,.95,compact);h=bed(h,p,vec3<f32>(center.x+bay*.15,a.y,min(center.z+.25,1.55)),s,c,programmeCode==5u);h=woodBox(h,p,vec3<f32>(ix,a.y+.63,select(min(center.z+1.7,2.3),b.y-.75,compact)),vec3<f32>(.35,.63,.3),s,c+20u,1u);h=table(h,p,vec3<f32>(select(center.x-.1,ix,compact),a.y,select(center.z-1.35,1.6,compact)),vec2<f32>(.48,.26),.72,s,c+21u);h=stool(h,p,vec3<f32>(select(center.x+.15,ix,compact),a.y,select(center.z-1.9,.9,compact)),s,c+23u);}
 else if(programmeCode==2u){let ix=clamp(round(q.x/.83),-1.,1.);let iz=clamp(round((q.z+.20)/1.05),-1.,1.);let tc=center+vec3<f32>(ix*.83,0.,iz*1.05);h=table(h,p,tc,vec2<f32>(.33,.22),.62,s,c+30u);h=stool(h,p,tc+vec3<f32>(0.,0.,-.43),s,c+32u);h=woodBox(h,p,vec3<f32>(a.x,a.y+1.18,b.y-.25),vec3<f32>(1.2,.48,.045),s,c+34u,0u);}
 else if(programmeCode==3u){h=stool(h,p,center,s,c+40u);h=woodBox(h,p,center+vec3<f32>(0.,.76,.13),vec3<f32>(.24,.28,.03),s,c+42u,1u);h=addBox(h,p,center+vec3<f32>(0.,1.24,1.),vec3<f32>(.36,.56,.015),5u,s,c+43u);h=table(h,p,center+vec3<f32>(0.,0.,.82),vec2<f32>(.52,.20),.85,s,c+44u);}
 else{h=table(h,p,center,vec2<f32>(.85,.6),select(.78,.93,programmeCode==0u),s,c+50u);h=stool(h,p,center+vec3<f32>(0.,0.,-.9),s,c+52u);if(programmeCode==0u||programmeCode==6u){let qm=p-(center+vec3<f32>(.15,1.04,0.));let fly=max(length(qm.yz)-.24,abs(qm.x)-.04);h=choose(h,fly,3u,s,c+54u,qm,normalize(vec3<f32>(.1,qm.yz)));h=addBox(h,p,center+vec3<f32>(-.13,.98,.03),vec3<f32>(.27,.12,.15),3u,s,c+55u);}else{let pot=p-(center+vec3<f32>(.26,1.,.12));let shell=max(max(length(pot.xz)-.22,abs(pot.y)-.19),-max(length(pot.xz)-.195,pot.y+.15));h=choose(h,shell,3u,s,c+56u,pot,normalize(vec3<f32>(pot.x,.2,pot.z)));}}
 let sh=vec3<f32>(center.x-bay*.85,a.y+1.37,b.y-.30);h=woodBox(h,p,sh,vec3<f32>(.6,.035,.22),s,c+70u,0u);h=addBox(h,p,sh+vec3<f32>(.15,.18,.01),vec3<f32>(.20,.14,.14),7u,s,c+71u);return h;}
fn wetService(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let bid=u32(rec(s,3u).x);let signX=select(-1.,1.,bid==2u);let center=vec3<f32>(a.x+signX*(a.z*.5-.75),a.y,b.y-1.05);let q=p-center;let basinQ=q-vec3<f32>(0.,.78,0.);let outer=boxD(basinQ,vec3<f32>(.5,.18,.34))-.04;let cavity=boxD(basinQ-vec3<f32>(0.,.055,0.),vec3<f32>(.46,.20,.30))-.025;h=choose(h,max(outer,-cavity),3u,s,800000u+s,basinQ,boxN(basinQ,vec3<f32>(.5,.18,.34)));let corner=vec3<f32>(select(-.43,.43,q.x>0.),.32,select(-.28,.28,q.z>0.));h=addBox(h,p,center+corner,vec3<f32>(.025,.32,.025),3u,s,800100u+s);h=addPipe(h,p,center+vec3<f32>(0.,0.,.36),center+vec3<f32>(0.,1.18,.36),.022,s,800200u+s);h=addPipe(h,p,center+vec3<f32>(0.,1.18,.36),center+vec3<f32>(0.,1.18,.10),.023,s,800300u+s);h=addPipe(h,p,center+vec3<f32>(0.,.56,0.),center+vec3<f32>(0.,.10,0.),.04,s,800400u+s);h=woodBox(h,p,center+vec3<f32>(.84,.72,.03),vec3<f32>(.26,.035,.35),s,800500u+s,0u);return h;}
fn canopy(h0:GeoHit,p:vec3<f32>,center:vec3<f32>,half:vec2<f32>,s:u32,c:u32)->GeoHit{var h=h0;let q=p-center;let slope=.18;let yy=q.y-slope*q.z-.014*sin(q.x*52.);let sheet=boxD(vec3<f32>(q.x,yy,q.z),vec3<f32>(half.x,.025,half.y))*.94;h=choose(h,sheet,3u,s,c,q,normalize(vec3<f32>(0.,1.,-slope)));let x=select(-half.x+.1,half.x-.1,q.x>0.);h=addPipe(h,p,center+vec3<f32>(x,-slope*half.y,-half.y),center+vec3<f32>(x,slope*half.y,half.y),.035,s,c+1u);h=addPipe(h,p,center+vec3<f32>(x,slope*half.y,half.y),center+vec3<f32>(x,slope*half.y-.95,half.y),.031,s,c+2u);return h;}
// Dated household event, partitioned along existing execution groups.
fn householdFrontageShell(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let event=rec(s,3u);if(event.y<.5||u.size.w<event.w){return h;}let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let depth=event.z;let wallZ=frontZ(s,u32(event.y)-1u);let z=wallZ-depth;let base=a.y;let height=rec(s,5u).z;let c=1000000u;let fq=p-vec3<f32>(x,base+height*.5,z);
 let wh=vec2<f32>(min(.90,hw-.20),.52);let window=vec3<f32>(x,base+1.48,z);
 h=choose(h,max(boxD(fq,vec3<f32>(hw,height*.5,.065)),-boxD(p-window,vec3<f32>(wh,.20))),1u,s,c,fq,boxN(fq,vec3<f32>(hw,height*.5,.065)));
 let side=select(-1.,1.,p.x>x);let sq=p-vec3<f32>(x+side*hw,base+height*.5,wallZ-depth*.5);
 h=choose(h,boxD(sq,vec3<f32>(.055,height*.5,depth*.5)),1u,s,c+1u,sq,boxN(sq,vec3<f32>(.055,height*.5,depth*.5)));
return h;}
fn householdFrontageOpenings(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let event=rec(s,3u);if(event.y<.5||u.size.w<event.w){return h;}let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let depth=event.z;let wallZ=frontZ(s,u32(event.y)-1u);let z=wallZ-depth;let base=a.y;let height=rec(s,5u).z;let c=1000000u;let wh=vec2<f32>(min(.90,hw-.20),.52);let window=vec3<f32>(x,base+1.48,z);h=windowParts(h,p,window,wh,s,c+20u,false,false,false);return h;}
fn householdFrontageLife(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let event=rec(s,3u);if(event.y<.5||u.size.w<event.w){return h;}let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let depth=event.z;let wallZ=frontZ(s,u32(event.y)-1u);let z=wallZ-depth;let base=a.y;let height=rec(s,5u).z;let c=1000000u; if(rec(s,5u).w>.5){return h;}h=table(h,p,vec3<f32>(x+.35,base,z+.26),vec2<f32>(.48,.17),.74,s,c+40u);
 h=woodBox(h,p,vec3<f32>(x-.55,base+.91,z+.18),vec3<f32>(.30,.035,.14),s,c+44u,0u);
return h;}
fn householdFrontageStorage(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let event=rec(s,3u);if(event.y<.5||u.size.w<event.w||rec(s,5u).w<.5){return h;}let a=rec(s,0u);let b=rec(s,1u);let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let tier=clamp(round((p.y-a.y-.55)/.49),0.,2.);let center=vec3<f32>(x,a.y+.55+tier*.49,frontZ(s,u32(event.y)-1u)-event.z+.20);h=woodBox(h,p,center,vec3<f32>(hw*.70,.03,.11),s,1000040u,0u);let clothTier=clamp(round((p.y-a.y-.73)/.49),0.,2.);h=addBox(h,p,vec3<f32>(x,a.y+.73+clothTier*.49,frontZ(s,u32(event.y)-1u)-event.z+.20),vec3<f32>(hw*.46,.13,.105),7u,s,1000043u);return h;}
fn frontDrainRun(h0:GeoHit,p:vec3<f32>,s:u32,startX:f32,cell:u32,y:f32,c:u32)->GeoHit{var h=h0;let a=rec(s,0u);var x=startX;var z=frontZ(s,cell)-.14;for(var j=cell;j<3u;j++){var endX=a.x+a.z*.5-.15;if(j<2u){let next=frontZ(s,j+1u)-.14;let corner=frontageBounds(s,j).y+sign(next-z)*.15;if(abs(corner-x)>.0001){h=addPipe(h,p,vec3<f32>(x,y,z),vec3<f32>(corner,y,z),.026,s,c+j*3u);}if(abs(next-z)>.0001){h=addPipe(h,p,vec3<f32>(corner,y,z),vec3<f32>(corner,y,next),.026,s,c+j*3u+1u);}x=corner;z=next;}else{if(abs(endX-x)>.0001){h=addPipe(h,p,vec3<f32>(x,y,z),vec3<f32>(endX,y,z),.026,s,c+j*3u);}}}return h;}
fn householdFrontageExterior(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let event=rec(s,3u);if(event.y<.5||u.size.w<event.w){return h;}let eb=frontageBounds(s,u32(event.y)-1u);let x=(eb.x+eb.y)*.5;let hw=(eb.y-eb.x)*.43;let depth=event.z;let wallZ=frontZ(s,u32(event.y)-1u);let z=wallZ-depth;let base=a.y;let height=rec(s,5u).z;let c=1000000u; h=canopy(h,p,vec3<f32>(x,base+height+.015,wallZ-depth*.5),vec2<f32>(hw+.07,depth*.5+.08),s,c+60u);
 // Drain to the existing riser.
 let gutter=vec3<f32>(x+hw+.07,base+height+.015-.18*(depth*.5+.08)-.025,z-.08);let oldPipe=vec3<f32>(gutter.x,base+.23,wallZ-.14);
 h=addPipe(h,p,vec3<f32>(x-hw-.07,gutter.y,gutter.z),gutter,.026,s,c+72u);h=addPipe(h,p,gutter,vec3<f32>(gutter.x,oldPipe.y,oldPipe.z),.026,s,c+70u);
 h=frontDrainRun(h,p,s,gutter.x,u32(event.y)-1u,oldPipe.y,c+80u);
return h;}
// Metric frontage rules are compiled with household uses, not randomized per pixel.
fn frontageCell(s:u32,x:f32)->u32{let a=rec(s,0u);let f=rec(s,4u);let u=(x-a.x)/a.z+.5;return select(select(0u,1u,u>=f.x),2u,u>=f.y);}
fn frontageBounds(s:u32,cell:u32)->vec2<f32>{let a=rec(s,0u);let f=rec(s,4u);let lo=select(select(0.,f.x,cell==1u),f.y,cell==2u);let hi=select(select(f.x,f.y,cell==1u),1.,cell==2u);return a.x-a.z*.5+vec2<f32>(lo,hi)*a.z;}
fn frontZ(s:u32,cell:u32)->f32{return rec(s,6u)[cell];}
fn frontAt(s:u32,x:f32)->f32{return frontZ(s,frontageCell(s,x));}
fn supportFrontZ(s:u32,cell:u32)->f32{return rec(s,7u)[cell];}
fn hasTerrace(s:u32,cell:u32)->bool{return (u32(rec(s,6u).w)&(1u<<cell))!=0u;}
fn hasPlatform(s:u32,cell:u32)->bool{return hasTerrace(s,cell)||(rec(s,1u).w>.5&&(frontageType(s,cell)>=3u||(u32(rec(s,4u).w)&(1u<<cell))!=0u));}
fn platformFront(s:u32,cell:u32)->f32{return select(frontZ(s,cell)-.95,supportFrontZ(s,cell),hasTerrace(s,cell));}

fn frontageType(s:u32,cell:u32)->u32{return (u32(rec(s,5u).x)>>(cell*3u))&7u;}
fn frontageAperture(s:u32,cell:u32)->vec4<f32>{let a=rec(s,0u);let fb=frontageBounds(s,cell);let pitch=fb.y-fb.x;let kind=frontageType(s,cell);let door=kind>=3u;return vec4<f32>((fb.x+fb.y)*.5,a.y+select(select(1.48,1.88,kind==0u),select(1.03,1.15,kind==4u),door),select(select(pitch*.30,pitch*.41,kind==2u),select(min(.51,pitch*.29),pitch*.40,kind==4u),door),select(select(.63,.32,kind==0u),select(1.02,1.14,kind==4u),door));}
fn frontageOpenings(h0:GeoHit,p:vec3<f32>,s:u32,c:u32)->GeoHit{var h=h0;let b=rec(s,1u);let count=min(3u,arrayLength(&worldRules));for(var cell=0u;cell<count;cell++){let ap=frontageAperture(s,cell);h=frontageOpening(h,p,s,cell,vec3<f32>(ap.xy,frontZ(s,cell)-.005),ap.zw,c+20u+cell*10000u);}return h;}
fn frontageOpening(h0:GeoHit,p:vec3<f32>,s:u32,cell:u32,center:vec3<f32>,half:vec2<f32>,c:u32)->GeoHit{var h=h0;let kind=frontageType(s,cell);if(kind!=0u){return windowParts(h,p,center,half,s,c,false,kind>=3u,(u32(rec(s,7u).w)&(1u<<cell))!=0u);}let q=p-center;let frame=max(boxD(q,vec3<f32>(half+vec2<f32>(.035),.055)),-boxD(q,vec3<f32>(half-vec2<f32>(.012),.10)));h=choose(h,frame,3u,s,c,q,vec3<f32>(0.,0.,-1.));let slatY=clamp(round(q.y/.13)*.13,-half.y+.05,half.y-.05);let sq=q-vec3<f32>(0.,slatY,0.);let tilted=vec3<f32>(sq.x,sq.y+.34*sq.z,sq.z);h=choose(h,boxD(tilted,vec3<f32>(half.x,.018,.065))*.94,3u,s,c+1u,sq,normalize(vec3<f32>(0.,.34,-1.)));return h;}
fn frontageShelter(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let f=rec(s,4u);let count=min(3u,arrayLength(&worldRules));for(var cell=0u;cell<count;cell++){if((u32(f.z)&(1u<<cell))==0u){continue;}let bounds=frontageBounds(s,cell);let x=(bounds.x+bounds.y)*.5;let width=(bounds.y-bounds.x)*.44;let drop=select(.33,.20,b.z==0.||b.z==1.);let deep=select(.44,.60,b.w>.5);let c=1200000u+cell*20u;let center=vec3<f32>(x,a.y+a.w-drop,frontZ(s,cell)-deep*.62);h=canopy(h,p,center,vec2<f32>(width,deep),s,c);let end=center+vec3<f32>(width,-.18*deep-.025,-deep);h=addPipe(h,p,end-vec3<f32>(width*2.,0.,0.),end,.028,s,c+5u);}return h;}
fn frontageDrainage(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let f=rec(s,4u);let count=min(3u,arrayLength(&worldRules));for(var cell=0u;cell<count;cell++){if((u32(f.z)&(1u<<cell))==0u){continue;}let bounds=frontageBounds(s,cell);let x=(bounds.x+bounds.y)*.5;let width=(bounds.y-bounds.x)*.44;let drop=select(.33,.20,b.z==0.||b.z==1.);let deep=select(.44,.60,b.w>.5);let c=1200000u+cell*20u;let end=vec3<f32>(x+width,a.y+a.w-drop-.18*deep-.025,frontZ(s,cell)-deep*1.62);let sink=vec3<f32>(end.x,a.y+.23,frontZ(s,cell)-.14);h=addPipe(h,p,end,sink,.026,s,c+6u);h=frontDrainRun(h,p,s,sink.x,cell,sink.y,c+7u);}return h;}
fn frontageDrying(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let mask=u32(rec(s,4u).w);if(mask==0u){return h;}let cell=select(select(0u,1u,(mask&2u)>0u),2u,(mask&4u)>0u);let bounds=frontageBounds(s,cell);let x=(bounds.x+bounds.y)*.5;let half=min((bounds.y-bounds.x)*.36,1.03);let z=platformFront(s,cell)-.25;let c=1300000u+cell*20u;h=addPipe(h,p,vec3<f32>(x-half,a.y+1.96,z),vec3<f32>(x+half,a.y+1.96,z),.009,s,c);for(var k=0u;k<2u;k++){let endX=x+select(-half,half,k==1u);let supportZ=select(frontZ(s,cell)-.10,platformFront(s,cell)+.06,hasTerrace(s,cell));h=addPipe(h,p,vec3<f32>(endX,a.y+1.96,z),vec3<f32>(endX,a.y+1.96,supportZ),.013,s,c+1u+k*3u);if(hasTerrace(s,cell)){h=addPipe(h,p,vec3<f32>(endX,a.y,supportZ),vec3<f32>(endX,a.y+1.96,supportZ),.022,s,c+10u+k);}}let side=select(-1.,1.,p.x>x);let q=p-vec3<f32>(x+side*half*.45,a.y+1.52,z);let fold=.045*sin(q.x*20.)+.025*sin(q.y*9.);let cloth=vec3<f32>(q.x,q.y,q.z-fold);h=choose(h,boxD(cloth,vec3<f32>(select(.19,.27,side>0.),select(.39,.31,side>0.),.018))*.88,7u,s,c+select(2u,3u,side>0.),q.xzy,vec3<f32>(0.,0.,-1.));return h;}
fn parcelSlabs(h0:GeoHit,p:vec3<f32>,s:u32,inner:f32,stairZ:f32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);for(var cell=0u;cell<3u;cell++){let xb=frontageBounds(s,cell);let front=frontZ(s,cell);let floorFront=min(front,supportFrontZ(s,cell));let fq=p-vec3<f32>((xb.x+xb.y)*.5,a.y-.08,(floorFront+b.y)*.5);var slab=boxD(fq,vec3<f32>((xb.y-xb.x)*.5,.10,(b.y-floorFront)*.5));if(rec(s,2u).w>0.){slab=max(slab,-boxD(p-vec3<f32>(inner,a.y-.08,stairZ),vec3<f32>(1.10,.30,2.15)));}h=choose(h,slab,9u,s,1500000u+cell,fq,vec3<f32>(0.,1.,0.));let cq=p-vec3<f32>((xb.x+xb.y)*.5,a.y+a.w-.055,(front+b.y)*.5);let ceilingD=max(boxD(cq,vec3<f32>((xb.y-xb.x)*.5,.065,(b.y-front)*.5)),-boxD(p-vec3<f32>(inner,a.y+a.w-.055,stairZ),vec3<f32>(1.10,.30,2.15)));h=choose(h,ceilingD,9u,s,1500010u+cell,cq,vec3<f32>(0.,-1.,0.));}return h;}
fn parcelFacade(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);for(var cell=0u;cell<3u;cell++){let xb=frontageBounds(s,cell);let front=frontZ(s,cell);let ap=frontageAperture(s,cell);let half=vec3<f32>((xb.y-xb.x)*.5,a.w*.5,.11);let q=p-vec3<f32>((xb.x+xb.y)*.5,a.y+a.w*.5,front);let opening=boxD(p-vec3<f32>(ap.xy,front),vec3<f32>(ap.zw,.32));h=choose(h,max(boxD(q,half),-opening),1u,s,1400000u+cell,q,boxN(q,half));if(cell<2u){let next=frontZ(s,cell+1u);if(abs(next-front)>.001){let rq=p-vec3<f32>(xb.y,a.y+a.w*.5,(front+next)*.5);let rh=vec3<f32>(.11,a.w*.5,abs(next-front)*.5);h=choose(h,boxD(rq,rh),1u,s,1400010u+cell,rq,boxN(rq,rh));}}}return h;}
fn parcelPlatforms(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);for(var cell=0u;cell<3u;cell++){if(!hasPlatform(s,cell)){continue;}let xb=frontageBounds(s,cell);let front=platformFront(s,cell);let back=frontZ(s,cell);let c=1700000u+cell*100u;if(!hasTerrace(s,cell)){h=addBox(h,p,vec3<f32>((xb.x+xb.y)*.5,a.y-.02,(front+back)*.5),vec3<f32>((xb.y-xb.x)*.5,.085,(back-front)*.5+.01),9u,s,c);}h=rail(h,p,vec3<f32>(xb.x,a.y,front+.04),vec3<f32>(xb.y,a.y,front+.04),s,c+10u);
 for(var edge=0u;edge<2u;edge++){let x=select(xb.x,xb.y,edge==1u);let outer=(cell==0u&&edge==0u)||(cell==2u&&edge==1u);let neighbour=select(select(cell-1u,cell+1u,edge==1u),cell,outer);var end=back;if(!outer){if(hasPlatform(s,neighbour)){end=platformFront(s,neighbour);if(end<=front+.001){continue;}}else{end=min(back,frontZ(s,neighbour));}}if(end>front+.045){h=rail(h,p,vec3<f32>(x,a.y,front+.04),vec3<f32>(x,a.y,end),s,c+20u+edge*4u);}}
 }return h;}
fn storey(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let c=rec(s,2u);let bid=u32(rec(s,3u).x);let halfW=a.z*.5;let middleZ=(b.x+b.y)*.5;let depth=(b.y-b.x)*.5;let fronts=rec(s,7u).xyz;let boundFront=min(b.x,min(fronts.x,min(fronts.y,fronts.z)))-1.25;let center=vec3<f32>(a.x,a.y+a.w*.5+.45,(boundFront+b.y+.1)*.5);let bound=boxD(p-center,vec3<f32>(halfW+.9,a.w*.5+.63,(b.y+.1-boundFront)*.5));if(bound>h.d+.024){return h;}if(bound>.22){return choose(h,bound-.06,0u,s,0u,p,vec3<f32>(0.,1.,0.));}
 let wall=.11;let q=p-center;let f=u32(c.w);let base=a.y;let top=base+a.w;let family=1000u+s*100u;
 // Main slab leaves a real alternating switchback stair opening next to the gap.
 let inner=select(a.x+halfW-1.90,a.x-halfW+1.90,bid==2u);let stairZ=2.4;let accessZ=.25;let slabQ=p-vec3<f32>(a.x,base-.08,middleZ);h=parcelSlabs(h,p,s,inner,stairZ);
 // Front and rear apertures programmeCode the actual storey footprint and programme.
 let cell=frontageCell(s,p.x);let fb=frontageBounds(s,cell);let pitch=fb.y-fb.x;let bx=(fb.x+fb.y)*.5;let ap=frontageAperture(s,cell);h=parcelFacade(h,p,s);h=frontageOpenings(h,p,s,family);
 let rq=p-vec3<f32>(a.x,base+a.w*.5,b.y);let rearHole=boxD(p-vec3<f32>(bx,base+1.55,b.y),vec3<f32>(pitch*.26,.58,.35));h=choose(h,max(boxD(rq,vec3<f32>(halfW,a.w*.5,wall)),-rearHole),1u,s,family+2u,rq,boxN(rq,vec3<f32>(halfW,a.w*.5,wall)));h=windowParts(h,p,vec3<f32>(bx,base+1.55,b.y),vec2<f32>(pitch*.26,.58),s,family+25u,false,false,false);
 h=householdFrontageShell(h,p,s);h=householdFrontageOpenings(h,p,s);
 // Both sides contain real windows and gap-side doors to shared landings.
 let signX=select(-1.,1.,p.x>a.x);let sideX=a.x+signX*halfW;let gapSide=(bid==1u&&signX>0.)||(bid==2u&&signX<0.);let sideFront=frontZ(s,select(0u,2u,signX>0.));let sideDepth=(b.y-sideFront)*.5;let sideMid=(b.y+sideFront)*.5;let sideCell=clamp(floor((p.z-sideFront)/2.5),0.,floor((b.y-sideFront)/2.5)-1.);let rawSZ=sideFront+(sideCell+.5)*2.5;let isDoor=gapSide&&(f==0u||s==3u||s==17u||s==7u||s==21u||s==10u||s==24u)&&abs(p.z-accessZ)<1.5;let sz=select(rawSZ,accessZ,isDoor);let sk=frontageType(s,min(u32(sideCell),2u));let sh=select(vec2<f32>(select(select(.45,.76,sk==2u),.34,sk==0u),select(.60,.30,sk==0u)),vec2<f32>(.48,1.02),isDoor);let sy=select(base+select(1.48,1.88,sk==0u),base+1.03,isDoor);let sideQ=p-vec3<f32>(sideX,base+a.w*.5,sideMid);let sideHole=boxD((p-vec3<f32>(sideX,sy,sz)).zyx,vec3<f32>(sh,.32));h=choose(h,max(boxD(sideQ,vec3<f32>(wall,a.w*.5,sideDepth)),-sideHole),1u,s,family+3u,sideQ,boxN(sideQ,vec3<f32>(wall,a.w*.5,sideDepth)));h=windowParts(h,p,vec3<f32>(sideX,sy,sz),sh,s,family+30u,true,isDoor,false);
 // Life split: side stair/service strip, small front work/sleep area, rear wet/storage.
 let partitionX=select(inner-1.12,inner+1.12,bid==2u);let coreFront=max(frontAt(s,partitionX-.075),frontAt(s,partitionX+.075))+.12;let coreBack=b.y-.12;let coreDepth=(coreBack-coreFront)*.5;let pq=p-vec3<f32>(partitionX,base+a.w*.5,(coreFront+coreBack)*.5);let pd=boxD(pq,vec3<f32>(.075,a.w*.5,coreDepth));let doorHole=boxD(p-vec3<f32>(partitionX,base+1.0,stairZ+select(-1.44,1.44,bid==2u)),vec3<f32>(.2,1.,.48));h=choose(h,max(pd,-doorHole),1u,s,family+4u,pq,boxN(pq,vec3<f32>(.075,a.w*.5,coreDepth)));let sepZ=select(2.9,3.55,b.z==0.||b.z==6.);let livingCX=a.x+select(-1.51,1.51,bid==2u);let livingHalf=(a.z-3.02)*.5;let wq=p-vec3<f32>(livingCX,base+a.w*.5,sepZ);let wetWall=boxD(wq,vec3<f32>(livingHalf,a.w*.5,.065));let wetDoor=boxD(p-vec3<f32>(partitionX+select(-.60,.60,bid==2u),base+.99,sepZ),vec3<f32>(.43,.99,.18));h=choose(h,max(wetWall,-wetDoor),1u,s,family+5u,wq,boxN(wq,vec3<f32>(livingHalf,a.w*.5,.065)));
 if(b.z==4.||b.z==5.||b.z==8.||b.z==9.||b.z==11.){let livingSide=select(1.,-1.,bid==2u);let splitX=a.x-livingSide*1.51;let partFront=max(b.x+.12,-2.0);let partRear=sepZ-.07;let partQ=p-vec3<f32>(splitX,base+a.w*.5,(partFront+partRear)*.5);let div=boxD(partQ,vec3<f32>(.065,a.w*.5,(partRear-partFront)*.5));let passageCut=boxD(p-vec3<f32>(splitX,base+1.,max(-.25,b.x+.70)),vec3<f32>(.18,1.,.42));h=choose(h,max(div,-passageCut),1u,s,family+7u,partQ,boxN(partQ,vec3<f32>(.065,a.w*.5,(partRear-partFront)*.5)));}
 // Two flights and a true half-height turning platform, with continuous handrail.
 let rev=bid==2u;let firstX=inner-.53;let secondX=inner+.53;h=stair(h,p,vec3<f32>(firstX,base,stairZ),a.w*.5,2.02,.98,s,700000u+s*100u,rev);h=stair(h,p,vec3<f32>(secondX,base+a.w*.5,stairZ),a.w*.5,2.02,.98,s,700030u+s*100u,!rev);let landingZ=stairZ+select(1.44,-1.44,rev);h=addBox(h,p,vec3<f32>(inner,base+a.w*.5-.08,landingZ),vec3<f32>(1.10,.08,.43),9u,s,family+70u);let turnGuardZ=landingZ+select(.40,-.40,rev);h=rail(h,p,vec3<f32>(inner-1.06,base+a.w*.5,turnGuardZ),vec3<f32>(inner+1.06,base+a.w*.5,turnGuardZ),s,family+72u);
 // Same handedness on successive floors: arrival and next departure share the unobstructed landing.
 let entryZ=stairZ+select(-1.44,1.44,rev);let outer=select(1.,-1.,bid==2u);h=addBox(h,p,vec3<f32>(inner,base-.08,entryZ),vec3<f32>(1.10,.08,.43),9u,s,family+190u);let entryGuardZ=entryZ+select(-.40,.40,rev);h=rail(h,p,vec3<f32>(inner-1.06,base,entryGuardZ),vec3<f32>(inner+1.06,base,entryGuardZ),s,family+192u);
 let guardX=inner+outer*1.10;let routeSign=select(1.,-1.,rev);h=rail(h,p,vec3<f32>(guardX,base,stairZ-1.01*routeSign),vec3<f32>(guardX,base,stairZ+2.15*routeSign),s,family+196u);h=rail(h,p,vec3<f32>(guardX,base,stairZ-2.15*routeSign),vec3<f32>(guardX,base,stairZ-1.87*routeSign),s,family+200u);h=rail(h,p,vec3<f32>(guardX,base+a.w*.5,landingZ-.43),vec3<f32>(guardX,base+a.w*.5,landingZ+.43),s,family+204u);
 // Shared balcony is only generated when a rent/addition event grants access.
 h=parcelPlatforms(h,p,s);
 h=frontageShelter(h,p,s);h=frontageDrying(h,p,s);
 h=householdFrontageExterior(h,p,s);
 // Joint-aligned water and drainage, not arbitrary noise streaks.
 let pipeX=a.x+halfW-.15;let pipeZ=frontZ(s,2u)-.14;let lowerZ=supportFrontZ(s,2u)-.14;h=addPipe(h,p,vec3<f32>(pipeX,base+.23,pipeZ),vec3<f32>(pipeX,top+.23,pipeZ),.047,s,family+90u);if(abs(lowerZ-pipeZ)>.001){h=addPipe(h,p,vec3<f32>(pipeX,base+.23,lowerZ),vec3<f32>(pipeX,base+.23,pipeZ),.047,s,family+93u);}h=addPipe(h,p,vec3<f32>(pipeX,base+.23,pipeZ),vec3<f32>(pipeX,base+.23,b.y),.025,s,family+91u);
 h=roomLife(h,p,s);h=householdFrontageLife(h,p,s);h=householdFrontageStorage(h,p,s);h=frontageDrainage(h,p,s);h=wetService(h,p,s);
 return h;}
fn roof(h0:GeoHit,p:vec3<f32>,s:u32)->GeoHit{var h=h0;let a=rec(s,0u);let b=rec(s,1u);let y=a.y+a.w;let mid=(b.x+b.y)*.5;let out=select(1.,-1.,rec(s,3u).x==2.);let inner=a.x+out*(a.z*.5-1.90);let rs=out;let ez=2.4-1.44*rs;let qf=p-vec3<f32>(a.x,y,mid);let slab=boxD(qf,vec3<f32>(a.z*.5,.10,(b.y-b.x)*.5));let hole=boxD(p-vec3<f32>(inner,y,2.4),vec3<f32>(1.10,.30,2.15));h=choose(h,max(slab,-hole),9u,s,900000u+s,qf,vec3<f32>(0.,1.,0.));h=addBox(h,p,vec3<f32>(inner,y+.02,ez),vec3<f32>(1.10,.08,.43),9u,s,920000u+s);
 for(var k=0u;k<2u;k++){let side=select(-1.,1.,k==1u);let x=inner+side*1.10;let c=921000u+s*100u+k*10u;h=rail(h,p,vec3<f32>(x,y+.1,2.4-2.15*rs),vec3<f32>(x,y+.1,2.4-1.87*rs),s,c);h=rail(h,p,vec3<f32>(x,y+.1,2.4-1.01*rs),vec3<f32>(x,y+.1,2.4+2.15*rs),s,c+3u);h=rail(h,p,vec3<f32>(inner-1.1,y+.1,2.4+side*2.15),vec3<f32>(inner+1.1,y+.1,2.4+side*2.15),s,c+6u);}
 h=rail(h,p,vec3<f32>(inner-1.1,y+.1,ez-.40*rs),vec3<f32>(inner+1.1,y+.1,ez-.40*rs),s,925000u+s*10u);h=rail(h,p,vec3<f32>(inner-1.1,y+.1,2.4-1.01*rs),vec3<f32>(inner,y+.1,2.4-1.01*rs),s,926000u+s*10u);
 let signX=select(-1.,1.,p.x>a.x);h=addBox(h,p,vec3<f32>(a.x+signX*(a.z*.5-.075),y+.60,mid),vec3<f32>(.075,.60,(b.y-b.x)*.5),1u,s,900010u+s);let signZ=select(b.x+.075,b.y-.075,p.z>mid);h=addBox(h,p,vec3<f32>(a.x,y+.60,signZ),vec3<f32>(a.z*.5,.60,.075),1u,s,900020u+s);
 let cc=vec3<f32>(a.x-out*1.51,y+2.50,mid+.15);h=canopy(h,p,cc,vec2<f32>(1.35,1.45),s,900030u+s);for(var k=0u;k<4u;k++){let dx=select(-1.25,1.25,(k&1u)>0u);let dz=select(-1.45,1.45,(k&2u)>0u);h=addPipe(h,p,vec3<f32>(cc.x+dx,y+.1,cc.z+dz),cc+vec3<f32>(dx,.18*dz,dz),.035,s,910000u+s*10u+k);}
 let q=p-vec3<f32>(a.x-out*3.6,y+.71,b.y-1.2);h=choose(h,max(length(q.xz)-.65,abs(q.y)-.61),3u,s,900040u+s,q,normalize(vec3<f32>(q.x,.15,q.z)));h=addPipe(h,p,vec3<f32>(a.x-out*2.4,y,b.x+.4),vec3<f32>(a.x-out*2.4,y+3.4,b.x+.4),.029,s,900050u+s);h=addPipe(h,p,vec3<f32>(a.x-out*2.4-.7,y+3.1,b.x+.4),vec3<f32>(a.x-out*2.4+.7,y+3.1,b.x+.4),.012,s,900052u+s);return h;}
fn borrowedStairs(h0:GeoHit,p:vec3<f32>,sa:u32,sb:u32,k:u32)->GeoHit{var h=h0;let a=rec(sa,0u);let b=rec(sb,0u);let xa=a.x+a.z*.5;let xb=b.x-b.z*.5;let z=.25;let landing=.48;let start=xa+landing;let end=xb-landing;let count=max(2u,u32(ceil(abs(b.y-a.y)/.18)));let rise=(b.y-a.y)/f32(count);let tread=(end-start)/f32(count-1u);let c=1960000u+k*100u;
 h=addBox(h,p,vec3<f32>(xa+(landing-.18)*.5,a.y-.09,z),vec3<f32>((landing+.18)*.5,.09,.58),9u,sa,c);h=addBox(h,p,vec3<f32>(xb-(landing-.18)*.5,b.y-.09,z),vec3<f32>((landing+.18)*.5,.09,.58),9u,sb,c+1u);
 for(var i=0u;i<count;i++){let level=a.y+f32(i+1u)*rise;let x=start+f32(i)*tread;let rh=vec3<f32>(.018,abs(rise)*.5+.07,.58);h=addBox(h,p,vec3<f32>(x,level-rise*.5-.07,z),rh,9u,sa,c+10u+i);if(i<count-1u){h=addBox(h,p,vec3<f32>(x+tread*.5,level-.07,z),vec3<f32>(tread*.5,.07,.58),9u,sa,c+20u+i);}}
 for(var side=0u;side<2u;side++){let zz=z+select(-.56,.56,side==1u);let id=c+40u+side*12u;h=rail(h,p,vec3<f32>(xa,a.y,zz),vec3<f32>(start,a.y,zz),sa,id);h=rail(h,p,vec3<f32>(start,a.y,zz),vec3<f32>(end,b.y,zz),sa,id+4u);h=rail(h,p,vec3<f32>(end,b.y,zz),vec3<f32>(xb,b.y,zz),sa,id+8u);}return h;}
// Three narrow linked leaves fold entirely over the level A platform.
fn borrowedGate(h0:GeoHit,p:vec3<f32>,sa:u32,k:u32,opened:bool)->GeoHit{var h=h0;let a=rec(sa,0u);let x=a.x+a.z*.5+.165;let c=1970000u+k*100u;let length=.72/3.;var hinge=vec3<f32>(x+.023,a.y,.70);
 for(var j=0u;j<3u;j++){let sign=select(1.,-1.,j==1u);let angle=select(0.,sign*1.50,opened);let sn=sin(angle);let cs=cos(angle);let normal=vec3<f32>(cs,0.,sn);let direction=vec3<f32>(sn,0.,-cs);let start=hinge-sign*.023*normal;let rel=p-(start+direction*length*.5+vec3<f32>(0.,.565,0.));let q=vec3<f32>(rel.x*cs+rel.z*sn,rel.y,rel.x*sn-rel.z*cs);let half=vec3<f32>(.023,.525,length*.5);let d=max(boxD(q,half),-boxD(q,vec3<f32>(.08,.455,length*.5-.03)));let n=boxN(q,half);h=choose(h,d,3u,sa,c+j,q,vec3<f32>(cs*n.x+sn*n.z,n.y,sn*n.x-cs*n.z));h=addPipe(h,p,hinge+vec3<f32>(0.,.06,0.),hinge+vec3<f32>(0.,1.08,0.),.009,sa,c+40u+j);hinge=start+direction*length-sign*.023*normal;}
 h=addPipe(h,p,hinge+vec3<f32>(0.,.06,0.),hinge+vec3<f32>(0.,1.08,0.),.009,sa,c+43u);
 // Fixed jamb posts stand on the same slab. Short guards close both side gaps.
 h=addPipe(h,p,vec3<f32>(x,a.y,.70),vec3<f32>(x,a.y+1.11,.70),.023,sa,c+10u);h=addPipe(h,p,vec3<f32>(x,a.y,-.02),vec3<f32>(x,a.y+1.11,-.02),.023,sa,c+11u);h=rail(h,p,vec3<f32>(x,a.y,-.31),vec3<f32>(x,a.y,-.02),sa,c+20u);h=rail(h,p,vec3<f32>(x,a.y,.70),vec3<f32>(x,a.y,.81),sa,c+30u);return h;}
fn querySettlement(p:vec3<f32>,maximum:f32)->GeoHit{var h=GeoHit(maximum,0u,0u,0u,0u,p,vec3<f32>(0.,1.,0.),0u);if(!excludedFieldObject(0u,0u)){h=GeoHit(min(maximum,p.y),6u,0u,0u,0u,p,vec3<f32>(0.,1.,0.),0u);}let storeyCount=arrayLength(&worldRules)/8u;for(var s=0u;s<storeyCount;s++){h=storey(h,p,s);}h=roof(h,p,13u);h=roof(h,p,26u);
 // Three explicitly negotiated borrowed connections. Differences are stepped,
 // never visually erased by forcing the two independently grown floors level.
 let connectionCount=min(3u,arrayLength(&worldRules)/72u);for(var k=0u;k<connectionCount;k++){let sa=array<u32,3>(3u,7u,10u)[k];let sb=array<u32,3>(17u,21u,24u)[k];let a=rec(sa,0u);let b=rec(sb,0u);let xa=a.x+a.z*.5;let xb=b.x-b.z*.5;let z=.25;let span=xb-xa;h=borrowedStairs(h,p,sa,sb,k);
 // Gate controller is a shared lease, with one time-dependent leaf in this world.
 let opened=u.size.z>=21600.&&u.size.z<79200.;h=borrowedGate(h,p,sa,k,opened);
 // Clothes hung between usable windows: the line has no navigation edge.
 let clothX=clamp(round((p.x-xa)/.58),0.,2.)*.58+xa+.22;let sag=.11*sin((clothX-xa)/max(span,.1)*3.14159265);let cq=p-vec3<f32>(clothX,min(a.y,b.y)+1.95-sag,z+1.);let fold=.045*sin(cq.x*20.)+.025*sin(cq.y*9.);h=choose(h,boxD(vec3<f32>(cq.x,cq.y,cq.z-fold),vec3<f32>(.22,.38,.018))*.88,7u,sa,950060u+k,cq.xzy,vec3<f32>(0.,0.,-1.));h=addPipe(h,p,vec3<f32>(xa,min(a.y,b.y)+2.4,z+1.),vec3<f32>(xb,min(a.y,b.y)+2.4,z+1.),.008,sa,950070u+k);}
 return h;}


// R3.12 family-0 original fitted edge waves, field and surface core.
// WGSL syntax/explicit arguments are new. No renderer, vertex or instance lists.
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }












































// Return original [chips, contour, weight] contributions instead of GLSL inout.





// Exact original family-0 distance, in metres. This is not guaranteed Lipschitz 1.0



// New explicit isotropic footprint bridge. Original wave, 17 octaves and gates
// remain; the original screen dFdx/dFdy footprint is NOT claimed equivalent.

// Raw original family-0 albedo, roughness and height. No lighting/tone mapping.


// R3.12 original macro/micro/observed field algebra. Explicit coordinates and
// derivative-free physical footprint are receiver bridges. No patch silhouette.
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}












// Syntax port of locked V26 waterWeatherMasks dependency closure.
// pField is the ORIGINAL normalized material field coordinate, not metres.
// localPosM/dimensionsM are original physical local position/size for gates.












// Existing explicitly authored unified fabric bridge, not source physical years.
struct KpFabricState { moisture:f32, damage:f32, retention:f32, thicknessM:f32, baseScale:f32, roughDelta:f32, }


// Apply the exact same resolved state used by receiver coat retention/thickness.
// Requires KpSurface from brick-core. No second independently computed age.


// User Library timber v3, exact box coordinate/noise/field formulas in WGSL.
// KpSurface must be declared by the parent brick module before this string.
// No bindings, stages, renderer, textures, geometry buffers or scene objects.
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}









































// pSourceM = member-local metres + inherited source grainOffset, +X axial.
// Signed normal displacement; use only this function in the geometry distance.

// Conservative magnitude bound for the original vertex displacement, in metres.
// Source macro noise is nonnegative with sum (0.58+0.261+0.11745)/0.94;
// original normal class multiplier is at most 1.08. This is not a Lipschitz bound.

// New screen-independent AA bridge. This is a nominal physical frequency estimate,
// not the original screen derivative and not a proof of derivative equivalence.
// fp=0 preserves the unfiltered original field exactly (up to f32 arithmetic).

// Complete source material terms before source-specific lighting or gamma.
// The caller supplies the actual member-local surface normal and face class.
// 0=longitudinal, 1=end grain, 2=joint cut, 3=weathered side.
// No camera-ray parallax march is hidden in this pure field call.


// Original fragment micro-height: PBR normal detail, NOT a replacement for macro geometry.

// Compatibility entry: top longitudinal face of the original default box timber.
// age/wet/repair are reserved host arguments; the original v3 has no such model.
// Scene overlays must be explicit outside this source-preserving material leaf.


// STONE_STUDY same-page stoneFields, kind 0 (the stone receiver's default).
// KpSurface is supplied once by the shared brick core; do not redefine it here.
// No texture, mesh, voxel atlas, material cache or additional noise family.
// Authored unit bridge: a 0.42 m longest side maps to 3.4 specimen units.
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_KIND:i32 = 0;
const KP_STONE_MASTER_SEED:u32 = 8231u;
// Original normalizeSeedDNA offsets: color +401, pore +307, weather +601.
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;








// New explicit isotropic footprint bridge replacing screen-space fwidth(line).
// It reevaluates the ORIGINAL line and warp at three metric axis offsets.
// This bound-like footprint is not screen-space fwidth equivalence and is not
// complete band-limiting of the original noise; zero footprint keeps 0.008.

// Original kind-0 stoneFields arithmetic. Fixed original material controls:
// sSurface.x=1, sSurface.y=0.7, sDisplay.w=1, sRelief=1, uEventCount=0.
// Original event-loop contribution is therefore 0. Original pits still apply.
// Branches 1/2/3 and their inactive grain/phase/crystal evaluations are omitted.

// New, authored age/moisture/repair bridge copied from resolveStoneFabric.
// Its original default wear=0.15 is fixed because this call has no wear input.
// No calibrated decay law, damage geometry, formation events or SDF is ported.
// Age changes original wet/rough uniforms only; original height stays intact.


// STONE_STUDY original sKind == 3 (blue-gray slate) surface branch.
// Append AFTER existing KP_STONE_WGSL; reuse its st_* source functions/seeds.
// Receiver controls below are explicit design bindings, NOT physical calibration.
// Original event count remains 0, matching the current surface-only port.
struct KpStoneSlateParams {
 sourceScaleM:f32, materialScale:f32, mineral:f32, chroma:f32, relief:f32,
};


// Same existing authored age/moisture/repair bridge; only source branch differs.











const RC_PI:f32=3.14159265359;
struct KpClothM{col:vec3<f32>,roughW:f32,roughF:f32,sheen:f32,bump:f32,trans:f32,irr:f32,fuzz:f32,slub:f32,open:f32,macroTone:f32,age:f32,farId:f32,meso:f32,den:vec2<f32>}
struct KpClothPattern{h:f32,thread:f32,orient:f32,variation:f32,gap:f32,nearW:f32,midW:f32,farW:f32,slub:f32,roughVar:f32,wear:f32,bundle:f32}










// Source material coordinates are centimetres. This explicit footprint bridge
// replaces screen derivatives; physical microheight always uses footprint zero.

















struct MaterialResult{surface:KpSurface,metal:f32,cavity:f32,specular:f32,coat:f32,coatRough:f32}
struct PhysicalState{age:f32,wet:f32,repair:f32,q:vec3<f32>}

struct SettlementField{d:f32,geo:GeoHit,sectionCap:u32}












// Analytic current-parameter bounds are recorded in qa/material-distance-bounds.txt.
// 0.012m is deliberately wider than every possible displacement; this is a
// distance-value bound, not a claim that the displaced field is a strict SDF.
const MATERIAL_DISTANCE_BOUND:f32=.012;



struct Stats {hit:atomic<u32>,miss:atomic<u32>,exhausted:atomic<u32>,maximumSteps:atomic<u32>,retried:atomic<u32>,glassRays:atomic<u32>,boundOnly:atomic<u32>,reserved:atomic<u32>,visibilityRetried:atomic<u32>,visibilityMaximumSteps:atomic<u32>,extendedPrimary:atomic<u32>,candidateOverflows:atomic<u32>,activeQueries:atomic<u32>}

struct HitRecord { ray:vec4<f32>,local:vec4<f32>,ids:vec4<u32>,normal:vec4<f32>,glass:vec4<f32>,through:vec4<f32> }

struct RetryQueue {count:atomic<u32>,indices:array<u32,256>}




// Initial 64-step exit and final sparse continuation. No scene or material state is copied.


















struct Frag { @location(0) color:vec4<f32>, @builtin(frag_depth) depth:f32 }



struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }

@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;

struct SampleHit { ids:vec4<u32>,local:vec4<f32>,normal:vec4<f32>,extra:vec4<u32> }




fn mapHit(p:vec3<f32>)->GeoHit {fieldCompetition=true;fieldExcludedCount=1u;fieldExcluded[0]=vec2<u32>(0u,0u);return querySettlement(p,150.);}
fn mapDistance(p:vec3<f32>)->f32 {return mapHit(p).d;}

@compute @workgroup_size(32) fn sampleNormal(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w<.5){return;}var gradient=vec3<f32>(0.);for(var j=0u;j<6u;j++){var offset=vec3<f32>(0.);let axis=j/2u;let sign=select(-1.,1.,j%2u==0u);offset[axis]=sign*.002;let d=mapDistance(o.position.xyz+offset);gradient[axis]+=sign*d;}o.normal=vec4<f32>(normalize(gradient),o.normal.w);mapSamples[i]=o;}
