# City finite-sampler material compile repair

Local-only change, 2026-10-14. Source lock: `942f27bfcf966d501e79586915899ba62cff75f5`.
No GitHub writes, no main map runtime/integration changes, and no source city mother/runtime changes.

## One repair

The former 93,344-byte `sampleColor` closure combined whole-city `querySettlement` with all nine material domains. It also repeated the geometry query after geometry and normal sampling.

1. `sampleGeometry` now caches the exact successful `GeoHit` from its existing march query. The explicit 64-byte cache includes all integer identifiers, local position, distance, analytic normal and object ID.
2. `sampleNormal` remains a separate, six-query central-difference stage at the original 0.002 m epsilon.
3. Each color stage retains its corresponding original `sceneMaterial` conditional branch byte-for-byte. Only mutually exclusive material branches are removed before the existing static reachability extractor runs. All reachable mother/domain helper functions are byte-identical to the locked source.
4. The runner partitions actual sampled hits by material ID. It compiles and runs only non-empty domains, with both CPU and WGSL material-ID guards. Color stages cannot reach `querySettlement` or `mapHit`.
5. Full geometry/normal samples and complete cached hits are saved before any material compilation. Partial color output has a distinct filename. The final `*-samples.f32` is written only after all actual hit domains succeed. No fallback material is supplied.

The original inputs remain unchanged: albedo/roughness only, footprint 0.18 m, cap 0, eye `[50,30,-50]`, year 1984, 10:00 and growth enabled. The original analytic hit normal stays separate from the sampled shading normal. The 48-byte final sample ABI and downstream map mesh layout are unchanged. Rays are reconstructed with the original formula from the plan; a byte-equality test against the emitted ray file confirms no new binary runtime dependency.

## Files

Modified:
- `emit-sampling-source.mjs`
- `sample.mjs` (city-only delegation; lost-bureau path retained)
- `sampling-plan.json`
- `candidate-adapter.test.mjs` (only add true SHA256 values for existing fixture buffers)
- `walled-pair-sampleGeometry.wgsl`
- `walled-pair-sampleNormal.wgsl`

Added:
- `city-sampling-source.mjs`: checked branch specialization and cached-hit shaders
- `run-city-sampling.mjs`: geometry checkpoint and per-hit-domain execution
- `walled-pair-sampleColor1.wgsl` through `walled-pair-sampleColor9.wgsl`
- `city-sampling.test.mjs`
- `city-material-smoke.cjs`
- This report and `results/city-sampling-tests.tap`, `results/city-repair-tests.tap`

The old `walled-pair-sampleColor.wgsl` is retained as an unreferenced diagnostic baseline. It is absent from the new sampling plan and is not compiled by the city path.

Material closure sizes in ID order: 23,451 / 25,569 / 13,398 / 29,179 / 11,066 / 16,260 / 16,958 / 23,285 / 13,273 bytes. The largest is 31.3% of the former combined closure, without a city geometry query.

Lost-bureau regenerated closure hashes remain identical:
- Geometry `87920d873ecb6a790c3ab0083df674263b4583277d4778533fed3564159a1fd5`
- Color `9901cdbcadf7468c2506a729530faf5dcd3bfb19aa4d4dc3fbc68ba66e311d8f`

## Verified

- All five changed/added executable modules pass `node --check`.
- `node --test city-sampling.test.mjs`: 8/8 pass.
- Byte-identical original mother/helper function bodies and corresponding material branch bodies; no geometry call in color closures.
- Correct generated shader byte counts/hashes and fail-closed detection of a changed material router.
- Mock WebGPU orchestration: 263 rays, 256 + 7 batching, bounded resource ranges, skip unhit material IDs, cache before color compilation, all-hit color coverage, preserve sample position/normal/IDs, release buffers.
- Mock compiler failure after earlier material completion: geometry/hit and partial-color checkpoints survive; no final sample file is emitted.

Existing adapter suite plus these tests: 17/17 pass. The pre-existing valid-binary fixture was updated, as requested, to calculate the true SHA256 of each existing buffer under the current strict adapter contract. No adapter/runtime code, validation, or negative test was weakened or changed.

## Not verified

No WebGPU pipeline compilation, full city mesh output or visual appearance has been verified here. Normal Chromium launch is blocked by local socket permission; the single elevated local-only smoke launch returned `TurnAborted` and was not retried. No live GPU compiler-time improvement is claimed from source size alone.

## Integration QA commands

Run from the workspace root in an authorized WebGPU/Chromium environment:

```sh
node hong-kong-train88-r01/candidates/qa/emit-sampling-source.mjs
node --test hong-kong-train88-r01/candidates/qa/city-sampling.test.mjs
node hong-kong-train88-r01/candidates/qa/city-material-smoke.cjs
SAMPLE_MODEL=walled-pair node hong-kong-train88-r01/candidates/qa/run-sampling.cjs
SAMPLE_MODEL=walled-pair node hong-kong-train88-r01/candidates/qa/pack-samples.mjs
```

The standalone smoke test compiles and executes all nine specialized color pipelines using one representative complete hit record per domain, then writes `results/city-material-smoke.json`. It is a shader/ABI check, not proof of actual city appearance. The full sampler then records actual hit counts, per-domain compile times and output in `results/sampling-receipt.json`.

Checkpoints are inspection artifacts; automatic resume from them is not implemented in this bounded repair.


## Exact minimum city-only job payload

All paths below are relative to `hong-kong-train88-r01/candidates/qa/`:

1. `sample.mjs`
2. `run-city-sampling.mjs`
3. `sampling-plan.json`
4. `walled-pair-sampleGeometry.wgsl`
5. `walled-pair-sampleNormal.wgsl`
6. `walled-pair-sampleColor1.wgsl`
7. `walled-pair-sampleColor2.wgsl`
8. `walled-pair-sampleColor3.wgsl`
9. `walled-pair-sampleColor4.wgsl`
10. `walled-pair-sampleColor5.wgsl`
11. `walled-pair-sampleColor6.wgsl`
12. `walled-pair-sampleColor7.wgsl`
13. `walled-pair-sampleColor8.wgsl`
14. `walled-pair-sampleColor9.wgsl`

Continue using existing `sample.html`, `run-sampling.cjs`, `world-rules.json` and `pack-samples.mjs`. No additional binary upload is needed.

For source reproducibility and CPU testing, additionally include `emit-sampling-source.mjs`, `city-sampling-source.mjs`, `city-sampling.test.mjs`, and the corrected `candidate-adapter.test.mjs`. The separate `city-material-smoke.cjs` is optional; the single intended full city-only attempt need not run it first.

Always preserve the entire `results/` directory as the city-only job artifact, even on failure. The geometry, complete-hit, partial-color and final outputs are distinct files; their existence depends on which stages completed. The current job receipt remains the authority on completion.
