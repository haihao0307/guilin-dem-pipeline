
struct Frame { eye:vec4<f32>,forward:vec4<f32>,right:vec4<f32>,up:vec4<f32>,cut:vec4<f32>,size:vec4<f32>,tile:vec4<u32>,controls:vec4<f32> }
@group(0) @binding(0) var<uniform> u:Frame;

@group(0) @binding(1) var<storage,read> worldRules:array<vec4<f32>>;
struct GeoHit{d:f32,materialId:u32,buildingId:u32,componentId:u32,stateId:u32,q:vec3<f32>,n:vec3<f32>,objectId:u32}
// Short-lived per-ray candidate keys, never persistent world/brick instances.
var<private> fieldCompetition:bool;
var<private> fieldExcluded:array<vec2<u32>,32>;
var<private> fieldExcludedCount:u32;

fn rec(s:u32,k:u32)->vec4<f32>{return worldRules[s*8u+k];}
















// Dated household event, partitioned along existing execution groups.






// Metric frontage rules are compiled with household uses, not randomized per pixel.
fn frontageCell(s:u32,x:f32)->u32{let a=rec(s,0u);let f=rec(s,4u);let u=(x-a.x)/a.z+.5;return select(select(0u,1u,u>=f.x),2u,u>=f.y);}

fn frontZ(s:u32,cell:u32)->f32{return rec(s,6u)[cell];}
fn frontAt(s:u32,x:f32)->f32{return frontZ(s,frontageCell(s,x));}


















// Three narrow linked leaves fold entirely over the level A platform.




// R3.12 family-0 original fitted edge waves, field and surface core.
// WGSL syntax/explicit arguments are new. No renderer, vertex or instance lists.
const KP_BRICK_PI:f32=3.14159265359;
const KP_BRICK_SCALE:f32=0.1153846154;
struct KpSurface { height:f32, albedo:vec3<f32>, roughness:f32, }












































// Return original [chips, contour, weight] contributions instead of GLSL inout.





// Exact original family-0 distance, in metres. This is not guaranteed Lipschitz 1.0



// New explicit isotropic footprint bridge. Original wave, 17 octaves and gates
// remain; the original screen dFdx/dFdy footprint is NOT claimed equivalent.

// Raw original family-0 albedo, roughness and height. No lighting/tone mapping.


// R3.12 original macro/micro/observed field algebra. Explicit coordinates and
// derivative-free physical footprint are receiver bridges. No patch silhouette.
struct KpPlasterParams {
 centerM:vec2<f32>, halfM:vec2<f32>, thicknessM:f32, reliefM:f32,
 geometryMicroM:f32, minThicknessM:f32, maxThicknessM:f32, microM:f32,
 paletteDark:vec3<f32>, paletteLight:vec3<f32>,
 grainWavelengthM:f32, grainHeightM:f32, grainColor:f32,
}
struct KpPlasterField {macroTone:f32,micro:f32,thicknessM:f32,surface:KpSurface,}












// Syntax port of locked V26 waterWeatherMasks dependency closure.
// pField is the ORIGINAL normalized material field coordinate, not metres.
// localPosM/dimensionsM are original physical local position/size for gates.












// Existing explicitly authored unified fabric bridge, not source physical years.
struct KpFabricState { moisture:f32, damage:f32, retention:f32, thicknessM:f32, baseScale:f32, roughDelta:f32, }


// Apply the exact same resolved state used by receiver coat retention/thickness.
// Requires KpSurface from brick-core. No second independently computed age.


// User Library timber v3, exact box coordinate/noise/field formulas in WGSL.
// KpSurface must be declared by the parent brick module before this string.
// No bindings, stages, renderer, textures, geometry buffers or scene objects.
const KP_WOOD_PI:f32=3.141592653589793;
const KP_WOOD_TAU:f32=6.283185307179586;
struct KpWoodParams {
  seed:f32,
  ringFrequency:f32,
  ringScale:f32,
  ringWarp:f32,
  fiberFrequency:f32,
  fineFiberFrequency:f32,
  poreFrequency:f32,
  fiberStrength:f32,
  colorBias:f32,
  roughness:f32,
  angleOffset:f32,
  textureScale:f32,
  grainContrast:f32,
  detailFineness:f32,
  microReliefM:f32,
  parallaxM:f32,
  macroDisplacementM:f32,
  reliefScale:f32,
  reliefQuality:f32,
  parallaxSteps:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  distanceFadeStart:f32,
  distanceFadeEnd:f32,
  toolPhase:f32,
  crackPhase:f32,
  knotPhase:f32,
  pithOffset:vec2<f32>,
  darkGrainColor:vec3<f32>,
  lightGrainColor:vec3<f32>,
  agedSurfaceColor:vec3<f32>,
  weatheredColor:vec3<f32>,
  freshCutColor:vec3<f32>,
  cavityColor:vec3<f32>,
}
struct KpWoodSample {
  surface:KpSurface,
  cavity:f32,
  clearcoat:f32,
  clearcoatRoughness:f32,
  specularLevel:f32,
  macroHeightM:f32,
  parallaxHeight01:f32,
}









































// pSourceM = member-local metres + inherited source grainOffset, +X axial.
// Signed normal displacement; use only this function in the geometry distance.

// Conservative magnitude bound for the original vertex displacement, in metres.
// Source macro noise is nonnegative with sum (0.58+0.261+0.11745)/0.94;
// original normal class multiplier is at most 1.08. This is not a Lipschitz bound.

// New screen-independent AA bridge. This is a nominal physical frequency estimate,
// not the original screen derivative and not a proof of derivative equivalence.
// fp=0 preserves the unfiltered original field exactly (up to f32 arithmetic).

// Complete source material terms before source-specific lighting or gamma.
// The caller supplies the actual member-local surface normal and face class.
// 0=longitudinal, 1=end grain, 2=joint cut, 3=weathered side.
// No camera-ray parallax march is hidden in this pure field call.


// Original fragment micro-height: PBR normal detail, NOT a replacement for macro geometry.

// Compatibility entry: top longitudinal face of the original default box timber.
// age/wet/repair are reserved host arguments; the original v3 has no such model.
// Scene overlays must be explicit outside this source-preserving material leaf.


// STONE_STUDY same-page stoneFields, kind 0 (the stone receiver's default).
// KpSurface is supplied once by the shared brick core; do not redefine it here.
// No texture, mesh, voxel atlas, material cache or additional noise family.
// Authored unit bridge: a 0.42 m longest side maps to 3.4 specimen units.
const KP_STONE_SCALE_M:f32 = 0.12352941176470589;
const KP_STONE_KIND:i32 = 0;
const KP_STONE_MASTER_SEED:u32 = 8231u;
// Original normalizeSeedDNA offsets: color +401, pore +307, weather +601.
const KP_STONE_COLOR_SEED:f32 = 8632.0;
const KP_STONE_PORE_SEED:f32 = 8538.0;
const KP_STONE_WEATHER_SEED:f32 = 8832.0;

fn st_hash33(pIn:vec3<f32>)->vec3<f32> {
 var p=fract(pIn*vec3<f32>(0.1031,0.1030,0.0973));
 p+=vec3<f32>(dot(p,p.yxz+vec3<f32>(33.33)));
 return fract((p.xxy+p.yxx)*p.zyx);
}
fn st_valueNoise3(p:vec3<f32>)->f32 {
 let i=floor(p);var f=fract(p);
 f=f*f*f*(f*(f*6.0-vec3<f32>(15.0))+vec3<f32>(10.0));
 return mix(mix(mix(st_hash33(i).x,st_hash33(i+vec3<f32>(1,0,0)).x,f.x),mix(st_hash33(i+vec3<f32>(0,1,0)).x,st_hash33(i+vec3<f32>(1,1,0)).x,f.x),f.y),mix(mix(st_hash33(i+vec3<f32>(0,0,1)).x,st_hash33(i+vec3<f32>(1,0,1)).x,f.x),mix(st_hash33(i+vec3<f32>(0,1,1)).x,st_hash33(i+vec3<f32>(1,1,1)).x,f.x),f.y),f.z);
}
fn st_seedVector(seed:f32,salt:f32)->vec3<f32> {
 return st_hash33(vec3<f32>(seed*0.001,salt,seed*0.00013))*49.0;
}
fn st_srgbToLinear(c:vec3<f32>)->vec3<f32> {
 return mix(c/12.92,pow((c+vec3<f32>(0.055))/1.055,vec3<f32>(2.4)),step(vec3<f32>(0.04045),c));
}
fn st_sf(p:vec3<f32>)->f32 {
 return st_valueNoise3(p)*0.57+st_valueNoise3(p*2.07+vec3<f32>(13.7))*0.28+st_valueNoise3(p*4.11+vec3<f32>(27.2))*0.15;
}
fn st_warp(p:vec3<f32>,seed:vec3<f32>)->vec3<f32> {
 return p+vec3<f32>(st_sf(p*0.8+seed),st_sf(p*0.8+seed+vec3<f32>(7.0)),st_sf(p*0.8+seed+vec3<f32>(19.0)))*0.25;
}
fn st_line(q:vec3<f32>,seed:vec3<f32>)->f32 {
 return abs(sin((q.x*0.84+q.y*0.37+q.z*0.51+st_sf(q*1.7+seed)*0.44)*12.0));
}
// New explicit isotropic footprint bridge replacing screen-space fwidth(line).
// It reevaluates the ORIGINAL line and warp at three metric axis offsets.
// This bound-like footprint is not screen-space fwidth equivalence and is not
// complete band-limiting of the original noise; zero footprint keeps 0.008.
fn st_lineAA(pos:vec3<f32>,seed:vec3<f32>,line:f32,physicalFootprintM:f32)->f32 {
 let e=max(physicalFootprintM,0.0)/KP_STONE_SCALE_M;
 if(e==0.0){return 0.008;}
 let dx=abs(st_line(st_warp(pos+vec3<f32>(e,0,0),seed),seed)-line);
 let dy=abs(st_line(st_warp(pos+vec3<f32>(0,e,0),seed),seed)-line);
 let dz=abs(st_line(st_warp(pos+vec3<f32>(0,0,e),seed),seed)-line);
 return max(dx+dy+dz,0.008);
}
// Original kind-0 stoneFields arithmetic. Fixed original material controls:
// sSurface.x=1, sSurface.y=0.7, sDisplay.w=1, sRelief=1, uEventCount=0.
// Original event-loop contribution is therefore 0. Original pits still apply.
// Branches 1/2/3 and their inactive grain/phase/crystal evaluations are omitted.

// New, authored age/moisture/repair bridge copied from resolveStoneFabric.
// Its original default wear=0.15 is fixed because this call has no wear input.
// No calibrated decay law, damage geometry, formation events or SDF is ported.
// Age changes original wet/rough uniforms only; original height stays intact.


// STONE_STUDY original sKind == 3 (blue-gray slate) surface branch.
// Append AFTER existing KP_STONE_WGSL; reuse its st_* source functions/seeds.
// Receiver controls below are explicit design bindings, NOT physical calibration.
// Original event count remains 0, matching the current surface-only port.
struct KpStoneSlateParams {
 sourceScaleM:f32, materialScale:f32, mineral:f32, chroma:f32, relief:f32,
};
fn kpStoneSlateDefaultParams()->KpStoneSlateParams {
 return KpStoneSlateParams(KP_STONE_SCALE_M,1.0,0.7,1.0,1.0);
}
fn kpStoneSlateOriginalSurface(pLocalM:vec3<f32>,params:KpStoneSlateParams,sourceWet:f32,roughBias:f32,physicalFootprintM:f32)->KpSurface {
 let pos=pLocalM/params.sourceScaleM;
 let seed=st_seedVector(KP_STONE_COLOR_SEED,0.071);
 let p=pos*params.materialScale;
 let q=st_warp(p,seed);
 let broad=st_sf(q*1.35+seed);
 let region=st_sf(q*3.2+seed+vec3<f32>(11.0));
 let weather=st_sf(q*2.2+st_seedVector(KP_STONE_WEATHER_SEED,0.09));
 let phase=q.y*5.7+q.x*0.82+q.z*0.41+st_sf(q*1.8+seed)*1.25;
 let line=st_line(q,seed);
 // Existing helper converts its input by KP_STONE_SCALE_M. Undo that fixed
 // scale here, then provide THIS receiver's explicit source + texture scale.
 // physicalFootprintM == 0 retains exactly the source's intrinsic aa floor.
 let aa=st_lineAA(p,seed,line,physicalFootprintM*KP_STONE_SCALE_M*params.materialScale/params.sourceScaleM);
 let vein=(1.0-smoothstep(0.028,0.064+aa,line))*smoothstep(0.34,0.63,region);
 let pits=pow(max(0.0,(st_sf(q*19.0+st_seedVector(KP_STONE_PORE_SEED,0.061))-0.57)/0.43),2.0);
 // Exact source kind-3 arithmetic; grain/crystal/bands are inactive here.
 let cleavage=st_sf(vec3<f32>(q.x*1.8,phase*2.8,q.z*1.8)+seed);
 var col=mix(vec3<f32>(0.10,0.15,0.19),vec3<f32>(0.30,0.37,0.40),smoothstep(0.20,0.78,cleavage*0.58+broad*0.42));
 col=mix(col,vec3<f32>(0.47,0.33,0.20),smoothstep(0.60,0.77,weather)*0.67);
 let mineral=vein*params.mineral;
 col=mix(col,vec3<f32>(0.57,0.61,0.57),mineral*0.51);
 let rough=0.48+cleavage*0.17-mineral*0.19;
 let h=(cleavage-0.5)*0.009+(broad-0.5)*0.012+sin(phase*6.28318)*0.0018-pits*0.01;
 let geomCavity=0.0;
 let cav=clamp(geomCavity*0.55+pits*1.4,0.0,1.0);
 let wet=clamp(sourceWet*(0.18+0.82*smoothstep(0.32,0.75,weather+cav*0.25)),0.0,1.0);
 let lum=dot(col,vec3<f32>(0.2126,0.7152,0.0722));
 col=mix(vec3<f32>(lum),col,params.chroma);
 var linear=st_srgbToLinear(clamp(col,vec3<f32>(0.025),vec3<f32>(0.95)));
 linear*=1.0-wet*0.38;
 return KpSurface(h*params.relief*params.sourceScaleM,linear,clamp(mix(rough+roughBias,0.17,wet),0.12,0.98));
}
// Same existing authored age/moisture/repair bridge; only source branch differs.
fn kpStoneSlateSurface(pLocalM:vec3<f32>,params:KpStoneSlateParams,age:f32,wet:f32,repair:f32,physicalFootprintM:f32)->KpSurface {
 let a=clamp(age,0.0,1.0);let r=clamp(repair,0.0,1.0);let m=clamp(wet,0.0,1.0);
 let retainedAge=a*(1.0-r);
 let sourceWet=clamp(m*(0.45+0.55*retainedAge)*(1.0-0.45*r),0.0,1.0);
 let roughBias=0.07*retainedAge+0.025*0.15-0.06*r;
 return kpStoneSlateOriginalSurface(pLocalM,params,sourceWet,roughBias,physicalFootprintM);
}










const RC_PI:f32=3.14159265359;
struct KpClothM{col:vec3<f32>,roughW:f32,roughF:f32,sheen:f32,bump:f32,trans:f32,irr:f32,fuzz:f32,slub:f32,open:f32,macroTone:f32,age:f32,farId:f32,meso:f32,den:vec2<f32>}
struct KpClothPattern{h:f32,thread:f32,orient:f32,variation:f32,gap:f32,nearW:f32,midW:f32,farW:f32,slub:f32,roughVar:f32,wear:f32,bundle:f32}










// Source material coordinates are centimetres. This explicit footprint bridge
// replaces screen derivatives; physical microheight always uses footprint zero.

















struct MaterialResult{surface:KpSurface,metal:f32,cavity:f32,specular:f32,coat:f32,coatRough:f32}
struct PhysicalState{age:f32,wet:f32,repair:f32,q:vec3<f32>}
fn physicalState(h:GeoHit,p:vec3<f32>)->PhysicalState{let d=dna(h);var q=h.q;var wet=.06;if(h.materialId==3u){q=vec3<f32>(h.q.x,p.y-d.w,h.q.z);wet=(1.-smoothstep(.04,.22,abs(q.y)))*.18;}else if(h.materialId==6u){q=vec3<f32>(p.x,p.z,p.y);}else if(h.materialId==9u){let a=rec(h.stateId-1u,0u);let b=rec(h.stateId-1u,1u);q=p-vec3<f32>(a.x,a.y,frontAt(h.stateId-1u,p.x));}return PhysicalState(d.x,wet,d.z,q);}
struct SettlementField{d:f32,geo:GeoHit,sectionCap:u32}
fn dna(h:GeoHit)->vec4<f32>{if(h.stateId==0u){return vec4<f32>(.24,.1,0.,0.);}let a=rec(h.stateId-1u,0u);let c=rec(h.stateId-1u,2u);let event=rec(h.stateId-1u,3u);let added=event.y>.5&&((h.componentId>=1000000u&&h.componentId<1001000u)||(h.componentId>=4000000u&&h.componentId<4004000u));let shelter=h.componentId>=1200000u&&h.componentId<1201000u;let eventYear=select(event.w,rec(h.stateId-1u,5u).y,shelter);let age=select(c.x,clamp((u.size.w-eventYear)/40.,0.,1.),added||shelter);return vec4<f32>(age,f32(h.stateId)*.731+select(0.,9.17,added),select(c.y,.05,added),a.y);}








fn stoneParameters(h:GeoHit)->KpStoneSlateParams{var a=kpStoneSlateDefaultParams();a.sourceScaleM=select(.8,2.5,h.buildingId==0u);a.relief=.06;return a;}
fn sceneMaterial(h:GeoHit,p:vec3<f32>,n:vec3<f32>,fp:f32,cap:u32)->MaterialResult{var s=KpSurface(0.,vec3<f32>(.3),.8);var metal=0.;var cavity=1.;var spec=1.;var coat=0.;var coatRough=.25;let d=dna(h);
 if(h.stateId==0u){return MaterialResult(KpSurface(0.,vec3<f32>(.28),.92),0.,1.,1.,0.,.25);}
 
 
 
 
 
 
 if(h.materialId==6u){let state=physicalState(h,p);s=kpStoneSlateSurface(state.q,stoneParameters(h),state.age,state.wet,state.repair,fp);}
 
 
 return MaterialResult(s,metal,cavity,spec,coat,coatRough);}

// Analytic current-parameter bounds are recorded in qa/material-distance-bounds.txt.
// 0.012m is deliberately wider than every possible displacement; this is a
// distance-value bound, not a claim that the displaced field is a strict SDF.
const MATERIAL_DISTANCE_BOUND:f32=.012;



struct Stats {hit:atomic<u32>,miss:atomic<u32>,exhausted:atomic<u32>,maximumSteps:atomic<u32>,retried:atomic<u32>,glassRays:atomic<u32>,boundOnly:atomic<u32>,reserved:atomic<u32>,visibilityRetried:atomic<u32>,visibilityMaximumSteps:atomic<u32>,extendedPrimary:atomic<u32>,candidateOverflows:atomic<u32>,activeQueries:atomic<u32>}

struct HitRecord { ray:vec4<f32>,local:vec4<f32>,ids:vec4<u32>,normal:vec4<f32>,glass:vec4<f32>,through:vec4<f32> }

struct RetryQueue {count:atomic<u32>,indices:array<u32,256>}




// Initial 64-step exit and final sparse continuation. No scene or material state is copied.


















struct Frag { @location(0) color:vec4<f32>, @builtin(frag_depth) depth:f32 }



struct SampleRay { origin:vec4<f32>,direction:vec4<f32> }
struct SampleOutput { position:vec4<f32>,normal:vec4<f32>,color:vec4<f32> }

@group(1) @binding(1) var<storage,read_write> mapSamples:array<SampleOutput>;

struct SampleHit { ids:vec4<u32>,local:vec4<f32>,normal:vec4<f32>,extra:vec4<u32> }
@group(1) @binding(2) var<storage,read_write> mapHits:array<SampleHit>;

fn unpackMapHit(h:SampleHit)->GeoHit{return GeoHit(h.local.w,h.ids.x,h.ids.y,h.ids.z,h.ids.w,h.local.xyz,h.normal.xyz,h.extra.x);}






@compute @workgroup_size(32) fn sampleColor6(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=arrayLength(&mapSamples)){return;}var o=mapSamples[i];if(o.position.w!=6.){return;}let h=unpackMapHit(mapHits[i]);if(h.materialId!=6u){return;}let m=sceneMaterial(h,o.position.xyz,o.normal.xyz,.18,0u).surface;o.color=vec4<f32>(m.albedo,m.roughness);mapSamples[i]=o;}
