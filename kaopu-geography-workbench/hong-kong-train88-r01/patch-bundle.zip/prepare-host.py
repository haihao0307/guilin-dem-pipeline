from pathlib import Path
import json,hashlib,re
R=Path(__file__).resolve().parent
source=R.parent/'hong-kong-map-sea-r03/publish-final/index.html'
s=source.read_text()
# Keep the released map byte-for-byte at its existing URL, with an exact hash gate.
# At load the new host applies only this explicit integration delta to that source.
patches=[
 ["R03 局部地形与车站装配 · 未接 88 游戏", "香港 × 88 同場試跑 · 機車＋煤水車 / 車廂待接"],

 ["bakeTile(now);envMix=", "const stageStart=performance.now();bakeTile(now);envMix="],
 ["gl.drawArrays(gl.TRIANGLES,0,3);\ngl.clear(gl.DEPTH_BUFFER_BIT)", "gl.drawArrays(gl.TRIANGLES,0,3);if(window.HK_PROFILE_NEXT){gl.finish();qa.stageProfile={skyMs:performance.now()-stageStart};window.HK_PROFILE_AT=performance.now();}\ngl.clear(gl.DEPTH_BUFFER_BIT)"],

 ["precision highp float;in vec3 p,n;in float water;uniform vec3 uSun;uniform float exposure;out vec4 O;void main(){", "precision highp float;in vec3 p,n;in float water;uniform vec3 uSun,uTrackFocus;uniform float exposure,uTrackCut;out vec4 O;void main(){if(uTrackCut>0.5&&distance(p.xz,uTrackFocus.xz)<180.&&p.y>uTrackFocus.y+1.)discard;"],
 ["gl.useProgram(p);lighting(p,s,e);", "gl.useProgram(p);lighting(p,s,e);v3(p,'uTrackFocus',window.HK_TRAIN_CUT?.position||[0,0,0]);f(p,'uTrackCut',window.HK_TRAIN_CUT?.enabled?1:0);"],
 ['<title>','<title>'],
 ["function cameraData(){return mapCamera()}","let trainIntegration=null;function cameraData(){return trainIntegration?.camera()||mapCamera()}"],
 ["statistics(now);const dt=Math.max(0,(now-last)/1000);last=now;", "statistics(now);const dt=Math.max(0,(now-last)/1000);last=now;trainIntegration?.tick(dt,paused);"],
 ["drawHK(now,s,e,c);\nif(pendingQuery)","drawHK(now,s,e,c);if(window.HK_PROFILE_NEXT){gl.finish();qa.stageProfile.worldMs=performance.now()-window.HK_PROFILE_AT;window.HK_PROFILE_AT=performance.now();}trainIntegration?.draw(c,s,e);if(window.HK_PROFILE_NEXT){gl.finish();qa.stageProfile.trainMs=performance.now()-window.HK_PROFILE_AT;qa.stageProfile.complete=true;window.HK_PROFILE_NEXT=false;}\nif(pendingQuery)"],
 ["quality();worker.postMessage({noise:true});", "trainIntegration=await (await import('__INTEGRATION_URL__')).createIntegration({gl,canvas,HK,mapState,hkHeight,requestFrame:()=>needFrame=true,mapCamera,mapFocus,qa});window.HKTrain88=trainIntegration;quality();worker.postMessage({noise:true});"],
 ["document.body.append(labelLayer);", "document.body.append(labelLayer);"],
 ["drawCanopy(now,s,e,c);drawKowloon(now,s,e,c);", "drawCanopy(now,s,e,c);if(window.HK_CANDIDATE_VISIBILITY?.kowloon!==false)drawKowloon(now,s,e,c);"],
 ["const c=cameraData();common(skyProgram", "gl.disable(gl.CULL_FACE);gl.depthMask(true);gl.colorMask(true,true,true,true);const c=cameraData();common(skyProgram"],
 ["const scale=S.quality==='ultra'?Math.min(devicePixelRatio,1.5):S.quality==='fine'?1:.8", "const scale=S.quality==='ultra'?Math.min(devicePixelRatio,1.5):1"],
 ["mapState.canopy=true", "mapState.canopy=true"],
 ]
patches=[p for p in patches if p[0]!=p[1]]
for a,b in patches:
 assert s.count(a)==1,(a,s.count(a))
config={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source':'../hong-kong-map-sea-r03/index.html','patches':patches}
(R/'host-patches.json').write_text(json.dumps(config,ensure_ascii=False,separators=(',',':')))
