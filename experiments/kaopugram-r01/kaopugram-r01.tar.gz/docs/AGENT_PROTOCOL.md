# Agent protocol

When the user says “用靠谱锚定” or “启用 KaoPuGram”:

1. Run `resolve` in the current workbench repository.
2. If the active object is unresolved or ambiguous, do not guess; request runtime context or one clarification.
3. Load the accepted anchor(s) for the resolved object and its dependencies.
4. Before modifying anything, list the anchors that may be affected and the intended write scope.
5. After work, run `anchor verify` for all affected anchors and the workbench's domain tests.
6. Treat file/hash drift as a review trigger, not an automatic semantic failure.
7. Never promote without explicit approval and passing verification.
8. Never automatically reset or overwrite the worktree; recovery is plan-only.

The workbench should export `.kaopugram/runtime-context.json` from its active UI state. Include stable object/module IDs, selected entity count, geometry/data fingerprints and optional feature vectors. Exclude tokens, secrets, personal data and large binary assets.
