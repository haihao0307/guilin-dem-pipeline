#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';

const VERSION = '0.1.0';
const META = '.kaopugram';
const args = process.argv.slice(2);
const command = args.shift() || 'help';
const opt = (name, fallback = null) => { const i = args.indexOf(name); return i < 0 ? fallback : args[i + 1]; };
const listOpt = name => (opt(name, '') || '').split(',').map(x => x.trim()).filter(Boolean);
const print = value => process.stdout.write(JSON.stringify(value, null, 2) + '\n');
const die = message => { process.stderr.write(message + '\n'); process.exitCode = 1; };
const json = (file, fallback = null) => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } };
const git = (cwd, ...argv) => { try { return execFileSync('git', argv, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); } catch { return null; } };
const sha = value => crypto.createHash('sha256').update(value).digest('hex');

function repoInfo(cwd = process.cwd()) {
  const root = git(cwd, 'rev-parse', '--show-toplevel');
  if (!root) return null;
  const remote = git(root, 'remote', 'get-url', 'origin');
  const normalized = (remote || '').replace(/^git@github\.com:/, 'https://github.com/').replace(/\.git$/, '').replace(/\/$/, '');
  const dirty = git(root, 'status', '--porcelain') || '';
  return {
    root, remote, repository: normalized.split('/').slice(-2).join('/') || path.basename(root),
    branch: git(root, 'branch', '--show-current') || 'DETACHED',
    head: git(root, 'rev-parse', 'HEAD'),
    changedPaths: dirty.split('\n').filter(Boolean).map(line => line.slice(3).trim()).filter(Boolean)
  };
}

function inferFromPaths(changedPaths, rules = []) {
  const hits = new Set();
  for (const rule of rules) {
    const patterns = [rule.prefix, ...(rule.paths || [])].filter(Boolean);
    if (patterns.some(prefix => changedPaths.some(file => file.startsWith(prefix)))) hits.add(rule.objectId);
  }
  if (hits.size === 1) return { id: [...hits][0], source: 'git-path-rule', confidence: 'MEDIUM' };
  return { id: null, source: 'git-path-rule', confidence: 'LOW', candidates: [...hits] };
}

function resolve(cwd = process.cwd()) {
  const repo = repoInfo(cwd);
  if (!repo) return { status: 'NOT_A_GIT_WORKTREE', confidence: 'NONE' };
  const config = json(path.join(repo.root, META, 'workbench.json'), {});
  const runtimePath = path.join(repo.root, config.runtimeContext || `${META}/runtime-context.json`);
  const runtime = json(runtimePath, null);
  const activeId = runtime?.activeObject?.id || runtime?.selection?.objectId || null;
  const inferred = activeId ? { id: activeId, source: 'runtime-context', confidence: 'HIGH' } : inferFromPaths(repo.changedPaths, config.pathRules || []);
  return {
    schema: 'kaopugram.context/0.1', status: inferred.id ? 'RESOLVED' : 'NEEDS_CONTEXT', confidence: inferred.confidence,
    workbench: { id: config.workbenchId || path.basename(repo.root), domain: config.domain || 'unknown', adapter: config.adapter || 'generic' },
    repository: repo.repository, remote: repo.remote, branch: repo.branch, head: repo.head,
    changedPaths: repo.changedPaths, activeModule: runtime?.activeModule?.id || runtime?.moduleId || null,
    activeObject: inferred.id ? { id: inferred.id, source: inferred.source } : null,
    candidateObjects: inferred.candidates || [], runtimeContextFound: Boolean(runtime),
    note: inferred.id ? null : 'Project/Git context is known, but active object is not reliable. Export runtime selection or specify --target.'
  };
}

function gramSnapshot(features) {
  if (!Array.isArray(features) || !features.length) return null;
  const rows = features.map((item, index) => {
    if (!item || typeof item.id !== 'string' || !Array.isArray(item.vector) || !item.vector.length || !item.vector.every(Number.isFinite)) throw new Error(`Invalid feature vector at index ${index}.`);
    return { id: item.id, vector: item.vector };
  }).sort((a, b) => a.id.localeCompare(b.id));
  if (new Set(rows.map(x => x.id)).size !== rows.length) throw new Error('Feature IDs must be unique.');
  if (new Set(rows.map(x => x.vector.length)).size !== 1) throw new Error('Feature vector dimensions must match.');
  return { featureIds: rows.map(x => x.id), matrix: rows.map(a => rows.map(b => a.vector.reduce((sum, v, i) => sum + v * b.vector[i], 0))) };
}

function compareGram(before, after, tolerance = 1e-4) {
  if (!before || !after) return { status: 'INSUFFICIENT_EVIDENCE', relativeError: null };
  if (JSON.stringify(before.featureIds) !== JSON.stringify(after.featureIds)) return { status: 'DRIFT', relativeError: null, reason: 'Feature IDs changed.' };
  let delta = 0, norm = 0;
  before.matrix.forEach((row, i) => row.forEach((v, j) => { delta += (v - after.matrix[i][j]) ** 2; norm += v ** 2; }));
  const relativeError = Math.sqrt(delta) / Math.max(Math.sqrt(norm), 1e-12);
  return { status: relativeError <= tolerance ? 'PASS' : 'DRIFT', relativeError, tolerance };
}

function listFiles(root) {
  return (git(root, 'ls-files', '--cached', '--others', '--exclude-standard') || '').split('\n').filter(Boolean);
}
function globRegex(pattern) {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');
  return new RegExp('^' + escaped.replace(/\*\*/g, '§§').replace(/\*/g, '[^/]*').replace(/§§/g, '.*') + '$');
}
function expandPaths(root, patterns) {
  const all = listFiles(root), found = new Set();
  for (const raw of patterns) {
    const p = String(raw).replaceAll('\\', '/').replace(/^\.\//, '');
    if (!p) continue;
    const full = path.join(root, p);
    if (!p.includes('*') && fs.existsSync(full) && fs.statSync(full).isFile()) found.add(p);
    else if (!p.includes('*') && fs.existsSync(full) && fs.statSync(full).isDirectory()) all.filter(f => f.startsWith(p.replace(/\/$/, '') + '/')).forEach(f => found.add(f));
    else { const re = globRegex(p); all.filter(f => re.test(f)).forEach(f => found.add(f)); }
  }
  return [...found].filter(p => !p.startsWith(`${META}/`)).sort();
}
function fileHash(file) {
  const fd = fs.openSync(file, 'r'), hash = crypto.createHash('sha256'), buf = Buffer.allocUnsafe(1024 * 1024);
  let bytes = 0;
  try { while (true) { const n = fs.readSync(fd, buf, 0, buf.length, null); if (!n) break; hash.update(buf.subarray(0, n)); bytes += n; } }
  finally { fs.closeSync(fd); }
  return { sha256: hash.digest('hex'), bytes };
}
function snapshot(root, files) {
  return Object.fromEntries(files.map(rel => {
    const full = path.join(root, rel);
    if (!fs.existsSync(full) || !fs.statSync(full).isFile()) return [rel, { exists: false, sha256: null, bytes: 0 }];
    return [rel, { exists: true, ...fileHash(full) }];
  }));
}
function readConfig(root) { return json(path.join(root, META, 'workbench.json'), {}); }
function anchorPath(root, id) { return path.join(root, META, 'anchors', `${id}.json`); }
function loadAnchor(root, id) { const a = json(anchorPath(root, id)); if (!a) throw new Error(`Anchor not found: ${id}`); return a; }

function propose({ name, target, paths, invariants }) {
  const context = resolve();
  if (context.status === 'NOT_A_GIT_WORKTREE') throw new Error('Run KaoPuGram inside a Git worktree.');
  const repo = repoInfo();
  const objectId = target || context.activeObject?.id;
  if (!objectId) throw new Error('NEEDS_CONTEXT: active object is unknown. Export runtime context or provide --target.');
  if (!name) throw new Error('Missing --name.');
  const config = readConfig(repo.root);
  const rules = (config.pathRules || []).filter(r => r.objectId === objectId).flatMap(r => r.paths || [r.prefix].filter(Boolean));
  const patterns = paths.length ? paths : (config.objectPaths?.[objectId] || rules);
  if (!patterns.length) throw new Error(`NEEDS_PROTECTED_SCOPE: configure objectPaths.${objectId} or provide --paths.`);
  const protectedPaths = expandPaths(repo.root, patterns);
  if (!protectedPaths.length) throw new Error('No files matched protected scope; refusing an empty anchor.');
  const runtime = json(path.join(repo.root, config.runtimeContext || `${META}/runtime-context.json`), null);
  const id = `${context.workbench.id}.${objectId}.${Date.now()}`.toLowerCase().replace(/[^a-z0-9.-]+/g, '-');
  const anchor = {
    schema: 'kaopugram.anchor/0.1', id, name, status: 'CANDIDATE', createdAt: new Date().toISOString(),
    workbench: context.workbench, repository: context.repository,
    target: { objectId, moduleId: context.activeModule, resolvedFrom: target ? 'explicit-user-target' : context.activeObject.source },
    source: { branch: repo.branch, commit: repo.head, remote: repo.remote },
    protectedPaths, fileSnapshot: snapshot(repo.root, protectedPaths),
    invariants: invariants.map(statement => ({ statement, verification: 'MANUAL_OR_ADAPTER_REQUIRED' })),
    runtimeSnapshot: { activeObjectId: runtime?.activeObject?.id || runtime?.selection?.objectId || null, activeModuleId: runtime?.activeModule?.id || runtime?.moduleId || null, geometryHash: runtime?.activeObject?.geometryHash || null, dataHash: runtime?.activeObject?.dataHash || null },
    featureGram: runtime?.features ? gramSnapshot(runtime.features) : null,
    featureGramTolerance: Number(config.featureGramTolerance ?? 1e-4),
    adapterCapabilities: { fileIntegrity: true, gramRelations: Boolean(runtime?.features), geometrySemantics: false, visualPerception: false, physicsBehavior: false, performance: false },
    approval: null,
    limitations: ['R0.1 checks file hashes and optional adapter-provided feature relationships; it does not yet prove 3D semantic or perceptual equivalence.']
  };
  fs.mkdirSync(path.dirname(anchorPath(repo.root, id)), { recursive: true });
  fs.writeFileSync(anchorPath(repo.root, id), JSON.stringify(anchor, null, 2) + '\n');
  return { status: 'CANDIDATE_CREATED', anchor, file: path.relative(repo.root, anchorPath(repo.root, id)) };
}

function verify(id) {
  const repo = repoInfo(); if (!repo) throw new Error('Not a Git worktree.');
  const anchor = loadAnchor(repo.root, id), current = snapshot(repo.root, anchor.protectedPaths || []), config = readConfig(repo.root);
  const runtime = json(path.join(repo.root, config.runtimeContext || `${META}/runtime-context.json`), null);
  const featureRelation = anchor.featureGram ? compareGram(anchor.featureGram, runtime?.features ? gramSnapshot(runtime.features) : null, anchor.featureGramTolerance) : { status: 'NOT_CONFIGURED', relativeError: null };
  const differences = [];
  for (const rel of anchor.protectedPaths || []) {
    const before = anchor.fileSnapshot[rel] || {}, after = current[rel] || {};
    if (before.exists !== after.exists || before.sha256 !== after.sha256) differences.push({ path: rel, expected: before.sha256 || null, actual: after.sha256 || null, state: !after.exists ? 'MISSING' : 'CONTENT_CHANGED' });
  }
  const status = differences.length || featureRelation.status === 'DRIFT' ? 'DRIFT' : featureRelation.status === 'INSUFFICIENT_EVIDENCE' ? 'INSUFFICIENT_EVIDENCE' : 'PASS';
  const result = { schema: 'kaopugram.verification/0.1', anchorId: id, status, checkedAt: new Date().toISOString(), checkedCommit: repo.head, baselineCommit: anchor.source.commit, checkedFiles: (anchor.protectedPaths || []).length, differences, featureRelation };
  const evidenceDir = path.join(repo.root, META, 'evidence'); fs.mkdirSync(evidenceDir, { recursive: true });
  fs.writeFileSync(path.join(evidenceDir, `${id}-latest-verification.json`), JSON.stringify(result, null, 2) + '\n');
  return result;
}

function promote(id, approvedBy) {
  if (!approvedBy) throw new Error('Promotion requires --approved-by.');
  const result = verify(id); if (result.status !== 'PASS') throw new Error(`PROMOTION_BLOCKED: verification is ${result.status}.`);
  const repo = repoInfo(), anchor = loadAnchor(repo.root, id);
  const dirty = git(repo.root, 'status', '--porcelain', '--', ...anchor.protectedPaths) || '';
  if (dirty.trim()) throw new Error('PROMOTION_BLOCKED: protected files have uncommitted changes. Commit the verified state first.');
  anchor.status = 'ACCEPTED'; anchor.source.acceptedCommit = repo.head;
  anchor.approval = { approvedBy, approvedAt: new Date().toISOString(), verificationCommit: result.checkedCommit };
  fs.writeFileSync(anchorPath(repo.root, id), JSON.stringify(anchor, null, 2) + '\n');
  return anchor;
}

function status() {
  const repo = repoInfo(); if (!repo) throw new Error('Not a Git worktree.');
  const dir = path.join(repo.root, META, 'anchors'); if (!fs.existsSync(dir)) return { anchors: [] };
  const anchors = fs.readdirSync(dir).filter(f => f.endsWith('.json')).map(f => json(path.join(dir, f))).filter(Boolean);
  return { anchors: anchors.map(a => ({ id: a.id, name: a.name, status: a.status, currentState: verify(a.id).status, target: a.target.objectId })) };
}

function recoverPlan(id) {
  const repo = repoInfo(); if (!repo) throw new Error('Not a Git worktree.');
  const anchor = loadAnchor(repo.root, id);
  return { schema: 'kaopugram.recovery-plan/0.1', status: 'PLAN_ONLY_NO_MUTATION', anchorId: id, restoreFromCommit: anchor.source.commit, protectedPaths: anchor.protectedPaths, currentBranch: repo.branch, currentHead: repo.head, instruction: 'Create a recovery branch and restore only the listed paths after reviewing uncommitted changes. R0.1 never performs destructive reset/checkout.' };
}

try {
  if (command === 'version' || command === '--version') print({ name: 'KaoPuGram', version: VERSION });
  else if (command === 'init') {
    const dir = path.join(process.cwd(), META); fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, 'workbench.json');
    if (fs.existsSync(file)) throw new Error('workbench.json already exists; refusing to overwrite.');
    fs.writeFileSync(file, JSON.stringify({ schema: 'kaopugram.workbench/0.1', workbenchId: path.basename(process.cwd()), domain: 'unknown', adapter: 'generic', runtimeContext: `${META}/runtime-context.json`, pathRules: [], objectPaths: {} }, null, 2) + '\n');
    fs.writeFileSync(path.join(dir, '.gitignore'), 'runtime-context.json\nevidence/\n');
    print({ status: 'INITIALIZED', config: path.relative(process.cwd(), file) });
  } else if (command === 'resolve' || (command === 'context' && args[0] === 'show')) print(resolve());
  else if (command === 'context' && args[0] === 'import') {
    const source = args[1]; if (!source) throw new Error('Usage: kaopugram context import <file.json>');
    const input = path.resolve(process.cwd(), source), data = JSON.parse(fs.readFileSync(input, 'utf8'));
    if (!data.activeObject?.id && !data.selection?.objectId) throw new Error('Context must include activeObject.id or selection.objectId.');
    const repo = repoInfo(); if (!repo) throw new Error('Run inside a Git worktree.');
    const config = readConfig(repo.root), destination = path.join(repo.root, config.runtimeContext || `${META}/runtime-context.json`);
    fs.mkdirSync(path.dirname(destination), { recursive: true }); fs.writeFileSync(destination, JSON.stringify(data, null, 2) + '\n');
    print({ status: 'CONTEXT_IMPORTED', objectId: data.activeObject?.id || data.selection.objectId, destination: path.relative(repo.root, destination) });
  } else if (command === 'anchor' && args[0] === 'propose') print(propose({ name: opt('--name'), target: opt('--target'), paths: listOpt('--paths'), invariants: listOpt('--invariant') }));
  else if (command === 'anchor' && args[0] === 'verify') print(verify(args[1]));
  else if (command === 'anchor' && args[0] === 'promote') print(promote(args[1], opt('--approved-by')));
  else if (command === 'status') print(status());
  else if (command === 'recover-plan') print(recoverPlan(args[0]));
  else print({ name: 'KaoPuGram', version: VERSION, commands: ['init', 'resolve', 'context show', 'context import <file>', 'anchor propose', 'anchor verify <id>', 'anchor promote <id> --approved-by <name>', 'status', 'recover-plan <id>'] });
} catch (error) { die(error.message); }
