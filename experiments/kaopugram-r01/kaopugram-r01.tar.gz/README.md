# KaoPuGram R0.1 — cross-workbench anchoring prototype

This is a small, dependency-free Node.js prototype testing the core promise: a workbench can export its current context, call one shared CLI, create an anchor candidate, verify it later, detect drift, and block unsafe promotion.

## Test

Requirements: Node.js 20+ and Git.

```bash
npm test
```

## Basic integration

1. Copy `kaopugram.mjs` into a workbench repo or install it from the eventual standalone KaoPuGram repository.
2. Run `node kaopugram.mjs init` once.
3. Configure `.kaopugram/workbench.json`, especially `objectPaths`.
4. Export the current UI selection to `.kaopugram/runtime-context.json`.
5. Run `node kaopugram.mjs resolve`.
6. Run `node kaopugram.mjs anchor propose --name "Accepted object"`.
7. Run `node kaopugram.mjs anchor verify <id>` and explicitly promote only after review.

## Runtime context

The active workbench should export stable IDs for the selected object/module, plus optional feature vectors. Git metadata alone cannot identify the object selected in an open browser tab. If runtime context is absent, the CLI may infer an object only when exactly one configured path rule matches changed files; ambiguous cases return `NEEDS_CONTEXT`.

## Commands

- `init`
- `resolve` / `context show`
- `context import <runtime-context.json>`
- `anchor propose --name <name> [--target <id>] [--paths <glob,...>] [--invariant <text,...>]`
- `anchor verify <id>`
- `anchor promote <id> --approved-by <approver>`
- `status`
- `recover-plan <id>`

## What the prototype verifies

- Repository, branch, HEAD, dirty paths, workbench identity.
- Active module/object from runtime context.
- SHA-256 integrity of explicitly protected files.
- Optional Gram matrix of adapter-provided feature vectors: `G = X Xᵀ`. It checks whether pairwise feature relationships remain within tolerance.
- Candidate/accepted lifecycle, explicit promotion, drift detection, and non-destructive recovery planning.

The Gram comparison is an engineering prototype inspired by Gram anchoring; it is not a reproduction of DINOv3's training objective.

## Deliberate limits

R0.1 does not extract 3D mesh features, assess visual quality, simulate cloth, or validate physics. Those capabilities require domain adapters. A file hash change is a drift signal, not proof of quality loss. Recovery is plan-only; no destructive reset or checkout is executed.
