import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const cli = path.join(root, 'kaopugram.mjs');
const git = (cwd, ...args) => execFileSync('git', args, { cwd, stdio: 'ignore' });
function call(cwd, ...args) { const r = spawnSync(process.execPath, [cli, ...args], { cwd, encoding: 'utf8' }); return { code: r.status, stdout: r.stdout, stderr: r.stderr, json: (() => { try { return JSON.parse(r.stdout); } catch { return null; } })() }; }
function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kaopugram-test-'));
  git(dir, 'init'); git(dir, 'config', 'user.email', 'test@example.invalid'); git(dir, 'config', 'user.name', 'KaoPuGram Test');
  fs.mkdirSync(path.join(dir, 'src/cloth'), { recursive: true }); fs.writeFileSync(path.join(dir, 'src/cloth/solver.js'), 'export const solver = "xpbd-v1";\n');
  fs.mkdirSync(path.join(dir, '.kaopugram'), { recursive: true });
  fs.writeFileSync(path.join(dir, '.kaopugram/workbench.json'), JSON.stringify({ workbenchId:'clothing-test', domain:'clothing', adapter:'generic', objectPaths:{'jacket-01':['src/cloth/**']}, pathRules:[{prefix:'src/cloth/',objectId:'jacket-01'}] }, null, 2));
  fs.writeFileSync(path.join(dir, '.kaopugram/runtime-context.json'), JSON.stringify({ activeModule:{id:'cloth-solver'}, activeObject:{id:'jacket-01'}, features:[{id:'body',vector:[1,0]},{id:'sleeve',vector:[0,1]}] }, null, 2));
  git(dir, 'add', '.'); git(dir, 'commit', '-m', 'fixture baseline'); return dir;
}

test('resolves repository, active module and selected object', () => {
  const dir = fixture(), r = call(dir, 'resolve');
  assert.equal(r.json.status, 'RESOLVED'); assert.equal(r.json.activeObject.id, 'jacket-01'); assert.equal(r.json.confidence, 'HIGH');
});

test('proposes, verifies, promotes and detects file drift', () => {
  const dir = fixture(), p = call(dir, 'anchor', 'propose', '--name', 'Approved jacket');
  assert.equal(p.code, 0, p.stderr); const id = p.json.anchor.id;
  assert.equal(call(dir, 'anchor', 'verify', id).json.status, 'PASS');
  assert.equal(call(dir, 'anchor', 'promote', id, '--approved-by', 'user').json.status, 'ACCEPTED');
  fs.writeFileSync(path.join(dir, 'src/cloth/solver.js'), 'export const solver = "changed";\n');
  assert.equal(call(dir, 'anchor', 'verify', id).json.status, 'DRIFT');
  assert.equal(call(dir, 'status').json.anchors[0].currentState, 'DRIFT');
  assert.equal(call(dir, 'recover-plan', id).json.status, 'PLAN_ONLY_NO_MUTATION');
});

test('Gram matrix preserves relations under a rotation and detects relation change', () => {
  const dir = fixture(), p = call(dir, 'anchor', 'propose', '--name', 'Gram relation'); const id = p.json.anchor.id;
  const file = path.join(dir, '.kaopugram/runtime-context.json'), ctx = JSON.parse(fs.readFileSync(file, 'utf8'));
  ctx.features = [{id:'body',vector:[0,1]},{id:'sleeve',vector:[-1,0]}]; fs.writeFileSync(file, JSON.stringify(ctx));
  assert.equal(call(dir, 'anchor', 'verify', id).json.featureRelation.status, 'PASS');
  ctx.features = [{id:'body',vector:[1,0]},{id:'sleeve',vector:[0.6,0.8]}]; fs.writeFileSync(file, JSON.stringify(ctx));
  assert.equal(call(dir, 'anchor', 'verify', id).json.featureRelation.status, 'DRIFT');
});

test('does not guess when runtime context is absent or path mapping is ambiguous', () => {
  const dir = fixture(), file = path.join(dir, '.kaopugram/runtime-context.json'); fs.unlinkSync(file);
  fs.writeFileSync(path.join(dir, 'src/cloth/solver.js'), 'changed');
  assert.equal(call(dir, 'resolve').json.status, 'RESOLVED');
  const cfg = path.join(dir, '.kaopugram/workbench.json'), c = JSON.parse(fs.readFileSync(cfg, 'utf8'));
  c.pathRules.push({prefix:'src/cloth/',objectId:'other'}); fs.writeFileSync(cfg, JSON.stringify(c));
  const r = call(dir, 'resolve'); assert.equal(r.json.status, 'NEEDS_CONTEXT'); assert.equal(r.json.candidateObjects.length, 2);
});

test('blocks promotion if protected candidate files are uncommitted', () => {
  const dir = fixture(); fs.writeFileSync(path.join(dir, 'src/cloth/solver.js'), 'candidate');
  const p = call(dir, 'anchor', 'propose', '--name', 'Uncommitted'); const id = p.json.anchor.id;
  const blocked = call(dir, 'anchor', 'promote', id, '--approved-by', 'user');
  assert.equal(blocked.code, 1); assert.match(blocked.stderr, /uncommitted changes/);
});

test('requires fresh runtime evidence when the anchor includes Gram features', () => {
  const dir = fixture(), p = call(dir, 'anchor', 'propose', '--name', 'Evidence required'), id = p.json.anchor.id;
  fs.unlinkSync(path.join(dir, '.kaopugram/runtime-context.json'));
  const v = call(dir, 'anchor', 'verify', id); assert.equal(v.json.status, 'INSUFFICIENT_EVIDENCE');
});
