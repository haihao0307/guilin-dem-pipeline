#!/usr/bin/env node
import { resolveContext, proposeAnchor, verifyAnchor, promoteAnchor, recoveryPlan } from './core.js';
const [cmd,...args]=process.argv.slice(2); const root=process.cwd();
const print=x=>console.log(JSON.stringify(x,null,2));
try {
 if(cmd==='resolve') print(resolveContext(root,args[0]));
 else if(cmd==='propose') { const [id,paths=''] = args; print(proposeAnchor(root,{id,protectedPaths:paths?paths.split(','):[]})); }
 else if(cmd==='verify') print(verifyAnchor(root,args[0]));
 else if(cmd==='promote') { const [id,approvedBy] = args; const v=verifyAnchor(root,id); print(promoteAnchor(root,id,{approvedBy,verification:v})); }
 else if(cmd==='recover-plan') print(recoveryPlan(root,args[0]));
 else { console.log('KaoPuGram 0.2\nCommands: resolve [runtime.json] | propose <id> [protected,path,list] | verify <id> | promote <id> <approvedBy> | recover-plan <id>'); process.exitCode=2; }
} catch(e){ console.error(`GRAM_ERROR: ${e.message}`); process.exitCode=1; }
