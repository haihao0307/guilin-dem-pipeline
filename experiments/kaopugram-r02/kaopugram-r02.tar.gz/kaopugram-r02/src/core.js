import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';

export const sha256 = b => crypto.createHash('sha256').update(b).digest('hex');
const readJson = p => JSON.parse(fs.readFileSync(p,'utf8'));
const writeJson = (p,v) => { fs.mkdirSync(path.dirname(p),{recursive:true}); fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n'); };
const git = (cwd,...args) => execFileSync('git',args,{cwd,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();

export function resolveContext(root, runtimePath) {
  const cwd=path.resolve(root);
  const gitRoot=git(cwd,'rev-parse','--show-toplevel');
  const branch=git(gitRoot,'branch','--show-current');
  const head=git(gitRoot,'rev-parse','HEAD');
  const status=git(gitRoot,'status','--porcelain','--untracked-files=all');
  const dirtyFiles=status?status.split('\n').map(x=>x.slice(3)).filter(x=>!x.startsWith('.kaopugram/')):[];
  const dirty=dirtyFiles.join('\n');
  const cfgPath=path.join(gitRoot,'kaopugram.yaml');
  const config=fs.existsSync(cfgPath)?readJson(cfgPath):{};
  let runtime=null;
  if(runtimePath){ const p=path.resolve(gitRoot,runtimePath); if(fs.existsSync(p)) runtime=readJson(p); }
  const activeObject=runtime?.activeObject ?? config?.context?.activeObject ?? null;
  const activeModule=runtime?.activeModule ?? config?.context?.activeModule ?? null;
  const candidates=runtime?.candidates ?? [];
  const ambiguous=(!activeObject && candidates.length!==1) || candidates.length>1 && !activeObject;
  return {schema:'kaopugram.context/0.2',repository:path.basename(gitRoot),root:gitRoot,branch,head,dirty:!!dirty,dirtyFiles,workbench:runtime?.workbench??config.workbench??null,domain:runtime?.domain??config.domain??null,activeModule,activeObject,selectionSource:runtime?'runtime':activeObject?'config':'unresolved',ambiguous,config};
}

export function gramMatrix(vectors) {
  if(!Array.isArray(vectors)||!vectors.length||!vectors.every(v=>Array.isArray(v)&&v.length===vectors[0].length&&v.every(Number.isFinite))) throw new Error('featureVectors must be a non-empty rectangular numeric matrix');
  return vectors.map(a=>vectors.map(b=>a.reduce((s,x,i)=>s+x*b[i],0)));
}
export function matrixDistance(a,b) {
  if(a.length!==b.length||a.some((r,i)=>r.length!==b[i].length)) return Infinity;
  let sum=0,den=0; a.forEach((r,i)=>r.forEach((x,j)=>{sum+=(x-b[i][j])**2;den+=x*x;}));
  return Math.sqrt(sum)/Math.max(Math.sqrt(den),1e-12);
}
function fileSnapshot(root, paths) {
  const out={}; for(const rel of paths){ const p=path.resolve(root,rel); if(!p.startsWith(root+path.sep)) throw new Error(`path escapes repository: ${rel}`); if(!fs.existsSync(p)||!fs.statSync(p).isFile()) throw new Error(`missing file: ${rel}`); out[rel]=sha256(fs.readFileSync(p)); } return out;
}
function saveDir(root){return path.join(root,'.kaopugram');}

export function proposeAnchor(root, {id, protectedPaths=[], featureVectors=null, relations=[], acceptance=[]}) {
  const c=resolveContext(root);
  if(!c.workbench||!c.domain) throw new Error('Workbench identity missing: add kaopugram.yaml');
  if(!c.activeObject||c.ambiguous) throw new Error('Active object unresolved or ambiguous; export runtime context or set context.activeObject');
  if(c.dirty) throw new Error('Working tree is dirty; commit or explicitly snapshot a clean worktree before anchoring');
  const candidate={schema:'kaopugram.anchor/0.2',id,status:'CANDIDATE',createdAt:new Date().toISOString(),context:{workbench:c.workbench,domain:c.domain,module:c.activeModule,object:c.activeObject,repository:c.repository,branch:c.branch,commit:c.head},protectedFiles:fileSnapshot(c.root,protectedPaths),featureGram:featureVectors?gramMatrix(featureVectors):null,relations,acceptance,sourceCommit:c.head};
  writeJson(path.join(saveDir(c.root),'candidates',`${id}.json`),candidate); return candidate;
}

export function verifyAnchor(root,id,{featureVectors=null,checks=[]}={}) {
  const c=resolveContext(root),p=path.join(saveDir(c.root),'anchors',`${id}.json`),candidatePath=path.join(saveDir(c.root),'candidates',`${id}.json`);
  const anchor=fs.existsSync(p)?readJson(p):fs.existsSync(candidatePath)?readJson(candidatePath):null;
  if(!anchor) throw new Error(`anchor not found: ${id}`);
  const current=fileSnapshot(c.root,Object.keys(anchor.protectedFiles??{}));
  const fileDrift=Object.keys(current).filter(k=>current[k]!==anchor.protectedFiles[k]);
  let relationDrift=null;
  if(anchor.featureGram&&featureVectors) relationDrift=matrixDistance(anchor.featureGram,gramMatrix(featureVectors));
  const failedChecks=checks.filter(x=>x.status!=='PASS');
  const relationTolerance=anchor.relationTolerance??0.02;
  const passed=fileDrift.length===0&&(relationDrift===null||relationDrift<=relationTolerance)&&failedChecks.length===0;
  return {schema:'kaopugram.verification/0.2',anchorId:id,checkedAt:new Date().toISOString(),commit:c.head,workingTreeDirty:c.dirty,fileDrift,relationDrift,relationTolerance,failedChecks,passed,status:passed?'PASS':'HOLD',note:'A PASS means configured invariants passed; it is not a universal visual-quality judgment.'};
}

export function promoteAnchor(root,id,{approvedBy,verification}) {
  const c=resolveContext(root); if(c.dirty) throw new Error('Cannot promote from dirty working tree');
  if(!approvedBy) throw new Error('Explicit approval identity required');
  if(!verification?.passed||verification.anchorId!==id) throw new Error('A matching passing verification is required');
  const cp=path.join(saveDir(c.root),'candidates',`${id}.json`); if(!fs.existsSync(cp)) throw new Error('candidate not found');
  const a=readJson(cp); if(a.sourceCommit!==c.head) throw new Error('Candidate source commit differs from current HEAD');
  a.status='ACCEPTED'; a.approvedAt=new Date().toISOString(); a.approvedBy=approvedBy; a.verification=verification;
  writeJson(path.join(saveDir(c.root),'anchors',`${id}.json`),a); fs.unlinkSync(cp); return a;
}

export function recoveryPlan(root,id) {
  const c=resolveContext(root),p=path.join(saveDir(c.root),'anchors',`${id}.json`); if(!fs.existsSync(p)) throw new Error('accepted anchor not found');
  const a=readJson(p); return {schema:'kaopugram.recovery-plan/0.2',anchorId:id,currentHead:c.head,anchorCommit:a.sourceCommit,actions:[`Inspect diff ${a.sourceCommit}..${c.head}`,`Create a recovery branch from ${a.sourceCommit}`,`Restore only approved paths after review`],automaticMutation:false,warning:'No files or refs were changed. Recovery requires an explicit reviewed action.'};
}
