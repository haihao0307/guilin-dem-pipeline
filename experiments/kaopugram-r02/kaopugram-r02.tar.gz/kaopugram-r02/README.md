# KaoPuGram R0.2 — cross-workbench anchor core

A dependency-free Node.js prototype. It deliberately separates repository identity from runtime-selected object identity.

## Quick start

1. Add `kaopugram.yaml` to a workbench repository:

```json
{
  "workbench": "clothing",
  "domain": "clothing",
  "context": { "activeModule": "cloth-solver", "activeObject": "jacket-01" }
}
```

2. Or provide runtime selection in a JSON file and call `kaopugram resolve runtime-context.json`.
3. Run `npm test`.

## Commands

- `kaopugram resolve [runtime-context.json]`
- `kaopugram propose <anchor-id> [protected,path,list]`
- `kaopugram verify <anchor-id>`
- `kaopugram promote <anchor-id> <approval-identity>`
- `kaopugram recover-plan <anchor-id>`

## Design correction from R0.1

File hashes are exact provenance/integrity checks, not a general measure of quality. Gram matrices compare adapter-provided feature relations; they do not extract semantic features from a mesh and do not certify visual quality. Domain adapters must supply geometry, motion, material, physical and performance measurements. The core refuses to infer an active object when context is missing or ambiguous.

## Safety

Promotion requires a clean worktree, a matching passing verification, and an explicit approval identity. Recovery only emits a plan; it never resets files or moves Git refs automatically.
