Weather Mother R36 全量包
身份与用途：Weather Mother 是本 天气和云体研究工作台的交接名称，用于标识云体、天气交互和预览研究。
R36 是最新研究候选，R34 仍是此前已验收的视觉基线；R36 尚未通过自然动态与等画质性能验收。
预览：https://raw.githack.com/haihao0307/guilin-dem-pipeline/4f59489d3a399034e82190cae9b41d3e92a5942b/weather-mother/cloud-r36-20261031/index.html?scene=waves
源码位于 R36/，运行 python R36/build.py 构建；规则、研究来源、证据及脚本见包内。
图标是为 Weather Mother 设计的雷雨图形，不表示品牌商标或权利已注册。
