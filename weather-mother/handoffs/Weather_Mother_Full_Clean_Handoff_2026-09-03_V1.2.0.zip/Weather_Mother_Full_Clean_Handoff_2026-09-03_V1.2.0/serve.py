from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
import webbrowser
root = Path(__file__).resolve().parent / 'web'
os.chdir(root)
url = 'http://127.0.0.1:8000/weather-mother/'
print(url)
try:
    webbrowser.open(url)
except Exception:
    pass
ThreadingHTTPServer(('127.0.0.1', 8000), SimpleHTTPRequestHandler).serve_forever()
