# Weather Mother Full Clean Handoff V1.2.0

这是 Weather Mother 当前干净全量交接包。

公开入口只有 Weather Mother。根入口默认进入 World。Rain、Snow、Fog、Cloud、Storm 都在统一壳层中切换。

当前 Rain 使用 liquid-rain-v100，保留用户确认可以继续发展的三维村院方向。旧平面村落、旧 Rain 实验、旧壳层和旧发布包均不进入当前路由与本包。

运行方式：在本目录执行 python3 serve.py，然后打开终端显示的地址。

当前质量状态：visualApproved=false，aaaQualityApproved=false，productionReady=false。
