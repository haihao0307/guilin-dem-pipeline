@echo off
py -3 serve.py
pause
