Weather Mother R36 全量交接 2026-11-01
R36 是最新发布的研究候选，并非已验收生产基线；R34 仍是已接受的视觉基线。
固定公网预览：https://raw.githack.com/haihao0307/guilin-dem-pipeline/4f59489d3a399034e82190cae9b41d3e92a5942b/weather-mother/cloud-r36-20261031/index.html?scene=waves
源码在 R36/；在该目录运行 python build.py 可生成入口、场景与独立页面。验证工具在 scripts/，证据在 evidence/。
本包不代表历史版本全量归档。原天气默认 144 步有画质取舍；解析边界不代表自然动态或等画质性能已验收。第三方研究代码的来源和许可边界见 R36/SOURCES.txt。
遵守两份 Mother 规则；清理完成前暂停新资产生产与工具重建。
