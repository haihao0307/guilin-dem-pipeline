from pathlib import Path
import re,json,subprocess,moderngl,numpy as np,tempfile,hashlib
from PIL import Image
R=Path(__file__).resolve().parents[1];N=R/'R36';D=R/'delivery/R36';D.mkdir(parents=True,exist_ok=True)
s=(N/'src/waves.html').read_text(encoding='utf8')
fs=re.search(r'<script id="fs"[^>]*>(.*?)</script>',s,re.S)[1].replace('#version 300 es','#version 330').replace('precision highp float;','')
c=moderngl.create_standalone_context(require=330)
p=c.program(vertex_shader='#version 330\nvoid main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(p*2.-1.,0.,1.);}',fragment_shader=fs);v=c.vertex_array(p,[])
for k,x in {'uAngles':(.25,.12),'uTime':0,'uDistance':10,'uDetail':.65,'uDensity':1,'uSteps':96}.items():p[k]=x
f=c.simple_framebuffer((960,540));f.use();p['uResolution']=(960,540)
def draw(t):
 p['uTime']=t;v.render(vertices=3);return np.frombuffer(f.read(components=3),dtype=np.uint8).copy()
a=draw(0);b=draw(2);a2=draw(0);assert np.array_equal(a,a2);motion=float(np.abs(a.astype(float)-b).mean());assert motion>.1
for name,arr in [('wave-time-0.png',a),('wave-time-2.png',b)]:Image.frombytes('RGB',(960,540),arr.tobytes()).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(D/name)
bench=[]
for w,h,steps in [(960,540,64),(1280,720,96),(1280,720,144)]:
 f=c.simple_framebuffer((w,h));f.use();p['uResolution']=(w,h);p['uSteps']=steps
 samples=[]
 for i in range(12):
  p['uTime']=i*.1
  with c.query(time=True) as q:v.render(vertices=3)
  c.finish()
  if i>1:samples.append(q.elapsed/1e6)
 bench.append({'pixels':[w,h],'steps':steps,'gpuMsMedian':float(np.median(samples))})
subprocess.run(['python',str(N/'build.py')],check=True)
with tempfile.TemporaryDirectory() as tmp:
 script=re.search(r'<script>\(\(\)=>.*?</script>',s,re.S)[0][8:-9];fp=Path(tmp)/'a.js';fp.write_text(script,encoding='utf8');subprocess.run(['node','--check',str(fp)],check=True)
unchanged=[]
for pth in (R/'R35/src').iterdir():
 if pth.name in ['host.html','waves.html','weather_world.html']:continue
 assert pth.read_bytes()==(N/'src'/pth.name).read_bytes(),pth.name
 unchanged.append(pth.name)
res={'version':'R36 candidate','gpu':c.info['GL_RENDERER'],'backend':'desktop OpenGL, not browser FPS','fixedTimeReplayIdentical':True,'meanByteChangeAfter2Seconds':motion,'benchmarks':bench,'R35RetainedSourceFilesEqual':unchanged,'visualAcceptance':False,'equalQualityPerformanceImprovementProven':False,'scope':'cloud-only wave field; original rain unchanged; weather density/dynamics unchanged, default quality tier adjusted'}
(D/'CHECK.json').write_text(json.dumps(res,indent=2),encoding='utf8');print(json.dumps(res))
