from pathlib import Path
import json,time,threading,http.server,functools,argparse
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];D=R/'delivery/R36';D.mkdir(exist_ok=True)
ap=argparse.ArgumentParser();ap.add_argument('--url');args=ap.parse_args()
server=http.server.ThreadingHTTPServer(('127.0.0.1',8769),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(R)))
threading.Thread(target=server.serve_forever,daemon=True).start()
results=[]
with sync_playwright() as p:
 b=p.chromium.launch(channel='msedge',headless=True,args=['--enable-webgl','--ignore-gpu-blocklist'])
 for version,url in ([('R36-public',args.url)] if args.url else [('R35','http://127.0.0.1:8769/R35/index.html'),('R36','http://127.0.0.1:8769/R36/index.html')]):
  context=b.new_context(viewport={'width':1280,'height':900},device_scale_factor=1)
  page=context.new_page();requests=[];errors=[]
  page.on('request',lambda r:requests.append(r.url));page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(url+'?scene=waves',wait_until='networkidle')
  if page.get_by_role('button',name='Open the page',exact=True).count():
   page.get_by_role('button',name='Open the page',exact=True).click()
   page.wait_for_load_state('networkidle')
  page.wait_for_timeout(2500)
  wave=next(f for f in page.frames if f.evaluate('!!window.WaveCloudQA'))
  wave.locator('#play').click();page.screenshot(path=str(D/(version+'-waves.png')))
  waveqa=wave.evaluate('({qa:WaveCloudQA,canvas:[c.width,c.height],viewport:[innerWidth,innerHeight]})')
  wave.locator('#reset').click();wave.locator('#measure').click();page.wait_for_timeout(5800)
  waveqa['measurement']=wave.evaluate('WaveCloudQA.measurement');initial_requests=list(requests)
  page.locator('[data-scene=weather]').click()
  for _ in range(90):
   frames=[f for f in page.frames if f.evaluate('!!window.WeatherMother?.qa?.ready')]
   if frames:break
   page.wait_for_timeout(500)
  assert frames,'weather did not become ready'
  weather=frames[0];weather.evaluate('WeatherMother.resetMeasurements()');page.wait_for_timeout(6000)
  weatherqa=weather.evaluate('WeatherMother.qa');weather.evaluate('WeatherMother.pause()');page.wait_for_timeout(800)
  page.screenshot(path=str(D/(version+'-weather.png')))
  quality=weather.locator('#quality').input_value()
  # Test existing high-quality option and core weather controls.
  weather.locator('#quality').select_option('fine',force=True);weather.locator('[data-hour="12"]').click();weather.evaluate('WeatherMother.play()');page.wait_for_timeout(2200)
  high=weather.evaluate('({size:WeatherMother.qa.renderSize,steps:WeatherMother.qa.steps,errors:WeatherMother.qa.errors})')
  page.locator('[data-scene=lab]').click();page.wait_for_timeout(1800)
  lab=next(f for f in page.frames if f.locator('#renderer').count())
  lab.locator('#renderer').select_option('weather');page.wait_for_timeout(1200)
  page.screenshot(path=str(D/(version+'-lab.png')))
  page.locator('[data-scene=waves]').click();page.wait_for_timeout(800)
  page.set_viewport_size({'width':820,'height':1100});page.wait_for_timeout(900)
  wave=next(f for f in page.frames if f.evaluate('!!window.WaveCloudQA'))
  portrait=wave.evaluate('({canvas:[c.width,c.height],viewport:[innerWidth,innerHeight],errors:WaveCloudQA.errors})')
  page.screenshot(path=str(D/(version+'-portrait.png')))
  results.append(dict(version=version,url=url,initialRequests=initial_requests,allRequests=requests,errors=errors,wave=waveqa,weather=weatherqa,defaultQuality=quality,high=high,portrait=portrait))
  context.close()
 b.close()
suffix='public' if args.url else 'local'
(D/('browser-'+suffix+'.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(results,ensure_ascii=True))
server.shutdown()
