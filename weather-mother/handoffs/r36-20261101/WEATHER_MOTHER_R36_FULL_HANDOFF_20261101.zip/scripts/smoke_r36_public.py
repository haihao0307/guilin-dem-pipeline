from pathlib import Path
from playwright.sync_api import sync_playwright
import json
url='https://raw.githack.com/haihao0307/guilin-dem-pipeline/4f59489d3a399034e82190cae9b41d3e92a5942b/weather-mother/cloud-r36-20261031/index.html?scene=waves'
out=Path(__file__).resolve().parents[1]/'delivery/R36'
with sync_playwright() as p:
 b=p.chromium.launch(channel='msedge',headless=True)
 page=b.new_page(viewport={'width':1280,'height':900});errors=[];responses=[];rows=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('response',lambda r:responses.append({'status':r.status,'url':r.url}))
 page.goto(url,wait_until='networkidle')
 if page.get_by_role('button',name='Open the page',exact=True).count():page.get_by_role('button',name='Open the page',exact=True).click()
 page.wait_for_timeout(2000)
 for scene in ['silver','sea','flight','tiny','protean','lab','weather','waves']:
  page.locator('[data-scene='+scene+']').click();page.wait_for_timeout(1800)
  page.wait_for_function('WeatherR36.qa.loaded===true')
  rows.append({'scene':scene,'canvases':sum(f.locator('canvas').count() for f in page.frames),'error':page.locator('#error').inner_text()})
  assert rows[-1]['canvases']>0 and not rows[-1]['error']
 wave=next(f for f in page.frames if f.evaluate('!!window.WaveCloudQA'))
 wave.locator('#detail').press('ArrowRight');wave.locator('#density').press('ArrowRight')
 canvas=wave.locator('canvas');box=canvas.bounding_box()
 page.mouse.move(box['x']+box['width']*.7,box['y']+box['height']*.6);page.mouse.down();page.mouse.move(box['x']+box['width']*.8,box['y']+box['height']*.63,steps=8);page.mouse.up();page.mouse.wheel(0,100)
 page.wait_for_timeout(1000);wave.locator('#reset').click();page.wait_for_timeout(600)
 assert not wave.evaluate('WaveCloudQA.errors')
 records=page.evaluate('performance.getEntriesByType("resource").map(e=>({name:e.name,transfer:e.transferSize,encoded:e.encodedBodySize,decoded:e.decodedBodySize}))')
 result={'rows':rows,'errors':errors,'responses':responses,'resources':records,'controls':'detail,density,orbit,wheel,reset passed'}
 (out/'public-smoke.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result));b.close()
