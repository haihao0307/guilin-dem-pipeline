// Weather Mother own implementation. Value noise, not a stored image.
// uint overflow is modulo 2^32. Lattice period 65536 cells per axis.
// Coordinate unit: noise lattice cell; use a local/rebased frame.
precision highp int;
uint kaopuHash(uint x){x^=x>>16u;x*=0x7feb352du;x^=x>>15u;x*=0x846ca68bu;x^=x>>16u;return x;}
float kaopuCorner(ivec2 p,uint seed){uvec2 q=uvec2(p)&uvec2(65535u);return float(kaopuHash(q.x^(q.y*0x9e3779b9u)^seed)>>8u)/16777216.;}
vec2 kaopuFade(vec2 x){return x*x*x*(x*(x*6.-15.)+10.);}
float kaopuNoise2(vec2 p,uint seed){
 ivec2 i=ivec2(floor(p));vec2 f=kaopuFade(fract(p));
 return mix(mix(kaopuCorner(i,seed),kaopuCorner(i+ivec2(1,0),seed),f.x),mix(kaopuCorner(i+ivec2(0,1),seed),kaopuCorner(i+ivec2(1,1),seed),f.x),f.y);
}
float kaopuFiltered2(vec2 p,uint seed,float footprint){return mix(kaopuNoise2(p,seed),.5,smoothstep(.25,.75,footprint));}
