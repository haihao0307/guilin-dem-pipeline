// CPU reference for noise.glsl. No raster, no external dependencies.
export const version='kaopu-weather-value2/1';
export function hash(x){x>>>=0;x^=x>>>16;x=Math.imul(x,0x7feb352d);x^=x>>>15;x=Math.imul(x,0x846ca68b);x^=x>>>16;return x>>>0;}
export function corner(x,y,seed){return (hash((x&65535)^Math.imul(y&65535,0x9e3779b9)^(seed>>>0))>>>8)/16777216;}
const fade=x=>x*x*x*(x*(x*6-15)+10), mix=(a,b,t)=>a+(b-a)*t;
export function noise2(x,y,seed=20261026){
 if(!Number.isFinite(x)||!Number.isFinite(y)||Math.abs(x)>1048576||Math.abs(y)>1048576)throw RangeError('Use local coordinates within +/- 2^20 cells');
 x=((x%65536)+65536)%65536;y=((y%65536)+65536)%65536;
 const ix=Math.floor(x),iy=Math.floor(y),fx=fade(x-ix),fy=fade(y-iy);
 return mix(mix(corner(ix,iy,seed),corner(ix+1,iy,seed),fx),mix(corner(ix,iy+1,seed),corner(ix+1,iy+1,seed),fx),fy);
}
export function filtered2(x,y,seed,footprint){const t=Math.max(0,Math.min(1,(footprint-.25)/.5));return mix(noise2(x,y,seed),.5,t*t*(3-2*t));}
