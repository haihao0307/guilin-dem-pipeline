"""Build standalone preview using only this folder, no old handoff dependencies."""
from pathlib import Path
import json
R=Path(__file__).resolve().parent
def read(n):return (R/'src'/n).read_text(encoding='utf8')
def js(x):return json.dumps(x,ensure_ascii=False).replace('</','<\\/')
modules={k:read('weather_'+k+'.html') for k in ['world','rain']}
tiny=read('tiny.html').replace('__NOISE_GLSL__',read('noise.glsl'))
pages={k:read(k+'.html') for k in ['scapes','flight','protean','lab','waves']}
pages['tiny']=tiny;pages['weather']=read('weather_shell.html').replace('__WEATHER_MODULES__',js(modules))
host=read('host.html')
(R/'standalone.html').write_text(host.replace('__SCENES__',js(pages)),encoding='utf8',newline='\n')
out=R/'pages';out.mkdir(exist_ok=True)
for name,source in pages.items():
 (out/(name+'.html')).write_text(source,encoding='utf8',newline='\n')
host=host.replace('function activate(scene){','async function activate(scene){')
host=host.replace('frame.srcdoc=SOURCES[key];', '''try {
 const response=await fetch(SOURCES[key]);
 if(!response.ok)throw Error('场景加载失败 '+response.status);
 const source=await response.text();if(id!==ticket)return;
 frame.srcdoc=source;
 }catch(e){if(id===ticket)document.getElementById('error').textContent=String(e);return;}''')
host=host.replace("const id=++ticket;", "document.getElementById('error').textContent='';const id=++ticket;")
html=host.replace('__SCENES__',js({k:'pages/'+k+'.html' for k in pages}))
(R/'index.html').write_text(html,encoding='utf8',newline='\n')
print('Host',len(html.encode()),'bytes; scenes load on demand')
