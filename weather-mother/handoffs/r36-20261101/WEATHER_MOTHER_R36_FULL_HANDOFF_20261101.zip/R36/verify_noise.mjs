import assert from 'node:assert/strict';
import {noise2,hash,filtered2} from './src/noise.mjs';
import {writeFileSync} from 'node:fs';
assert.equal(hash(0),0);let min=1,max=0,changed=0,maxSeamError=0,maxSlope=0;
for(let i=0;i<4096;i++){
 const x=(i*13.371)%1600-800,y=(i*31.127)%1600-800,a=noise2(x,y),b=noise2(x,y,123);
 assert.ok(Number.isFinite(a)&&a>=0&&a<=1);assert.equal(a,noise2(x,y));
 min=Math.min(min,a);max=Math.max(max,a);if(Math.abs(a-b)>1e-4)changed++;
 const seam=Math.abs(a-noise2(x+65536,y-65536));maxSeamError=Math.max(maxSeamError,seam);assert.ok(seam<1e-8);
 const edge=Math.floor(x),h=1e-4;maxSlope=Math.max(maxSlope,Math.abs(noise2(edge+h,y)-noise2(edge-h,y))/(2*h));
 assert.equal(filtered2(x,y,123,1),.5);
}
assert.ok(changed>4000);assert.ok(max-min>.85);assert.ok(maxSlope<1e-5);
const result={passed:true,samples:4096,min,max,changedSeedSamples:changed,maxSeamError,maxLatticeBoundarySlope:maxSlope,cpuGpuParityVerified:false,visualAcceptance:false,performanceAcceptance:false};
writeFileSync(new URL('NOISE_CHECK.json',import.meta.url),JSON.stringify(result,null,2));console.log(result);
