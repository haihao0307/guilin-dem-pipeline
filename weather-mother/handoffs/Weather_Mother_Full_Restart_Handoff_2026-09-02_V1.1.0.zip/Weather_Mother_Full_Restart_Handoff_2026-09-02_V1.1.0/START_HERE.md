# Weather Mother 全量重启交接包 V1.1.0

日期：2026-09-02

这是新窗口继续 Weather Mother 的唯一启动包。先完整读取本文件，再依次读取：

1. `HANDOFF.json`
2. `CURRENT_STATE.md`
3. `METHOD_ADOPTION.md`
4. `INTEGRATION.md`
5. `POLICY.json`
6. `MANIFEST.json`
7. `RESTART_QA.json`

读取完成后，先核对 GitHub 上的候选运行版、稳定回退版和当前分支状态，再继续代码工作。不要从旧 Cloud Mother、V0.3.2、独立光影实验页或其他 Mother 的文件恢复路线。

## 当前主线

主线名称是 **Weather Mother**。主要目标是一个纯程序化、可复现、可交互的高质量体积天气母体，覆盖云形、光学、风场、时间演化、天气事件和跨项目接口。

当前全天气候选为 `1.1.0-world`，包含 20 个天气案例、10 个云属、种子切换、独立风力与云速、连续形态循环、晨昏光照、虹彩、彩虹、雨雪、闪电和台风组织预览。

在线候选：
`https://haihao0307.github.io/guilin-dem-pipeline/weather-mother/v110-full/`

干净在线镜像：
`https://haihao0307.github.io/guilin-dem-pipeline/weather-mother/clean-v110/`

稳定回退：
`https://haihao0307.github.io/guilin-dem-pipeline/weather-mother/clean-v1/`

## 下一窗口的第一优先级

继续完整 Weather Mother，不把工作缩成单独打光页。保留当前 20 个天气案例与 10 个云属，优先提高云体细腻度、内部光影层次、闪电真实度和真实 GPU 帧率；继续扩展天气体系时，所有新现象需有原因、关系、时间历史、单位、适用尺度和近似边界。

台风目前是风眼、眼墙、螺旋雨带和高层云盾的程序化组织预览。闪电目前仍是图形近似。它们可以继续迭代，禁止提前标记为最终 3A 通过或科学求解完成。

## 保护规则

只修改 Weather Mother 明确授权的目录。不得借本包修改 Ocean Mother、Landscape Mother、桂林 DEM、冻结真值、其他仓库或其他生产线。不得强推、改写历史或自动授予人工批准。

共同方法已经蒸馏为 `POLICY.json` 与 `METHOD_ADOPTION.md`。原始长文不在本包重复保存。运行时完整守卫迁移尚未覆盖全天气引擎，缺口必须继续如实记录。

`visualApproved=false`、`aaaQualityApproved=false`、`productionReady=false`，直到用户对精确构建作出明确批准。
