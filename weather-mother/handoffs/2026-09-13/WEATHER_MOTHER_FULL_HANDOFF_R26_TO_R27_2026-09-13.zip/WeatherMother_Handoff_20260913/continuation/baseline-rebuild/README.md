# R26 可重建基线

这是独立的 R26 构建复现目录，不是 R27。没有覆盖或重新发布任何冻结版本。

原构建器与来源收据保留在上一级 `recovered-source/` 和 `evidence/source-recovery.json`。
本目录唯一代码修复：`Path.write_text` 指定 `newline=""`，避免 Windows 把每个 LF 转成 CRLF。
修复后输出与原包冻结 R26 的 801331 字节逐字节一致，SHA-256：
`23e1898a534728c5b6f07ea0890192cfb12b0c480681ef13639fb87b94735042`。

## 重建

在本目录运行：

```powershell
python weather-mother/r26-observation-bandwidth-src/build-r26.py
```

构建需要 Python 和 Git；不依赖 pip 或 npm 包。Git 对象库需要固定的 R22 提交
`8aeb8dac519f8bda851cfc998e07266870d3eaef`，本轮已从原仓库取回。
其页面字节与原包 `FROZEN_R21_R22/R22/index.html` 匹配。

QA 脚本需要 Playwright 和浏览器，并读取 `PUBLIC_URL`、`PAGE_SHA`、`GITHUB_WORKSPACE`。
本轮没有运行该浏览器脚本，没有新增手机性能或视觉接受结论。
内置浏览器打开固定公网版本时连接超时，后续浏览器清单请求也失败。

原始构建差异与修复验收分别见上一级：

- `evidence/rebuild-result.json`
- `evidence/rebuild-fixed-result.json`

共同规则位于上一级 `rules/`，继续生效。新资产与 R27 对象运行时开发仍须满足现行清理前置条件或获得明确范围调整。
