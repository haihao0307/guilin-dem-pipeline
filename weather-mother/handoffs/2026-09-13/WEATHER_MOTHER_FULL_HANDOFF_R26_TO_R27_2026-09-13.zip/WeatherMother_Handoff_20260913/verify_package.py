from pathlib import Path
import hashlib, json, os

root = Path(__file__).resolve().parent
if os.name == 'nt' and not str(root).startswith('\\\\?\\'):
    root = Path('\\\\?\\' + str(root))
manifest = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
expected = {item['path'] for item in manifest['files']} | {'MANIFEST.json'}
actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts and '__pycache__' not in p.relative_to(root).parts}
assert actual == expected, {'missing': sorted(expected-actual), 'extra': sorted(actual-expected)}
for item in manifest['files']:
    p = (root / item['path']).resolve()
    assert p.is_relative_to(root.resolve())
    data = p.read_bytes()
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
old = root / 'continuation/WEATHER_MOTHER_CURRENT_FULL_HANDOFF_R26_TO_R27_2026-09-12'
checked = 0
for line in (old / 'MANIFEST/SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
    if not line.strip(): continue
    digest, name = line.split(maxsplit=1)
    name = name.lstrip('*').strip().replace('\\', '/')
    assert hashlib.sha256((old / name).read_bytes()).hexdigest() == digest, name
    checked += 1
r26 = (old / 'CURRENT_R26/index.html').read_bytes()
assert r26 == (root / 'continuation/baseline-rebuild/weather-mother/full-weather-r26-observation-bandwidth-20260911/index.html').read_bytes()
assert hashlib.sha256(r26).hexdigest() == '23e1898a534728c5b6f07ea0890192cfb12b0c480681ef13639fb87b94735042'
print(json.dumps({'ok': True, 'manifestFiles': len(expected), 'originalHashes': checked, 'r26Bytes': len(r26)}))
