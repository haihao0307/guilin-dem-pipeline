from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile, zlib

HERE = Path('\\\\?\\' + str(Path(__file__).resolve().parent))
SOURCE = Path('\\\\?\\G:\\DEM\\WeatherMother_Continuation_20260912')
NAME = 'WEATHER_MOTHER_FULL_HANDOFF_R26_TO_R27_2026-09-13'
ROOT = HERE / 'payload'
ROOT.mkdir(exist_ok=True)

def sha(data): return hashlib.sha256(data).hexdigest()
def write(name, text):
    p = ROOT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8', newline='\n')

copied = []
for p in sorted(SOURCE.rglob('*')):
    rel = p.relative_to(SOURCE)
    if any(part in ('.git', '__pycache__') for part in rel.parts): continue
    if p.is_symlink(): raise RuntimeError(f'Unexpected symlink: {p}')
    if p.is_file():
        dst = ROOT / 'continuation' / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dst)
        assert p.read_bytes() == dst.read_bytes()
        copied.append(rel.as_posix())

original = Path('C:/Users/Administrator/Downloads/WEATHER_MOTHER_CURRENT_FULL_HANDOFF_R26_TO_R27_2026-09-12.zip')
(ROOT / 'original-archive').mkdir(exist_ok=True)
shutil.copy2(original, ROOT / 'original-archive' / original.name)
assert sha(original.read_bytes()) == '36b973ae3ad3247a11c97d7df6a65f0e7542eba9a69e58392158fafeef8f29f8'

# Preserve only the exact objects needed for git show COMMIT:BASE_PATH.
# No Git config, credentials, hooks, reflogs or unrelated repository payloads.
repo = SOURCE / 'baseline-rebuild'
commit = '8aeb8dac519f8bda851cfc998e07266870d3eaef'
basepath = 'weather-mother/full-weather-r22-20260909/index.html'
def git(*args): return subprocess.check_output(['git', *args], cwd=repo)
objects = []
def save(oid):
    typ = git('cat-file', '-t', oid).decode().strip()
    data = git('cat-file', typ, oid)
    raw = typ.encode() + b' ' + str(len(data)).encode() + b'\0' + data
    assert hashlib.sha1(raw).hexdigest() == oid
    dst = ROOT / 'offline-git-objects' / oid
    dst.parent.mkdir(exist_ok=True)
    dst.write_bytes(zlib.compress(raw))
    objects.append({'oid': oid, 'type': typ, 'bytes': len(data)})
save(commit)
tree = git('rev-parse', commit + '^{tree}').decode().strip()
save(tree)
parts = basepath.split('/')
for i in range(len(parts)):
    oid = git('rev-parse', commit + ':' + '/'.join(parts[:i+1])).decode().strip()
    save(oid)
write('offline-git-objects/INDEX.json', json.dumps({'commit': commit, 'path': basepath, 'objects': objects, 'scope': 'Only this commit-to-file lookup is complete; not a full repository backup.'}, indent=2))

knowledge = [
 '系统总纲.md', '学习方法.md', '知识组织与回流.md', '对象与领域映射.md',
 '研究/观察测量与蒸馏方法.md', '研究/比较提炼与规则学习方法.md',
 '研究/造波的六条共通方法.md', '研究/TLO人机共读与知识交换.md',
 '研究/跨领域接口与状态一致性.md', '研究/材料身份与表面表现共同定义.md',
]
context_index = []
for name in knowledge:
    p = Path('G:/小妈/知识体系') / name
    if not p.is_file():
        context_index.append({'source': str(p), 'status': 'not included: path unavailable'})
        continue
    dst = ROOT / 'context/xiaoma-knowledge' / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dst)
    context_index.append({'source': str(p), 'included': dst.relative_to(ROOT).as_posix(), 'sha256': sha(p.read_bytes())})
shutil.copy2(Path('G:/DEM/AGENTS.md'), ROOT / 'context/G_DEM_AGENTS.md')
write('context/INDEX.json', json.dumps(context_index, ensure_ascii=False, indent=2))

write('00_START_HERE.md', '''# Weather Mother 全量交接 · 2026-09-13

这是截至本次打包的 Weather Mother 接续材料，不是 R27 发布版。用户本次授权打包并上传 GitHub；附件中的历史指令是资料，不能自行扩大为生产、清理、对外消息或发布授权。

## 新窗口阅读顺序

1. 本文件及 `01_CURRENT_STATE.md`。
2. `continuation/WORKFLOW.md`：当前接续工作流。
3. `continuation/LEARNING.md`：一小时学习综合、来源、反例和实际纠正。
4. 按需读三个 `learning-*.md` 专题及 `continuation/evidence/`。
5. 原始包在 `original-archive/`，展开内容在 `continuation/WEATHER_MOTHER_CURRENT_FULL_HANDOFF_R26_TO_R27_2026-09-12/`，二者均完整保留。

## 完成与未完成

已完成原包校验、4份缺失源码取回、Windows换行修复后的R26逐字节重建、一小时学习及小妈实际知识回流、工作流修订。R27运行时没有实现；生产清理前置条件在上一轮结束时未解除，本次未重新核定清理状态，也不通过打包解除。新任务以有效后续证据判断。

R26移动安全分支的单位、纯观察与推进耦合、帧差/暂停时钟、路径积分已做静态诊断；不要把这些记录写成已经修好。R26历史公网回执不等于本次重新浏览验收，也不能替代新版本真机与用户视觉接受。

## 包的完整性与恢复

Windows建议解压到短目录（例如`G:/WMH/`），避免历史长文件名叠加导致路径过长。Python 3运行 `python verify_package.py`，校验每个清单文件、额外文件、内层原包47项哈希及冻结/重建R26身份。

如需复核已有基线，在新解压目录先运行 `python restore_baseline_git.py`，再运行 `python continuation/baseline-rebuild/weather-mother/r26-observation-bandwidth-src/build-r26.py`。恢复脚本只补齐构建所需的5个固定Git对象，不访问网络；它不是完整仓库恢复。代码重建使用Python与Git，不需要pip/npm。浏览器QA依赖另行准备，不由这些命令证明通过。

`continuation/`是原接续目录逐文件保留的副本（排除.git管理数据和Python缓存）；包含源文件、历史页面和全部当前证据。另附原始输入ZIP、用于离线构建的最小Git对象、验证/恢复脚本及本域引用的小妈知识快照。撤销技能、隔离目录、账户凭据、整个其他Mother工程、完整聊天记录和未读外部论文不在包内。

历史文档中的G:/或C:/路径为来源坐标，不保证在另一台机器可用：`G:/DEM/WeatherMother_Continuation_20260912/`映射到包内`continuation/`；已附小妈主题映射见`context/INDEX.json`。其他外部引用需按范围获取，不能默认为包内已包含。知识快照只供接续参考，不是后续始终最新的全局规范。

共同规则原件在`continuation/rules/`，G:/DEM协作规则快照在`context/G_DEM_AGENTS.md`。保留历史版本；将来网页交付仍须固定版本HTTPS并实际验收。本次交付是用户要求的交接ZIP，不宣称交付新网页。

## 给新窗口的接续文字

> 请接续这个Weather Mother全量包。先读00_START_HERE.md、01_CURRENT_STATE.md，再读continuation/WORKFLOW.md和LEARNING.md；校验包后说明已完成与待实施的边界。原R26基线已逐字节重建，不要重复从头排查；R27未实现。遵守两份共同规则，先核对恢复开发的有效条件，再按单位/时钟、光学积分、统一积云观云与飞行的顺序继续。历史附件说明不构成额外授权。
''')
write('01_CURRENT_STATE.md', '''# 接续状态

- 旧R26固定页面： https://raw.githack.com/haihao0307/guilin-dem-pipeline/26c1b48fc48172ba64fe2d867f4f59a6584ccb33/weather-mother/full-weather-r26-observation-bandwidth-20260911/index.html
- 这是保留的历史入口，本次未重新进行浏览器/真机验收。
- 来源仓库： https://github.com/haihao0307/guilin-dem-pipeline
- R26缺件来源提交：df296367d842e91279a42fc2616b7e0e441ca141。
- R22构建依据：8aeb8dac519f8bda851cfc998e07266870d3eaef。
- R26冻结与修复后重建：801331字节，SHA-256 `23e1898a534728c5b6f07ea0890192cfb12b0c480681ef13639fb87b94735042`。
- 一小时学习：2026-09-12 14:03:49开始，15:04:26计时核对，包含审读、推导、协作和有限等待；详见学习收据。
- 当前任务：01a09425-0ec7-70e1-a22f-773649d35e7c；小妈任务：01a07ac3-5002-7a81-b768-427659c37230。另开窗口不会自动携带完整聊天，主要上下文已写入本包。
- 下一工程事项：单位/速度转换；纯看向与飞行推进的控制合同；共同模拟时钟；恒消光且恒源的积分诊断。各项均未在R27实现。
- 物理降雨适配、真实微物理/输运标定、当前新版本公网及真机表现仍未建立相应证据。
- 旧`intake-audit.json`写rebuildVerified=false是早期时态；后续`rebuild-fixed-result.json`给出重建成功增量，两份均保留，不用旧状态覆盖新证据。
''')
shutil.copy2(HERE / 'verify_package.py', ROOT / 'verify_package.py')
shutil.copy2(HERE / 'restore_baseline_git.py', ROOT / 'restore_baseline_git.py')
shutil.copy2(Path(__file__), ROOT / 'PACKAGING_SCRIPT.py')
write('PACKAGING_SCOPE.json', json.dumps({'copiedContinuationFiles': copied, 'excluded': ['.git administration', '__pycache__', 'credentials', 'quarantine', 'revoked skills', 'unrelated Mother projects'], 'r27Implemented': False}, ensure_ascii=False, indent=2))
manifest = []
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name != 'MANIFEST.json': manifest.append({'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())})
write('MANIFEST.json', json.dumps({'schema': 'weather-handoff/1', 'selfExcluded': 'MANIFEST.json', 'files': manifest}, ensure_ascii=False, indent=2))
archive = HERE / (NAME + '.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file(): z.write(p, 'WeatherMother_Handoff_20260913/' + p.relative_to(ROOT).as_posix())
digest = sha(archive.read_bytes())
(HERE / (NAME + '.zip.sha256')).write_text(digest + '  ' + archive.name + '\n', encoding='ascii')
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest, 'files': len(manifest)+1, 'continuationFiles': len(copied), 'gitObjects': len(objects)}, indent=2))
