from pathlib import Path
import hashlib, json, subprocess, zlib, os

root = Path(__file__).resolve().parent
if os.name == 'nt' and not str(root).startswith('\\\\?\\'):
    root = Path('\\\\?\\' + str(root))
repo = root / 'continuation/baseline-rebuild'
index = json.loads((root / 'offline-git-objects/INDEX.json').read_text(encoding='utf-8'))
if not (repo / '.git').exists():
    subprocess.run(['git', 'init', '--quiet', str(repo)], check=True)
if not (repo / '.git').is_dir():
    raise SystemExit('Expected a standalone .git directory; refusing a linked worktree.')
for item in index['objects']:
    oid = item['oid']
    packed = (root / 'offline-git-objects' / oid).read_bytes()
    raw = zlib.decompress(packed)
    assert hashlib.sha1(raw).hexdigest() == oid, oid
    dst = repo / '.git/objects' / oid[:2] / oid[2:]
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        assert zlib.decompress(dst.read_bytes()) == raw
    else:
        dst.write_bytes(packed)
result = subprocess.check_output(['git', 'show', index['commit'] + ':' + index['path']], cwd=repo)
expected = root / 'continuation/WEATHER_MOTHER_CURRENT_FULL_HANDOFF_R26_TO_R27_2026-09-12/FROZEN_R21_R22/R22/index.html'
assert result == expected.read_bytes()
print('PASS: offline Git lookup reproduces the exact frozen R22 bytes. No network required.')
