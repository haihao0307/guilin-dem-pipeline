# 小温州 DEM Kernel R1 全量重启包

包名：`WENZHOU_DEM_KERNEL_R1_FULL_PACKAGE_2026-09-07.zip`

生产实验分支：`feature/wenzhou-dem-clean-kernel-r1`

打包源提交：`ba3286b8104538ee1fdf1d115b711cf23c597f2e`

小妈任务包提交：`3eb58693235505b9bb35dbb340c1cfd3007b8e01`

Draft PR：`#64`

## 阅读顺序

1. `source-knowledge/WENZHOU_DEM_CLEAN_SYSTEM_R1.md`
2. `projects/wenzhou/dem-kernel/RESTART_START_HERE.md`
3. `projects/wenzhou/dem-kernel/CONTRACT.json`
4. `projects/wenzhou/dem-kernel/qa/KEEP_ARCHIVE_DROP_R1.json`
5. `projects/wenzhou/dem-kernel/qa/MATH_PROBE_RESULTS_R1.json`
6. `projects/wenzhou/dem-kernel/qa/REAL_WINDOW_STATUS_R1.json`
7. `projects/wenzhou/dem-kernel/qa/REAL_WINDOW_RECOVERY_SEARCH_R1.json`

## 已完成

已经建立温州专属干净实验线、真值身份合同、资产去留总账、整数可逆 CDF 5/3 二维变换、NoData 独立掩膜、哈希容器、局部频带重构、真实窗口来源门禁、单元测试与 GitHub Actions 门禁。

## 当前硬阻塞

固定的完整 17 片 12.5 米 COG 仍未挂载。活动树中没有带原始 Int16 载荷、整数源窗口和载荷 SHA256 的合格 R12 或 R13 窗口。因此真实温州压缩率、全域性能与视觉结论保持未产生。

## 继续工作的入口

先运行：

```bash
python -m unittest discover -s projects/wenzhou/dem-kernel/tests -p 'test_*.py'
python projects/wenzhou/dem-kernel/transform/math_probe.py
python projects/wenzhou/dem-kernel/transform/probe_real_window.py   --manifest projects/wenzhou/dem-kernel/truth/REAL_WINDOW_MANIFEST_TEMPLATE.json
```

真实窗口探针必须先通过来源清单、固定 COG 身份、整数窗口、载荷字节和 SHA256 检查。任何生成数据只能用于数学验证。

## 冻结边界

本包不修改 V0.5.9、V0.6.0、温州真值、公开工作台、Weather、Cloud、Ocean、水文或人工接受状态。旧七层精确节点金字塔继续作为冻结对照。
