
/* Ocean adapter. getEnvironment body and default state below are extracted verbatim from
Weather Mother Clean V1.0; frozen source files in weather/ remain byte-identical. */
(function(root){'use strict';const normal=v=>{const l=Math.hypot(...v)||1;return v.map(x=>x/l)};
let state={hour:16,density:.86,count:3,wind:12,direction:270,exposure:1,detail:.64,rain:0,fog:.03,humidity:68,instability:.45,snow:0,sunlight:1,skylight:1,scatter:1,haze:.16,shear:.18,cloudSpeed:12,gust:.15,turbulence:.25,timeScale:1,evolution:1,silver:1,groundLight:1,loopSeconds:60,loopAmount:.6,lightningRate:6,lightningPower:.9},target={...state};
const presets={fair:{kind:'Cu',density:.86,count:3,rain:0,fog:.03,humidity:68,instability:.45,snow:0},coast:{kind:'Sc',density:.70,count:6,rain:.04,fog:.12,humidity:83,instability:.22,snow:0},mountain:{kind:'Cu',density:.80,count:5,rain:.07,fog:.44,humidity:94,instability:.30,snow:0},rain:{kind:'Ns',density:1.12,count:7,rain:.70,fog:.20,humidity:97,instability:.18,snow:0},storm:{kind:'Cb',density:1.05,count:4,rain:.80,fog:.12,humidity:94,instability:.98,snow:0},rainbow:{kind:'Cu',density:.65,count:3,rain:.42,fog:.05,humidity:82,instability:.25,snow:0,hour:17.5},snow:{kind:'St',density:.72,count:6,rain:0,fog:.32,humidity:91,instability:.1,snow:1},high:{kind:'Ci',density:.5,count:6,rain:0,fog:.02,humidity:50,instability:.12,snow:0}};

let seed=4217,kind='Cu',weather='fair',time=0,evolutionTime=0,playing=true,loopPhase=0,windOffset=[0,0,0];
const switches={windLink:false};const $=k=>({checked:!!switches[k]});
function getEnvironment(){
 const a=(state.hour-12)/12*Math.PI,l=Math.PI/6,sun=normal([-Math.sin(a),Math.cos(l)*Math.cos(a),Math.sin(l)*Math.cos(a)]),mass=1/(Math.max(sun[1],0)+.07),bearing=state.direction*Math.PI/180,dir=[-Math.sin(bearing),0,Math.cos(bearing)],gust=1+state.gust*(.65*Math.sin(time*.39)+.35*Math.sin(time*.13+1.3)),speed=$('windLink').checked?state.wind:state.cloudSpeed;
 return{format:'weather-mother-environment',schemaVersion:1,units:{length:'metre',velocity:'metre/second',time:'simulation second'},axes:{east:'+X',up:'+Y',north:'-Z'},simulationSeconds:time,hour:state.hour,paused:!playing,timeScale:state.timeScale,wind:{fromDegrees:state.direction,direction:dir,forceMps:state.wind,gustMultiplier:gust,velocityMps:dir.map(v=>v*state.wind*gust)},cloud:{kind,seed,driftMps:speed,velocityMps:dir.map(v=>v*speed*gust),offsetMetres:windOffset.map(v=>v*1000),loopPhase},sun:{direction:sun,linearColor:[1.30*Math.exp(-(.012+.018*state.haze)*mass),1.27*Math.exp(-(.056+.021*state.haze)*mass),1.22*Math.exp(-(.145+.025*state.haze)*mass)],intensity:state.sunlight,skylight:state.skylight,exposure:state.exposure},weather:{case:weather,rain:state.rain,fog:state.fog,snow:state.snow,humidityPercent:state.humidity},limitations:['illustrative solar clock; no geographic ephemeris','graphical weather presets; not observed conditions','no ocean wave, foam, reflection or shared-depth integration supplied']};
}

function tick(dt){if(!playing)return;const d=dt*state.timeScale;time+=d;evolutionTime+=d*state.evolution;loopPhase=(loopPhase+d*state.evolution/state.loopSeconds)%1;const e=getEnvironment();windOffset=windOffset.map((v,k)=>v+e.cloud.velocityMps[k]*.001*d)}
function set(k,v){if(typeof v!=='number'||!Number.isFinite(v))throw Error('Invalid weather value');state[k]=v}
function setWeather(k){if(!Object.hasOwn(presets,k))throw Error('Unknown weather');weather=k;Object.assign(state,presets[k]);kind=presets[k].kind}
root.OceanWeather={getEnvironment,tick,set,setWeather,presets,setSeed:v=>seed=v>>>0,setKind:v=>kind=v,pause:()=>playing=false,play:()=>playing=true,snapshot:()=>({...state,seed,kind,weather,time,evolutionTime,playing,loopPhase,windOffset:[...windOffset]}),reset:()=>{time=0;evolutionTime=0;loopPhase=0;windOffset=[0,0,0]}};
})(window);

