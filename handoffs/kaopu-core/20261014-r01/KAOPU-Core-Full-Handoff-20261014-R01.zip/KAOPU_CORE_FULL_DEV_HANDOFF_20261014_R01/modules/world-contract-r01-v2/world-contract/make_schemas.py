import json
from pathlib import Path
P=Path(__file__).parent

def obj(properties,required=None):
 return {'type':'object','properties':properties,'required':list(properties) if required is None else required,'additionalProperties':False}
def arr(items,minItems=0):return {'type':'array','items':items,'minItems':minItems}
sid={'type':'string','minLength':1,'maxLength':128}
vec3={'type':'array','items':{'type':'number'},'minItems':3,'maxItems':3}
source=obj({'basis':{'enum':['observed','inferred','authored']},'source':{'type':'string','minLength':1}})
pose=obj({'position':vec3,'rotation':vec3})
record=obj({'objectId':sid,'typeId':{'type':'string','pattern':r'^kaopu\.[a-z0-9_.-]+@[1-9][0-9]*$'},'parentId':{'anyOf':[sid,{'type':'null'}]},'localPose':pose,'state':{'type':'object'},'provenance':obj({'localPose':source,'state':source})})
view=obj({'viewId':sid,'worldId':sid,'revision':{'type':'integer','minimum':0},'timeSnapshot':{'type':'integer','minimum':0},'objectRefs':arr(sid)})
snapshot=obj({'schemaVersion':{'const':'1.0'},'worldId':sid,'revision':{'type':'integer','minimum':0},'timeSnapshot':{'type':'integer','minimum':0},'tickSeconds':{'type':'number','exclusiveMinimum':0},'seed':{'type':'integer','minimum':0},'generator':obj({'id':sid,'version':sid}),'units':obj({'distance':{'const':'m'},'time':{'const':'s'},'angle':{'const':'rad'}}),'coordinates':obj({'handedness':{'const':'right'},'up':{'const':'Y'},'rotationOrder':{'const':'intrinsic-XYZ'}}),'types':{'type':'object','minProperties':1,'additionalProperties':obj({'label':sid,'stateSchema':{'type':'object'}})},'objects':arr(record),'views':arr(view),'appliedEventIds':{'type':'array','items':sid,'uniqueItems':True}})
snapshot.update({'$schema':'https://json-schema.org/draft/2020-12/schema','title':'KAOPU unique world snapshot 1.0'})
condition=obj({'objectId':sid,'pointer':{'type':'string','pattern':r'^/(typeId|parentId|localPose|state)(/.*)?$'},'equals':{}})
event=obj({'eventId':sid,'worldId':sid,'expectedRevision':{'type':'integer','minimum':0},'fromTimeSnapshot':{'type':'integer','minimum':0},'toTimeSnapshot':{'type':'integer','minimum':0},'preconditions':arr(condition,1),'updates':arr(record,1)})
event.update({'$schema':'https://json-schema.org/draft/2020-12/schema','title':'KAOPU atomic world event 1.0'})
for name,data in [('world.schema.json',snapshot),('event.schema.json',event)]:
 (P/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
index=obj({'schemaVersion':{'const':'1.0'},'worlds':arr(obj({'worldId':sid,'revision':{'type':'integer','minimum':0},'timeSnapshot':{'type':'integer','minimum':0},'activeSnapshot':{'type':'string','minLength':1},'sha256':{'type':'string','pattern':'^[a-f0-9]{64}$'}}),1)})
index.update({'$schema':'https://json-schema.org/draft/2020-12/schema','title':'KAOPU active snapshot index 1.0'})
(P/'world-index.schema.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
