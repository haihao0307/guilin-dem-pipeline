import copy
import unittest
from pathlib import Path
from validate_world import load,replay,canonical,ContractError
from compact_exchange import build_exchange,decode_exchange,digest
P=Path(__file__).parent/'examples'

class CompactTests(unittest.TestCase):
    def setUp(self):
        self.initial=load(P/'initial.world.json');self.events=load(P/'events.json')
        self.dictionary,self.exchange=build_exchange(self.initial,self.events)
    def reject(self,mutate):
        before=canonical(self.exchange)
        mutate(self.exchange)
        altered=canonical(self.exchange)
        with self.assertRaises(ContractError):decode_exchange(self.exchange,self.dictionary)
        self.assertEqual(canonical(self.exchange),altered)
    def test_lossless_full_snapshot_equivalence(self):
        self.assertEqual(canonical(decode_exchange(self.exchange,self.dictionary)),canonical(replay(self.initial,self.events)))
    def test_missing_dictionary_rejected(self):
        with self.assertRaises(ContractError):decode_exchange(self.exchange,None)
    def test_dictionary_version_mismatch(self):
        self.reject(lambda x:x['dictionaryRef'].update(dictionaryVersion='2.0'))
    def test_dictionary_same_version_changed_meaning(self):
        self.dictionary['definitions']['units']['distance']='cm'
        with self.assertRaises(ContractError):decode_exchange(self.exchange,self.dictionary)
    def test_unsupported_units_with_valid_hash_rejected(self):
        self.dictionary['definitions']['units']['distance']='cm'
        self.exchange['dictionaryRef']['sha256']=digest(self.dictionary)
        with self.assertRaises(ContractError):decode_exchange(self.exchange,self.dictionary)
    def test_foreign_world_rejected(self):self.reject(lambda x:x.update(worldId='foreign'))
    def test_wrong_base_revision(self):self.reject(lambda x:x.update(baseRevision=10))
    def test_missing_event_rejected(self):self.reject(lambda x:x['events'].pop(0))
    def test_reordered_events_rejected(self):self.reject(lambda x:x['events'].reverse())
    def test_duplicate_event_rejected(self):self.reject(lambda x:x['events'].append(copy.deepcopy(x['events'][0])))
    def test_duplicate_event_with_new_sequence_rejected(self):
        event=copy.deepcopy(self.exchange['events'][0]);event.update(sequence=2,expectedRevision=2,fromTimeSnapshot=2,toTimeSnapshot=3)
        self.exchange['events'].append(event);self.exchange['eventCount']=3
        with self.assertRaises(ContractError):decode_exchange(self.exchange,self.dictionary)
    def test_object_identity_change_rejected(self):
        self.reject(lambda x:x['events'][0]['changes'][0]['replace'].update({'/objectId':'duplicate'}))
    def test_second_truth_in_initial_rejected(self):self.reject(lambda x:x['initial'].update(units={'distance':'cm'}))
    def test_ambiguous_overlap_rejected(self):
        self.reject(lambda x:x['events'][0]['changes'][0]['replace'].update({'/state':{'mode':'moving','shape':'intact'}}))
    def test_unknown_delta_field_rejected(self):
        self.reject(lambda x:x['events'][0]['changes'][0]['replace'].update({'/state/other':1}))
    def test_input_files_unchanged_after_success(self):
        a,b=canonical(self.exchange),canonical(self.dictionary)
        decode_exchange(self.exchange,self.dictionary)
        self.assertEqual(canonical(self.exchange),a);self.assertEqual(canonical(self.dictionary),b)

    def test_missing_final_event_rejected(self):self.reject(lambda x:x['events'].pop())
    def test_tampered_delta_detected_by_final_checksum(self):
        self.reject(lambda x:x['events'][1]['changes'][0]['replace'].update({'/localPose/position':[999,0,0]}))
    def test_wrong_final_revision(self):self.reject(lambda x:x.update(finalRevision=99))

if __name__=='__main__':unittest.main()
