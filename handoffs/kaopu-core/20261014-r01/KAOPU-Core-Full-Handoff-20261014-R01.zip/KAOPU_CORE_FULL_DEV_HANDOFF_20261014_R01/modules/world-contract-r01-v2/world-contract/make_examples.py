import copy,json
from pathlib import Path
P=Path(__file__).parent/'examples'
source={'basis':'authored','source':'仅用于合同验证的架空样例，不代表实测车站或列车'}
def rec(oid,tid,parent,pos,state):
 return {'objectId':oid,'typeId':tid,'parentId':parent,'localPose':{'position':pos,'rotation':[0,0,0]},'state':state,'provenance':{'localPose':copy.deepcopy(source),'state':copy.deepcopy(source)}}
world={'schemaVersion':'1.0','worldId':'kaopu.contract.example','revision':0,'timeSnapshot':0,'tickSeconds':0.1,'seed':42,'generator':{'id':'explicit-event-example','version':'1.0'},'units':{'distance':'m','time':'s','angle':'rad'},'coordinates':{'handedness':'right','up':'Y','rotationOrder':'intrinsic-XYZ'},'types':{
 'kaopu.station@1':{'label':'车站参考框架','stateSchema':{'type':'object','properties':{'open':{'type':'boolean'}},'required':['open'],'additionalProperties':False}},
 'kaopu.train.carriage@1':{'label':'车厢','stateSchema':{'type':'object','properties':{'mode':{'enum':['parked','moving']},'shape':{'enum':['intact','deformed']}},'required':['mode','shape'],'additionalProperties':False}}
},'objects':[rec('station','kaopu.station@1',None,[0,0,0],{'open':True}),rec('carriage','kaopu.train.carriage@1','station',[1,0,0],{'mode':'parked','shape':'intact'})],'views':[{'viewId':'main','worldId':'kaopu.contract.example','revision':0,'timeSnapshot':0,'objectRefs':['station','carriage']}],'appliedEventIds':[]}
e1={'eventId':'move-001','worldId':world['worldId'],'expectedRevision':0,'fromTimeSnapshot':0,'toTimeSnapshot':1,'preconditions':[{'objectId':'carriage','pointer':'/state/mode','equals':'parked'}],'updates':[rec('carriage','kaopu.train.carriage@1','station',[4,0,0],{'mode':'moving','shape':'intact'})]}
e2={'eventId':'reshape-002','worldId':world['worldId'],'expectedRevision':1,'fromTimeSnapshot':1,'toTimeSnapshot':2,'preconditions':[{'objectId':'carriage','pointer':'/state/shape','equals':'intact'}],'updates':[rec('carriage','kaopu.train.carriage@1','station',[5,0,0],{'mode':'moving','shape':'deformed'})]}
for name,value in [('initial.world.json',world),('events.json',[e1,e2])]:
 (P/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
