from pathlib import Path
import hashlib,json
P=Path(__file__).parent/'examples'
w=json.loads((P/'final.world.json').read_text())
e={key:w[key] for key in ['worldId','revision','timeSnapshot']}
e.update(activeSnapshot='final.world.json',sha256=hashlib.sha256((P/'final.world.json').read_bytes()).hexdigest())
(P/'WORLD_INDEX.json').write_text(json.dumps({'schemaVersion':'1.0','worlds':[e]},ensure_ascii=False,indent=2)+'\n')
