"""Versioned dictionary + lossless JSON deltas; standalone transport example."""
from __future__ import annotations
import copy
import hashlib
from validate_world import require, validate_world, apply_event, canonical, pointer_get, ContractError

DICT_FIELDS = ('schemaVersion', 'units', 'coordinates', 'types')
ROOT_FIELDS = {'typeId', 'parentId', 'localPose', 'state', 'provenance'}

def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()

def exact_keys(value, keys, label):
    require(isinstance(value, dict) and set(value) == set(keys), f'{label}: unexpected or missing fields')

def make_dictionary(world):
    validate_world(world)
    return {'dictionaryId':'kaopu.world-contract','dictionaryVersion':'1.0',
            'definitions':{k:copy.deepcopy(world[k]) for k in DICT_FIELDS}}

def differences(before, after, path=''):
    if canonical(before) == canonical(after): return {}
    if isinstance(before, dict) and isinstance(after, dict) and set(before)==set(after):
        result={}
        for key in sorted(before):
            part=key.replace('~','~0').replace('/','~1')
            result.update(differences(before[key],after[key],path+'/'+part))
        return result
    return {path:copy.deepcopy(after)}

def build_exchange(initial, events):
    dictionary=make_dictionary(initial)
    reference={k:dictionary[k] for k in ('dictionaryId','dictionaryVersion')}
    reference['sha256']=digest(dictionary)
    compact_initial=copy.deepcopy(initial)
    for key in DICT_FIELDS:del compact_initial[key]
    compact_events=[]
    current=copy.deepcopy(initial)
    for sequence,event in enumerate(events):
        next_world=apply_event(current,event)
        old={o['objectId']:o for o in current['objects']}
        changes=[]
        for update in event['updates']:
            patch=differences(old[update['objectId']],update)
            require(bool(patch), 'No-op updates are not supported by this delta example')
            changes.append({'objectId':update['objectId'],'replace':patch})
        compact_events.append({
            'sequence':sequence,'eventId':event['eventId'],
            'expectedRevision':event['expectedRevision'],
            'fromTimeSnapshot':event['fromTimeSnapshot'],'toTimeSnapshot':event['toTimeSnapshot'],
            'preconditions':copy.deepcopy(event['preconditions']),'changes':changes})
        current=next_world
    exchange={'format':'kaopu.dictionary-delta@1','worldId':initial['worldId'],
              'baseRevision':initial['revision'],'baseTimeSnapshot':initial['timeSnapshot'],
              'dictionaryRef':reference,'initial':compact_initial,'events':compact_events,
              'eventCount':len(compact_events),'finalRevision':current['revision'],
              'finalTimeSnapshot':current['timeSnapshot'],'finalStateSha256':digest(current)}
    return dictionary,exchange

def set_existing(value,pointer,replacement):
    require(pointer.startswith('/') and pointer.split('/')[1] in ROOT_FIELDS,
            f'Unapproved delta field: {pointer}')
    parts=pointer[1:].split('/')
    require(all('~' not in part.replace('~0','').replace('~1','') for part in parts),
            'Invalid JSON pointer escape')
    parts=[part.replace('~1','/').replace('~0','~') for part in parts]
    parent=value
    try:
        for part in parts[:-1]:
            if isinstance(parent,list):
                require(part.isdigit() and str(int(part))==part and int(part)<len(parent),'Invalid array delta index')
                parent=parent[int(part)]
            else:parent=parent[part]
        last=parts[-1]
        if isinstance(parent,list):
            require(last.isdigit() and str(int(last))==last and int(last)<len(parent),'Invalid array delta index')
            parent[int(last)]=copy.deepcopy(replacement)
        else:
            require(isinstance(parent,dict) and last in parent,'Delta field must already exist')
            parent[last]=copy.deepcopy(replacement)
    except (KeyError,IndexError,TypeError,ValueError) as exc:
        raise ContractError(f'Invalid delta path: {pointer}') from exc

def decode_exchange(exchange,dictionary):
    """Reject missing/changed semantics, sequence gaps and duplicates before returning state."""
    require(dictionary is not None,'Missing dictionary; never guess definitions')
    exact_keys(dictionary,('dictionaryId','dictionaryVersion','definitions'),'dictionary')
    exact_keys(dictionary['definitions'],DICT_FIELDS,'definitions')
    exact_keys(exchange,('format','worldId','baseRevision','baseTimeSnapshot','dictionaryRef','initial','events','eventCount','finalRevision','finalTimeSnapshot','finalStateSha256'),'exchange')
    require(exchange['format']=='kaopu.dictionary-delta@1','Unknown exchange format')
    reference=exchange['dictionaryRef']
    exact_keys(reference,('dictionaryId','dictionaryVersion','sha256'),'dictionaryRef')
    for key in ('dictionaryId','dictionaryVersion'):
        require(reference[key]==dictionary[key],f'Dictionary mismatch: {key}')
    require(reference['sha256']==digest(dictionary),'Dictionary bytes/meaning changed')
    require(isinstance(exchange['initial'],dict),'initial must be an object')
    require(not any(k in exchange['initial'] for k in DICT_FIELDS),'Initial snapshot must reference dictionary definitions')
    current=copy.deepcopy(exchange['initial'])
    current.update(copy.deepcopy(dictionary['definitions']))
    validate_world(current)
    require(current['worldId']==exchange['worldId'],'Initial world mismatch')
    require(current['revision']==exchange['baseRevision'],'Initial revision mismatch')
    require(current['timeSnapshot']==exchange['baseTimeSnapshot'],'Initial time mismatch')
    require(isinstance(exchange['events'],list),'events must be an ordered array')
    require(type(exchange['eventCount']) is int and len(exchange['events'])==exchange['eventCount'], 'Missing or extra events in bounded exchange')
    for sequence,delta in enumerate(exchange['events']):
        exact_keys(delta,('sequence','eventId','expectedRevision','fromTimeSnapshot','toTimeSnapshot','preconditions','changes'),'delta')
        require(type(delta['sequence']) is int and delta['sequence']==sequence,'Sequence gap, reordering or duplicate')
        require(isinstance(delta['changes'],list) and bool(delta['changes']),'changes must be nonempty')
        records={o['objectId']:o for o in current['objects']}
        updates=[];seen=set()
        for change in delta['changes']:
            exact_keys(change,('objectId','replace'),'change')
            oid=change['objectId']
            require(oid in records and oid not in seen,'Unknown or duplicate object delta')
            seen.add(oid)
            patch=change['replace']
            require(isinstance(patch,dict) and bool(patch),'replace must be a nonempty object')
            paths=sorted(patch)
            for i,path in enumerate(paths):
                require(not any(other.startswith(path+'/') for other in paths[i+1:]),'Overlapping delta fields')
            updated=copy.deepcopy(records[oid])
            for path in paths:set_existing(updated,path,patch[path])
            updates.append(updated)
        event={'eventId':delta['eventId'],'worldId':exchange['worldId'],
               'expectedRevision':delta['expectedRevision'],
               'fromTimeSnapshot':delta['fromTimeSnapshot'],'toTimeSnapshot':delta['toTimeSnapshot'],
               'preconditions':copy.deepcopy(delta['preconditions']),'updates':updates}
        current=apply_event(current,event)
    require(current['revision']==exchange['finalRevision'],'Final revision mismatch')
    require(current['timeSnapshot']==exchange['finalTimeSnapshot'],'Final time mismatch')
    require(digest(current)==exchange['finalStateSha256'],'Replayed state checksum mismatch')
    return current
