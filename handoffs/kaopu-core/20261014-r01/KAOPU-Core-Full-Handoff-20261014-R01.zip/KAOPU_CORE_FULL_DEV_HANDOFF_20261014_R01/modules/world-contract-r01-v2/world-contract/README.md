# KAOPU 唯一世界状态合同

这是与《KAOPU 共同质量与交付规范》配套的独立参考实现。它把同一世界、同一时刻、同一对象只有一个当前答案落实为文件入口、字段合同和可执行检查。没有改动或接入任何现有工作台，也不代表视觉、音乐、物理或全系统质量通过。

## 先看当前答案

本例唯一活动入口是 examples/WORLD_INDEX.json。它对每个 worldId 只允许一条活动快照引用，并锁定 revision、timeSnapshot 与快照文件的 SHA-256。旧快照可以留存，但运行端不得扫描“最大版本号”、复制位置表或自行挑一个文件作为当前状态。消费者经索引读取，发现重复入口、过期版本或字节不符就失败。

对象的完整定位键为 worldId / objectId / revision / timeSnapshot。worldId、revision、timeSnapshot 由整个快照继承，每条对象只存 objectId，避免冗余字段互相打架。相同 objectId 可存在于另一 worldId，但不得混进本世界的视图或事件。旧 revision 是历史，不与当前修订共同组成一次活动查询。

本例的 initial.world.json 是初始快照；events.json 是有序事件；final.world.json 是重放结果。目录示例只含一个世界，索引支持多个 worldId。生产接入时将不可变历史快照、事件日志、schema 与唯一活动索引分开保存，并指定一个拥有提交权的状态管理器。

## 数据如何保持唯一

- localPose 是唯一持久化位姿，父级只有一个；根对象 parentId 为 null，表示直接处于世界坐标。坐标树不能有环或缺失父级。
- 距离为 m，时间为 s，角度为 rad，右手系且 Y 轴向上。timeSnapshot 是整数 tick，实际时间为 tick × tickSeconds。
- rotation 存 rx、ry、rz，使用列向量与内禀 XYZ；localMatrix = T × Rx × Ry × Rz，worldMatrix = parentWorldMatrix × localMatrix。world_position 通过坐标树求位置，不另存第二套世界坐标。
- typeId 必须指向 types 中的字段定义，名称 label 只供人阅读。对象 state 必须通过该类型的闭合 JSON Schema。互斥状态使用单值枚举或领域 schema 约束，不能靠模糊名称或注释推断。本例 mode 只能是 parked 或 moving 的一个值。
- 视图只保存 worldId、revision、timeSnapshot 和 objectRefs。嵌入独立位置、对象状态或外部世界引用会被拒绝。渲染缓存必须随引用的修订失效；本例没有实现渲染缓存。
- 运行值与知识来源分开：localPose 和 state 分别标记 observed、inferred 或 authored，并附 source。架空样例可以运行，但不能伪称实测。本例全部是 authored，不含真实列车或车站测量。

## 事件与回退

事件必须给出 worldId、expectedRevision、起止 tick、唯一 eventId、前置条件，以及更新对象的完整记录。每个更新对象至少有一个显式前置条件；条件精确匹配，布尔值不当作数字。本例不允许重复事件、重复更新、过期修订或时间倒退。

apply_event 先校验，再在副本上一起修改，全部通过才返回新快照；任何失败都不改变原快照。更新结果与视图引用同步推进 revision。原快照保留以便回退。样例演示同一车厢先移动再变形，objectId 不变，证明“唯一状态”不禁止合法变形。

replay 使用相同初始快照、seed、算法版本和事件顺序，得到相同规范化 JSON。本例的事件已显式写出目标值，没有随机生成器；seed 保持并参加完整状态比较。这项测试证明样例事件的确定性，不证明未接入生成器、GPU 或跨平台浮点过程的确定性。生产中的随机算法必须另锁实现版本、随机数推进规则并验证重放。

## 运行

需要 Python 3.10 或以上及 requirements.txt 指定的 jsonschema。依赖已在本次环境中使用，没有为本任务安装额外软件。

验证活动入口：

    python validate_world.py --index examples/WORLD_INDEX.json --world kaopu.contract.example

验证并重放；写入新文件，保留初始快照：

    python validate_world.py examples/initial.world.json --events examples/events.json --out replay.world.json

运行全部测试：

    python -m unittest -v

Python API：validate_world、load_active_world、world_position、apply_event、replay。三份 JSON Schema 分别约束快照、事件和活动索引；跨字段、引用、树与哈希约束由 Python 校验器补充，单跑 JSON Schema 不能替代完整检查。

## 已验证与边界

2026年10月12日，本地 60 项单元测试通过，完整记录在 TEST_RESULTS.txt；样例重放到 revision 2、tick 2，仍只有两个对象。测试包括唯一入口、文件哈希、父子环、派生坐标、类型与互斥状态、视图引用、观察来源、原子失败、版本冲突、合法变形、同输入重放和重复 JSON 键。

这是进程内的最小合同示例：目前只更新已有对象，不创建、删除或跨世界迁移对象；同一个 tick 的多个改动要组成一笔事件。本例没有并发数据库、分布式锁、崩溃恢复日志或自动推进索引的实现。atomic_write 仅提供本地最终文件的原子替换，不能冒充多文件事务；活动索引模式只读。

正式接入必须适配工作台真实类型与状态机，补充领域互斥规则，并由唯一状态管理器以修订比较和事务控制推进活动索引；测试并发写入、断电恢复、回退、缓存失效和实际渲染绑定。schema 不能自行判断世界是否真实、艺术是否优秀、资产是否有许可，也不能阻止绕开该入口的旧代码。完成这些实际接入与验证后，才可把该工作台记录为已采用。

## 共识语义与紧凑交换的小实验

compact_exchange.py 在相同 JSON 语法上共享类型、单位和坐标定义，仅交换已有字段的变化。词典用 dictionaryId、dictionaryVersion 和规范化内容 SHA-256 绑定；消息同时绑定 worldId、基准修订与时间。接收方缺词典、版本或语义不符时直接拒绝，不猜测补齐。

有界事件包声明事件数量、顺序、目标修订、目标时间和最终状态哈希。丢失首条或末条、乱序、重复事件、未知字段、冲突路径与结果不一致都被拒绝；失败不改调用方原始数据。消息只提供已有对象已有字段的替换，不支持新增或删除。该例是独立交换协议验证，没有接入网络、各工作台或持续流传输。

运行完整对照：

    python benchmark_compact.py

读取外部 JSON 时使用 validate_world.load，以拒绝重复键与非法数值；decode_exchange 用传入的词典恢复并校验完整权威快照。examples/full-snapshots.min.json 与 examples/dictionary-delta.min.json 是实际比较字节，COMPACT_BENCHMARK.json 保存详细测量口径和结果。

本机、两个对象、两次事件的结果：

- 完整快照序列 5,074 字节；首次词典加差量共 2,772 字节，少 45.37%。两侧使用相同 UTF-8 JSON 紧凑分隔符，没有删必要标点。
- 纯 JSON 解析中位数为 83.308 与 48.425 微秒；均为 9 批、每批 2,000 次、预热后计时。
- 读取并校验所有完整快照为 13.688 毫秒；词典校验并逐事件重放为 18.071 毫秒。后者多做前置条件、哈希与重放，两个任务的计算工作不同。
- 最终状态一致；新增 19 项紧凑交换测试，总计 60 项通过。

这是一个本机小样本，证明可以减少重复传输且保持明确语义。没有测网络、GPU、模型 token 或费用，不能把字节下降比例写成这些成本同比下降。短消息也可能因词典头与校验开销而更大；生产场景需要自己的数据和设备测量。

## 有限预备与分层运行

RUNTIME_APPENDIX.md 是配套运行规则，涵盖多分支有限预备、镜头焦点与门窗可见域、镜外关键事件、缓存复用和失效、硬预算及停止条件。“准备十碗”是余量比喻，不是固定预加载倍数。本次仅补充规则，没有为此新增性能测试，也未实现或集成运行调度器。
