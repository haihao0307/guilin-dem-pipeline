"""Standalone contract example. No repository, web, or rendering integration."""
from __future__ import annotations
import argparse
import copy
import json
import hashlib
import math
import os
from pathlib import Path
import tempfile
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parent
WORLD_SCHEMA = json.loads((ROOT / 'world.schema.json').read_text())
EVENT_SCHEMA = json.loads((ROOT / 'event.schema.json').read_text())
INDEX_SCHEMA = json.loads((ROOT / 'world-index.schema.json').read_text())

class ContractError(ValueError):
    pass

def require(ok, message):
    if not ok:
        raise ContractError(message)

def finite(value):
    if isinstance(value, float):
        require(math.isfinite(value), 'Non-finite numeric value')
    elif isinstance(value, dict):
        for item in value.values(): finite(item)
    elif isinstance(value, list):
        for item in value: finite(item)

def schema_check(schema, value):
    finite(value)
    errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: str(e.path))
    if errors:
        error = errors[0]
        raise ContractError(f'{list(error.path)}: {error.message}')

def no_refs(value):
    if isinstance(value, dict):
        require(not any(k in value for k in ('$ref', '$dynamicRef', '$recursiveRef')),
                'State schemas must be self-contained; references are not supported')
        for v in value.values(): no_refs(v)
    elif isinstance(value, list):
        for v in value: no_refs(v)

def validate_world(world):
    schema_check(WORLD_SCHEMA, world)
    for type_id, declaration in world['types'].items():
        schema = declaration['stateSchema']
        no_refs(schema)
        Draft202012Validator.check_schema(schema)
        require(schema.get('type') == 'object' and schema.get('additionalProperties') is False,
                f'{type_id}: state schema must be an explicit closed object')
    objects = {}
    for record in world['objects']:
        oid = record['objectId']
        require(oid not in objects, f'Duplicate objectId: {oid}')
        require(record['typeId'] in world['types'], f'Undefined typeId: {record["typeId"]}')
        schema_check(world['types'][record['typeId']]['stateSchema'], record['state'])
        objects[oid] = record
    for oid in objects:
        seen = set()
        node = oid
        while node is not None:
            require(node in objects, f'Unknown parent: {node}')
            require(node not in seen, f'Coordinate tree cycle at {node}')
            seen.add(node)
            node = objects[node]['parentId']
    views = set()
    for view in world['views']:
        require(view['viewId'] not in views, f'Duplicate viewId: {view["viewId"]}')
        views.add(view['viewId'])
        for key in ('worldId', 'revision', 'timeSnapshot'):
            require(view[key] == world[key], f'Stale or foreign view {key}')
        require(len(set(view['objectRefs'])) == len(view['objectRefs']), 'Duplicate view object reference')
        require(all(oid in objects for oid in view['objectRefs']), 'View references an unknown object')
    return world

def world_position(world, object_id):
    """Derived metres, never another stored source of truth. Column-vector convention."""
    validate_world(world)
    objects = {o['objectId']: o for o in world['objects']}
    require(object_id in objects, f'Unknown object: {object_id}')
    def mul(a, b):
        return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
    def matrix(oid):
        record = objects[oid]
        x,y,z = record['localPose']['position']
        rx,ry,rz = record['localPose']['rotation']
        cx,sx,cy,sy,cz,sz = math.cos(rx),math.sin(rx),math.cos(ry),math.sin(ry),math.cos(rz),math.sin(rz)
        t=[[1,0,0,x],[0,1,0,y],[0,0,1,z],[0,0,0,1]]
        a=[[1,0,0,0],[0,cx,-sx,0],[0,sx,cx,0],[0,0,0,1]]
        b=[[cy,0,sy,0],[0,1,0,0],[-sy,0,cy,0],[0,0,0,1]]
        c=[[cz,-sz,0,0],[sz,cz,0,0],[0,0,1,0],[0,0,0,1]]
        local=mul(mul(mul(t,a),b),c)
        return local if record['parentId'] is None else mul(matrix(record['parentId']),local)
    transform=matrix(object_id)
    return [transform[i][3] for i in range(3)]

def pointer_get(value, pointer):
    try:
        for part in pointer[1:].split('/'):
            key = part.replace('~1', '/').replace('~0', '~')
            value = value[int(key)] if isinstance(value, list) else value[key]
        return value
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        raise ContractError(f'Missing precondition field: {pointer}') from exc

def apply_event(world, event):
    """Return a new valid snapshot; never mutate the caller's old snapshot."""
    validate_world(world)
    schema_check(EVENT_SCHEMA, event)
    require(event['worldId'] == world['worldId'], 'Wrong worldId')
    require(event['expectedRevision'] == world['revision'], 'Stale expectedRevision')
    require(event['fromTimeSnapshot'] == world['timeSnapshot'], 'Wrong fromTimeSnapshot')
    require(event['toTimeSnapshot'] > world['timeSnapshot'], 'Event must advance the snapshot tick')
    require(event['eventId'] not in world['appliedEventIds'], 'Duplicate eventId')
    current = {o['objectId']: o for o in world['objects']}
    ids = [o['objectId'] for o in event['updates']]
    require(len(ids) == len(set(ids)), 'Duplicate object update in transaction')
    require(all(oid in current for oid in ids), 'This example only updates existing objects')
    guarded = set()
    for condition in event['preconditions']:
        oid = condition['objectId']
        require(oid in current, f'Unknown precondition object: {oid}')
        require(canonical(pointer_get(current[oid], condition['pointer'])) == canonical(condition['equals']),
                f'Precondition failed: {oid} {condition["pointer"]}')
        guarded.add(oid)
    require(set(ids) <= guarded, 'Every updated object needs an explicit precondition')
    result = copy.deepcopy(world)
    updates = {o['objectId']: copy.deepcopy(o) for o in event['updates']}
    result['objects'] = [updates.get(o['objectId'], o) for o in result['objects']]
    result['revision'] += 1
    result['timeSnapshot'] = event['toTimeSnapshot']
    result['appliedEventIds'].append(event['eventId'])
    for view in result['views']:
        view['revision'] = result['revision']
        view['timeSnapshot'] = result['timeSnapshot']
    validate_world(result)
    return result

def replay(initial, events):
    result = copy.deepcopy(initial)
    validate_world(result)
    for event in events:
        result = apply_event(result, event)
    return result

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

def reject_duplicate_keys(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, f'Duplicate JSON key: {key}')
        value[key] = item
    return value

def load(path):
    def bad_constant(value): raise ContractError(f'Invalid JSON constant: {value}')
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=reject_duplicate_keys,
                      parse_constant=bad_constant)

def load_active_world(index_path, world_id):
    index_path = Path(index_path).resolve()
    index = load(index_path)
    schema_check(INDEX_SCHEMA, index)
    entries = {}
    for entry in index['worlds']:
        require(entry['worldId'] not in entries, f'Duplicate active worldId: {entry["worldId"]}')
        entries[entry['worldId']] = entry
    require(world_id in entries, f'No active snapshot for {world_id}')
    entry = entries[world_id]
    relative = Path(entry['activeSnapshot'])
    require(not relative.is_absolute() and '..' not in relative.parts, 'Snapshot path must stay inside the index directory')
    path = (index_path.parent / relative).resolve()
    require(path.is_relative_to(index_path.parent), 'Snapshot symlink escapes the index directory')
    require(path.is_file(), 'Active snapshot is missing')
    require(hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], 'Snapshot bytes differ from the active index')
    world = validate_world(load(path))
    for key in ('worldId', 'revision', 'timeSnapshot'):
        require(world[key] == entry[key], f'Index/snapshot mismatch: {key}')
    return world

def atomic_write(path, value):
    """Atomic final-file replacement; not a concurrent database transaction."""
    path = Path(path)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent, delete=False) as file:
        temp = Path(file.name)
        file.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
        file.flush()
        os.fsync(file.fileno())
    try:
        os.replace(temp, path)
    finally:
        if temp.exists(): temp.unlink()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot', nargs='?')
    parser.add_argument('--index')
    parser.add_argument('--world')
    parser.add_argument('--events')
    parser.add_argument('--out')
    args = parser.parse_args()
    require(bool(args.snapshot) != bool(args.index), 'Choose a snapshot or an index, not both')
    require(not args.index or bool(args.world), '--index needs --world')
    result = load_active_world(args.index, args.world) if args.index else validate_world(load(args.snapshot))
    if args.events:
        events = load(args.events)
        require(isinstance(events, list), 'Events file must be an ordered array')
        result = replay(result, events)
    if args.out:
        require(not args.index, 'Index mode is read-only; use a separate snapshot output for event replay')
        require(Path(args.out).resolve() != Path(args.snapshot).resolve(), 'Keep the initial snapshot for rollback')
        atomic_write(args.out, result)
    print(f'PASS world={result["worldId"]} revision={result["revision"]} tick={result["timeSnapshot"]} objects={len(result["objects"])}')

if __name__ == '__main__':
    main()
