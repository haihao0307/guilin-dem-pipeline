"""Local, bounded microbenchmark. Includes the first dictionary in cold wire bytes."""
import copy,json,statistics,time,platform,sys
from pathlib import Path
from validate_world import load,apply_event,canonical,validate_world
from compact_exchange import build_exchange,decode_exchange
P=Path(__file__).parent/'examples'
initial=load(P/'initial.world.json');events=load(P/'events.json')
full=[copy.deepcopy(initial)];current=initial
for event in events:
    current=apply_event(current,event);full.append(current)
dictionary,exchange=build_exchange(initial,events)
full_payload={'format':'kaopu.full-snapshots@1','snapshots':full}
compact_payload={'dictionary':dictionary,'exchange':exchange}
full_bytes=canonical(full_payload).encode('utf-8')
compact_bytes=canonical(compact_payload).encode('utf-8')
assert canonical(decode_exchange(exchange,dictionary))==canonical(full[-1])
(P/'full-snapshots.min.json').write_bytes(full_bytes)
(P/'dictionary-delta.min.json').write_bytes(compact_bytes)

def median_us(call,iterations,batches=9):
    for _ in range(20):call()
    values=[]
    for _ in range(batches):
        start=time.perf_counter_ns()
        for _ in range(iterations):call()
        values.append((time.perf_counter_ns()-start)/iterations/1000)
    return round(statistics.median(values),3)

def full_validate():
    value=json.loads(full_bytes)
    for state in value['snapshots']:validate_world(state)

def compact_validate():
    value=json.loads(compact_bytes)
    return decode_exchange(value['exchange'],value['dictionary'])

result={
 'scope':'本机小实验；2个对象、初始快照和2次事件；UTF-8未压缩JSON；两侧均用相同JSON标点与紧凑分隔符；词典首次传输已计入；不含网络协议、磁盘读取、GPU或渲染',
 'python':sys.version.split()[0], 'platform':platform.platform(),
 'full_snapshot_count':len(full),'event_count':len(events),'object_count':len(initial['objects']),
 'full_snapshot_bytes':len(full_bytes),'dictionary_plus_delta_bytes':len(compact_bytes),
 'byte_reduction_percent':round((1-len(compact_bytes)/len(full_bytes))*100,2),
 'parse_only_median_us':{
  'full':median_us(lambda:json.loads(full_bytes),2000),
  'dictionary_delta':median_us(lambda:json.loads(compact_bytes),2000),
  'measurement':'9批，每批2000次，预热20次，取批次中位数；json.loads含UTF-8解码，不含业务校验与重放'},
 'parse_and_check_median_us':{
  'full_validate_all_snapshots':median_us(full_validate,10),
  'dictionary_validate_and_replay':median_us(compact_validate,10),
  'measurement':'9批，每批10次，预热20次；两侧检查工作不同，不用该比值推断通用算力节省'},
 'same_final_state':True,
 'limitations':['只有一个小样本，无网络或GPU测量','词典delta路径额外做哈希、前置条件和逐事件重放，不能与直接读成品快照当作同一计算任务','没有删除必要JSON标点；未测模型token或成本','较短消息可能因词典头和校验开销变大']
}
Path(__file__).with_name('COMPACT_BENCHMARK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
