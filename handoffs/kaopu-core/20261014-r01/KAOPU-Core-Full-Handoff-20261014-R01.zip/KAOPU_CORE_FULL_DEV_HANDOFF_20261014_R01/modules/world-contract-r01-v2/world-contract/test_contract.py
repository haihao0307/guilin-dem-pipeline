import copy
import json
import math
from pathlib import Path
import tempfile
import shutil
import unittest
from validate_world import ContractError, validate_world, apply_event, replay, canonical, load, atomic_write, load_active_world, world_position

P=Path(__file__).parent/'examples'

class ContractTests(unittest.TestCase):
    def setUp(self):
        self.world=load(P/'initial.world.json')
        self.events=load(P/'events.json')

    def reject_world(self, mutate):
        mutate(self.world)
        with self.assertRaises((ContractError,ValueError)):validate_world(self.world)

    def test_valid_initial(self):validate_world(self.world)
    def test_duplicate_object(self):self.reject_world(lambda w:w['objects'].append(copy.deepcopy(w['objects'][1])))
    def test_missing_position(self):self.reject_world(lambda w:w['objects'][1]['localPose'].pop('position'))
    def test_missing_parent(self):self.reject_world(lambda w:w['objects'][1].update(parentId='missing'))
    def test_parent_cycle(self):self.reject_world(lambda w:w['objects'][0].update(parentId='carriage'))
    def test_wrong_unit(self):self.reject_world(lambda w:w['units'].update(distance='cm'))
    def test_undefined_type(self):self.reject_world(lambda w:w['objects'][1].update(typeId='kaopu.unknown@1'))
    def test_ambiguous_mode(self):self.reject_world(lambda w:w['objects'][1]['state'].update(mode=['parked','moving']))
    def test_undeclared_state_field(self):self.reject_world(lambda w:w['objects'][1]['state'].update(secondPosition=[99,0,0]))
    def test_unknown_provenance(self):self.reject_world(lambda w:w['objects'][1]['provenance']['state'].update(basis='unknown'))
    def test_authored_provenance_is_allowed(self):validate_world(self.world)
    def test_view_cannot_embed_second_truth(self):self.reject_world(lambda w:w['views'][0].update(position=[4,0,0]))
    def test_view_other_world(self):self.reject_world(lambda w:w['views'][0].update(worldId='another'))
    def test_view_old_revision(self):self.reject_world(lambda w:w['views'][0].update(revision=90))
    def test_view_old_tick(self):self.reject_world(lambda w:w['views'][0].update(timeSnapshot=90))
    def test_view_unknown_object(self):self.reject_world(lambda w:w['views'][0]['objectRefs'].append('missing'))
    def test_nan(self):self.reject_world(lambda w:w['objects'][1]['localPose']['position'].__setitem__(0,float('nan')))
    def test_state_schema_no_remote_reference(self):self.reject_world(lambda w:w['types']['kaopu.station@1']['stateSchema'].update({'$ref':'https://invalid.example/schema'}))
    def test_movement_is_new_unique_snapshot(self):
        old=canonical(self.world); new=apply_event(self.world,self.events[0])
        self.assertEqual(canonical(self.world),old)
        self.assertEqual(new['objects'][1]['localPose']['position'],[4,0,0])
        self.assertEqual(len(new['objects']),2)
        self.assertEqual(new['views'][0]['revision'],1)
    def test_deformation_retains_identity(self):
        new=replay(self.world,self.events)
        self.assertEqual(new['objects'][1]['objectId'],'carriage')
        self.assertEqual(new['objects'][1]['state']['shape'],'deformed')
    def test_replay_same_initial_seed_and_events(self):
        a=replay(self.world,self.events);b=replay(self.world,copy.deepcopy(self.events))
        self.assertEqual(canonical(a),canonical(b))
        self.assertEqual(a['seed'],42)
    def test_stale_revision(self):
        self.events[0]['expectedRevision']=1
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
    def test_wrong_world_event(self):
        self.events[0]['worldId']='another'
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
    def test_false_precondition(self):
        self.events[0]['preconditions'][0]['equals']='moving'
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
    def test_missing_update_precondition(self):
        self.events[0]['preconditions']=[{'objectId':'station','pointer':'/state/open','equals':True}]
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
    def test_same_tick_rejected(self):
        self.events[0]['toTimeSnapshot']=0
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
    def test_duplicate_event(self):
        self.world['appliedEventIds']=['move-001']
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
    def test_duplicate_update(self):
        self.events[0]['updates'].append(copy.deepcopy(self.events[0]['updates'][0]))
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
    def test_invalid_transaction_has_no_partial_write(self):
        old=canonical(self.world)
        self.events[0]['updates'][0]['parentId']='missing'
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
        self.assertEqual(canonical(self.world),old)
    def test_cross_world_identity_is_separate(self):
        other=copy.deepcopy(self.world);other['worldId']='other';other['views'][0]['worldId']='other'
        other['objects'][1]['localPose']['position']=[99,0,0]
        validate_world(other);validate_world(self.world)
        self.assertNotEqual(other['worldId'],self.world['worldId'])
    def test_duplicate_json_key_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.json';p.write_text('{"worldId":"A","worldId":"B"}')
            with self.assertRaises(ContractError):load(p)
    def test_atomic_output_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'out.json';atomic_write(p,replay(self.world,self.events))
            self.assertEqual(load(p)['revision'],2)

    def test_active_index_selects_one_current_revision(self):
        result=load_active_world(P/'WORLD_INDEX.json',self.world['worldId'])
        self.assertEqual(result['revision'],2)
        self.assertEqual(result['objects'][1]['localPose']['position'],[5,0,0])
    def check_bad_index(self, mutate, tamper_snapshot=False):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            shutil.copy(P/'final.world.json',root/'final.world.json')
            index=load(P/'WORLD_INDEX.json');mutate(index)
            (root/'WORLD_INDEX.json').write_text(json.dumps(index))
            if tamper_snapshot:
                with (root/'final.world.json').open('a') as f:f.write(' ')
            with self.assertRaises(ContractError):load_active_world(root/'WORLD_INDEX.json',self.world['worldId'])
    def test_duplicate_active_world(self):
        self.check_bad_index(lambda x:x['worlds'].append(copy.deepcopy(x['worlds'][0])))
    def test_active_index_stale_revision(self):
        self.check_bad_index(lambda x:x['worlds'][0].update(revision=3))
    def test_active_index_tampered_bytes(self):
        self.check_bad_index(lambda x:None,tamper_snapshot=True)
    def test_active_index_path_escape(self):
        self.check_bad_index(lambda x:x['worlds'][0].update(activeSnapshot='../final.world.json'))
    def test_multiple_updates_are_atomic(self):
        old=canonical(self.world)
        station=copy.deepcopy(self.world['objects'][0]);station['parentId']='missing'
        self.events[0]['updates'].append(station)
        self.events[0]['preconditions'].append({'objectId':'station','pointer':'/state/open','equals':True})
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])
        self.assertEqual(canonical(self.world),old)

    def test_parent_translation_is_derived_once(self):
        self.world['objects'][0]['localPose']['position']=[10,0,0]
        self.assertEqual(world_position(self.world,'carriage'),[11,0,0])
    def test_parent_rotation_is_part_of_position(self):
        self.world['objects'][0]['localPose']={'position':[10,0,0],'rotation':[0,0,math.pi/2]}
        p=world_position(self.world,'carriage')
        self.assertAlmostEqual(p[0],10);self.assertAlmostEqual(p[1],1);self.assertAlmostEqual(p[2],0)
    def test_precondition_bool_is_not_number(self):
        self.events[0]['preconditions'].append({'objectId':'station','pointer':'/state/open','equals':1})
        with self.assertRaises(ContractError):apply_event(self.world,self.events[0])

if __name__=='__main__':unittest.main()
