# 环境与依赖

## Python

最低 Python 3.10；本次测试 Python 3.12.14。

- 世界状态合同原 requirements.txt：jsonschema==4.26.0。
- `requirements-tested.txt` 锁定本次已存在环境的实际传递依赖，仅代表本次复测环境，不是声称测试了所有操作系统。
- 方法论 V1.1 与包清单验证器只需 Python 标准库。

新环境可按原 requirements.txt 或本包 requirements-tested.txt 安装。包不包含 Python 解释器、平台 wheels 或原生扩展 rpds-py 的跨平台二进制，所以不是“全新机器断网零安装”包。此轮没有安装新软件或复制未知系统库。

## JavaScript 局部交换例

本次使用 Node 24.19.0，支持 ES modules 与 JSON import attributes。局部测试不需要 npm install。

- KST1 所需 Three.js r170 已原样随包附带，固定原文件 Git blob 6bc781491ae24ffd29ee22c8f019cdb67c2c61b7；MIT LICENSE 随包。
- 字形为带 SIL OFL 1.1 许可和来源记录的有限曲线函数，未包含原字体二进制。
- 动物交换校验器本地 JS/JSON 依赖均随包，未加入浏览器动物运行器。
- 街区管理器默认 fetch 本地相邻谱；本次 CPU 测试直接传入包内谱，无网络请求。浏览器使用时应从 HTTP 服务运行，并由消费者提供真正世界状态。

## 全工作台集成才需要的外部内容

街道原完整主机测试依赖 R17 session/timetable/camera、全场景页面及 Playwright/浏览器；已移到 provenance 标明上下文，未作为本包通过项。动物真实导入预览依赖完整动物 UI、注册运行器与合法动物资产。这里保留固定源路径，不把整套工作台源码、模型或依赖装成一个重复大仓。

各 Mother 的生产资产、原始 DEM、录音、参考照片、商业素材、模型权重不属于核心协议运行依赖。需要具体项目时应根据其资产清单与许可单独接入，不能把没有取得的东西标成已打包。
