# KAOPU 核心体系完整开发交接快照

日期：2026-10-14｜快照：R01｜范围：已取得的核心规范、独立参考实现、方法论与局部交换例的完整可携带源码。

这是可以继续开发的核心资料与模块快照。它不是所有人物、服装、毛发、地形、海洋、动物和铁路工作台的全仓备份，也不是一个已经统一集成完成的万能引擎。源文件原样保留；本次只增加交接入口、索引、依赖说明、局部验证和文件清单。

## 1. 先读哪份

1. `standards/KAOPU_UNIFIED_EXPRESSION_EXECUTION_V2_1_20261013.md`：当前统一原则，正文版本 V2.1，2026-10-13。原 Library 文件名仍带 V1，以正文版本为准。
2. `STATUS.md`：哪些能运行、哪些只是规范、哪些尚未接通。
3. `standards/KAOPU_共同质量与交付规范_r01.md`：10-12共同质量与交付规范，含运行附录；同名PDF也保留。
4. `INDEX.md`：每个模块的入口、来源与职责。
5. `DEPENDENCIES.md` 与 `LICENSES_AND_SCOPE.md`：环境、依赖、权利及明确排除的范围。
6. `SOURCE_MANIFEST.json`：每份取回文件的固定仓库提交、原始路径、Git blob、SHA-256；`FILE_MANIFEST.json` 是最终交接文件清单。

## 2. 包含的可执行模块

### 唯一世界状态合同 r01，含紧凑交换与运行附录

完整解包位于 `modules/world-contract-r01-v2/world-contract/`，原 ZIP 保存在 `provenance/original-packages/`。

- Python 快照、事件、索引三份 schema 与补充语义校验器。
- 唯一活动入口、对象身份、父子变换、显式来源、版本冲突、事件原子失败和重放。
- 词典绑定与差量交换、样例、生成脚本、对照基准、60 项测试。
- `RUNTIME_APPENDIX.md` 是有限预备与分层运行规则，没有实现统一调度器。

### 工作台搭建方法论 V1.1

最新固定源码位于 `modules/workbench-methodology-v1.1/`。它来自 Humanoid-Rig-Lab-Next 的 `39cff1cbaf9f903b2cbfde628e30b80ab4d51519`，并非 guilin 的 main。2026-10-14 核查时 PR 35 仍是未合并的 Draft。

- 最新顺序为先忠实复刻、冻结基线，再拆解、掌握参数、做变量与融合。
- 完整模板、PARAMETERS、registry、lint、交付回执检查器、47 项测试。
- 10-10 原始 V1 ZIP 与解包内容保留在 `provenance/`，用于追溯，不是当前入口。
- 方法论工具只检查记录与证据，不会生成三维模型，不替人判断视觉质量。

### KST1 街道局部乐器

`examples/street-kst1/` 保存固定提交中的整个 `r18/street/`，加有界街区管理器、路线合同、Three.js r170 与许可。

其 `instrument.mjs` 可 build/update/measure/snapshot/dispose；`route-plan.mjs` 显式升级旧锚点谱为 1.1.0。未经 resolve 的 first-street 谱保持原始 R17 版本，不能直接冒充 R18 谱。

完整铁路主机、R17 会话、相机、场景、录音与浏览器入口不在本核心包中。原有依赖这些主机文件的测试与相机辅助源码保存在 `provenance/street-full-host-context/`，不是本包可直接运行的测试。新增 `verification/test_local_examples.mjs` 只核本地核心 API，未声称浏览器/GPU/视觉验收。

### 动物交换合同

`examples/animal-exchange/animal-atlas/` 包含完整 docs/contracts/examples 子目录，以及 `check-animal-package.mjs` 的实际校验源码和全部本地依赖闭包。可离线核样例身份、版本、档案、参数及拒绝反例。

完整动物仓库的 UI、资产、K4/K5 运行器和真实三维导入预览不包含在此核心交换模块。校验成功不代表动物已渲染，也不把局部允许的 GLB 扩写为全局纯函数标准。

## 3. 第一次验证

需要 Python 3.10+，jsonschema 4.26.0；本次环境为 Python 3.12.14。局部 JavaScript 示例本次使用 Node 24.19.0。依赖未偷偷安装，平台解释器及 Python 第三方包没有打进 ZIP。

在解压后的根目录执行：

    python verification/verify_package.py
    python -m unittest discover -s modules/workbench-methodology-v1.1/tests -p 'test_workbench_methodology.py' -v
    python modules/workbench-methodology-v1.1/tools/workbench_methodology.py lint
    node verification/test_local_examples.mjs

进入世界合同目录后：

    cd modules/world-contract-r01-v2/world-contract
    python -m unittest -v
    python validate_world.py --index examples/WORLD_INDEX.json --world kaopu.contract.example
    python validate_world.py examples/initial.world.json --events examples/events.json --out replay.world.json

`replay.world.json` 是新输出；运行后文件清单严格检查会显示新增文件。不要覆盖原始样例或原始测试记录来伪装快照不变。基准脚本会更新同目录结果，因此请在副本运行，或另保存新结果。

## 4. 标准之间的优先级与冲突

V2.1 的当前纯函数与谱、形材同因、程序声音要求优先。9 月冻结资产合同保留为版本/哈希/缓存与历史生产思想，不得拿它证明“烘焙网格就是当前 KAOPU 本体”。派生缓存与交付本体需要清楚区分。

World Score、TLO、Object DNA 是重要语义与草案。局部 schema 约束各自组件，不得把它们拼起来就宣布全局 schema 冻结。旧文件中的“当前”“通过”和待办只指它们原来的日期与任务，不自动成为本次验收。

## 5. 继续开发的最小路线

1. 选一个真实消费者；固定它的版本、单位、对象键、状态写入者和缓存失效合同。
2. 先把该消费者接入 WORLD_INDEX 与已有对象更新/重放，补真实类型和状态机。
3. 为谱与乐器增加有版本的解析注册表及依赖解析，未知协议显式拒绝。通用 loader 尚待实现。
4. 补活动索引事务推进、并发写冲突、崩溃恢复和实际渲染绑定，再记录该消费者已采用。
5. 导演声画调度与全程序声音分开完成可测闭环，不能因文档存在而标记已完成。

不要求重新复制各个全仓。所有新集成须保存旧版本、当前证据和回退点，测试通过与用户视觉/听感接受分开记录。
