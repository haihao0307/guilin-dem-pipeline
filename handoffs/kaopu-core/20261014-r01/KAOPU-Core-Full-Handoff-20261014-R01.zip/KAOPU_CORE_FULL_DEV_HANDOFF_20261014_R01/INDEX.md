# 核心模块索引

## 当前原则与独立实现

- `standards/KAOPU_UNIFIED_EXPRESSION_EXECUTION_V2_1_20261013.md`：统一表达与执行规范 V2.1，10-13。
- `modules/world-contract-r01-v2/world-contract/README.md`：唯一世界状态合同；同目录含所有源代码、schema、样例、60项测试与运行附录。
- `modules/workbench-methodology-v1.1/WORKBENCH_BUILD_SYSTEM.md`：工作台方法论 V1.1；源码、模板、CI、47项测试全量保存。来源：Humanoid-Rig-Lab-Next，39cff1cbaf9f903b2cbfde628e30b80ab4d51519。

## 上位与沿革规范

- `standards/public-foundation/KAOPU_PUBLIC_FOUNDATION_CHARTER_R01_ZH.md`：公共基础宪章，02aa820ea92b2daa713666e05ce6687b77f02591。
- `standards/world-knowledge-core/`：原完整 core 子目录，World Kernel、Object DNA、World Score/TLO、命名与闭环五文，f254721b7e3e23cb35b7b660fa9441dc6cef9796。
- `standards/tlo-dna-r01/`：TLO 交接原目录全部展开文本/JSON/来源锁，a4e1b79298205f37dd09b5c63cbcfbe88912e6f9。
- `standards/functional-world-score-r1/`：9-14函数世界谱全量文本、schema草案、状态与原交接清单，f94df95cd2c1349f4298123365b5c8264168a0ab。排除三个教学图片及重复ZIP，详见STATUS。
- `standards/frozen-artifact/`：冻结资产核心、完整 manifest schema、采用回执模板与合同，f94df95cd2c1349f4298123365b5c8264168a0ab。
- `standards/mother-production/`：Mother OS R2、Factory R3、Parallel Coverage R4，7ed6ce55684965026188e06436ac91525526e762。
- `standards/grammar-anchor/GRAMMAR_ANCHOR_CORRECTION_20260930_ZH.md`：原Grammar Anchor纪律，e394e54f8f17159dc69bcf65bab557b1208790b6。

## 局部协议实例

- `examples/street-kst1/kaopu-minigame-workbench/voxel-train-study/game/r18/street/instrument.manifest.json`：局部KST1 1.1.0契约与边界；相邻完整源码/谱/schema/字形许可，e394e54f8f17159dc69bcf65bab557b1208790b6。
- 同例 `game/r18/street-district.mjs`：有界空间加载，非全局导演调度器；`vendor/three.module.js` 已附依赖。
- `examples/animal-exchange/animal-atlas/docs/ANIMAL_IMPORT_STANDARD.md`：动物1.1交换合同；完整 docs/contracts/examples，校验器及本地依赖闭包。来源 fda12bf2fe0262e4d02f1b08508128d17959e0c8。
- `references/local-audio/SPATIAL_AUDIO.md`：历史局部声音接口文档，仍含采样，不代表满足最新全部程序声音目标。

## 保留的原始交付

- `provenance/original-packages/`：10-12 world-contract与10-10方法论V1原ZIP。
- `provenance/workbench-methodology-v1-original/`：V1解包原文、旧测试、旧audit；不代表本次最新结果。
- `provenance/historical-r3/`：V2.1引用的8c8635a512d6d136c202e96187f8b31d93325bd9历史R3。
- `provenance/street-full-host-context/`：原完整铁路主机测试及相机辅助源码，未取得全主机，因此不算本包可复跑的集成测试。

- `provenance/repository-project-guidance/`：最新方法论来源仓库的项目AGENTS文档惰性快照；它是用户项目的原有工程指导，不是本包自动加载的根执行指令。

## 验证与范围

- `TEST_REPORT.md`：本次执行范围。
- `verification/`：实际日志、局部验证器与包级校验器。
- `SOURCE_MANIFEST.json`：固定源身份与每文件哈希。
- `FILE_MANIFEST.json` / `SHA256SUMS.txt`：最终内容清单。
- `STATUS.md` / `DEPENDENCIES.md` / `LICENSES_AND_SCOPE.md`：实现缺口、安装需求、版权边界与排除项。

`standards/KAOPU_共同质量与交付规范_r01.md` 与同名 PDF：world-contract 配套原文，Library 版本3，10-12更新，均已纳入。
