import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import * as I from '../examples/street-kst1/kaopu-minigame-workbench/voxel-train-study/game/r18/street/instrument.mjs';
import * as R from '../examples/street-kst1/kaopu-minigame-workbench/voxel-train-study/game/r18/street/route-plan.mjs';
import {createStreetDistrict} from '../examples/street-kst1/kaopu-minigame-workbench/voxel-train-study/game/r18/street-district.mjs';
import {checkAnimalPackage} from '../examples/animal-exchange/animal-atlas/tools/check-animal-package.mjs';
const read=p=>JSON.parse(readFileSync(new URL(p,import.meta.url),'utf8'));
const base='../examples/street-kst1/kaopu-minigame-workbench/voxel-train-study/game/r18/street/';
const anchor=read(base+'first-street.score.json'),route=read(base+'route.score.json');
const plan=R.createRoutePlan(route,[{target:0},{target:700}]);
assert.equal(plan.chunks.length,37);
const resolved=R.resolveChunk(plan,plan.chunks.find(x=>x.anchor),anchor,'far');
assert.equal(resolved.instrument.version,'1.1.0');
assert.equal(I.validate(resolved).valid,true);
assert.equal(I.validate(anchor).valid,false); // Raw R17 anchor needs the explicit resolver.
const bad=structuredClone(resolved);bad.instrument.abi='UNKNOWN';assert.equal(I.validate(bad).valid,false);
const a=I.build(resolved,{timeSeconds:0}),s1=I.snapshot(a);I.update(a,1,{});const s2=I.snapshot(a);
assert.equal(s1.instrument,'kaopu.street.architecture');assert.equal(s2.time,1);
assert.ok(s1.measure.expandedTriangles>0);I.dispose(a);assert.throws(()=>I.snapshot(a));
const district=createStreetDistrict({routeScore:route,anchorScore:anchor});await district.ready;assert.equal(district.proof.ready,true);district.dispose();
const animal=read('../examples/animal-exchange/animal-atlas/examples/procedural-dog.kaopu.json');
assert.equal(checkAnimalPackage(animal).needsRealImportPreview,true);
for (const mutate of [d=>d.payload.animal.profile.health=101,d=>d.payload.score.instrument.version='other',d=>d.extensions=[]]) {
 const invalid=structuredClone(animal);mutate(invalid);assert.throws(()=>checkAnimalPackage(invalid));
}
console.log(JSON.stringify({passed:true,scope:'CPU local exchange examples only',street:{routeChunks:37,buildUpdateMeasureSnapshotDispose:true,rawAnchorRequiresResolver:true},animal:{positiveExample:true,negativeCases:3,realImportPreviewRun:false},browser:false,GPU:false,visualAcceptance:false},null,2));
