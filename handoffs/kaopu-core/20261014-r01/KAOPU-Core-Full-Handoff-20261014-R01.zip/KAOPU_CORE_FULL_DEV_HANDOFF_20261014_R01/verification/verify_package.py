"""Verify this snapshot's declared bytes; never fetch or mutate source files."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]

def main():
    manifest = json.loads((ROOT / 'FILE_MANIFEST.json').read_text(encoding='utf-8'))
    failures = []
    declared = set()
    for entry in manifest['files']:
        relative = entry['path']
        path = ROOT / relative
        declared.add(relative)
        if not path.is_file():
            failures.append('missing: ' + relative)
            continue
        data = path.read_bytes()
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            failures.append('changed: ' + relative)
    excluded = {'FILE_MANIFEST.json', 'SHA256SUMS.txt'}
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    failures += ['undeclared: ' + p for p in sorted(actual - declared - excluded)
                 if '__pycache__/' not in p and not p.endswith('.pyc')]
    source = json.loads((ROOT / 'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
    git_verified = 0
    for item in source['sources']:
        if not item.get('verified_git_blob'):
            continue
        p = ROOT / item['dest']
        if not p.is_file():
            continue
        b = p.read_bytes()
        actual_blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        if actual_blob != item['verified_git_blob']:
            failures.append('source blob changed: ' + item['dest'])
        else:
            git_verified += 1
    result = {'passed': not failures, 'files': len(declared),
              'source_git_blobs_verified': git_verified, 'failures': failures,
              'scope': 'Byte integrity only; not source authenticity, integration or quality certification.'}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return int(bool(failures))

if __name__ == '__main__':
    sys.exit(main())
