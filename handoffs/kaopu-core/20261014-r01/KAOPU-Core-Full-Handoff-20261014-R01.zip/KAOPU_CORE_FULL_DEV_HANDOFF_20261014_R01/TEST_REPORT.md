# 本次验证报告

日期：2026-10-14。环境：Linux，Python 3.12.14，Node 24.19.0，jsonschema 4.26.0。依赖均已存在；没有为本次安装新软件。

执行前用 AST/import 与文件操作检查核查了测试和被测Python源码。测试写入临时目录；重放仅输出到 verification/replay.world.json。未执行原包的CI发布、第三方安装、外部上传或浏览器部署脚本。

## 通过

1. 世界状态合同：60项单元测试，全部通过。见 verification/world-contract-tests.log。
2. 最新工作台方法论V1.1：47项单元测试，全部通过。见 verification/methodology-v1.1-tests.log。
3. 方法论lint：version 1.1.0，consistent=true；qualityCertification=false。见 verification/methodology-lint.json。
4. WORLD_INDEX活动索引：revision=2、tick=2、objects=2。原初始状态加事件重放也得到该终态；输出单独保留。
5. KST1与动物局部交换CPU检查：37块路线计划；谱解析/版本拒绝；原旧锚点必须显式resolve；几何构造、更新、测量、快照、释放；动物正例和3种反例拒绝。见 verification/local-examples-tests.json。
6. 每份下载源码与固定来源Git blob匹配；最终包清单另以SHA-256核对。

## 没有执行、不能外推

- 没有运行所有上游工作台或原完整铁路主机测试。
- 没有浏览器、GPU、手机、声音听感、视觉、物理或人工接受验收。
- 没有对所有示例域的语义/世界真实性背书。
- 没有重复原benchmark计时，以免把不同环境微基准当同一个结果。原数据仍属原交付，本次只重跑其正确性测试。
- 原V1的42项旧audit和CI结果按历史材料保留；本次最新V1.1以47项复测为准。

测试过程发现动物校验器还需要parameter-catalog.json与basic-references.json，已按原固定提交补齐并核Git blob后复跑通过。源模块无修改。

ZIP完整性与新目录解压验证由外层PACKAGING_RECEIPT记录，避免把自引用ZIP哈希写进ZIP自身。
