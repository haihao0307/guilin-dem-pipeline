# HISTORY MAP

- `workbenches/landscape-function/`：水蚀石灰岩宏观基线与 Brick 石材迁移后的可重建源码。当前 R5 的大形来源。
- `workbenches/landscape-microscope-r2/`：Macroscopic microscope 原理学习与复现。
- `workbenches/landscape-microscope-r3/`：裂隙、色彩、湿痕和苔藓扩展实验，可供表面层参考。
- R4 提交 `c8d31fc1de3b75dbd6da8877cf65d90dadfde918`：用户明确退回。不得作为地形真值或恢复基线。
- R5 提交 `039d3a7f32c73ff3ac292c5bbb18c3f6f5535b90`：当前候选，microscope 仅表面。
- R017/R018 及其他大型旧实验继续保留在 Git 历史，不重复进入本包，避免重新污染运行依赖。
