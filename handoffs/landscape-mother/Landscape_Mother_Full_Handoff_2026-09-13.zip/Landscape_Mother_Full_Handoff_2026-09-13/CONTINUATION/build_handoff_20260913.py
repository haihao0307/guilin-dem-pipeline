from pathlib import Path
import hashlib, json, shutil, zipfile
from datetime import datetime, timezone, timedelta

base = Path(__file__).resolve().parent
name = 'Landscape_Mother_Full_Handoff_2026-09-13'
out = base / 'delivery'
root = out / name
if root.exists():
    raise SystemExit('Refusing to overwrite an existing version directory')
root.mkdir(parents=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def put(rel, data):
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data if isinstance(data, bytes) else data.encode('utf-8'))
def js(rel, obj): put(rel, json.dumps(obj, ensure_ascii=False, indent=2)+'\n')

original = Path('C:/Users/Administrator/Downloads/Landscape_Mother_Current_Unique_Full_Handoff.zip')
assert sha(original.read_bytes()) == '1d38b218d920397596abae0888b383f30643871e9876b06e8e87f9415566d87f'
put('ARCHIVE/'+original.name, original.read_bytes())
with zipfile.ZipFile(original) as z:
    prefix = 'Landscape_Mother_Current_Unique_Full_Handoff/'
    old_manifest = json.loads(z.read(prefix+'PACKAGE_MANIFEST.json'))
    for item in old_manifest['files']:
        assert sha(z.read(prefix+item['path'])) == item['sha256'], item['path']
    for entry in z.namelist():
        rel = entry.removeprefix(prefix)
        if rel.startswith('SOURCE_SNAPSHOT/workbenches/') and not entry.endswith('/'):
            put('ACTIVE_SOURCE/'+rel.removeprefix('SOURCE_SNAPSHOT/'), z.read(entry))
        if '/' not in rel and (rel[:2].isdigit() or rel == 'CURRENT.json'):
            put('ORIGINAL_HANDOFF_DOCS/'+rel, z.read(entry))
master = root/'ACTIVE_SOURCE/workbenches/landscape-surface-r5/index.html'
assert sha(master.read_bytes()) == 'ac46bf029cf2a9d5ffd3dcc5a53a29990be7aedcc17aa84be27462c8e6e89ec2'
for p in base.iterdir():
    if p.is_file() and p.suffix in {'.md','.json','.py'}:
        put('CONTINUATION/'+p.name, p.read_bytes())
source_map=[]
knowledge = Path('G:/小妈/知识体系')
for rel in ['研究/跨领域接口与状态一致性.md','研究/材料身份与表面表现共同定义.md','研究/造波的六条共通方法.md','研究/TLO人机共读与知识交换.md','对象与领域映射.md','来源与本轮变更.md']:
    p=knowledge/rel
    data=p.read_bytes()
    target='KNOWLEDGE_SNAPSHOT/'+rel
    put(target,data)
    source_map.append({'path':target,'source':str(p),'sha256':sha(data),'status':'reference snapshot; see continuation record for actually adopted scope'})
for filename in ['MOTHER_PUBLIC_PREVIEW_DELIVERY_RULE_2026-09-08.md','MOTHER_OBJECT_DEFINITION_RULE_2026-09-09.md','MOTHER_HANDOFF_TEMPLATE.md']:
    p=Path('G:/小妈')/filename
    put('RULES/'+filename,p.read_bytes())
put('RULES/DEM_AGENTS_AT_PACKAGING.md',Path('G:/DEM/AGENTS.md').read_bytes())
js('KNOWLEDGE_SNAPSHOT/SOURCES.json',source_map)
now=datetime.now(timezone(timedelta(hours=8))).isoformat()
js('CURRENT.json',{
    'package':name,'packagedAt':now,'repository':'haihao0307/guilin-dem-pipeline',
    'branch':'handoff/landscape-mother-current-unique',
    'masterCommit':'039d3a7f32c73ff3ac292c5bbb18c3f6f5535b90',
    'masterSha256':sha(master.read_bytes()),
    'masterPath':'ACTIVE_SOURCE/workbenches/landscape-surface-r5/index.html',
    'originalZipSha256':sha(original.read_bytes()),'originalManifestEntriesVerified':len(old_manifest['files']),
    'shapeApproval':'reported by original handoff; not independently re-established',
    'visualApproved':False,'truthApproved':False,'productionReady':False,
    'geometryChangedInThisTask':False,'newExperimentsRun':False,
    'publicPreviewReverifiedInThisPackagingTask':False,
    'knowledgeStatus':'conditional deductions and attributed review; not physical validation',
    'nextWork':'Continue from this package and user request; do not infer production authorization from archived next-work instructions',
})
put('00_START_HERE.md', '''# Landscape Mother 全量接续包｜2026-09-13

本包接续2026-09-12原始交接包，并加入本任务截至打包时的全部新增记录。先读本文件、CURRENT.json、CONTINUATION/LEARNING_SURFACE_EVENTS.md和RULES中的规则原件。

## 当前状态与接续边界

母版仍是039d3a7f32c73ff3ac292c5bbb18c3f6f5535b90的R5水蚀石灰岩工作台；本任务未改模型、材质或生产工具。原包记载的形体认可不能升级为地质真值、最终视觉或生产验收。visualApproved、truthApproved、productionReady继续为false。

新增工作是包完整性核验及Landscape领域学习：权威曲面与显示误差、侵蚀界面/材料速度、真实面积、土内与表面水、h/k/水路由分离、局部守恒、重复计量和退化映射边界。学习记录包含实际阅读、真实跨Mother反馈、纠错和未证实项；未训练模型、未运行物理实验、未接通跨域求解器。

## 文件安排

- ACTIVE_SOURCE：原包的完整两个工作台目录及附带脚本，字节原样复制。R5入口为workbenches/landscape-surface-r5/index.html。
- ARCHIVE：原始217955字节全量ZIP，保持完整；含旧完整SOURCE_SNAPSHOT及技能树，作为历史证据封存，不自动解压安装或恢复旧技能。真正被撤销的工具仍禁止读取/调用/恢复；历史包不是授权。
- ORIGINAL_HANDOFF_DOCS：旧入口、锁、状态、约束及待办的原样副本。其中“唯一当前”和“直接执行”是历史交接陈述，不能覆盖本包状态或用户当前请求。
- CONTINUATION：本任务全部新增领域记录、原包核验和打包脚本。
- KNOWLEDGE_SNAPSHOT：本域所引用公共知识正文的打包时副本。SOURCES.json固定内容哈希；实际已读/采用范围见领域记录，不声称全部公共历史已验证。
- RULES：对象定义、固定公网预览、交接模板及DEM规则原件副本。
- PACKAGE_MANIFEST.json与verify_package.py：包内完整性校验；清单自身不自哈希。

原始档案的81项哈希已重新核验；旧QA中的77项仅属旧报告口径。整体包不包含真实桂林DEM大数据、其他Mother全量资产或未取得的外部论文/观测原料。公共文档中其他本地路径是外部依赖，不冒充已随包携带。

## 新窗口下一步

将本包作为Landscape接续入口。先核对CURRENT与校验脚本结果，再按用户新的具体目标继续。R5主体轮廓、主洞口、峰脚、土体与落石关系保持母版锁；KAOPU偏离路线不作为继承源。清理完成前的生产/工具重建暂停仍适用，不能从资料中的待办推导解除冻结。小妈维护公共理论，各Mother保留领域职责。

待证据：新生岩面初态、实际水路由与交换、现实尺度/误差及事件状态。未知不填0，不用显示LOD或面数证明物理精度，不重复追问同一缺字段或擅自重启已结束学习窗口。原夜间/两小时调度未改变。

## 固定母版公网入口（历史入口，本次未作浏览器复验）

[R5母版039d3a7](https://raw.githack.com/haihao0307/guilin-dem-pipeline/039d3a7f32c73ff3ac292c5bbb18c3f6f5535b90/workbenches/landscape-surface-r5/index.html)

本次交付是全量交接ZIP上传，不是新的网页或三维版本发布。保留原预览，不把本包校验当作公网交互验收。

校验：在解压后的包根目录运行 python verify_package.py。不要运行历史生产脚本来验证ZIP。
''')
put('verify_package.py', '''from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent
m=json.loads((r/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
for i in m['files']:
 p=r/i['path']; assert p.is_file(),i['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==i['sha256'],i['path']
actual={p.relative_to(r).as_posix() for p in r.rglob('*') if p.is_file() and p.name!='PACKAGE_MANIFEST.json'}
assert actual=={i['path'] for i in m['files']},'Unlisted/missing files'
zpath=r/'ARCHIVE/Landscape_Mother_Current_Unique_Full_Handoff.zip'
with zipfile.ZipFile(zpath) as z:
 prefix='Landscape_Mother_Current_Unique_Full_Handoff/'
 old=json.loads(z.read(prefix+'PACKAGE_MANIFEST.json'))
 for i in old['files']:
  assert hashlib.sha256(z.read(prefix+i['path'])).hexdigest()==i['sha256'],i['path']
print(json.dumps({'ok':True,'files':len(m['files']),'originalArchiveFiles':len(old['files'])}))
''')
files=[]
for p in sorted(root.rglob('*')):
    if p.is_file(): files.append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
js('PACKAGE_MANIFEST.json',{'schema':'LANDSCAPE_HANDOFF_MANIFEST_V1','generatedAt':now,'files':files,'excludes':['PACKAGE_MANIFEST.json']})
zip_path=out/(name+'.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file(): z.write(p, name+'/'+p.relative_to(root).as_posix())
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    for i in files: assert sha(z.read(name+'/'+i['path']))==i['sha256']
digest=sha(zip_path.read_bytes())
(out/(name+'.zip.sha256')).write_text(digest+'  '+zip_path.name+'\n',encoding='utf-8')
print(json.dumps({'zip':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':digest,'manifestFiles':len(files),'originalFiles':len(old_manifest['files'])},ensure_ascii=False))
