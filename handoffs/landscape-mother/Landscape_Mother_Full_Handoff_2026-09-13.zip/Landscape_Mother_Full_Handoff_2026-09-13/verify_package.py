from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent
m=json.loads((r/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
for i in m['files']:
 p=r/i['path']; assert p.is_file(),i['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==i['sha256'],i['path']
actual={p.relative_to(r).as_posix() for p in r.rglob('*') if p.is_file() and p.name!='PACKAGE_MANIFEST.json'}
assert actual=={i['path'] for i in m['files']},'Unlisted/missing files'
zpath=r/'ARCHIVE/Landscape_Mother_Current_Unique_Full_Handoff.zip'
with zipfile.ZipFile(zpath) as z:
 prefix='Landscape_Mother_Current_Unique_Full_Handoff/'
 old=json.loads(z.read(prefix+'PACKAGE_MANIFEST.json'))
 for i in old['files']:
  assert hashlib.sha256(z.read(prefix+i['path'])).hexdigest()==i['sha256'],i['path']
print(json.dumps({'ok':True,'files':len(m['files']),'originalArchiveFiles':len(old['files'])}))
