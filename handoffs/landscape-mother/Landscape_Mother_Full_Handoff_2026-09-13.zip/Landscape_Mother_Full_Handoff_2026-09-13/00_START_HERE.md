# Landscape Mother 全量接续包｜2026-09-13

本包接续2026-09-12原始交接包，并加入本任务截至打包时的全部新增记录。先读本文件、CURRENT.json、CONTINUATION/LEARNING_SURFACE_EVENTS.md和RULES中的规则原件。

## 当前状态与接续边界

母版仍是039d3a7f32c73ff3ac292c5bbb18c3f6f5535b90的R5水蚀石灰岩工作台；本任务未改模型、材质或生产工具。原包记载的形体认可不能升级为地质真值、最终视觉或生产验收。visualApproved、truthApproved、productionReady继续为false。

新增工作是包完整性核验及Landscape领域学习：权威曲面与显示误差、侵蚀界面/材料速度、真实面积、土内与表面水、h/k/水路由分离、局部守恒、重复计量和退化映射边界。学习记录包含实际阅读、真实跨Mother反馈、纠错和未证实项；未训练模型、未运行物理实验、未接通跨域求解器。

## 文件安排

- ACTIVE_SOURCE：原包的完整两个工作台目录及附带脚本，字节原样复制。R5入口为workbenches/landscape-surface-r5/index.html。
- ARCHIVE：原始217955字节全量ZIP，保持完整；含旧完整SOURCE_SNAPSHOT及技能树，作为历史证据封存，不自动解压安装或恢复旧技能。真正被撤销的工具仍禁止读取/调用/恢复；历史包不是授权。
- ORIGINAL_HANDOFF_DOCS：旧入口、锁、状态、约束及待办的原样副本。其中“唯一当前”和“直接执行”是历史交接陈述，不能覆盖本包状态或用户当前请求。
- CONTINUATION：本任务全部新增领域记录、原包核验和打包脚本。
- KNOWLEDGE_SNAPSHOT：本域所引用公共知识正文的打包时副本。SOURCES.json固定内容哈希；实际已读/采用范围见领域记录，不声称全部公共历史已验证。
- RULES：对象定义、固定公网预览、交接模板及DEM规则原件副本。
- PACKAGE_MANIFEST.json与verify_package.py：包内完整性校验；清单自身不自哈希。

原始档案的81项哈希已重新核验；旧QA中的77项仅属旧报告口径。整体包不包含真实桂林DEM大数据、其他Mother全量资产或未取得的外部论文/观测原料。公共文档中其他本地路径是外部依赖，不冒充已随包携带。

## 新窗口下一步

将本包作为Landscape接续入口。先核对CURRENT与校验脚本结果，再按用户新的具体目标继续。R5主体轮廓、主洞口、峰脚、土体与落石关系保持母版锁；KAOPU偏离路线不作为继承源。清理完成前的生产/工具重建暂停仍适用，不能从资料中的待办推导解除冻结。小妈维护公共理论，各Mother保留领域职责。

待证据：新生岩面初态、实际水路由与交换、现实尺度/误差及事件状态。未知不填0，不用显示LOD或面数证明物理精度，不重复追问同一缺字段或擅自重启已结束学习窗口。原夜间/两小时调度未改变。

## 固定母版公网入口（历史入口，本次未作浏览器复验）

[R5母版039d3a7](https://raw.githack.com/haihao0307/guilin-dem-pipeline/039d3a7f32c73ff3ac292c5bbb18c3f6f5535b90/workbenches/landscape-surface-r5/index.html)

本次交付是全量交接ZIP上传，不是新的网页或三维版本发布。保留原预览，不把本包校验当作公网交互验收。

校验：在解压后的包根目录运行 python verify_package.py。不要运行历史生产脚本来验证ZIP。
