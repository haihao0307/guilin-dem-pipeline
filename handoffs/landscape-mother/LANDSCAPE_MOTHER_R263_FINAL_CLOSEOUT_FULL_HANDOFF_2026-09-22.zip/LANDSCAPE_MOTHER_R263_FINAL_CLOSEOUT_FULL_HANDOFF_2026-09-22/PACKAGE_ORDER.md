# Landscape Mother R2.6.3 最终封版全量包

输出：`LANDSCAPE_MOTHER_R263_FINAL_CLOSEOUT_FULL_HANDOFF_2026-09-22.zip`

包含固定一按入口、最终关闭记录、模块保留合同、R2.5.1—R2.6.3 源链、对应工作流、原始 R2.6.3 恢复包、manifest 与 SHA-256 清单。M1、M1.1、M1.2 和 R2.6.4 不得进入活动基线。
