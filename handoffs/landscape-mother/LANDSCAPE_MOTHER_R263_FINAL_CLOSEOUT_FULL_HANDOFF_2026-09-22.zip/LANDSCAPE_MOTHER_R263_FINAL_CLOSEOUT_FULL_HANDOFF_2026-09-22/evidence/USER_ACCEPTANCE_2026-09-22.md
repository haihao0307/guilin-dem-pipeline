# 用户验收记录｜2026-09-22

用户确认回退后的固定在线入口现在正常，并要求重新打全量包、推送 GitHub、关闭当前生产线，后续在其他工作区调用和修改，同时保留 Landscape 模块。

固定入口：`https://raw.githack.com/haihao0307/guilin-dem-pipeline/14fa478ff4545c2c58656bf57ba5326c03492a33/workbenches/landscape-karst-dem-field-r2-6-3-production/index.html`
