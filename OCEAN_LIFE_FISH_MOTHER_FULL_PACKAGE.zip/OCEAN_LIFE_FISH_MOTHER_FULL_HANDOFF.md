# Ocean Life Mother / Fish Mother 全量单文件交接包

**日期：2026-09-19**  
**仓库：`haihao0307/guilin-dem-pipeline`**  
**干净基线：R02，提交 `d7c39469c6158dbd5f6e36f6d275608bd73d816a`**  
**本文件是唯一交接入口。**

本文件把用户过去交代的 Ocean Life Mother / Fish Mother 知识、边界、资料索引、执行规则和重启顺序合并在一个 Markdown 中。后续执行者只需先读这一份。

---

## 1. 最高级别执行规则

当前助手、后续助手、Codex、自动化或任何执行代理，身份都只是：

> **执行平台。**

用户是方向和视觉验收的唯一最终权威；小妈已有知识是方法边界。执行平台无权：

- 自己改变项目目标；
- 自己另起架构；
- 自己替换基线；
- 自己删除或改造 Bird、Coral、Ocean、Game Mother；
- 自己公开发布；
- 把研究候选升级为生产结果；
- 用数量、颜色或场景复杂度遮盖鱼的形体错误；
- 用讨论和规划代替实际实现；
- 假装已经获得小妈新的实时回复。

每次工作前必须依次完成：

1. 读取用户最新指令；
2. 读取本文件；
3. 读取当前接受基线；
4. 读取与任务直接有关的小妈知识；
5. 只定义一个鱼、一个主要缺陷、一个验收证据；
6. 执行；
7. 做同机位视觉检查和必要数值检查；
8. 如实报告完成、失败和未知；
9. 在改变范围、基线、Mother分工或公网发布之前停止并等待明确批准。

---

## 2. 项目目标

长期系统叫 **Ocean Life Mother**，用于 Stone Money Island / Survivor Palau。它最终可以协调：

- Fish；
- Bird；
- Coral；
- 热带岛屿植物与动物；
- 海水、潮水、天气、礁盘、通道、深海；
- 食物网；
- 玩家观察、钓鱼、生存和生态事件；
- Game Mother 接口。

但本次干净重开后：

> **当前只做 Fish Mother。**

分工固定：

- **Fish Mother：**鱼体、鱼材质、鱼动作、鱼群、鱼生态接口、鱼与水/海床/障碍关系、鱼工作台。
- **Bird：**保留 R02 的 Bird 入口和已有成果；没有单独任务就不改。
- **Coral Mother：**负责珊瑚形体、成长、材料、群落；Fish Mother 以后只接宿主、遮蔽和碰撞接口。
- **Ocean Mother：**提供水面、水体、流速、潮位、湿区、海床接口；Fish Mother 不另造假海洋。
- **Game Mother：**接收通过验收的鱼系统；Fish Mother 不自行改游戏生产分支。

---

## 3. 活动基线

活动可见基线是 **R02**。

必须保留：

- R02 工作台；
- R02 Bird 入口；
- R00/R01/R02 的必要运行依赖；
- Tuna 等已收到资料的索引。

新工作必须：

- 在新分支或新候选目录里进行；
- 不覆盖 R02；
- 不在未通过视觉验收前替换 R02；
- 不加入未经 Coral Mother 验收的珊瑚占位；
- 不改变其他 Mother。

---

## 4. “蒸馏”的正式定义

用户提供的模型、图片、网页和视频是加速学习资料。它们帮助快速看清：

- 鱼体比例；
- 头、嘴、眼、鳃、鳍；
- 颜色、鳞片、透明度、反光；
- 动作方式；
- 群体关系；
- 生态位置。

最终运行目标不依赖：

- 源 GLB 网格；
- 源贴图文件；
- 源完整骨架和蒙皮；
- 源完整关键帧；
- 把源数据换后缀或压缩后冒充自己的体系。

最终应保留：

- 自己的共享函数内核；
- 物种/变体/生命周期/状态参数；
- 来自自然观察的结构和动作规律；
- 无法由规则恢复、但确实必须保留的必要残差；
- 明确的对象身份、空间、时间、字段语义、检查点和版本；
- 明确的未知和适用范围。

必须区分五个状态：

1. 用户已经提供；
2. 当前运行能读取原文件；
3. 已经观察/解析；
4. 已经形成独立函数候选；
5. 已经通过用户视觉验收。

前四项都不能冒充第五项。

---

## 5. 鱼体函数体系

鱼体要在统一的身体坐标中表达。至少需要：

- 头到尾的纵向参数；
- 每一节宽度函数；
- 每一节高度函数；
- 中轴和局部方向；
- 左右、背腹关系；
- 头部、尾柄和鱼鳍附近的特殊变化；
- 真实不对称和必要局部修正；
- 稳定的器官附着坐标；
- 有证据时的生命周期/时间参数。

函数不是随便叠噪声。主形和解剖关系先于纹理细节。

### 必须是真结构的部位

- 头部体积；
- 上下颌；
- 口腔和开口边缘；
- 眼球、角膜、瞳孔和转动范围；
- 鳃盖和呼吸边界；
- 躯干；
- 尾柄；
- 尾鳍根部和尾鳍形状；
- 背鳍、臀鳍、胸鳍、腹鳍根部和表面；
- 鳞片或无鳞表面；
- 左右结构和真实不对称。

不允许用颜色线条代替嘴和鳃，不允许鱼鳍悬空，不允许所有鱼共享同一个未经参考约束的头部。

### 近远显示

同一条鱼、同一身份、同一状态，按观察尺度求值：

- 近处：头、嘴、眼、鳃、鳍缘、鳞片和 PBR；
- 中距：轮廓、主要鳍、主要色区和动作；
- 远处：正确过滤后的轮廓、颜色、覆盖或点状贡献。

不把高/中/低三套传统模型当作 canonical 资产；但必须承认按尺度计算和过滤仍然有成本。

---

## 6. 材质、PBR、色彩和变体

材质必须绑定在稳定的鱼体坐标中，不能在游动时滑动。

至少分别表达：

- Base Color / Albedo；
- Alpha / Transmission；
- Roughness；
- Specular / F0；
- Normal；
- 鳞片或皮肤微结构；
- 鱼鳍透明和鳍条；
- 条纹、斑点、网纹、边缘色；
- 头、腹、背、鳍等区域掩码。

使用标准 PBR 和明确颜色空间。Pantone 或现成色彩体系只能作参考，不能让含义混乱。

必须区分：

1. 不同物种；
2. 雌雄；
3. 幼体/成体；
4. 地区或个体色型；
5. 生理状态变色；
6. 环境光照变化；
7. 工程配色实验。

相似形体可以共享身体家族并使用不同外观配方，但相似照片不自动证明同种、同一拓扑或同一成长关系。

---

## 7. 生命周期

不能把成年鱼等比例缩小后称为幼鱼。

生命周期至少要研究：

- 头身比；
- 眼睛相对大小；
- 嘴和颌；
- 身体高宽；
- 尾柄和鱼鳍比例；
- 鳞片可见程度；
- 色区和花纹；
- 游速、频率、振幅；
- 食性；
- 捕食者；
- 栖息区域；
- 群游角色。

只有成年参考时，幼体保持未知。

---

## 8. 动作体系

源动画只用于观察，不是最终动作资产。

动作内核需要分开：

- 中轴弯曲；
- 振幅沿身体变化；
- 相位延迟；
- 摆尾频率；
- 尾鳍动作；
- 背鳍/臀鳍稳定；
- 胸鳍/腹鳍控制；
- 眼球转向；
- 张嘴/闭嘴；
- 鳃盖呼吸；
- 转弯；
- 加速；
- 水流中的世界输运。

动作状态至少包括：

- 稳定巡游；
- 慢速机动；
- 转弯；
- 加速；
- 逃逸；
- 追逐；
- 摄食；
- 躲藏；
- 群游；
- 避让玩家；
- 返回宿主/栖息点；
- 休息或低活动状态。

动画时长不能直接当作真实米/秒。没有尺度、相机和水流信息时，只能记录相对量。

### 水流与鱼自身游动

- 相对水体游速决定鱼自身推进和摆尾；
- 水流决定世界坐标输运；
- 逆流时鱼可以在世界中不移动，但仍在游；
- 世界位移不能直接等同于游动强度；
- 具体数值只能在物种、体长、温度、流速和行为状态与证据匹配时使用。

---

## 9. 鱼群 / BIOS

目标是局部感知，不是每条鱼计算整个世界，也不是播放一段烘焙群体动画。

未来鱼群可包含：

- 局部邻居集；
- 前方食物/路线/危险感知；
- 侧后方群体连续与警戒传播；
- 分离；
- 对齐；
- 凝聚；
- 群体边缘、内部和带头角色；
- 行为记忆；
- 捕食者、玩家、礁体、潮水和食物影响。

烘焙鱼群文件只能说明作者做了什么轨迹，不能证明自主群游、找食物或避敌逻辑已经完成。

---

## 10. 帕劳海洋生态

鱼不能随机均匀撒在场景中。

核心区域：

- 沙滩/浪打边界；
- 礁盘；
- 内礁/潟湖；
- 珊瑚斑块和遮蔽区；
- 通道；
- 外礁坡；
- 陡降和深海；
- 远洋；
- 水面层。

帕劳相关要求：

- 外礁盘保护很多内侧水域，内礁不等于持续大浪；
- 近岸、礁盘、通道、外礁和深海有明显差异；
- 外礁之外可以迅速变深；
- 潮水、时段、季节、通道和饵鱼影响大型鱼出现概率；
- Tuna 可能随饵鱼进入通道/礁区，但不是绝对；
- 饵鱼有季节与路线；
- Barracuda、GT、Shark 等会响应饵鱼，但不能写成绝对单线脚本。

目标食物网成员包括：

- 沙丁鱼/饵鱼群；
- Tuna；
- Barracuda；
- GT；
- Shark；
- Snapper（以后包括 red/black snapper）；
- 小丑鱼/海葵关系；
- 珊瑚礁观赏鱼；
- 海龟；
- Manta Ray；
- Eagle Ray；
- 其他 Ray；
- Seabird 等后续联系。

“大鱼吃小鱼”只是最低层规则。真实交互还要考虑物种、体型、生命周期、饥饿、季节、深度、潮水、遮挡、速度和栖息地。

---

## 11. 玩家、观察和 Game Mother 接口

玩家不只是捕鱼，也要和自然相处。

目标行为：

- 玩家接近，礁鱼躲开；
- 鱼不能瞬移；
- 玩家离开且安全后，鱼回到宿主/栖息点；
- 鱼始终在水里；
- 鱼不能游到沙滩下面；
- 笔记本只记录真实看见的内容；
- 未识别的鱼不能被系统自动假装识别；
- 后续连接钓鱼、背包、食物和 Game Mother。

已知 Game Mother 相关设定：

- 玩家是 1944 年迫降并漂流到帕劳的盟军飞行员；
- 通讯工具损坏；
- 可以有笔记本/笔、刀、打火机、急救包、鱼钩等合理装备；
- 角色喜欢钓鱼；
- 海上和岛上会出现漂来物；
- 90–100 天左右的低频陪伴猫事件属于 Game Mother 叙事候选，不是 Fish Mother 常驻生态。

---

## 12. 物理底线

- 鱼不穿沙；
- 鱼不穿岸；
- 鱼不穿岩石和礁体；
- 鱼不穿 Coral Mother 提供的碰撞体；
- 鱼不越出水面，除非是明确跃出动作；
- 海床显示与约束读取同一世界定义；
- 检查整个身体和鱼鳍，不只检查中心点；
- 不安全移动要拒绝，不能瞬移；
- 朝向跟随运动；
- 相机远近不能重置物理历史；
- 单位、坐标、时间、潮位基准明确；
- 未知水流不能偷填 0；
- Bird、Fish、Ocean 使用一致世界坐标和时间。

---

## 13. 视觉和质量顺序

顺序不可跳过：

1. 整体轮廓和身体比例；
2. 头、嘴、眼、鳃；
3. 鳍根、鳍面、尾柄、尾鳍；
4. 材质和色区；
5. 鳞片/皮肤、法线、粗糙度；
6. 透明鳍；
7. 动作；
8. 水体和障碍关系；
9. 鱼群和生态；
10. 增加物种和密度。

不能通过增加鱼种、颜色、珊瑚或场景复杂度隐藏前面阶段的缺陷。

---

## 14. 固定验收视角

每次可见改动必须至少保存：

- 侧面；
- 三分之四；
- 正面/头部近景；
- 顶部或底部；
- 动作关键帧或短对照。

前后版本使用同相机、同尺度、同背景、同照明。执行者必须先看截图，不能只看测试“通过”。

用户是视觉验收人。自动测试不能替代用户确认。

---

## 15. 浏览器与公开交付

用户要的是一按进入网页，不要：

- 下载 HTML；
- ZIP 解压后本地运行；
- localhost；
- ChatGPT 中转页；
- 猜测网址；
- 旧版冒充新版。

新网页公开前必须：

1. 正确提交；
2. 入口和依赖 HTTP 200；
3. 版本匹配；
4. 桌面浏览器启动；
5. 390×844 启动；
6. 无 JS/WebGL 错误；
7. 主要交互有效；
8. 真正公网；
9. 内部截图自检；
10. 用户明确允许发布。

没有用户视觉接受，不能说 production ready。

---

## 16. 全量参考资料索引


### 第一批

| ID | 文件 / 标签 | 身份 | SHA-256 | 用途与边界 |
|---|---|---|---|---|
| FISH-REF-001 | model_67a_-_largemouth_bass(1).glb / model_67a_-_largemouth_bass.glb | 大口黑鲈 | c1b964b34e80e8534b7801c496576d6a594938d217b4f763b35d04a922b3ee64 | 第一条完整形体、PBR、动作研究基准；淡水身份保留 |
| FISH-REF-002 | tuna_fish.glb | Tuna，1024纹理版 | f75f073a2999ee20c4839434d28f90565e486b50270e663f48484cca2dbae9f0 | Tuna共享内核迁移测试；与4096版为同一形体/动作来源 |
| FISH-REF-002B | tuna_fish (1)(1).glb | Tuna，4096纹理版 | 5603d4aabc9a1127856841335a86ae7aa462b6b25d1a6586e93bf644f4d47abe | 高分辨率外观观察；不是第二种鱼，也不是运行LOD |
| FISH-REF-003 | koi_fish(1).glb | 锦鲤 | 487d5062b04de9112dc67e285e6cbf2535ccf516c666131501a4e29b50d74b6e | 150个Morph目标；无骨骼不等于无动作 |
| FISH-REF-004 | model_73a_-_great_hammerhead_shark.glb | 大锤头鲨 | b24b395b66a05de28d2a5af0128d3194e6dc843ffb85e32dc1511d0b1eced178 | 特殊头部、颌、鳃和鲨类身体关系 |
| FISH-REF-005 | bream_fish__dorade_royale.glb | Bream / Dorade Royale | eada3ccfc7bace32ac223b71b9251e4184b799600e479e4764c26a311702ddf1 | 高体型与specular-glossiness材料；不能擅自改名为Snapper |
| FISH-REF-006 | guppy(1).glb | 孔雀鱼♀ | 7516c686e2d4e93e9c0c8ce64491c185482f38cd94f60d29563cf88e2d9701e0 | 透明薄鳍、多材质、多动作；源关节数量不等于原生目标 |

### 第二批

| ID | 文件 / 标签 | 身份 | SHA-256 | 用途与边界 |
|---|---|---|---|---|
| FISH-REF-007 | marine_life_fish_non-commercial.glb | Marine Life Fish | 46ce4f48619720b73bc9bc502c424ed8a1e8b7debfad4bd266e15ab6c6bdd34a | 单鱼游动、斑点与色区；来源未给可靠物种鉴定 |
| FISH-REF-008 | cc0___giant_trevally_caranx_ignobilis.glb | GT / Giant Trevally | b9448664998c04b8feaaaec18d1ba1619779e09f15ac91db9ddd86c6ee63e6a1 | 精细静态形体；无动画；unlit不是完整PBR真值 |
| REPTILE-REF-001 | alligator_-_realistic_3d_model_demo_free.glb | Alligator | 306e91d338060cc75da3cb33ae628b435f8c014d73fa380e7c70cfc8e69516b0 | 四肢动物动作参考；不自动进入帕劳生态 |
| REPTILE-REF-002 | nile_crocodile_swimming.glb | Nile Crocodile | 5ed4490255d6ab59eaddfbe5b79222425381bb41eaa1ff08746ba35374e4ee81 | 水面游动观察；不是Fish Mother原生鱼 |
| TURTLE-REF-001 | model_72b_-_juvenile_green_sea_turtle.glb | 幼体绿海龟 | 9aad64e05a0c32fa359d30604df5ddc24c390703efa40c650610dea7eacad534 | 幼体龟壳、鳍肢、眼和游动；不等于成长规律 |
| CRUSTACEAN-REF-001 | animated_crab_rigged_free.glb | 螃蟹 | ead68d7a32a5195f603febff2cc990000da412462a17d3f6ab23a8ca90b20879 | 多足关节、侧向步态、壳体材料 |
| RAY-REF-001 | model_84a_-_manta_ray_feeding.glb | Manta feeding | 75c0003f5245e72c07fab9afe9ccd90a75f273125cdbd9a09ed5cea29d7c6ba1 | 摄食状态；蒙皮和Morph并存 |
| RAY-REF-002 | model_84b_-_manta_ray_swimming.glb | Manta swimming | 57af8f6ad35aa9b09bd69714a327204b54ee27e32867a5a4082dd804114189e7 | 游动状态；与feeding共享部分基础但动作不同 |
| FISH-REF-009 | model_91_-_leopard_catshark.glb | 豹纹猫鲨 | 815ccacb6ca72d649aa7cac52fb3c93024af7e8ed3964b130326b8beb400b6b8 | 鲨类斑纹、身体动作、局部形变 |
| FISH-REF-010 | pseudotropheus_demasoni_fish.glb | Demasoni | 33c7d3312434f9e9ce11cdc0450009c137f47b8d31caf722e4116d23337ab26b | 蓝色条纹与薄鳍；淡水身份保留 |
| FISH-REF-011 | carp_fish.glb | Carp | 9aa465afb18456a5b211d91ead0af9fbc3c45960102869ce6ae41234853645bd | 鳞片、色区和游动观察 |
| SCHOOL-REF-001 | school_of_fish.glb | School Of Fish | e7b179f6faa1186f6dd623cd8b55c59bd55e952b9a20e2576335017fe32ad8d2 | Morph烘焙群体轨迹；不是自主鱼群AI |

### 第三批

| ID | 文件 / 标签 | 身份 | SHA-256 | 用途与边界 |
|---|---|---|---|---|
| FISH-REF-012 | rainbow_trout_-_redband.glb | Rainbow Trout - Redband | f81b55a8194e4461d133b43b685a8a0510ffb09c4fba420a598f94651433c260 | 成年/Young形体、材质与慢游/待机/加速动作；不是实测成长函数 |
| SCHOOL-REF-002 | waltz_of_the_sharks.glb | Waltz of the sharks | 5432689680a20c22c3ccd248baacae85dcbc80bae36229353f21fd779796b7d0 | 多对象鲨鱼场景；不是自主捕食群 |
| FISH-REF-013 | model_65a_-_longnose_gar.glb | Longnose Gar | b044963f9a08aad49803525792a68a0956c1c41a23063f649e0bc2674f2d6280 | 长吻鱼体与动作观察 |
| FISH-REF-014 | 鲨鱼018d30c9-2a16-749c-996f-30a900311e08.glb.glb | Shark source A | 84b78c8df564aa5c673ebcc411e842d1b7d28e5280985e60efbca7a9bb9c5ef0 | swimming/circling/bite；与FISH-REF-025存在共同来源线索 |
| TURTLE-REF-002 | turtle.glb | Turtle source B | 87539908b03e6dfdb6f1349ea679ff926ae2e8bafe76621130f37e13d99da80a | 另一个海龟来源；与早期幼体海龟存在部分重合线索 |
| FISH-REF-015 | blue_powder_tang.glb | Blue Powder Tang | 448599b13a1d8524b94d16703df60a6bbd5005f8aefdd4bbf6c926a559378b8c | 鲜艳色区和短动作；仅使用实际鱼体UV覆盖区域 |
| RAY-REF-003 | manta_new.glb | Manta_new | ecb42f92e60d2513ee01e4e87974e0364a013cd3cad850a7096d214449f48070 | 独立Manta来源 |
| FISH-REF-016 | chub_v2_01_baked (1).glb / chub_v2_01_baked.glb | Chub | b8858f09175b0c873b094caa59a7d3124ebf39e83441f7fc6a8dcad2b2debf1f | 两个文件字节完全相同，只保留一个身份 |
| FISH-REF-017 | dace.glb | Dace | a67f05e1153448a527b372b28247b5cb182bbe59a86b783dcde5abbd62cbdfe2 | Dace形体与动作；淡水身份保留 |
| CRUSTACEAN-REF-002 | temp_04_scaledup.glb | Crawfish-labelled source | 61fac01edcbccb3f2d2f3053b11f276c748c16a13cb512a62a451b517bc80135 | 甲壳类关节参考；泛化文件名不等于物种 |
| FISH-REF-018 | laketrout_v3_03_bakedanimation.glb | Lake Trout | 92be551753d3b340f94a9520b776b663a0c81e3bebe57ebdeaa1e52476ad7f96 | Lake Trout形体与动作 |
| FISH-REF-019 | speckleddace_v4_03a.glb | Speckled Dace | a0e8222f517c0baa28a58fecccbdf43980ed4f2b573ac0962d21facdc7d74d9b | Speckled Dace形体与动作 |
| FISH-REF-020 | redsideshiner_v2.glb | Redside Shiner | 9445229140e9427f70555afc060ce4255ee098adf326e8e93950d24359f2594b | 细长鱼体与群游形态比较 |
| FISH-REF-021 | rainbow_trout.glb | Rainbow Trout | ab3fd3fefe82438bf7e2cab4d9853a6b1d45df1aad25ac271b7815982bc7cca2 | 独立Rainbow Trout来源 |
| FISH-REF-022 | whitefish.glb | Whitefish | 1cb527c4693950df2830653da50165190dd13a148be18eca0dad9ac98bce96db | Whitefish形体与动作 |
| CRUSTACEAN-REF-003 | crayfish.glb | Crayfish | 847481ef35753c64cb1b8986978da2db9559f25e6e6f16f6a60ed83fad9a828c | Crayfish关节与壳体 |
| FISH-REF-023 | lahontan_cutthroat_trout.glb | Lahontan Cutthroat Trout | 110089741c542c1a7e5f0cdd8858eda123494f5df1a5e524d8efa40dcb733b2b | Cutthroat Trout形体与动作 |
| FISH-REF-024 | fishe.glb | Fishe | 1b104372f7247747663664959ce04fac9222ea109fc6479e58278d637e7b6146 | 通用题名来源；不能据文件名鉴定物种 |
| FISH-REF-025 | swimming_shark.glb | Swimming Shark | 2f3b5e22e5e79aa57d86c5763f2863bd8179031f758871fa1828020999d16171 | swimming/circling/bite；与FISH-REF-014存在共同来源线索 |

### 第四批

| ID | 文件 / 标签 | 身份 | SHA-256 | 用途与边界 |
|---|---|---|---|---|
| SCHOOL-REF-003 | school_of_fish2.glb | School Of Fish 2 | 01767944b8e899283276fa82f0241fbf92f43665cafb223b65ae021e373a7bd7 | 群体资料；不是自主群游控制器 |
| MARINE-MAMMAL-REF-001 | model_61a_-_bottlenose_dolphin.glb | Bottlenose Dolphin | 03fe19af9e3b60ce00c929fc9376cd8f902f29a5f08cae3f0c3905e241602f36 | 海洋哺乳类独立类别，不能当作鱼变体 |
| FISH-REF-026 | model_99a_-_whale_shark.glb | Whale Shark | a857f72f8131b278347d4e4e8a68b9172a0d8f7046399532542f859e9f73e208 | 大型鲨类形体与动作研究 |
| FISH-REF-027 | colorfull_fish.glb | Colorfull Fish | 4db79d81797050259d8dc2743ff2aa7076126e716889e8ed64528206e4a10292 | 8个源对象不等于8个物种 |
| MARINE-MAMMAL-REF-002 | dolphin.glb | Dolphin | a3e0b787721a533833ce60144b289f8ed31e14a6b95c881f7e47a5423a70e2e0 | 复杂源场景；对象数量不等于动物数量 |
| FISH-REF-028 | guppie_animated.glb | Guppie Animated | 4ff51616e58785a879fb7e00e42f5306b853506632b6938f5be6b11aea256390 | 色彩和鱼鳍动作参考；淡水身份保留 |
| FISH-REF-029 | discus_3.glb | Discus 3 | 2670fedba3771a5a08d127a45002c7cf68fa495d56605f397616865e1deab4a6 | 圆盘形身体和外观家族研究 |
---

## 17. 两张鱼类合集图与网页参考

### 鱼类合集图 1

文件：`671d1a91-fc07-4ba0-a0ae-2c2b21e6912a.png`  
尺寸：1698×1126  
SHA-256：`a3d37ccc8e1b98da475bbacae0fe65ed17c7233165127ba7229f03196c754a7b`

可观察：高体、长吻、箱形、梭形、大型鱼、条纹、斑点、网纹和大色区。  
不能直接推出：完整物种清单、真实尺寸、游速或共同拓扑。

### 鱼类合集图 2

文件：`75d9a9da-360a-4ace-8503-2929742218c4.png`  
尺寸：1882×1114  
SHA-256：`383b95d34838a86e42d60fd19eb0fdbd81db0b9cf6fb09505d4164aba74af7b0`

左侧圆盘形鱼显示“相近身体家族 + 多种外观”的研究问题。它不自动证明同种、同一拓扑或同一成长阶段。

### Fish Pack 30 – Coral Bay

`https://sketchfab.com/3d-models/fish-pack-30-coral-bay-96af1f4364644e1490834e556087ec0c`

已知公开标题：Fish Pack 30 – Coral Bay。  
管理环境直接访问曾返回 403，因此不能声称已经播放和测量网站动画，也不能绕过限制下载。

---

## 18. Palau、Stone Money Island、礁盘和自然图像

用户在项目中持续提供：

- 石灰岩 Rock Islands；
- turquoise lagoon；
- 深蓝外海；
- 礁盘和浅海；
- 外礁陡降；
- 沙滩；
- 珊瑚礁；
- 航拍通道；
- Stone Money Island 实景；
- Palau 鱼类和海底生态图；
- 鸟、植物和岛屿生命参考。

这些图用于理解：

- 宏观空间；
- 近岸和深海关系；
- 水色、透明度、尺度；
- 礁盘、通道和岛体；
- 鱼群密度和相机语言。

没有尺度/相机/时间信息时，不能把图直接当精确数值测量。

---

## 19. Coral 资料（交给 Coral Mother）

已知文件：

- `precious_red_coral_nhmw-zoo-ev-0000149.glb`
- `compact_coral_community_whitsundays_islands.glb`
- `fan_coral_cluster_low.glb`
- `rainbow_haven_reef_-_coral.glb`
- `chromaflare_reef_-_coral.glb`
- `pond_weed.glb`
- 用户给 Coral Mother 的 decorative reef Sketchfab 链接。

Fish Mother 不再制作 Coral 形体。以后只接 Coral Mother 提供的遮蔽、宿主和碰撞接口。

---

## 20. Bird 资料和边界

Bird 保留 R02 入口，不从 Fish Mother 删除。

已知 Bird 资料包括：

- Grey Heron R60/R61 流程；
- `BIRD_R60_A0R2_BIRDKEEPER_V07_BODY_PORT_FULL_PROJECT_2026-09-17(1).zip`
- Grey Heron 独立生成器/适配器/证据 Markdown；
- 斑鸠、麻雀、红嘴海鸥等 Bird 工作线参考；
- Bird 行为、栖息、飞行和岸上动作研究。

Fish Mother 不用通用鱼逻辑替代 Bird，也不在没有单独指令时改 Bird。

---

## 21. 自然知识来源

长期优先：

- NOAA；
- NOAA Fisheries；
- NOAA Ocean Exploration；
- National Geographic / Pristine Seas；
- PICRC；
- Palau 本地机构；
- 原始研究论文；
- 用户后续提供的真实鱼类视频、图片和资料。

每个自然参数要保存：

- 物种；
- 生命周期；
- 体长定义；
- 水温；
- 流速；
- 水深；
- 行为状态；
- 观察环境；
- 误差；
- 适用范围。

不能把一个黄鳍金枪鱼实验套到所有鱼；不能把水槽数据当成 Palau 野外全部状态。

---

## 22. 当前已确定、候选和未知

### 已确定方向

- KAOPU 函数/内核 Fish Mother；
- 参考资料只作加速学习；
- 最终以自然为主；
- 共享核心 + 物种/变体/状态参数；
- 真实解剖优先；
- 鱼不穿沙、岸、礁；
- R02 为活动基线；
- Bird 保留；
- Coral 分出；
- 一按打开网页，但先验收。

### 研究候选

- 具体鱼体方程；
- 具体压缩大小；
- 旧的源拟合系数；
- 局部邻居群游算法；
- 生命周期插值；
- 未验收动作和材料函数。

### 仍未完成

- 第一条高保真原生鱼；
- 原生 Tuna；
- 眼/鳃/嘴联动；
- 高质量透明鳍；
- 完整自然鱼群；
- 生命周期；
- Palau 物种和季节标定；
- 移动端性能；
- Game Mother 接入。

---

## 23. 干净重启顺序

### 阶段 1：只选一条鱼

记录：

- 目标鱼；
- 当前可读参考文件；
- SHA；
- 一个主要缺陷；
- 固定视角；
- 验收条件。

### 阶段 2：只做结构

- 中轴；
- 截面；
- 身体轮廓；
- 头；
- 嘴；
- 眼；
- 鳃；
- 鱼鳍根部；
- 尾柄；
- 尾鳍。

不扩物种，不做 Coral，不做大生态场景。

### 阶段 3：只做材质

- 色区；
- PBR；
- 鳞片/皮肤；
- 法线；
- 粗糙度；
- 透明鳍；
- 近远稳定。

### 阶段 4：只做动作

- 巡游；
- 转向；
- 加速；
- 鳍协调；
- 眼睛；
- 鳃；
- 嘴；
- 水流关系。

### 阶段 5：Tuna 迁移测试

同一接口用于 Tuna。若必须完全重写，共享核心尚未成立。

### 阶段 6：行为和生态

鱼本身通过后再加：

- 群游；
- 逃跑；
- 返回；
- 捕食；
- 栖息地；
- Game Mother 接口。

---

## 24. 下一可见版本替换 R02 的条件

必须同时满足：

- 至少一条鱼形体正确、可辨认；
- 头、嘴、眼、鳃、鳍、尾是真结构；
- 动作不机械；
- 材质不假；
- 透明鳍可信；
- 鱼不穿沙、岸和障碍；
- Bird 保留；
- 没有 Coral 占位；
- 桌面和手机公网测试通过；
- 用户认可方向。

在此之前，R02 保持活动可见基线。

---

## 25. 原始附件可用性

本单文件保存了资料身份、文件名、SHA、作用和边界，但不把所有原始 GLB/JPG/PNG 二进制再复制进包内。

必须区分：

- 用户提供过；
- 过去解析过；
- 当前运行是否挂载；
- 派生数据是否持久保存；
- 是否完成独立函数候选；
- 是否通过用户验收。

下一次需要读取具体原文件时，先核对实际文件和 SHA，不能因为当前没挂载就说用户没有提供。

---

## 26. 最短执行提醒

> 只做用户明确交代的一件事。  
> 先把一条鱼做对，再做第二条。  
> 结构先于颜色，颜色先于动作，动作先于生态。  
> 不改其他 Mother，不擅自发布。  
> 用户没有验收，就不是完成。
