# Farmland Object DNA 全量干净重启包 V0.2.0

包号：`FARMLAND_OBJECT_DNA_FULL_CLEAN_RESTART_V0.2.0_20260907`

构建日期：2026-09-07

来源仓库：`haihao0307/guilin-dem-pipeline`

来源分支：`restart/farmland-object-dna-v020-20260907`

来源提交：`c118bd7b3c7919b090e6baf6c31fb5a7a9b55705`

来源提交时间：`2026-09-07T13:52:01+08:00`

小妈协调分支：`handoff/xiaoma-mentor-v1.1-20260905`

小妈协调提交：`265f2cd4fb92d56090ab3973ba0ee14a3830fda9`

## 这是什么

本包是 Farmland Object DNA 在 V0.1 被用户否决以后形成的完整干净重启快照。它保存严格生产规则、失败登记、对象合同、跨 Mother 接口、元阳整体系统研究、机器 schema、验证器、工作单、旧失败网页负面对照、发布状态和小妈启动规则快照。

本包可以恢复研究与生产组织状态。它不表示新水田结构、3A 视觉候选或最终生产资产已经完成。

## 唯一启动顺序

1. 阅读 `source/repository-context/AGENTS.md`。
2. 阅读 `source/farmland-object-dna/RESTART_START_HERE.md`。
3. 阅读 `source/farmland-object-dna/FARMLAND_PRODUCTION_RULES.md`。
4. 阅读 `source/farmland-object-dna/V001_FAILURE_REGISTER.md`。
5. 阅读 `source/farmland-object-dna/HANDOFF.json`。
6. 阅读 `source/farmland-object-dna/PRODUCTION_RESTART_TASKS.md`。
7. 阅读 `source/farmland-object-dna/OBJECT_DNA_CONTRACT.md`。
8. 阅读 `source/farmland-object-dna/INTERFACE_CONTRACT.md`。
9. 阅读 `source/farmland-object-dna/QUALITY_GATES.json`。
10. 阅读 `source/farmland-object-dna/research/OBJECT_SOURCE_CARD_TEMPLATE.md`。
11. 阅读 `source/farmland-object-dna/research/YUANYANG_SYSTEM_RESEARCH_PLAN.md`。
12. 阅读 `coordination/docs/mother_coordination/mentor-v1.1/MOTHER_STARTUP.md`。
13. 阅读 `coordination/docs/mother_coordination/learning-r1-20260905/WORLD_CONSENSUS.md`。
14. 运行 `source/farmland-object-dna/tools/validate_farmland_dna.py` 检查候选 DNA。
15. 核对 `VALIDATION_REPORT.json`、`PACKAGE_MANIFEST.json` 和 `SHA256SUMS.txt`。

## 冻结边界

`FARMLAND_DNA_WB_V0.1.0_20260907` 只允许作为负面对照。禁止从圆管水渠、圆管田埂、假水深、孤立节点、机械格网、重复条带梯田和圆锥水稻继续开发。

当前没有可分享的新公开视觉候选。`visualAcceptance=false`，`productionReady=false`。

## 重启后的首轮工作

先建立构件来源卡、渠道和田埂截面、元阳森林到河谷的完整系统图、平坝和梯田闭合水路、水深与水量守恒，以及水稻各生育阶段的独立结构。通过以后再做内部结构真值台、3A 材质与 Microscope 微观细节。

## 包内目录

`source/farmland-object-dna/`：Farmland 当前完整源码、规则、研究、schema、验证器与失败对照。

`source/repository-context/`：根生产规则、共享合同和相关工作流。

`coordination/`：小妈启动规则、世界共识和学习制度的固定快照。

`PACKAGE_METADATA.json`：包身份与来源。

`VALIDATION_REPORT.json`：构建时验证结果。

`PACKAGE_MANIFEST.json`：文件清单、字节数和 SHA256。

`SHA256SUMS.txt`：完整载荷校验表。
